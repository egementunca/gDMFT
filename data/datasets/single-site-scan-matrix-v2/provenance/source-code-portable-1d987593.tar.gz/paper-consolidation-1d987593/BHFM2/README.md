# BHFM2 Code Guide (Current Mainline)

This folder contains the **site + bond ghost-NCS** workflow used for current BHFM2 studies.

Current scope:
- No plaquette self-consistency in active production path.
- Active modes:
1. `bonding_only`
2. `bonding_plus_antibonding`

## 1) What To Run

Cluster runbooks:
- `jobs/current/BHFM2_SCC_INSTRUCTIONS.md`
- `jobs/current/BHFM2_MG3_CLUSTER_AGENT_PROMPT.md`

Primary entry points:
- `BHFM2/runners/run_bonding_systematic.py`
- `BHFM2/runners/run_bonding_systematic_gpu.py`
- `BHFM2/runners/benchmark_bab_lanczos.py`

Example local command:
```bash
python BHFM2/runners/run_bonding_systematic.py \
  --mode bonding_only \
  --Mh 2 --Mg 3 --Mb 1 \
  --grid quick \
  --objective gateway_plus_impfill_moments
```

## 2) Folder Structure

BHFM2 is now physically organized by role:

- `core/`
  - Solver physics + ED kernels.
  - Key files: `solve_min.py`, `solve_min_gpu.py`, `ed_fast.py`, `ghost_dmft_bond.py`.
- `runners/`
  - Study runners and setup checks.
  - Key files: `run_bonding_systematic.py`, `run_bonding_systematic_gpu.py`, `check_setup.py`.
- `diagnostics/`
  - Post-processing and paper-parity diagnostics.
  - Key files: `sigma_k.py`, `plot_fermi_arcs.py`, `plot_spectral.py`.
- `reporting/`
  - CSV export and result summary generation.
  - Key files: `export_bonding_parameters.py`, `report_bonding_results.py`.

Root-level `BHFM2/*.py` wrappers were removed.
Use the explicit subfolder entry points above (`core/`, `runners/`, `diagnostics/`, `reporting/`).

## 3) Physics Mode Summary

### `bonding_only`
- Plus-channel bond ghosts/baths only.
- Baseline convergence/physics path.

### `bonding_plus_antibonding`
- Adds minus-channel bond ghosts/baths in the same two-site framework.
- Used to test extra momentum-sector structure without plaquette extension.

## 4) Closures/Objectives

Current default objective in systematic runs:
- `gateway_plus_impfill_moments`

This optimizes:
- Gateway matching blocks
- Impurity/NCS filling closure
- Moment closure

Diagnostics still report:
- Lattice filling mismatch
- Bond-kinetic mismatch

Legacy direct bond-kinetic row is only in:
- `--objective legacy_full`

## 5) GPU Lanczos Safety

`core/solve_min_gpu.py` replaces dense interacting-sector construction with a
sparse Lanczos backend for sectors of dimension `>=1024`. It retains the lowest
`BHFM2_LANCZOS_K` states per truncated sector (`250` by default) and requires a
conservative omitted Boltzmann-weight bound below `BHFM2_THERMAL_TAIL_TOL`
(`1e-10` by default).

If a run raises `ThermalTruncationError`, do not use its partial output as a
physical result. Increase `BHFM2_LANCZOS_K` and validate observables against a
larger retained-state run before continuing. The default `k=250` is guarded
experimental infrastructure, not an already validated production setting.

For `Mh=2, Mg=3`, `bonding_plus_antibonding`, benchmark the largest sector on
H200 before submitting optimizer scans:

```bash
qsub jobs/current/bhfm2_bab_lanczos_benchmark_h200.sh
```

The benchmark runs a retained-state ladder (`k=250,500,1000,2000`) and exports
timings, thermal-tail bounds, and retained-sector observables under
`results/bhfm2_lanczos_benchmark/`. It is a solver feasibility measurement, not
a converged DMFT result. Cached sparse topology avoids rebuilding
coefficient-independent fermionic transitions during repeated assemblies.

After the initial low-temperature benchmark, test the harder finite-temperature
regime:

```bash
qsub jobs/current/bhfm2_bab_lanczos_temperature_ladder_h200.sh
```

This evaluates `T=0.05,0.1,0.2,0.3` from each retained spectrum, avoiding
duplicate eigensolves for a Hamiltonian that is unchanged by temperature.

## 6) Output Hygiene

Do not store generated artifacts in `BHFM2/`.

Use:
- `results/bhfm2_bonding/...` for run PKLs, tables, figures
- `results/reports/...` for narrative/report documents
- `logs/...` for cluster output

## 7) File Ownership Map

For a one-line classification of every maintained file:
- `BHFM2/FILE_MAP.md`
