#!/usr/bin/env python3
"""GPU-accelerated patches for solve_min.py and run_bonding_systematic.py.

Two acceleration paths:
  1. lat_obs: vectorized batched np.linalg.eigh over all k-points (CPU).
  2. eigh:   CuPy GPU dispatch for large ED sectors in imp2_obs.
"""
from __future__ import annotations

import os
import sys

import numpy as np
from numpy.linalg import eigh as _np_eigh

if __package__ in {None, ""}:
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

_gpu_active = False
cp = None
_GPU_DIM_THRESHOLD = 1024
_LANCZOS_K = int(os.environ.get("BHFM2_LANCZOS_K", "250"))
_THERMAL_TAIL_TOL = float(os.environ.get("BHFM2_THERMAL_TAIL_TOL", "1e-10"))
# Lanczos is only safe (and only cheaper) when k << dim: eigsh builds ~2k+1
# Krylov vectors, and as that approaches dim it stops converging (the smoke
# test documents 83% failing vs 3% converging). Use Lanczos only when
# dim > factor*k; otherwise solve the sector exactly.
_LANCZOS_MIN_DIM_FACTOR = int(os.environ.get("BHFM2_LANCZOS_MIN_DIM_FACTOR", "8"))
# If eigsh fails to converge anyway, fall back to dense-exact up to this dim.
_DENSE_FALLBACK_MAX = int(os.environ.get("BHFM2_DENSE_FALLBACK_MAX", "8192"))


def _lanczos_is_safe(dim, k):
    """Use Lanczos only deep in the k << dim regime."""
    return k >= 1 and k * _LANCZOS_MIN_DIM_FACTOR < dim


# Certification now happens globally (grand-canonically weighted) inside
# solve_min.imp1_obs/imp2_obs via _certify_global_tail; the class lives there.
from BHFM2.core.solve_min import ThermalTruncationError  # noqa: E402,F401


def init_gpu():
    """Attempt to enable CuPy GPU acceleration. Returns True if GPU is active."""
    global _gpu_active, cp
    try:
        import cupy as _cp

        _cp.cuda.Device(0).use()
        _a = _cp.eye(512, dtype=_cp.float64)
        _cp.linalg.eigh(_a)
        del _a
        cp = _cp
        _gpu_active = True
        dev = cp.cuda.Device(0)
        mem = dev.mem_info
        print(
            f"GPU OK: CuPy {cp.__version__}, device {dev.id}, "
            f"free={mem[0]//2**20}MB / total={mem[1]//2**20}MB"
        )
        return True
    except ImportError:
        print("GPU: CuPy not installed, using CPU only.")
        _gpu_active = False
        return False
    except Exception as e:
        print(f"GPU: init failed ({e}), using CPU only.")
        _gpu_active = False
        return False


def _sorted_eigsh(H_sparse, k):
    """Return the lowest k sparse eigenpairs on GPU, or CPU if GPU is absent."""
    if _gpu_active:
        import cupyx.scipy.sparse as csp
        import cupyx.scipy.sparse.linalg as cspsla

        H_gpu = csp.csr_matrix(
            (
                cp.asarray(H_sparse.data),
                cp.asarray(H_sparse.indices),
                cp.asarray(H_sparse.indptr),
            ),
            shape=H_sparse.shape,
        )
        ev, evec = cspsla.eigsh(H_gpu, k=k, which="SA")
        ev = cp.asnumpy(ev)
        evec = cp.asnumpy(evec)
    else:
        from scipy.sparse.linalg import eigsh

        ev, evec = eigsh(H_sparse, k=k, which="SA")
    order = np.argsort(ev)
    return np.asarray(ev[order]), np.asarray(evec[:, order])


def _dense_eigh_any(H_dense):
    """Dense symmetric eigendecomposition, on GPU when active (CPU fallback)."""
    if _gpu_active:
        try:
            e_g, v_g = cp.linalg.eigh(cp.asarray(H_dense))
            return cp.asnumpy(e_g), cp.asnumpy(v_g)
        except Exception:
            pass
    return _np_eigh(H_dense)


def _tail_bound(e, dim, beta):
    """Conservative omitted-Z bound relative to the retained sector ground state."""
    if len(e) >= dim:
        return 0.0
    gap = max(0.0, float(e[-1] - e[0]))
    return float((dim - len(e)) * np.exp(np.clip(-beta * gap, -700, 700)))


def _sector_eigh_gpu(h1, U, U_orbs, N_orb, basis, keys, vals, beta, sector_key=None):
    """Solve an ED sector exactly when small and with certified Lanczos otherwise."""
    from BHFM2.core.ed_fast import build_H_sector_fast
    from BHFM2.core.ed_sparse import build_H_sparse_cached

    dim = int(len(basis))
    if dim < _GPU_DIM_THRESHOLD:
        H = build_H_sector_fast(h1, U, U_orbs, N_orb, basis, keys, vals)
        e, ev = _np_eigh(H)
        return e, ev, dict(
            backend="dense_exact",
            dim=dim,
            n_returned=int(len(e)),
            truncated=False,
            thermal_tail_bound=0.0,
        )

    if sector_key is None:
        raise ValueError("Sparse Lanczos requires sector_key=(N_up, N_dn).")
    H_sparse, _basis, _keys, _vals = build_H_sparse_cached(
        h1, U, U_orbs, N_orb, sector_key[0], sector_key[1]
    )
    k = min(_LANCZOS_K, dim - 2)
    if not _lanczos_is_safe(dim, k):
        # k ~ dim regime: eigsh stops converging (ncv ~ 2k+1 approaches dim,
        # e.g. sector (1,3) dim=1200 at k=500 -> 83%) and offers no savings
        # over exact diagonalization at these sizes. Solve exactly.
        e, ev = _dense_eigh_any(H_sparse.toarray())
        return e, ev, dict(
            backend="dense_exact_gpu" if _gpu_active else "dense_exact",
            dim=dim,
            n_returned=int(len(e)),
            truncated=False,
            thermal_tail_bound=0.0,
            sector=tuple(sector_key),
        )

    try:
        e, ev = _sorted_eigsh(H_sparse, k)
    except Exception as err:
        # Lanczos non-convergence is parameter-dependent; never kill the
        # evaluation if an exact solve is affordable.
        if dim > _DENSE_FALLBACK_MAX:
            raise
        print(
            f"[lanczos-fallback] eigsh failed for sector={tuple(sector_key)} "
            f"dim={dim} k={k}: {err!r}; solving dense-exact instead.",
            flush=True,
        )
        e, ev = _dense_eigh_any(H_sparse.toarray())
        return e, ev, dict(
            backend="dense_exact_gpu" if _gpu_active else "dense_exact",
            dim=dim,
            n_returned=int(len(e)),
            truncated=False,
            thermal_tail_bound=0.0,
            sector=tuple(sector_key),
        )
    # No per-sector raise here: a sector's internal tail vs its OWN ground state
    # says nothing about its grand-canonical relevance. The binding check is the
    # global certificate in solve_min (_certify_global_tail), which weights each
    # sector's omitted states relative to the global E0.
    tail = _tail_bound(e, dim, beta)
    return e, ev, dict(
        backend="gpu_sparse_lanczos" if _gpu_active else "cpu_sparse_lanczos",
        dim=dim,
        n_returned=int(len(e)),
        truncated=True,
        thermal_tail_bound=tail,
        sector=tuple(sector_key),
        e_min=float(e[0]),
        e_max_retained=float(e[-1]),
    )


def lat_obs_gpu(p, mp, Mh, Mb, mode="bonding_only"):
    """Vectorized lattice k-sum using batched np.linalg.eigh (CPU)."""
    anti = (str(mode).lower() == "bonding_plus_antibonding") and int(Mb) > 0
    Nk = mp.Nk
    kvals = np.linspace(-np.pi, np.pi, Nk, endpoint=False)
    kx, ky = np.meshgrid(kvals, kvals, indexing="ij")
    eps_k = -2.0 * mp.t * (np.cos(kx) + np.cos(ky))
    ckx = np.cos(kx / 2.0)
    cky = np.cos(ky / 2.0)
    skx = np.sin(kx / 2.0)
    sky = np.sin(ky / 2.0)
    wk = 1.0 / (Nk * Nk)
    ndir = 2 if mp.use_y_bond else 1
    n_orb = 1 + Mh + Mb * ndir + (Mb * ndir if anti else 0)

    Nk2 = Nk * Nk
    eps_flat = eps_k.ravel()
    ckx_flat = ckx.ravel()
    cky_flat = cky.ravel()
    skx_flat = skx.ravel()
    sky_flat = sky.ravel()

    H_all = np.zeros((Nk2, n_orb, n_orb))
    H_all[:, 0, 0] = eps_flat + mp.eps_d + mp.Sigma_inf - p.mu

    off = 1
    for a in range(Mh):
        H_all[:, off + a, off + a] = p.eta[a]
        H_all[:, 0, off + a] = p.W[a]
        H_all[:, off + a, 0] = p.W[a]
    off += Mh

    for a in range(Mb):
        H_all[:, off + a, off + a] = p.eta_b[a]
        amp = p.B_h[a] * ckx_flat
        H_all[:, 0, off + a] = amp
        H_all[:, off + a, 0] = amp
    off += Mb

    if mp.use_y_bond:
        for a in range(Mb):
            H_all[:, off + a, off + a] = p.eta_b[a]
            amp = p.B_h[a] * cky_flat
            H_all[:, 0, off + a] = amp
            H_all[:, off + a, 0] = amp
        off += Mb

    if anti:
        eta_a = np.asarray(getattr(p, "eta_a", np.zeros(Mb)), dtype=float)
        B_ha = np.asarray(getattr(p, "B_ha", np.zeros(Mb)), dtype=float)
        for a in range(Mb):
            H_all[:, off + a, off + a] = eta_a[a]
            amp = B_ha[a] * skx_flat
            H_all[:, 0, off + a] = amp
            H_all[:, off + a, 0] = amp
        off += Mb
        if mp.use_y_bond:
            for a in range(Mb):
                H_all[:, off + a, off + a] = eta_a[a]
                amp = B_ha[a] * sky_flat
                H_all[:, 0, off + a] = amp
                H_all[:, off + a, 0] = amp

    e_all, U_all = np.linalg.eigh(H_all)
    xc = np.clip(mp.beta * e_all, -700, 700)
    f_all = 1.0 / (np.exp(xc) + 1.0)
    Uf = U_all * f_all[:, None, :]
    rho = np.einsum("kin,kjn->kij", Uf, U_all)

    spin = 2.0
    dens = float(spin * np.sum(rho[:, 0, 0]) * wk)

    hh = np.zeros(Mh)
    dh = np.zeros(Mh)
    for a in range(Mh):
        hh[a] = float(spin * np.sum(rho[:, 1 + a, 1 + a]) * wk)
        dh[a] = float(spin * np.sum(rho[:, 0, 1 + a]) * wk)

    hbp_hbp = np.zeros(Mb)
    hbp_d = np.zeros(Mb)
    hbm_hbm = np.zeros(Mb) if anti else np.zeros(0)
    hbm_d = np.zeros(Mb) if anti else np.zeros(0)
    off2 = 1 + Mh
    for a in range(Mb):
        idx_x = off2 + a
        hbp_hbp[a] += float(spin * np.sum(rho[:, idx_x, idx_x]) * wk / ndir)
        hbp_d[a] += float(spin * 2.0 * np.sum(ckx_flat * rho[:, idx_x, 0]) * wk / ndir)

    if mp.use_y_bond:
        off2_y = 1 + Mh + Mb
        for a in range(Mb):
            idx_y = off2_y + a
            hbp_hbp[a] += float(spin * np.sum(rho[:, idx_y, idx_y]) * wk / ndir)
            hbp_d[a] += float(spin * 2.0 * np.sum(cky_flat * rho[:, idx_y, 0]) * wk / ndir)

    if anti:
        offm = 1 + Mh + Mb * ndir
        for a in range(Mb):
            idx_xm = offm + a
            hbm_hbm[a] += float(spin * np.sum(rho[:, idx_xm, idx_xm]) * wk / ndir)
            hbm_d[a] += float(spin * 2.0 * np.sum(skx_flat * rho[:, idx_xm, 0]) * wk / ndir)
        if mp.use_y_bond:
            offm_y = offm + Mb
            for a in range(Mb):
                idx_ym = offm_y + a
                hbm_hbm[a] += float(spin * np.sum(rho[:, idx_ym, idx_ym]) * wk / ndir)
                hbm_d[a] += float(spin * 2.0 * np.sum(sky_flat * rho[:, idx_ym, 0]) * wk / ndir)

    bond_x = float(spin * np.sum(np.cos(kx).ravel() * rho[:, 0, 0]) * wk)

    return dict(
        hh=hh,
        dh=dh,
        hbp_hbp=hbp_hbp,
        hbp_d=hbp_d,
        hbm_hbm=hbm_hbm,
        hbm_d=hbm_d,
        dens=dens,
        bond_x=bond_x,
    )


def patch_all():
    """Patch solve_min and run_bonding_systematic with accelerated functions."""
    import BHFM2.core.solve_min as solve_min
    import BHFM2.runners.run_bonding_systematic as run_bonding_systematic

    solve_min._sector_eigh = _sector_eigh_gpu
    solve_min.lat_obs = lat_obs_gpu
    run_bonding_systematic.lat_obs = lat_obs_gpu
    solve_min.GLOBAL_THERMAL_TAIL_TOL = _THERMAL_TAIL_TOL

    status_eigh = "GPU sparse Lanczos" if _gpu_active else "CPU sparse Lanczos"
    print(
        f"Patched: interacting ED -> {status_eigh} "
        f"(threshold={_GPU_DIM_THRESHOLD}, k={_LANCZOS_K}, "
        f"lanczos_only_if_dim>{_LANCZOS_MIN_DIM_FACTOR}*k, "
        f"global_tail_tol={_THERMAL_TAIL_TOL:.1e}), "
        "lat_obs -> CPU-batched vectorized"
    )


def smoke_test():
    """Validate patched math against originals."""
    import time

    import BHFM2.core.solve_min as solve_min
    from BHFM2.core.solve_min import (
        ModelParamsMin,
        init_min,
        MODE_BONDING_ONLY,
        MODE_BONDING_PLUS_ANTIBONDING,
    )
    from BHFM2.core.solve_min import lat_obs as lat_obs_orig
    from BHFM2.core.solve_min import residual_min

    ok = True

    Mh, Mg, Mb = 2, 3, 1
    mp = ModelParamsMin(U=1.3, t=0.5, beta=10.0, Nk=16, Sigma_inf=0.65)
    p = init_min(Mh, Mg, Mb, mode=MODE_BONDING_ONLY)

    print("\n=== Test 1: lat_obs (CPU batched vs original loop) ===")
    t0 = time.time()
    for _ in range(3):
        r_orig = lat_obs_orig(p, mp, Mh, Mb, mode=MODE_BONDING_ONLY)
    t_orig = (time.time() - t0) / 3

    t0 = time.time()
    for _ in range(3):
        r_gpu = lat_obs_gpu(p, mp, Mh, Mb, mode=MODE_BONDING_ONLY)
    t_gpu = (time.time() - t0) / 3

    print(f"  Original loop: {t_orig*1000:.1f} ms")
    print(f"  Batched:       {t_gpu*1000:.1f} ms")
    print(f"  Speedup:       {t_orig/t_gpu:.1f}x")

    for key in r_orig:
        a = np.asarray(r_orig[key])
        b = np.asarray(r_gpu[key])
        if not np.allclose(a, b, atol=1e-12, rtol=1e-10):
            print(f"  MISMATCH {key}: {a} vs {b}")
            ok = False

    print("\n=== Test 2: sparse Lanczos eigenvalues vs dense ===")
    from scipy.sparse import csr_matrix

    np.random.seed(42)
    dim = 300
    A = np.random.randn(dim, dim) / np.sqrt(dim)
    A = 0.5 * (A + A.T)
    ev_ref, _ = _np_eigh(A)
    k = min(_LANCZOS_K, dim - 2)
    ev_sparse, _ = _sorted_eigsh(csr_matrix(A), k)
    ev_ok = np.allclose(ev_ref[:k], ev_sparse, atol=1e-9)
    print(f"  dim={dim:5d}: lowest {k} eigenvalues={'match' if ev_ok else 'FAIL'}")
    if not ev_ok:
        ok = False

    print("\n=== Test 3: residual_min consistency ===")
    orig_sector_eigh = solve_min._sector_eigh
    orig_lat = solve_min.lat_obs
    solve_min._sector_eigh = _sector_eigh_gpu
    solve_min.lat_obs = lat_obs_gpu

    Mh_t, Mg_t, Mb_t = 1, 1, 1
    mp_test = ModelParamsMin(U=1.3, t=0.5, beta=2.0, Nk=8, Sigma_inf=0.65)
    p_test = init_min(Mh_t, Mg_t, Mb_t, mode=MODE_BONDING_ONLY)

    t0 = time.time()
    r_patched = residual_min(p_test, mp_test, Mh_t, Mg_t, Mb_t, mode=MODE_BONDING_ONLY)
    t_patched = time.time() - t0

    solve_min._sector_eigh = orig_sector_eigh
    solve_min.lat_obs = orig_lat
    r_original = residual_min(p_test, mp_test, Mh_t, Mg_t, Mb_t, mode=MODE_BONDING_ONLY)

    diff = np.max(np.abs(r_patched - r_original))
    print(f"  M=1 residual max diff: {diff:.2e}  ({t_patched:.2f}s)")
    if diff > 1e-10:
        ok = False

    solve_min._sector_eigh = _sector_eigh_gpu
    solve_min.lat_obs = lat_obs_gpu

    print("\n=== Test 4: anti-bond residual executes under patched lat_obs ===")
    p_test_ab = init_min(Mh_t, Mg_t, Mb_t, mode=MODE_BONDING_PLUS_ANTIBONDING)
    r_ab = residual_min(
        p_test_ab,
        mp_test,
        Mh_t,
        Mg_t,
        Mb_t,
        mode=MODE_BONDING_PLUS_ANTIBONDING,
    )
    if not np.isfinite(np.linalg.norm(r_ab)):
        ok = False
        print("  anti-bond residual produced non-finite values")
    else:
        print(f"  anti-bond residual norm: {np.linalg.norm(r_ab):.3e}")

    print("\nSMOKE TEST PASSED ✓" if ok else "\nSMOKE TEST FAILED ✗")
    return ok


if __name__ == "__main__":
    init_gpu()
    smoke_test()
