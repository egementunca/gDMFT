#!/usr/bin/env python3
"""Canonical transformation between the bare (spectral) and physical gauges.

Implements the change of variables of the April-28 draft (Eqs 20-32) for the
shared d-h block H_dh (Eq 22/23). This is pure numpy/scipy: it touches no
Hamiltonian sector, no ED, no eigensolver on the many-body space. It is safe
to import and exercise on the SCC login node.

Bare gauge (what the optimizer fits today):
    Sigma(w) = Sigma_inf + sum_a |W_a|^2 / (w - eta_a)          (Eq 7)
parametrized by {eta_a, W_a}, a = 1..Mh, together with the local on-site level
    ebar = eps_d - mu + Sigma_inf.
These assemble into the (1+Mh)-dim arrowhead matrix (Eq 23, real W here):

        [ ebar  W_1   W_2  ...  W_Mh ]
        [ W_1   eta_1  0   ...   0   ]
  h_dh =[ W_2    0   eta_2 ...   0   ]
        [ ...                        ]
        [ W_Mh   0    0    ... eta_Mh]

Physical gauge (the reparametrization, Eqs 24-29):
    diagonalize  U^T h_dh U = diag(lam_0, ..., lam_Mh),  d = sum_g R_g f~_g,
    R_g = U[0, g]  (d-component of eigenvector g),  sum_g R_g^2 = 1.
The quasiparticle weight is Z = R_0^2 = 1/(1 - Sigma'(lam_0))  (Eq 29).

Parameter count is preserved (Eq 32 paragraph): the 2*Mh reals {eta_a, W_a}
map to {lam_g, R_g} (g = 0..Mh, so Mh+1 each) minus two constraints --
sum R_g^2 = 1 and sum lam_g R_g^2 = ebar -- i.e. back to 2*Mh.

Forward map:  (ebar, eta, W) -> (lam, R)  is just an eigendecomposition.
Inverse map:  (lam, R) -> (ebar, eta, W)  is the arrowhead inverse eigenvalue
problem, solved here via the resolvent function

    phi(x) = [ (x - h_dh)^{-1} ]_00 = sum_g R_g^2 / (x - lam_g)
           = 1 / ( x - ebar - sum_a W_a^2/(x - eta_a) ).

Its poles are the eigenvalues lam_g; its zeros are the ghost levels eta_a
(they interlace the lam_g, one per open interval). The couplings follow from
the residue:  W_a^2 = -1 / phi'(eta_a).
"""
from __future__ import annotations

import numpy as np
from scipy.linalg import eigh
from scipy.optimize import brentq


# --------------------------------------------------------------------------
# Forward: bare -> physical
# --------------------------------------------------------------------------
def build_h_dh(ebar: float, eta, W) -> np.ndarray:
    """Assemble the (1+Mh) arrowhead matrix h_dh (Eq 23). Real, symmetric."""
    eta = np.asarray(eta, dtype=float).ravel()
    W = np.asarray(W, dtype=float).ravel()
    if eta.shape != W.shape:
        raise ValueError(f"eta and W must match: {eta.shape} vs {W.shape}")
    Mh = eta.size
    h = np.zeros((1 + Mh, 1 + Mh), dtype=float)
    h[0, 0] = float(ebar)
    for a in range(Mh):
        h[0, 1 + a] = W[a]
        h[1 + a, 0] = W[a]
        h[1 + a, 1 + a] = eta[a]
    return h


def forward(ebar: float, eta, W):
    """(ebar, eta[Mh], W[Mh]) -> (lam[Mh+1], R[Mh+1]).

    lam ascending; R = first-row components of the eigenvectors, with a fixed
    sign convention R_g >= 0 (the overall sign of an eigenvector is arbitrary
    and the d-overlap is conventionally taken non-negative). sum R^2 == 1.
    """
    h = build_h_dh(ebar, eta, W)
    lam, U = eigh(h)                      # ascending eigenvalues, orthonormal U
    R = U[0, :].copy()
    # Fix the gauge of each eigenvector so its d-component is non-negative.
    sign = np.where(R < 0.0, -1.0, 1.0)
    R = R * sign
    return lam, R


# --------------------------------------------------------------------------
# Inverse: physical -> bare
# --------------------------------------------------------------------------
def _phi(x, lam, R2):
    return np.sum(R2 / (x - lam))


def _phi_prime(x, lam, R2):
    return -np.sum(R2 / (x - lam) ** 2)


def inverse(lam, R, *, tol: float = 1e-12):
    """(lam[Mh+1], R[Mh+1]) -> (ebar, eta[Mh], W[Mh]).

    Recovers the arrowhead matrix from its spectrum {lam_g} and the d-overlaps
    {R_g}. Requires distinct lam and all R_g != 0 (the generic, fully-coupled
    case the bounds W>0 guarantee). eta_a are the zeros of phi (one per open
    interval between consecutive lam), W_a^2 = -1/phi'(eta_a) >= 0.
    """
    lam = np.asarray(lam, dtype=float).ravel()
    R = np.asarray(R, dtype=float).ravel()
    if lam.shape != R.shape:
        raise ValueError(f"lam and R must match: {lam.shape} vs {R.shape}")
    order = np.argsort(lam)
    lam = lam[order]
    R = R[order]
    R2 = R ** 2

    if np.any(np.diff(lam) <= tol):
        raise ValueError(
            "inverse() requires distinct eigenvalues (degenerate spectrum "
            "means a decoupled ghost; handle W->0 separately)."
        )
    if np.any(R2 <= tol):
        raise ValueError(
            "inverse() requires non-zero d-overlap for every mode (R_g != 0); "
            "a vanishing R_g signals a dark/decoupled ghost."
        )

    ebar = float(np.sum(lam * R2))

    Mh = lam.size - 1
    eta = np.empty(Mh, dtype=float)
    W = np.empty(Mh, dtype=float)
    # phi has a simple pole at each lam_g with positive residue R2_g, so on each
    # open interval (lam_g, lam_{g+1}) it falls monotonically from +inf to -inf
    # and has exactly one zero -> the ghost level eta_a.
    for a in range(Mh):
        lo, hi = lam[a], lam[a + 1]
        span = hi - lo
        # Inset the bracket off the singular endpoints by a *finite* amount.
        # A relative inset (tol*span) underflows below the float64 ulp of an
        # O(1) eigenvalue and rounds the endpoint back onto the pole (-> divide
        # by zero). Use an absolute floor that stays resolvable.
        d = max(span * 1e-6, 1e-12 * (1.0 + abs(lo) + abs(hi)))
        d = min(d, 0.49 * span)
        xa = brentq(_phi, lo + d, hi - d, args=(lam, R2),
                    xtol=1e-14, rtol=1e-14, maxiter=200)
        eta[a] = xa
        W[a] = np.sqrt(-1.0 / _phi_prime(xa, lam, R2))
    return ebar, eta, W


# --------------------------------------------------------------------------
# Analytic derivative of the inverse map  (lam, R) -> (eta, W)
# --------------------------------------------------------------------------
def d_inverse(lam, R, *, tol: float = 1e-12):
    """Closed-form Jacobian of ``inverse``: d(eta, W) / d(lam, R).

    Differentiates the exact equations ``inverse`` solves, so the result
    matches a finite difference of ``inverse`` itself (not just the abstract
    transform). Pure numpy -- login-node safe.

    The ghost level eta_a is the zero of phi(x) = sum_g R2_g/(x - lam_g) in the
    open interval (lam_a, lam_{a+1}); the coupling is W_a^2 = -1/phi'(eta_a).
    Implicit differentiation of phi(eta_a)=0 gives

        d eta_a / d theta = - (d phi / d theta)|_{x=eta_a} / phi'(eta_a) ,

    and, with W_a^2 = -1/phi'(eta_a) so d(W_a^2) = W_a^4 d(phi'(eta_a)),

        d phi'(eta_a)/d theta = phi''(eta_a) d eta_a/d theta + (d phi'/d theta)| .

    The explicit partials, at x = eta_a, are
        d phi   / d R2_k = 1/(eta_a - lam_k)
        d phi   / d lam_k = R2_k/(eta_a - lam_k)^2
        d phi'  / d R2_k = -1/(eta_a - lam_k)^2
        d phi'  / d lam_k = -2 R2_k/(eta_a - lam_k)^3
    and R-columns follow from d/dR_k = 2 R_k d/dR2_k.

    Parameters
    ----------
    lam, R : arrays of length Mh+1 (any order; sorted internally like inverse).

    Returns
    -------
    deta_dlam : (Mh, Mh+1)  d eta_a / d lam_k     (columns in INPUT order)
    deta_dR   : (Mh, Mh+1)  d eta_a / d R_k
    dW_dlam   : (Mh, Mh+1)  d W_a   / d lam_k
    dW_dR     : (Mh, Mh+1)  d W_a   / d R_k
    eta, W    : the reconstructed ghost levels/couplings (sorted-interval order)

    Rows a = 0..Mh-1 are in ascending-interval order (matching ``inverse``);
    columns k are in the order the inputs were given.
    """
    lam_in = np.asarray(lam, dtype=float).ravel()
    R_in = np.asarray(R, dtype=float).ravel()
    if lam_in.shape != R_in.shape:
        raise ValueError(f"lam and R must match: {lam_in.shape} vs {R_in.shape}")
    order = np.argsort(lam_in)
    lam_s = lam_in[order]
    R_s = R_in[order]
    R2_s = R_s ** 2

    if np.any(np.diff(lam_s) <= tol):
        raise ValueError("d_inverse() requires distinct eigenvalues.")
    if np.any(R2_s <= tol):
        raise ValueError("d_inverse() requires non-zero d-overlap for every mode.")

    n = lam_s.size
    Mh = n - 1
    # Reconstruct eta, W (sorted-interval order) -- reuse inverse on sorted data.
    _, eta, W = inverse(lam_s, R_s, tol=tol)

    # Columns are computed in SORTED order, then permuted back to input order.
    deta_dlam_s = np.zeros((Mh, n))
    deta_dR2_s = np.zeros((Mh, n))
    dW2_dlam_s = np.zeros((Mh, n))
    dW2_dR2_s = np.zeros((Mh, n))

    for a in range(Mh):
        d = eta[a] - lam_s                      # (eta_a - lam_k), length n
        Wa2 = W[a] ** 2
        phi_pp = 2.0 * np.sum(R2_s / d ** 3)    # phi''(eta_a)
        # d eta_a / d theta = -(d phi/d theta)/phi'(eta_a),  phi'(eta_a) = -1/Wa2
        deta_dR2 = Wa2 * (1.0 / d)              # = -(1/d)/phi'
        deta_dlam = Wa2 * (R2_s / d ** 2)       # = -(R2/d^2)/phi'
        deta_dR2_s[a] = deta_dR2
        deta_dlam_s[a] = deta_dlam
        # d(W_a^2) = W_a^4 [ phi'' * d eta_a + explicit d phi' ]
        dW2_dR2_s[a] = Wa2 ** 2 * (phi_pp * deta_dR2 - 1.0 / d ** 2)
        dW2_dlam_s[a] = Wa2 ** 2 * (phi_pp * deta_dlam - 2.0 * R2_s / d ** 3)

    # Convert R2-columns to R-columns: d/dR_k = 2 R_k d/dR2_k.
    twoR = 2.0 * R_s
    deta_dR_s = deta_dR2_s * twoR[None, :]
    dW2_dR_s = dW2_dR2_s * twoR[None, :]
    # Convert d(W^2) rows to d(W): dW = d(W^2)/(2 W).
    inv2W = 1.0 / (2.0 * W)
    dW_dlam_s = dW2_dlam_s * inv2W[:, None]
    dW_dR_s = dW2_dR_s * inv2W[:, None]

    # Un-permute columns back to input order.
    inv_order = np.empty(n, dtype=int)
    inv_order[order] = np.arange(n)
    deta_dlam = deta_dlam_s[:, inv_order]
    deta_dR = deta_dR_s[:, inv_order]
    dW_dlam = dW_dlam_s[:, inv_order]
    dW_dR = dW_dR_s[:, inv_order]
    return deta_dlam, deta_dR, dW_dlam, dW_dR, eta, W


# --------------------------------------------------------------------------
# Diagnostics / physics helpers
# --------------------------------------------------------------------------
def sigma_prime(lam0: float, eta, W) -> float:
    """Sigma'(w) = -sum_a W_a^2/(w-eta_a)^2 evaluated at w=lam0 (Eq 29 input)."""
    eta = np.asarray(eta, dtype=float).ravel()
    W = np.asarray(W, dtype=float).ravel()
    return float(-np.sum(W ** 2 / (lam0 - eta) ** 2))


def quasiparticle_index(lam, R) -> int:
    """Index of the quasiparticle (0-mode): the eigenmode with maximal d-weight
    R_g^2 -- the pole carrying the most physical-electron character. For a
    coherent metal this is the low-energy quasiparticle; Z = R[idx]^2."""
    R = np.asarray(R, dtype=float).ravel()
    return int(np.argmax(R ** 2))


def quasiparticle_Z(lam, R):
    """Return (Z, idx) with Z = R_idx^2 for the MAX-d-weight mode.

    NOTE: this is the "most physical-electron character" mode, correct in the
    coherent metal but NOT the physical quasiparticle weight in the Mott phase
    (where a Hubbard band carries the max d-weight). For the reported physical Z
    use ``fermi_Z`` (the residue at the Fermi level). Retained for the structural
    QP/ghost split and backward compatibility.
    """
    idx = quasiparticle_index(lam, R)
    R = np.asarray(R, dtype=float).ravel()
    return float(R[idx] ** 2), idx


def fermi_index(lam, R=None, mu: float = 0.0) -> int:
    """Index of the COHERENT quasiparticle: the eigenmode whose eigenvalue is
    nearest the Fermi level lam = mu.

    In the shifted arrowhead frame the on-site level is ebar = eps_d + Sigma_inf
    - mu and the chemical potential sits at lam = 0, so the default mu=0 selects
    the lambda_0 of draft Eq 29 -- the pole at the Fermi level carrying the
    Fermi-liquid weight Z = R_0^2 = 1/(1 - Sigma'(0)).

    Distinct from ``quasiparticle_index`` (max d-weight): the two coincide in the
    coherent metal, but deep in the Mott phase the coherent pole's weight
    collapses (Z -> 0) while a high-energy Hubbard band carries the maximal
    d-weight. argmax(R^2) then mis-identifies the quasiparticle; nearest-to-Fermi
    is the correct selector for the physical Z at and below the Mott transition.
    """
    lam = np.asarray(lam, dtype=float).ravel()
    return int(np.argmin(np.abs(lam - mu)))


def fermi_Z(lam, R, mu: float = 0.0):
    """Return (Z, idx) with Z = R[idx]^2 the coherent quasiparticle weight at the
    Fermi level (Eq 29), idx = ``fermi_index``.

    This is the Z to report. It reproduces the pole-sum
    ``Z_pole = 1/(1 + sum_a W_a^2/eta_a^2)`` (the run_bonding_systematic
    diagnostic) to machine precision across the full Brinkman-Rice -> Mott curve,
    where the max-weight ``quasiparticle_Z`` breaks down (it reads a Hubbard band
    in the Mott phase).
    """
    idx = fermi_index(lam, R, mu=mu)
    R = np.asarray(R, dtype=float).ravel()
    return float(R[idx] ** 2), idx


def close_lambda0(lam_rest, R, ebar: float, idx0: int = 0) -> float:
    """Solve sum_g lam_g R_g^2 = ebar for the one free eigenvalue lam[idx0].

    Used by the physical-gauge codec: it fits {lam_g : g != idx0} and the
    normalized R, then pins lam[idx0] so the reconstructed on-site level equals
    ebar = eps_d - mu + Sigma_inf. Returns the value of lam[idx0].
    """
    R = np.asarray(R, dtype=float).ravel()
    R2 = R ** 2
    if R2[idx0] <= 0.0:
        raise ValueError("close_lambda0 needs R[idx0] != 0.")
    acc = 0.0
    j = 0
    for g in range(R2.size):
        if g == idx0:
            continue
        acc += float(lam_rest[j]) * R2[g]
        j += 1
    return (ebar - acc) / R2[idx0]
