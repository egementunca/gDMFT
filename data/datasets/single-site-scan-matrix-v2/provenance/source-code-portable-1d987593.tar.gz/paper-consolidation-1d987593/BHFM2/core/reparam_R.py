#!/usr/bin/env python3
"""Physical-gauge (R, lambda) reparametrization of the single-impurity solve.

Route A ("inverse-map bridge"): the optimizer fits the physical-gauge variables
{lambda, R} of the April-28 draft (Eqs 24-32) instead of the bare spectral
amplitudes {eta, W}. On every residual evaluation we reconstruct (eta, W) via
the arrowhead inverse (canonical_gauge.inverse) and DELEGATE to the existing,
untouched ``residual_min``. So the matching conditions, observables, ED, and
the analytic Jacobian are byte-for-byte the trusted code -- this path can only
produce the same physics as the bare gauge, which is exactly what makes it the
validation bridge and a drop-in selectable solve-type.

What is fit (single_impurity, per h-sector with Mh ghosts -> Mh+1 modes):

  - Mh "ghost" eigenvalues  lam_ghost        (the non-quasiparticle modes)
  - Mh free overlaps        R_free in [0,1]  (d-weight of the ghost modes)

The quasiparticle mode closes the books:
  - R_qp = sqrt(1 - sum R_free^2)             (normalization, Eq 27)
  - lam_qp = (ebar - sum lam_ghost R_free^2)/R_qp^2   (ebar-closure)
with  ebar = eps_d + Sigma_inf - mu  the on-site level shared by the lattice
and gateway d-h blocks. That is 2*Mh free reals per h-sector -- identical to
the bare {eta, W} count (Eq 32). The lattice and gateway h-sectors are fit
independently (matched, as in the bare gauge); both reconstruct with the same
ebar. Because inverse() sees R only through R^2, the sign of R is irrelevant to
(eta, W), so the free overlaps are bounded non-negative without loss.

Phase 1 scope: single_impurity mode only. Bond / B+AB modes raise.
"""
from __future__ import annotations

from dataclasses import dataclass, field
import time

import numpy as np
from scipy.optimize import least_squares

from . import canonical_gauge as cg
from .solve_min import (
    SParMin,
    imp1_obs,
    residual_min,
    _is_single_impurity,
    _normalize_mode,
    _resolve_dims,
    MODE_SINGLE_IMPURITY,
)

# Floor keeping the quasiparticle overlap (hence Z) away from exactly 0 and the
# spectrum non-degenerate, so canonical_gauge.inverse always has a valid
# arrowhead to reconstruct. The Mott point R_qp -> 0 sits at this boundary.
R_FLOOR = 1e-5
LAM_MIN_GAP = 1e-7


@dataclass
class SParR:
    """Physical-gauge parameters for one single-impurity point."""
    lamL_g: np.ndarray      # (Mh,) lattice ghost eigenvalues
    RL_f: np.ndarray        # (Mh,) lattice ghost overlaps in [0,1]
    eps1: np.ndarray        # (Mg,) impurity g-ghost levels (gauge-independent)
    V1: np.ndarray          # (Mg,) impurity g-ghost couplings (gauge-independent)
    lamG_g: np.ndarray      # (Mh,) gateway ghost eigenvalues
    RG_f: np.ndarray        # (Mh,) gateway ghost overlaps in [0,1]
    mu: float


# --------------------------------------------------------------------------
# (lam_ghost, R_free, ebar) <-> (eta, W)
# --------------------------------------------------------------------------
def _nudge_distinct(lam, gap=LAM_MIN_GAP):
    """Perturb any near-degenerate eigenvalues so inverse() stays well posed."""
    lam = np.array(lam, dtype=float)
    order = np.argsort(lam)
    s = lam[order]
    for i in range(1, len(s)):
        if s[i] - s[i - 1] < gap:
            s[i] = s[i - 1] + gap
    out = np.empty_like(lam)
    out[order] = s
    return out


def hsector_to_bare(lam_ghost, R_free, ebar):
    """(lam_ghost[Mh], R_free[Mh], ebar) -> (eta[Mh], W[Mh]).

    Assembles the full (lam, R) spectrum (QP mode + ghosts), normalized and
    ebar-consistent, then reconstructs the arrowhead via canonical_gauge.
    """
    lam_ghost = np.asarray(lam_ghost, dtype=float).ravel()
    R_free = np.clip(np.asarray(R_free, dtype=float).ravel(), 0.0, 1.0)
    Mh = lam_ghost.size
    if Mh == 0:
        return np.zeros(0), np.zeros(0)

    # Keep every overlap strictly positive (a vanishing R_g is a decoupled
    # "dark" ghost that makes the arrowhead inverse singular -- the same
    # configuration the bare gauge forbids via its W >= 1e-8 bound), then
    # project into the feasible ball so R_qp^2 >= R_FLOOR^2.
    R_free = np.clip(R_free, R_FLOOR, 1.0)
    s = float(np.sum(R_free ** 2))
    cap = 1.0 - R_FLOOR ** 2
    if s > cap:
        R_free = R_free * np.sqrt(cap / s)
        s = cap
    R_qp2 = 1.0 - s
    R_qp = np.sqrt(R_qp2)

    lam_qp = (ebar - float(np.sum(lam_ghost * R_free ** 2))) / R_qp2
    lam = np.concatenate(([lam_qp], lam_ghost))
    R = np.concatenate(([R_qp], R_free))
    # Sort (lam, R) together, then nudge any near-degenerate eigenvalues so the
    # arrowhead inverse stays well posed. Pairing is preserved throughout.
    o = np.argsort(lam)
    R_sorted = R[o]
    # The inverse is ill-conditioned as ghost eigenvalues collide; widen the
    # nudge progressively if a reconstruction is rejected so the optimizer
    # degrades gracefully (near-decoupled ghost) instead of crashing.
    for gap in (LAM_MIN_GAP, 1e-3, 1e-2):
        try:
            _, eta, W = cg.inverse(_nudge_distinct(lam[o], gap), R_sorted)
            return eta, W
        except (ValueError, FloatingPointError):
            continue
    # Last resort: treat each ghost as decoupled at its eigenvalue.
    return np.sort(lam[o])[1:].copy(), np.full(Mh, R_FLOOR)


def d_hsector_to_bare(lam_ghost, R_free, ebar):
    """Analytic Jacobian of ``hsector_to_bare``: d(eta, W)/d(lam_ghost, R_free, ebar).

    Composes the QP-closure (R_qp = sqrt(1 - sum R_free^2),
    lam_qp = (ebar - sum lam_ghost R_free^2)/R_qp^2) with the arrowhead-inverse
    derivative ``canonical_gauge.d_inverse``. Pure numpy -- login-node safe.

    Valid in the generic interior: R_free strictly inside (R_FLOOR, 1) with
    sum R_free^2 < 1 - R_FLOOR^2 (clip/projection inactive) and distinct
    eigenvalues (nudge inactive) -- the regime of the physical fixed point.

    Returns
    -------
    deta_dlamg : (Mh, Mh)   d eta_a / d lam_ghost_j
    deta_dRf   : (Mh, Mh)   d eta_a / d R_free_j
    dW_dlamg   : (Mh, Mh)
    dW_dRf     : (Mh, Mh)
    deta_debar : (Mh,)      d eta_a / d ebar
    dW_debar   : (Mh,)
    """
    lam_ghost = np.asarray(lam_ghost, dtype=float).ravel()
    R_free = np.asarray(R_free, dtype=float).ravel()
    Mh = lam_ghost.size
    if Mh == 0:
        z = np.zeros((0, 0))
        return z, z, z, z, np.zeros(0), np.zeros(0)

    # Mirror hsector_to_bare's feasibility projection so the closure and the
    # arrowhead-inverse derivative stay finite through the near-degenerate /
    # dark-mode boundary (R_qp^2 -> 0, or a ghost overlap -> 0) instead of
    # blowing up / raising -- otherwise the caller is forced onto a slow,
    # oscillation-prone finite-difference Jacobian right where continuation
    # crosses the correlated -> dark competition.
    R_free = np.clip(R_free, R_FLOOR, 1.0)
    ss = float(np.sum(R_free ** 2))
    cap = 1.0 - R_FLOOR ** 2
    if ss > cap:
        R_free = R_free * np.sqrt(cap / ss)

    # Closure (construction order: index 0 = QP, 1.. = ghosts).
    s = float(np.sum(R_free ** 2))
    R_qp2 = 1.0 - s
    R_qp = np.sqrt(R_qp2)
    lam_qp = (ebar - float(np.sum(lam_ghost * R_free ** 2))) / R_qp2
    lam_full = np.concatenate(([lam_qp], lam_ghost))
    R_full = np.concatenate(([R_qp], R_free))

    # Arrowhead-inverse derivative w.r.t. the full (construction-order) spectrum.
    # Nudge colliding eigenvalues (as inverse/hsector_to_bare do) so d_inverse's
    # distinct-spectrum precondition holds. Progressive-widening ladder (mirrors
    # hsector_to_bare): a tiny nudge underflows brentq's bracket when a ghost
    # overlap is near-dark, so widen until it resolves -- keeps the analytic
    # Jacobian finite and NON-RAISING right at the correlated->dark competition,
    # instead of throwing and forcing the caller onto a slow finite-difference J.
    deta_dlamF = deta_dRF = dW_dlamF = dW_dRF = None
    for _gap in (LAM_MIN_GAP, 1e-4, 1e-3, 1e-2):
        try:
            deta_dlamF, deta_dRF, dW_dlamF, dW_dRF, _, _ = cg.d_inverse(
                _nudge_distinct(lam_full, _gap), R_full)
            break
        except (ValueError, FloatingPointError):
            continue
    if deta_dlamF is None:
        # last resort: decoupled-limit block (zero coupling derivatives). Finite,
        # lets TRF continue; the residual path has its own graceful fallback.
        _sh = (Mh, Mh + 1)
        deta_dlamF = np.zeros(_sh); deta_dRF = np.zeros(_sh)
        dW_dlamF = np.zeros(_sh); dW_dRF = np.zeros(_sh)
    # d_inverse returns columns in INPUT order = construction order here.

    # Closure derivatives d(lam_full, R_full)/d(lam_ghost, R_free, ebar).
    # lam_full[0] = lam_qp:
    dlamqp_dlamg = -(R_free ** 2) / R_qp2                       # (Mh,)
    dlamqp_dRf = 2.0 * R_free * (lam_qp - lam_ghost) / R_qp2    # (Mh,)
    dlamqp_debar = 1.0 / R_qp2                                  # scalar
    # R_full[0] = R_qp:
    dRqp_dRf = -R_free / R_qp                                   # (Mh,)
    # lam_full[1+j] = lam_ghost[j], R_full[1+j] = R_free[j]  (identity blocks).

    # Chain. For output o in {eta, W} with full-spectrum derivs (do_dlamF[:,k],
    # do_dRF[:,k]) (k=0 QP, k=1+j ghost):
    #   do/d lam_ghost_j = do_dlamF[:,0] * dlamqp_dlamg[j] + do_dlamF[:,1+j]
    #   do/d R_free_j    = do_dlamF[:,0] * dlamqp_dRf[j]
    #                      + do_dRF[:,0] * dRqp_dRf[j] + do_dRF[:,1+j]
    #   do/d ebar        = do_dlamF[:,0] * dlamqp_debar
    def _chain(do_dlamF, do_dRF):
        qp_lam = do_dlamF[:, 0]                 # (Mh,)
        qp_R = do_dRF[:, 0]                     # (Mh,)
        ghost_lam = do_dlamF[:, 1:]            # (Mh, Mh)
        ghost_R = do_dRF[:, 1:]               # (Mh, Mh)
        d_dlamg = np.outer(qp_lam, dlamqp_dlamg) + ghost_lam
        d_dRf = np.outer(qp_lam, dlamqp_dRf) + np.outer(qp_R, dRqp_dRf) + ghost_R
        d_debar = qp_lam * dlamqp_debar
        return d_dlamg, d_dRf, d_debar

    deta_dlamg, deta_dRf, deta_debar = _chain(deta_dlamF, deta_dRF)
    dW_dlamg, dW_dRf, dW_debar = _chain(dW_dlamF, dW_dRF)
    return deta_dlamg, deta_dRf, dW_dlamg, dW_dRf, deta_debar, dW_debar


def hsector_from_bare(eta, W, ebar):
    """(eta[Mh], W[Mh], ebar) -> (lam_ghost[Mh], R_free[Mh]) for seeding."""
    eta = np.asarray(eta, dtype=float).ravel()
    W = np.asarray(W, dtype=float).ravel()
    if eta.size == 0:
        return np.zeros(0), np.zeros(0)
    lam, R = cg.forward(ebar, eta, W)
    qp = cg.quasiparticle_index(lam, R)          # max-weight mode = QP
    mask = np.ones(lam.size, dtype=bool)
    mask[qp] = False
    return lam[mask].copy(), R[mask].copy()


# --------------------------------------------------------------------------
# Codec
# --------------------------------------------------------------------------
class CodecMinR:
    """Pack/unpack the physical-gauge vector for single_impurity."""

    def __init__(self, Mh, Mg=None, Mb=None, mode=MODE_SINGLE_IMPURITY,
                 fixed_mu=None):
        Mh_r, Mg_r, Mb_r = _resolve_dims(Mh, Mg, Mb)
        mode_r = _normalize_mode(mode)
        if not _is_single_impurity(mode_r):
            raise NotImplementedError(
                "reparam_R Phase 1 supports single_impurity only "
                f"(got mode={mode_r!r})."
            )
        if Mb_r != 0:
            raise ValueError("single_impurity mode requires Mb=0")
        self.Mh, self.Mg, self.Mb = Mh_r, Mg_r, Mb_r
        self.mode = mode_r
        self.fixed_mu = None if fixed_mu is None else float(fixed_mu)

    def _fields(self):
        Mh, Mg = self.Mh, self.Mg
        return [("lamL_g", Mh), ("RL_f", Mh), ("eps1", Mg), ("V1", Mg),
                ("lamG_g", Mh), ("RG_f", Mh)]

    @property
    def size(self):
        return int(sum(n for _, n in self._fields())
                   + (0 if self.fixed_mu is not None else 1))

    def pack(self, pR: SParR):
        parts = [np.asarray(getattr(pR, name), float).ravel()[:n]
                 for name, n in self._fields()]
        if self.fixed_mu is None:
            parts.append(np.array([pR.mu], float))
        return np.concatenate(parts)

    def unpack(self, x) -> SParR:
        i, kw = 0, {}
        for name, n in self._fields():
            kw[name] = np.array(x[i:i + n], float)
            i += n
        mu = self.fixed_mu if self.fixed_mu is not None else float(x[i])
        return SParR(mu=float(mu), **kw)


def make_bounds_R(Mh, Mg=None, Mb=None, E=5.0, C=3.0, mu_lo=-5.0, mu_hi=5.0,
                  mode=MODE_SINGLE_IMPURITY, fixed_mu=None):
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    # The arrowhead eigenvalues bracket OUTSIDE the ghost-level range [-E, E]:
    # the W-coupling pushes them out by up to ~||W||. A Weyl bound on
    # h_dh = ebar(+/-E on diag) + W(off-diag, each <= C) gives |lam| <=
    # E + sqrt(Mh)*C, so the lambda box must be wider than the eta box or the
    # optimizer clips physical ghost levels (and the reconstruction drifts).
    E_lam = E + np.sqrt(max(Mh, 1)) * C
    fields = [("lamL_g", Mh, -E_lam, E_lam), ("RL_f", Mh, 0.0, 1.0),
              ("eps1", Mg, -E, E), ("V1", Mg, 1e-8, C),
              ("lamG_g", Mh, -E_lam, E_lam), ("RG_f", Mh, 0.0, 1.0)]
    lo, hi = [], []
    for _, n, l, h in fields:
        lo.extend([l] * n)
        hi.extend([h] * n)
    if fixed_mu is None:
        lo.append(mu_lo)
        hi.append(mu_hi)
    return np.array(lo), np.array(hi)


# --------------------------------------------------------------------------
# Reconstruction + residual
# --------------------------------------------------------------------------
def _g_only_spar(pR: SParR, Mh) -> SParMin:
    """A SParMin carrying only the gauge-independent g-ghosts (eps1, V1, mu),
    enough to evaluate imp1 -> n_avg -> Sigma_inf -> ebar."""
    z = np.zeros(Mh)
    return SParMin(eta=z, W=z, eta_b=np.zeros(0), B_h=np.zeros(0),
                   eps1=pR.eps1, V1=pR.V1, eta1=z, W1=z,
                   eps2=np.zeros(0), V2=np.zeros(0), eta2=np.zeros(0),
                   W2=np.zeros(0), eta_b2=np.zeros(0), B_h2=np.zeros(0),
                   eps_b=np.zeros(0), B_g=np.zeros(0), mu=pR.mu)


def to_bare(pR: SParR, mp, Mh, Mg) -> tuple[SParMin, float]:
    """Reconstruct the bare-gauge SParMin from physical params at the current
    self-consistent Sigma_inf. Returns (p_bare, ebar)."""
    imp1 = imp1_obs(_g_only_spar(pR, Mh), mp, Mg)
    Sigma_inf = mp.U * imp1["dens"] / 2.0
    ebar = mp.eps_d + Sigma_inf - pR.mu
    etaL, WL = hsector_to_bare(pR.lamL_g, pR.RL_f, ebar)
    etaG, WG = hsector_to_bare(pR.lamG_g, pR.RG_f, ebar)
    p = SParMin(
        eta=etaL, W=WL, eta_b=np.zeros(0), B_h=np.zeros(0),
        eps1=pR.eps1, V1=pR.V1, eta1=etaG, W1=WG,
        eps2=np.zeros(0), V2=np.zeros(0), eta2=np.zeros(0), W2=np.zeros(0),
        eta_b2=np.zeros(0), B_h2=np.zeros(0), eps_b=np.zeros(0),
        B_g=np.zeros(0), mu=pR.mu,
    )
    return p, ebar


def residual_min_R(pR: SParR, mp, Mh, Mg, Mb=None, mode=MODE_SINGLE_IMPURITY):
    """Physical-gauge residual: reconstruct (eta, W), then delegate to the
    untouched bare-gauge residual_min (which recomputes the same Sigma_inf)."""
    mode = _normalize_mode(mode)
    if not _is_single_impurity(mode):
        raise NotImplementedError("reparam_R Phase 1: single_impurity only.")
    p, _ = to_bare(pR, mp, Mh, Mg)
    return residual_min(p, mp, Mh, Mg, 0, mode=mode)


def jacobian_min_R(pR: SParR, mp, Mh, Mg, Mb=None, mode=MODE_SINGLE_IMPURITY,
                   fixed_mu=None):
    """Analytic residual + Jacobian in the physical (R, lambda) gauge.

    Chain rule  J_R = J_bare . dG, where J_bare is the trusted analytic bare-
    gauge Jacobian (jacobian_min.residual_and_jacobian_min) and dG = d(bare x)/
    d(R x) is the reconstruction Jacobian. Both codecs are index-aligned for
    single_impurity (eta<->lamL_g, W<->RL_f, eps1,V1 shared, eta1<->lamG_g,
    W1<->RG_f, mu shared), so dG is square and block-structured:

      - lattice  h-sector:  d(eta ,W )/d(lamL_g,RL_f) = D_lat   (d_hsector_to_bare)
      - gateway  h-sector:  d(eta1,W1)/d(lamG_g,RG_f) = D_gw
      - eps1,V1,mu pass through (identity), AND feed both h-sectors through
        ebar = eps_d + Sigma_inf(eps1,V1,mu) - mu:
            d(eta ,W )/d(eps1,V1,mu) += b_lat (x) d ebar/d(eps1,V1,mu)
            d(eta1,W1)/d(eps1,V1,mu) += b_gw  (x) d ebar/d(eps1,V1,mu)
        with d ebar/dx = dSigma_dx (from J_bare aux), minus 1 on the mu column.

    Returns (r, J_R) with rows identical to residual_min_R and columns in
    CodecMinR ordering. Single_impurity only.
    """
    from .jacobian_min import residual_and_jacobian_min
    mode = _normalize_mode(mode)
    if not _is_single_impurity(mode):
        raise NotImplementedError("jacobian_min_R: single_impurity only.")

    # Reconstruct the bare params at the current self-consistent Sigma_inf.
    p_bare, ebar = to_bare(pR, mp, Mh, Mg)

    # Trusted bare-gauge residual + Jacobian (+ dSigma_dx feed-forward grad).
    r, J_bare, aux = residual_and_jacobian_min(
        p_bare, mp, Mh, Mg, 0, mode=mode, fixed_mu=fixed_mu, return_aux=True
    )
    dSigma_dx = aux["dSigma_dx"]                 # over bare columns

    Mg = pR.eps1.size
    n_par = J_bare.shape[1]
    # Column/row index slices (identical layout in both gauges).
    sl_h1 = slice(0, Mh)                         # eta  / lamL_g
    sl_h2 = slice(Mh, 2 * Mh)                    # W    / RL_f
    base = 2 * Mh + 2 * Mg
    sl_g1 = slice(base, base + Mh)               # eta1 / lamG_g
    sl_g2 = slice(base + Mh, base + 2 * Mh)      # W1   / RG_f

    # d ebar / d(R x): copy dSigma_dx (eps1,V1,mu align), subtract 1 on mu.
    debar = dSigma_dx.copy()
    if fixed_mu is None:
        debar[n_par - 1] -= 1.0

    # Reconstruction Jacobian dG (rows = bare vars, cols = R vars).
    dG = np.zeros((n_par, n_par))
    # eps1, V1, mu pass through (identity); the h-sector blocks overwrite their
    # own rows below, so set identity everywhere first then fix h-rows.
    np.fill_diagonal(dG, 1.0)
    dG[sl_h1, sl_h1] = 0.0
    dG[sl_h2, sl_h2] = 0.0
    dG[sl_g1, sl_g1] = 0.0
    dG[sl_g2, sl_g2] = 0.0

    # Lattice h-sector.
    (deta_dlg, deta_dRf, dW_dlg, dW_dRf,
     deta_deb, dW_deb) = d_hsector_to_bare(pR.lamL_g, pR.RL_f, ebar)
    dG[sl_h1, sl_h1] = deta_dlg
    dG[sl_h1, sl_h2] = deta_dRf
    dG[sl_h2, sl_h1] = dW_dlg
    dG[sl_h2, sl_h2] = dW_dRf
    dG[sl_h1, :] += np.outer(deta_deb, debar)
    dG[sl_h2, :] += np.outer(dW_deb, debar)

    # Gateway h-sector.
    (deta_dlg, deta_dRf, dW_dlg, dW_dRf,
     deta_deb, dW_deb) = d_hsector_to_bare(pR.lamG_g, pR.RG_f, ebar)
    dG[sl_g1, sl_g1] = deta_dlg
    dG[sl_g1, sl_g2] = deta_dRf
    dG[sl_g2, sl_g1] = dW_dlg
    dG[sl_g2, sl_g2] = dW_dRf
    dG[sl_g1, :] += np.outer(deta_deb, debar)
    dG[sl_g2, :] += np.outer(dW_deb, debar)

    J_R = J_bare @ dG
    return r, J_R


def seed_R_from_bare(p_bare: SParMin, mp, Mh, Mg) -> SParR:
    """Map a bare-gauge seed into the physical gauge (forward transform)."""
    imp1 = imp1_obs(p_bare, mp, Mg)
    Sigma_inf = mp.U * imp1["dens"] / 2.0
    ebar = mp.eps_d + Sigma_inf - p_bare.mu
    lamL_g, RL_f = hsector_from_bare(p_bare.eta, p_bare.W, ebar)
    lamG_g, RG_f = hsector_from_bare(p_bare.eta1, p_bare.W1, ebar)
    return SParR(lamL_g=lamL_g, RL_f=RL_f, eps1=np.asarray(p_bare.eps1, float),
                 V1=np.asarray(p_bare.V1, float), lamG_g=lamG_g, RG_f=RG_f,
                 mu=float(p_bare.mu))


# --------------------------------------------------------------------------
# Solver
# --------------------------------------------------------------------------
def solve_min_R(mp0, Mh, Mg, filling_target, p_init_bare=None, pR_init=None,
                fixed_mu=None, max_nfev=400, ftol=1e-12, xtol=1e-12,
                verbose=False, mode=MODE_SINGLE_IMPURITY, jac="analytic"):
    """least_squares over the physical-gauge variables for single_impurity.

    Mirrors solve_min but fits {lambda, R}. Returns a dict with the solved
    physical params, the reconstructed bare params, residual norm, and the
    quasiparticle weights Z extracted directly from the fit.

    jac: "analytic" (default) uses the closed-form physical-gauge Jacobian
    ``jacobian_min_R`` (chain rule through the arrowhead inverse) -- this
    removes the finite-difference noise that stalls the cold-seed R-gauge solve
    (the inverse-map reconstruction corrupts TRF's 2-point gradient). "2-point"
    falls back to scipy's finite-difference Jacobian (the old behaviour, for
    comparison).
    """
    from dataclasses import replace
    mode = _normalize_mode(mode)
    mp = replace(mp0, filling_target=filling_target)
    codec = CodecMinR(Mh, Mg, 0, mode=mode, fixed_mu=fixed_mu)
    lo, hi = make_bounds_R(Mh, Mg, 0, mode=mode, fixed_mu=fixed_mu)

    if pR_init is None:
        if p_init_bare is None:
            from .solve_min import init_min
            mu0 = fixed_mu if fixed_mu is not None else mp.U * filling_target / 2.0
            p_init_bare = init_min(Mh, Mg, 0, W0=0.3, V0=0.3, base_mu=mu0,
                                   mode=mode)
            # Spread the ghost levels: init_min seeds eta=0 (degenerate), whose
            # arrowhead has an exact decoupled dark mode (R=0) -- singular for
            # the physical-gauge map. A small spread starts in the generic,
            # fully-coupled regime.
            if Mh > 1:
                spread = np.linspace(-0.4, 0.4, Mh)
                p_init_bare = replace(p_init_bare, eta=spread.copy(),
                                      eta1=spread.copy())
        pR_init = seed_R_from_bare(p_init_bare, mp, Mh, Mg)

    x0 = np.clip(codec.pack(pR_init), lo + 1e-8, hi - 1e-8)
    t0 = time.time()
    niter = [0]

    njev = [0]

    def fn(x):
        niter[0] += 1
        r = residual_min_R(codec.unpack(x), mp, Mh, Mg, 0, mode=mode)
        if verbose and niter[0] % 30 == 1:
            print(f"    nfev={niter[0]:3d}  ||r||={np.linalg.norm(r):.3e}  "
                  f"t={time.time()-t0:.0f}s", flush=True)
        return r

    if jac == "analytic":
        def jac_fn(x):
            njev[0] += 1
            _, J = jacobian_min_R(codec.unpack(x), mp, Mh, Mg, 0, mode=mode,
                                  fixed_mu=fixed_mu)
            return J
        jac_arg = jac_fn
    elif jac in ("2-point", "3-point", "cs"):
        jac_arg = jac
    else:
        raise ValueError(f"unknown jac={jac!r}")

    sol = least_squares(fn, x0, jac=jac_arg, method="trf", bounds=(lo, hi),
                        ftol=ftol, xtol=xtol, max_nfev=max_nfev, verbose=0)
    pR = codec.unpack(sol.x)
    p_bare, ebar = to_bare(pR, mp, Mh, Mg)

    # Quasiparticle weights straight from the physical fit. Use the Fermi-level
    # residue (fermi_Z), NOT the max-d-weight mode: the latter mis-reads a
    # Hubbard band as the QP in the Mott phase. fermi_Z reproduces the pole-sum
    # Z_pole across the whole Brinkman-Rice -> Mott curve.
    lamL, RL = cg.forward(ebar, p_bare.eta, p_bare.W)
    Z_lat, _ = cg.fermi_Z(lamL, RL)
    lamG, RG = cg.forward(ebar, p_bare.eta1, p_bare.W1)
    Z_gw, _ = cg.fermi_Z(lamG, RG)

    return dict(
        pR=pR, p_bare=p_bare, sol=sol, ebar=ebar,
        resid_norm=float(np.linalg.norm(sol.fun)),
        nfev=int(sol.nfev), njev=int(getattr(sol, "njev", 0) or njev[0]),
        jac=jac, Z_lat=Z_lat, Z_gw=Z_gw,
        elapsed=time.time() - t0,
    )
