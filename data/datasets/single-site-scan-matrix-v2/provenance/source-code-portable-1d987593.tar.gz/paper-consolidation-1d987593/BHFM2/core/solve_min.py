#!/usr/bin/env python3
"""Minimal ghost-DMFT with decoupled Mh/Mg and optional anti-bond channel."""
from __future__ import annotations

import time
from dataclasses import dataclass, field, replace
from functools import lru_cache

import numpy as np
from numpy.linalg import eigh
from scipy.optimize import least_squares
from scipy.special import ellipk

from .ghost_dmft_bond import build_sector
from .ed_fast import (
    build_H_sector_fast,
    make_lookup,
    expect_n_fast,
    expect_double_fast,
    expect_cdag_c_fast,
)


MODE_BONDING_ONLY = "bonding_only"
MODE_BONDING_PLUS_ANTIBONDING = "bonding_plus_antibonding"
MODE_SINGLE_IMPURITY = "single_impurity"
VALID_MODES = {MODE_SINGLE_IMPURITY, MODE_BONDING_ONLY, MODE_BONDING_PLUS_ANTIBONDING}

LATTICE_SQUARE = "square"
LATTICE_BETHE = "bethe"
VALID_LATTICES = {LATTICE_SQUARE, LATTICE_BETHE}


def _normalize_mode(mode: str | None) -> str:
    if mode is None:
        return MODE_BONDING_ONLY
    m = str(mode).strip().lower()
    aliases = {
        "bonding_only": MODE_BONDING_ONLY,
        "bonding": MODE_BONDING_ONLY,
        "plus_only": MODE_BONDING_ONLY,
        "bonding_plus_antibonding": MODE_BONDING_PLUS_ANTIBONDING,
        "bonding_plus_antibond": MODE_BONDING_PLUS_ANTIBONDING,
        "bonding_antibonding": MODE_BONDING_PLUS_ANTIBONDING,
        "plus_minus": MODE_BONDING_PLUS_ANTIBONDING,
        "bonding+antibonding": MODE_BONDING_PLUS_ANTIBONDING,
        "single": MODE_SINGLE_IMPURITY,
        "single_site": MODE_SINGLE_IMPURITY,
        "single_impurity": MODE_SINGLE_IMPURITY,
        "single-impurity": MODE_SINGLE_IMPURITY,
        "single-site": MODE_SINGLE_IMPURITY,
    }
    out = aliases.get(m, m)
    if out not in VALID_MODES:
        raise ValueError(f"Unknown mode: {mode}. Valid: {sorted(VALID_MODES)}")
    return out


def _has_antibond(mode: str, Mb: int) -> bool:
    return _normalize_mode(mode) == MODE_BONDING_PLUS_ANTIBONDING and int(Mb) > 0


def _is_single_impurity(mode: str | None) -> bool:
    return _normalize_mode(mode) == MODE_SINGLE_IMPURITY


def _normalize_lattice(lattice: str | None) -> str:
    if lattice is None:
        return LATTICE_SQUARE
    l = str(lattice).strip().lower()
    aliases = {
        "square": LATTICE_SQUARE,
        "sq": LATTICE_SQUARE,
        "2d_square": LATTICE_SQUARE,
        "2d-square": LATTICE_SQUARE,
        "bethe": LATTICE_BETHE,
        "bethe_lattice": LATTICE_BETHE,
        "bethe-lattice": LATTICE_BETHE,
        "semicircular": LATTICE_BETHE,
        "semicircle": LATTICE_BETHE,
        "semi-circular": LATTICE_BETHE,
    }
    out = aliases.get(l, l)
    if out not in VALID_LATTICES:
        raise ValueError(f"Unknown lattice: {lattice}. Valid: {sorted(VALID_LATTICES)}")
    return out


LATTICE_QUAD_KMESH = "uniform_kmesh"
LATTICE_QUAD_CONTINUUM = "continuum_elliptic_dos"


@lru_cache(maxsize=16)
def _square_dos_nodes(t: float, n_eps: int):
    """Graded 1-D quadrature of the exact square-lattice DOS rho(eps) =
    K(m)/(2 pi^2 t), m = 1-(eps/4t)^2 (band [-4t,4t]). Midpoint rule on a grid
    tightened toward the eps=0 van Hove point; weights renormalized to sum 1.
    Returns (eps[n_eps], weight[n_eps]) as numpy arrays."""
    band = 4.0 * t
    grade = 3.0
    u = np.linspace(-1.0, 1.0, n_eps + 1)
    edges = band * np.sign(u) * np.abs(u) ** grade
    centers = 0.5 * (edges[1:] + edges[:-1])
    deps = np.diff(edges)
    m = np.clip(1.0 - (centers / band) ** 2, 0.0, 1.0 - 1e-15)
    rho = np.where(m > 0.0, ellipk(m) / (2.0 * np.pi ** 2 * t), 0.0)
    w = rho * deps
    w = w / w.sum()
    return centers, w


def _lattice_quadrature(mp, mode: str = MODE_BONDING_ONLY, Mb: int = 0):
    """Yield (eps, weight, ckx, cky, skx, sky, cos_kx) lattice integration nodes.

    Square lattice supports two provenance-recorded quadratures via
    ``mp.lattice_quadrature``: ``uniform_kmesh`` (Nk x Nk (kx,ky) grid, the
    production default) and ``continuum_elliptic_dos`` (a graded 1-D integral of
    the exact square DOS -- the D=1 continuum limit, single_impurity only; its
    k-form-factor fields are 0 because it carries no (kx,ky) resolution).
    """
    lattice = _normalize_lattice(getattr(mp, "lattice", LATTICE_SQUARE))
    mode = _normalize_mode(mode)
    if lattice == LATTICE_BETHE:
        if not _is_single_impurity(mode) or int(Mb) != 0:
            raise ValueError("Bethe lattice is only implemented for single_impurity mode with Mb=0")
        if mp.t <= 0:
            raise ValueError("Bethe lattice requires positive hopping t")
        n = max(1, int(mp.Nk))
        j = np.arange(1, n + 1, dtype=float)
        theta = np.pi * j / (n + 1.0)
        eps = 2.0 * mp.t * np.cos(theta)
        weights = (2.0 / (n + 1.0)) * np.sin(theta) ** 2
        for ee, ww in zip(eps, weights):
            yield float(ee), float(ww), 0.0, 0.0, 0.0, 0.0, 0.0
        return

    quad = getattr(mp, "lattice_quadrature", LATTICE_QUAD_KMESH)
    if quad == LATTICE_QUAD_CONTINUUM:
        if not _is_single_impurity(mode) or int(Mb) != 0:
            raise ValueError(
                "continuum_elliptic_dos square quadrature is single_impurity "
                "only (no k-form-factors for bond/antibond channels)")
        centers, weights = _square_dos_nodes(float(mp.t),
                                             int(getattr(mp, "n_eps_dos", 4001)))
        for ee, ww in zip(centers, weights):
            yield float(ee), float(ww), 0.0, 0.0, 0.0, 0.0, 0.0
        return

    Nk = int(mp.Nk)
    kvals = np.linspace(-np.pi, np.pi, Nk, endpoint=False)
    wk = 1.0 / (Nk * Nk)
    for kx in kvals:
        for ky in kvals:
            yield (
                float(-2.0 * mp.t * (np.cos(kx) + np.cos(ky))),
                float(wk),
                float(np.cos(kx / 2.0)),
                float(np.cos(ky / 2.0)),
                float(np.sin(kx / 2.0)),
                float(np.sin(ky / 2.0)),
                float(np.cos(kx)),
            )


GS_BETA = 1.0e8  # effective beta for T=0 / ground-state mode: excited Boltzmann weights underflow,
                 # leaving only the ground manifold; _fermi() becomes the T=0 step (0.5 at the Fermi level).


@dataclass
class ModelParamsMin:
    t: float = 0.5
    eps_d: float = 0.0
    U: float = 1.3
    z: float = 4.0
    filling_target: float = 1.0
    Sigma_inf: float = 0.65
    beta: float = 0.5
    Nk: int = 16
    use_y_bond: bool = True
    n_moments: int = 4
    lattice: str = LATTICE_SQUARE
    ground_state: bool = False  # T=0: force beta->GS_BETA so only the ground manifold contributes
    # square-lattice integration route (provenance-recorded); default preserves
    # the production uniform Nk x Nk k-mesh. "continuum_elliptic_dos" selects the
    # graded exact-DOS 1-D integral (single_impurity only).
    lattice_quadrature: str = LATTICE_QUAD_KMESH
    n_eps_dos: int = 4001       # nodes for the continuum_elliptic_dos route

    def __post_init__(self):
        self.lattice = _normalize_lattice(self.lattice)
        if self.ground_state:
            self.beta = GS_BETA


@dataclass
class SParMin:
    eta: np.ndarray
    W: np.ndarray
    eta_b: np.ndarray
    B_h: np.ndarray
    eps1: np.ndarray
    V1: np.ndarray
    eta1: np.ndarray
    W1: np.ndarray
    eps2: np.ndarray
    V2: np.ndarray
    eta2: np.ndarray
    W2: np.ndarray
    eta_b2: np.ndarray
    B_h2: np.ndarray
    eps_b: np.ndarray
    B_g: np.ndarray
    mu: float
    eta_a: np.ndarray = field(default_factory=lambda: np.zeros(0))
    B_ha: np.ndarray = field(default_factory=lambda: np.zeros(0))
    eta_a2: np.ndarray = field(default_factory=lambda: np.zeros(0))
    B_ha2: np.ndarray = field(default_factory=lambda: np.zeros(0))
    eps_a: np.ndarray = field(default_factory=lambda: np.zeros(0))
    B_ga: np.ndarray = field(default_factory=lambda: np.zeros(0))


def _resolve_dims(Mh: int, Mg: int | None = None, Mb: int | None = None):
    """Support both new (Mh, Mg, Mb) and legacy (M, Mb) signatures."""
    if Mb is None:
        if Mg is None:
            raise ValueError("Expected either (Mh, Mg, Mb) or legacy (M, Mb).")
        return int(Mh), int(Mh), int(Mg)
    return int(Mh), int(Mg), int(Mb)


class CodecMin:
    def __init__(
        self,
        Mh: int,
        Mg: int | None = None,
        Mb: int | None = None,
        mode: str = MODE_BONDING_ONLY,
        fixed_mu: float | None = None,
    ):
        Mh_r, Mg_r, Mb_r = _resolve_dims(Mh, Mg, Mb)
        mode_r = _normalize_mode(mode)
        if _is_single_impurity(mode_r) and Mb_r != 0:
            raise ValueError("single_impurity mode requires Mb=0")
        self.Mh = Mh_r
        self.Mg = Mg_r
        self.Mb = Mb_r
        self.mode = mode_r
        self.fixed_mu = None if fixed_mu is None else float(fixed_mu)

    def _fields(self):
        Mh, Mg, Mb = self.Mh, self.Mg, self.Mb
        if _is_single_impurity(self.mode):
            return [
                ("eta", Mh),
                ("W", Mh),
                ("eps1", Mg),
                ("V1", Mg),
                ("eta1", Mh),
                ("W1", Mh),
            ]
        fields = [
            ("eta", Mh),
            ("W", Mh),
            ("eta_b", Mb),
            ("B_h", Mb),
            ("eps1", Mg),
            ("V1", Mg),
            ("eta1", Mh),
            ("W1", Mh),
            ("eps2", Mg),
            ("V2", Mg),
            ("eta2", Mh),
            ("W2", Mh),
            ("eta_b2", Mb),
            ("B_h2", Mb),
            ("eps_b", Mb),
            ("B_g", Mb),
        ]
        if _has_antibond(self.mode, Mb):
            fields.extend(
                [
                    ("eta_a", Mb),
                    ("B_ha", Mb),
                    ("eta_a2", Mb),
                    ("B_ha2", Mb),
                    ("eps_a", Mb),
                    ("B_ga", Mb),
                ]
            )
        return fields

    @property
    def size(self):
        return int(sum(n for _, n in self._fields()) + (0 if self.fixed_mu is not None else 1))

    def pack(self, p):
        parts = []
        for name, n in self._fields():
            arr = np.asarray(getattr(p, name, np.zeros(n)), dtype=float).ravel()
            if len(arr) < n:
                arr = np.pad(arr, (0, n - len(arr)))
            parts.append(arr[:n])
        if self.fixed_mu is None:
            parts.append(np.array([p.mu], dtype=float))
        return np.concatenate(parts)

    def unpack(self, x):
        i = 0
        kw = {}
        for name, n in self._fields():
            kw[name] = np.array(x[i : i + n], dtype=float)
            i += n
        mu = self.fixed_mu if self.fixed_mu is not None else float(x[i])
        for name in (
            "eta", "W", "eta_b", "B_h", "eps1", "V1", "eta1", "W1",
            "eps2", "V2", "eta2", "W2", "eta_b2", "B_h2", "eps_b", "B_g",
        ):
            kw.setdefault(name, np.zeros(0))
        return SParMin(mu=float(mu), **kw)


def init_min(
    Mh: int,
    Mg: int | None = None,
    Mb: int | None = None,
    W0=0.3,
    V0=0.3,
    B0=0.1,
    base_mu=0.65,
    mode: str = MODE_BONDING_ONLY,
):
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    mode = _normalize_mode(mode)
    if _is_single_impurity(mode):
        if Mb != 0:
            raise ValueError("single_impurity mode requires Mb=0")
        return SParMin(
            eta=np.zeros(Mh),
            W=np.full(Mh, W0),
            eta_b=np.zeros(0),
            B_h=np.zeros(0),
            eps1=np.zeros(Mg),
            V1=np.full(Mg, V0),
            eta1=np.zeros(Mh),
            W1=np.full(Mh, W0),
            eps2=np.zeros(0),
            V2=np.zeros(0),
            eta2=np.zeros(0),
            W2=np.zeros(0),
            eta_b2=np.zeros(0),
            B_h2=np.zeros(0),
            eps_b=np.zeros(0),
            B_g=np.zeros(0),
            mu=base_mu,
        )
    anti = _has_antibond(mode, Mb)
    return SParMin(
        eta=np.zeros(Mh),
        W=np.full(Mh, W0),
        eta_b=np.zeros(Mb),
        B_h=np.full(Mb, B0),
        eps1=np.zeros(Mg),
        V1=np.full(Mg, V0),
        eta1=np.zeros(Mh),
        W1=np.full(Mh, W0),
        eps2=np.zeros(Mg),
        V2=np.full(Mg, V0),
        eta2=np.zeros(Mh),
        W2=np.full(Mh, W0),
        eta_b2=np.zeros(Mb),
        B_h2=np.full(Mb, B0),
        eps_b=np.zeros(Mb),
        B_g=np.full(Mb, B0),
        mu=base_mu,
        eta_a=np.zeros(Mb if anti else 0),
        B_ha=np.full(Mb if anti else 0, B0),
        eta_a2=np.zeros(Mb if anti else 0),
        B_ha2=np.full(Mb if anti else 0, B0),
        eps_a=np.zeros(Mb if anti else 0),
        B_ga=np.full(Mb if anti else 0, B0),
    )


def _fermi(x, beta):
    xc = np.clip(beta * x, -700, 700)
    return 1.0 / (np.exp(xc) + 1.0)


def _dm(H, beta):
    e, U = eigh(H)
    with np.errstate(over="ignore", divide="ignore", invalid="ignore"):
        return (U * _fermi(e, beta)[None, :]) @ U.T


@lru_cache(maxsize=256)
def _sector_basis(N_orb, N_up, N_dn):
    """Cache immutable sector bases and binary-search lookups."""
    bnp, _ = build_sector(N_orb, N_up, N_dn)
    basis = bnp.astype(np.int64)
    keys, vals = make_lookup(basis)
    basis.setflags(write=False)
    keys.setflags(write=False)
    vals.setflags(write=False)
    return basis, keys, vals


def _sector_eigh(h1, U, U_orbs, N_orb, basis, keys, vals, beta, sector_key=None):
    """Solve one interacting ED sector exactly.

    The GPU launcher replaces this boundary with a sparse Lanczos backend.
    Keeping the override at the sector boundary avoids constructing a dense
    matrix before dispatching large sectors to the accelerated solver.
    """
    H = build_H_sector_fast(h1, U, U_orbs, N_orb, basis, keys, vals)
    e, ev = eigh(H)
    return e, ev, dict(
        backend="dense_exact",
        dim=int(len(basis)),
        n_returned=int(len(e)),
        truncated=False,
        thermal_tail_bound=0.0,
    )


class ThermalTruncationError(RuntimeError):
    """Raised when truncated sector solves cannot certify finite-T accuracy."""


# Set by solve_min_gpu.patch_all() from BHFM2_THERMAL_TAIL_TOL. None (CPU exact
# path) or inf disables the certificate.
GLOBAL_THERMAL_TAIL_TOL = None


def _certify_global_tail(sector_meta, E0, Z_ret, beta):
    """Certify omitted Boltzmann weight against the GLOBAL thermal sum.

    Every omitted state of a truncated sector lies at or above that sector's
    highest retained energy, so its weight relative to the global ground state
    is bounded by exp(-beta*(e_max_retained - E0)). Summing over truncated
    sectors bounds the total omitted weight, compared against the retained
    partition sum Z_ret.

    This replaces the old per-sector check, which compared a sector's tail to
    its OWN ground state and could abort the whole calculation on a sector
    whose grand-canonical weight is negligible (e.g. strongly spin-imbalanced
    sectors far above E0 with compressed spectra).
    """
    bound = 0.0
    for m in sector_meta:
        if not m.get("truncated"):
            continue
        omitted = int(m["dim"]) - int(m["n_returned"])
        if omitted <= 0:
            continue
        gap = max(0.0, float(m["e_max_retained"]) - float(E0))
        bound += omitted * float(np.exp(np.clip(-beta * gap, -700.0, 700.0)))
    frac = bound / max(float(Z_ret), 1e-300)
    tol = GLOBAL_THERMAL_TAIL_TOL
    if tol is not None and np.isfinite(tol) and frac > tol:
        worst = max(
            (m for m in sector_meta if m.get("truncated")),
            key=lambda m: (int(m["dim"]) - int(m["n_returned"]))
            * np.exp(np.clip(-beta * (float(m["e_max_retained"]) - float(E0)), -700.0, 700.0)),
        )
        raise ThermalTruncationError(
            "Global thermal truncation is not certified: "
            f"omitted_weight/Z_retained={frac:.3e} > {tol:.3e} at beta={beta:.6g}. "
            f"Worst sector={worst.get('sector')} dim={worst['dim']} "
            f"retained={worst['n_returned']}. Increase BHFM2_LANCZOS_K."
        )
    return frac


def _thermal_audit(sector_meta):
    """Summarize exact or certified-truncated sector solves."""
    if not sector_meta:
        return dict(
            backend="none",
            truncated_sectors=0,
            max_sector_dim=0,
            max_states_returned=0,
            max_thermal_tail_bound=0.0,
        )
    backends = sorted({str(m["backend"]) for m in sector_meta})
    return dict(
        backend="+".join(backends),
        truncated_sectors=int(sum(bool(m["truncated"]) for m in sector_meta)),
        max_sector_dim=int(max(m["dim"] for m in sector_meta)),
        max_states_returned=int(max(m["n_returned"] for m in sector_meta)),
        max_thermal_tail_bound=float(max(m["thermal_tail_bound"] for m in sector_meta)),
    )


def lat_obs(p, mp, Mh: int, Mb: int, mode: str = MODE_BONDING_ONLY):
    """Lattice observables with plus channel and optional minus channel."""
    mode = _normalize_mode(mode)
    anti = _has_antibond(mode, Mb)
    ndir = 2 if mp.use_y_bond else 1
    n_orb = 1 + Mh + Mb * ndir + (Mb * ndir if anti else 0)

    hh = np.zeros(Mh)
    dh = np.zeros(Mh)
    hbp_hbp = np.zeros(Mb)
    hbp_d = np.zeros(Mb)
    hbm_hbm = np.zeros(Mb) if anti else np.zeros(0)
    hbm_d = np.zeros(Mb) if anti else np.zeros(0)
    dens = 0.0
    bond_x = 0.0
    e_kin = 0.0

    for eps, wk, ckx, cky, skx, sky, cos_kx in _lattice_quadrature(mp, mode=mode, Mb=Mb):
        H = np.zeros((n_orb, n_orb))
        H[0, 0] = eps + mp.eps_d + mp.Sigma_inf - p.mu
        off = 1
        for a in range(Mh):
            H[off + a, off + a] = p.eta[a]
            H[0, off + a] = p.W[a]
            H[off + a, 0] = p.W[a]
        off += Mh
        for a in range(Mb):
            H[off + a, off + a] = p.eta_b[a]
            amp = p.B_h[a] * ckx
            H[0, off + a] = amp
            H[off + a, 0] = amp
        off += Mb
        if mp.use_y_bond:
            for a in range(Mb):
                H[off + a, off + a] = p.eta_b[a]
                amp = p.B_h[a] * cky
                H[0, off + a] = amp
                H[off + a, 0] = amp
            off += Mb
        if anti:
            for a in range(Mb):
                H[off + a, off + a] = p.eta_a[a]
                amp = p.B_ha[a] * skx
                H[0, off + a] = amp
                H[off + a, 0] = amp
            off += Mb
            if mp.use_y_bond:
                for a in range(Mb):
                    H[off + a, off + a] = p.eta_a[a]
                    amp = p.B_ha[a] * sky
                    H[0, off + a] = amp
                    H[off + a, 0] = amp

        C = _dm(H, mp.beta)
        spin = 2.0
        dens += spin * C[0, 0] * wk
        e_kin += spin * eps * C[0, 0] * wk
        for a in range(Mh):
            hh[a] += spin * C[1 + a, 1 + a] * wk
            dh[a] += spin * C[0, 1 + a] * wk

        off2 = 1 + Mh
        for a in range(Mb):
            idx_x = off2 + a
            hbp_hbp[a] += spin * C[idx_x, idx_x] * wk / ndir
            hbp_d[a] += spin * 2.0 * ckx * C[idx_x, 0] * wk / ndir

        if mp.use_y_bond:
            off2_y = 1 + Mh + Mb
            for a in range(Mb):
                idx_y = off2_y + a
                hbp_hbp[a] += spin * C[idx_y, idx_y] * wk / ndir
                hbp_d[a] += spin * 2.0 * cky * C[idx_y, 0] * wk / ndir

        if anti:
            offm = 1 + Mh + Mb * ndir
            for a in range(Mb):
                idx_xm = offm + a
                hbm_hbm[a] += spin * C[idx_xm, idx_xm] * wk / ndir
                hbm_d[a] += spin * 2.0 * skx * C[idx_xm, 0] * wk / ndir
            if mp.use_y_bond:
                offm_y = offm + Mb
                for a in range(Mb):
                    idx_ym = offm_y + a
                    hbm_hbm[a] += spin * C[idx_ym, idx_ym] * wk / ndir
                    hbm_d[a] += spin * 2.0 * sky * C[idx_ym, 0] * wk / ndir

        bond_x += spin * cos_kx * C[0, 0] * wk

    return dict(
        hh=hh,
        dh=dh,
        hbp_hbp=hbp_hbp,
        hbp_d=hbp_d,
        hbm_hbm=hbm_hbm,
        hbm_d=hbm_d,
        dens=float(dens),
        bond_x=float(bond_x),
        e_kin=float(e_kin),
    )


def gw1_obs(p, mp, Mh: int, Mg: int | None = None):
    """gw1: [d, g(Mg), h(Mh)]"""
    if Mg is None:
        Mg = Mh
    n_orb = 1 + Mg + Mh
    H = np.zeros((n_orb, n_orb))
    H[0, 0] = mp.eps_d + mp.Sigma_inf - p.mu
    og = 1
    oh = 1 + Mg
    for a in range(Mg):
        H[og + a, og + a] = p.eps1[a]
        H[0, og + a] = p.V1[a]
        H[og + a, 0] = p.V1[a]
    for a in range(Mh):
        H[oh + a, oh + a] = p.eta1[a]
        H[0, oh + a] = p.W1[a]
        H[oh + a, 0] = p.W1[a]
    C = _dm(H, mp.beta)
    spin = 2.0
    return dict(
        gg=np.array([spin * C[og + a, og + a] for a in range(Mg)]),
        dg=np.array([spin * C[0, og + a] for a in range(Mg)]),
        hh=np.array([spin * C[oh + a, oh + a] for a in range(Mh)]),
        dh=np.array([spin * C[0, oh + a] for a in range(Mh)]),
        dens=float(spin * C[0, 0]),
    )


def gw2_obs(p, mp, Mh: int, Mg: int, Mb: int | None = None, mode: str = MODE_BONDING_ONLY):
    """Two-site gateway observables with plus channel and optional minus channel."""
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    anti = _has_antibond(mode, Mb)

    d1, d2 = 0, 1
    oh1 = 2
    oh2 = oh1 + Mh
    ohbp = oh2 + Mh
    ohbm = ohbp + Mb if anti else ohbp
    og1 = ohbm + (Mb if anti else 0)
    og2 = og1 + Mg
    ogbp = og2 + Mg
    ogbm = ogbp + Mb
    n_orb = (ogbm + Mb) if anti else (ogbp + Mb)

    H = np.zeros((n_orb, n_orb))
    shift = mp.eps_d + mp.Sigma_inf - p.mu
    H[d1, d1] = shift
    H[d2, d2] = shift
    H[d1, d2] = H[d2, d1] = -mp.t

    for a in range(Mh):
        H[oh1 + a, oh1 + a] = p.eta2[a]
        H[oh2 + a, oh2 + a] = p.eta2[a]
        H[d1, oh1 + a] = p.W2[a]
        H[oh1 + a, d1] = p.W2[a]
        H[d2, oh2 + a] = p.W2[a]
        H[oh2 + a, d2] = p.W2[a]

    for b in range(Mb):
        H[ohbp + b, ohbp + b] = p.eta_b2[b]
        amp = p.B_h2[b] / 2.0
        H[d1, ohbp + b] = amp
        H[ohbp + b, d1] = amp
        H[d2, ohbp + b] = amp
        H[ohbp + b, d2] = amp

    if anti:
        for b in range(Mb):
            H[ohbm + b, ohbm + b] = p.eta_a2[b]
            amp = p.B_ha2[b] / 2.0
            H[d1, ohbm + b] = amp
            H[ohbm + b, d1] = amp
            H[d2, ohbm + b] = -amp
            H[ohbm + b, d2] = -amp

    for a in range(Mg):
        H[og1 + a, og1 + a] = p.eps2[a]
        H[og2 + a, og2 + a] = p.eps2[a]
        H[d1, og1 + a] = p.V2[a]
        H[og1 + a, d1] = p.V2[a]
        H[d2, og2 + a] = p.V2[a]
        H[og2 + a, d2] = p.V2[a]

    for b in range(Mb):
        H[ogbp + b, ogbp + b] = p.eps_b[b]
        amp = p.B_g[b] / 2.0
        H[d1, ogbp + b] = amp
        H[ogbp + b, d1] = amp
        H[d2, ogbp + b] = amp
        H[ogbp + b, d2] = amp

    if anti:
        for b in range(Mb):
            H[ogbm + b, ogbm + b] = p.eps_a[b]
            amp = p.B_ga[b] / 2.0
            H[d1, ogbm + b] = amp
            H[ogbm + b, d1] = amp
            H[d2, ogbm + b] = -amp
            H[ogbm + b, d2] = -amp

    C = _dm(H, mp.beta)
    spin = 2.0
    hh = np.zeros(Mh)
    dh = np.zeros(Mh)
    gg = np.zeros(Mg)
    dg = np.zeros(Mg)
    for a in range(Mh):
        i1, i2 = oh1 + a, oh2 + a
        hh[a] = spin * 0.5 * (C[i1, i1] + C[i2, i2])
        dh[a] = spin * 0.5 * (C[d1, i1] + C[d2, i2])
    for a in range(Mg):
        j1, j2 = og1 + a, og2 + a
        gg[a] = spin * 0.5 * (C[j1, j1] + C[j2, j2])
        dg[a] = spin * 0.5 * (C[d1, j1] + C[d2, j2])

    hbp_hbp = np.zeros(Mb)
    hbp_dplus = np.zeros(Mb)
    gbp_gbp = np.zeros(Mb)
    gbp_dplus = np.zeros(Mb)
    hbm_hbm = np.zeros(Mb) if anti else np.zeros(0)
    hbm_dminus = np.zeros(Mb) if anti else np.zeros(0)
    gbm_gbm = np.zeros(Mb) if anti else np.zeros(0)
    gbm_dminus = np.zeros(Mb) if anti else np.zeros(0)
    for b in range(Mb):
        ip = ohbp + b
        hbp_hbp[b] = spin * C[ip, ip]
        hbp_dplus[b] = spin * (C[d1, ip] + C[d2, ip])
        jp = ogbp + b
        gbp_gbp[b] = spin * C[jp, jp]
        gbp_dplus[b] = spin * (C[d1, jp] + C[d2, jp])
    if anti:
        for b in range(Mb):
            im = ohbm + b
            hbm_hbm[b] = spin * C[im, im]
            hbm_dminus[b] = spin * (C[d1, im] - C[d2, im])
            jm = ogbm + b
            gbm_gbm[b] = spin * C[jm, jm]
            gbm_dminus[b] = spin * (C[d1, jm] - C[d2, jm])

    return dict(
        hh=hh,
        dh=dh,
        gg=gg,
        dg=dg,
        hbp_hbp=hbp_hbp,
        hbp_dplus=hbp_dplus,
        gbp_gbp=gbp_gbp,
        gbp_dplus=gbp_dplus,
        hbm_hbm=hbm_hbm,
        hbm_dminus=hbm_dminus,
        gbm_gbm=gbm_gbm,
        gbm_dminus=gbm_dminus,
        dens_per_site=float(spin * 0.5 * (C[d1, d1] + C[d2, d2])),
        bond_kinetic_per_bond=float(spin * C[d1, d2]),
    )


GS_DEGEN_TOL = 1e-9  # grand-canonical energy window (code units) for the T=0 ground manifold


def _gs_manifold(all_states, energies, E0, tol=GS_DEGEN_TOL):
    """Real ground-state wavefunction(s): the eigenpairs within `tol` of E0.

    At T=0 the observables are an equal-weight average over this degenerate
    manifold. Returns a dict carrying the ACTUAL eigenvectors so callers can
    inspect the ground-state composition (e.g. metal Kondo-singlet g=1 vs Mott
    local-moment doublet g=2), plus the index array of manifold members."""
    idx = np.flatnonzero(energies - E0 < tol)
    states = []
    for k in idx:
        E, psi, basis, keys, vals = all_states[k]
        states.append(dict(energy=float(E), psi=np.asarray(psi).copy(),
                           basis=basis, keys=keys, vals=vals))
    gs = dict(energy=float(E0), degeneracy=int(idx.size), tol=float(tol), states=states)
    return gs, idx


def _state_weights(all_states, sector_meta, mp):
    """Boltzmann (finite-T) or ground-manifold (T=0) weights over all_states.

    Finite T: w_i ~ exp(-beta(E_i-E0)), omega = E0 - ln(Z)/beta (thermal-tail
    certified). Ground state (mp.ground_state): project onto the degenerate
    ground manifold (E_i-E0 < GS_DEGEN_TOL) with equal weights and omega = E0
    exactly (the entropy term T*ln g -> 0); the beta=1e8 thermal-tail
    certificate is vacuous and is skipped (dense ED keeps every state).
    Returns (w, omega, gs) where gs is the wavefunction dict at T=0 else None."""
    energies = np.array([s[0] for s in all_states])
    E0 = float(energies.min())
    if getattr(mp, "ground_state", False):
        gs, idx = _gs_manifold(all_states, energies, E0)
        w = np.zeros(len(all_states))
        w[idx] = 1.0 / max(int(idx.size), 1)
        return w, E0, gs
    w = np.exp(-mp.beta * (energies - E0))
    Z = float(w.sum())
    omega = float(E0 - np.log(max(Z, 1e-300)) / mp.beta)
    w = w / Z
    _certify_global_tail(sector_meta, E0, Z, mp.beta)
    return w, omega, None


def imp1_obs(p, mp, Mg: int):
    """imp1 ED: [d, g(Mg)] with U on d."""
    N_orb = 1 + Mg
    h1 = np.zeros((N_orb, N_orb))
    h1[0, 0] = mp.eps_d - p.mu
    for a in range(Mg):
        h1[1 + a, 1 + a] = p.eps1[a]
        h1[0, 1 + a] = p.V1[a]
        h1[1 + a, 0] = p.V1[a]

    U_orbs = np.array([0], dtype=np.int64)
    all_states = []
    sector_meta = []
    for N_up in range(N_orb + 1):
        for N_dn in range(N_orb + 1):
            basis, keys, vals = _sector_basis(N_orb, N_up, N_dn)
            if len(basis) == 0:
                continue
            e, ev, meta = _sector_eigh(
                h1, mp.U, U_orbs, N_orb, basis, keys, vals, mp.beta, sector_key=(N_up, N_dn)
            )
            sector_meta.append(meta)
            for j in range(len(e)):
                all_states.append((float(e[j]), ev[:, j], basis, keys, vals))

    w, omega, gs = _state_weights(all_states, sector_meta, mp)

    n_d = 0.0
    D = 0.0
    gg = np.zeros(Mg)
    dg = np.zeros(Mg)
    for (E, psi, basis, keys, vals), wi in zip(all_states, w):
        if wi < 1e-14:
            continue
        n_d += wi * expect_n_fast(0, psi, basis, N_orb)
        D += wi * expect_double_fast(0, psi, basis, N_orb)
        for a in range(Mg):
            gg[a] += wi * expect_n_fast(1 + a, psi, basis, N_orb)
            dg[a] += wi * expect_cdag_c_fast(1 + a, 0, psi, basis, keys, vals, N_orb)
    return dict(
        dens=n_d,
        double_occ=D,
        gg=gg,
        dg=dg,
        omega=omega,
        gs=gs,
        thermal_audit=_thermal_audit(sector_meta),
    )


def imp2_h1(p, mp, Mg: int, Mb: int, mode: str = MODE_BONDING_ONLY):
    """Build the two-site interacting impurity one-body Hamiltonian."""
    anti = _has_antibond(mode, Mb)
    d1, d2 = 0, 1
    og1 = 2
    og2 = og1 + Mg
    ogbp = og2 + Mg
    ogbm = ogbp + Mb
    N_orb = (ogbm + Mb) if anti else (ogbp + Mb)

    h1 = np.zeros((N_orb, N_orb))
    h1[d1, d1] = mp.eps_d - p.mu
    h1[d2, d2] = mp.eps_d - p.mu
    h1[d1, d2] = -mp.t
    h1[d2, d1] = -mp.t
    for a in range(Mg):
        i1, i2 = og1 + a, og2 + a
        h1[i1, i1] = p.eps2[a]
        h1[i2, i2] = p.eps2[a]
        h1[d1, i1] = p.V2[a]
        h1[i1, d1] = p.V2[a]
        h1[d2, i2] = p.V2[a]
        h1[i2, d2] = p.V2[a]
    for b in range(Mb):
        ip = ogbp + b
        h1[ip, ip] = p.eps_b[b]
        amp = p.B_g[b] / 2.0
        h1[d1, ip] = amp
        h1[ip, d1] = amp
        h1[d2, ip] = amp
        h1[ip, d2] = amp
    if anti:
        for b in range(Mb):
            im = ogbm + b
            h1[im, im] = p.eps_a[b]
            amp = p.B_ga[b] / 2.0
            h1[d1, im] = amp
            h1[im, d1] = amp
            h1[d2, im] = -amp
            h1[im, d2] = -amp

    return h1, np.array([d1, d2], dtype=np.int64)


def imp2_obs(p, mp, Mg: int, Mb: int, mode: str = MODE_BONDING_ONLY):
    """Two-site interacting impurity with plus channel and optional minus channel."""
    anti = _has_antibond(mode, Mb)
    d1, d2 = 0, 1
    og1 = 2
    og2 = og1 + Mg
    ogbp = og2 + Mg
    ogbm = ogbp + Mb
    h1, U_orbs = imp2_h1(p, mp, Mg, Mb, mode=mode)
    N_orb = h1.shape[0]
    all_states = []
    sector_meta = []
    for N_up in range(N_orb + 1):
        for N_dn in range(N_orb + 1):
            basis, keys, vals = _sector_basis(N_orb, N_up, N_dn)
            if len(basis) == 0:
                continue
            e, ev, meta = _sector_eigh(
                h1, mp.U, U_orbs, N_orb, basis, keys, vals, mp.beta, sector_key=(N_up, N_dn)
            )
            sector_meta.append(meta)
            for j in range(len(e)):
                all_states.append((float(e[j]), ev[:, j], basis, keys, vals))

    w, omega, gs = _state_weights(all_states, sector_meta, mp)

    n_d1 = 0.0
    n_d2 = 0.0
    D_avg = 0.0
    gg = np.zeros(Mg)
    dg = np.zeros(Mg)
    gbp_gbp = np.zeros(Mb)
    gbp_dplus = np.zeros(Mb)
    gbm_gbm = np.zeros(Mb) if anti else np.zeros(0)
    gbm_dminus = np.zeros(Mb) if anti else np.zeros(0)
    bond_kin = 0.0
    for (E, psi, basis, keys, vals), wi in zip(all_states, w):
        if wi < 1e-14:
            continue
        n_d1 += wi * expect_n_fast(d1, psi, basis, N_orb)
        n_d2 += wi * expect_n_fast(d2, psi, basis, N_orb)
        D_avg += wi * 0.5 * (
            expect_double_fast(d1, psi, basis, N_orb) + expect_double_fast(d2, psi, basis, N_orb)
        )
        bond_kin += wi * expect_cdag_c_fast(d1, d2, psi, basis, keys, vals, N_orb)
        for a in range(Mg):
            i1, i2 = og1 + a, og2 + a
            gg[a] += wi * 0.5 * (
                expect_n_fast(i1, psi, basis, N_orb) + expect_n_fast(i2, psi, basis, N_orb)
            )
            dg[a] += wi * 0.5 * (
                expect_cdag_c_fast(i1, d1, psi, basis, keys, vals, N_orb)
                + expect_cdag_c_fast(i2, d2, psi, basis, keys, vals, N_orb)
            )
        for b in range(Mb):
            ip = ogbp + b
            gbp_gbp[b] += wi * expect_n_fast(ip, psi, basis, N_orb)
            gbp_dplus[b] += wi * (
                expect_cdag_c_fast(ip, d1, psi, basis, keys, vals, N_orb)
                + expect_cdag_c_fast(ip, d2, psi, basis, keys, vals, N_orb)
            )
        if anti:
            for b in range(Mb):
                im = ogbm + b
                gbm_gbm[b] += wi * expect_n_fast(im, psi, basis, N_orb)
                gbm_dminus[b] += wi * (
                    expect_cdag_c_fast(im, d1, psi, basis, keys, vals, N_orb)
                    - expect_cdag_c_fast(im, d2, psi, basis, keys, vals, N_orb)
                )

    return dict(
        n_d1=n_d1,
        n_d2=n_d2,
        dens_per_site=0.5 * (n_d1 + n_d2),
        double_occ_per_site=D_avg,
        gg=gg,
        dg=dg,
        gbp_gbp=gbp_gbp,
        gbp_dplus=gbp_dplus,
        gbm_gbm=gbm_gbm,
        gbm_dminus=gbm_dminus,
        bond_kinetic_per_bond=bond_kin,
        omega=omega,
        omega_per_site=0.5 * omega,
        gs=gs,
        thermal_audit=_thermal_audit(sector_meta),
    )


def _omega_quadratic(evals, beta, spin=2.0):
    evals = np.asarray(evals, dtype=float)
    return float(-(spin / beta) * np.sum(np.logaddexp(0.0, -beta * evals)))


def atomic_impurity_grand_potential(U, beta, mu=None, eps_d=0.0):
    """Closed-form single-orbital atomic grand potential for sign checks."""
    mu = 0.5 * U if mu is None else float(mu)
    e1 = eps_d - mu
    e2 = 2.0 * (eps_d - mu) + U
    weights = np.array([0.0, e1, e1, e2], dtype=float)
    e0 = float(np.min(weights))
    zpart = float(np.sum(np.exp(np.clip(-beta * (weights - e0), -700.0, 700.0))))
    return float(e0 - np.log(max(zpart, 1e-300)) / beta)


def lat_grand_potential(p, mp, Mh: int, Mb: int, mode: str = MODE_BONDING_ONLY):
    """Quadratic lattice grand potential per physical site."""
    mode = _normalize_mode(mode)
    anti = _has_antibond(mode, Mb)
    ndir = 2 if mp.use_y_bond else 1
    n_orb = 1 + Mh + Mb * ndir + (Mb * ndir if anti else 0)
    out = 0.0
    for eps, wk, ckx, cky, skx, sky, _cos_kx in _lattice_quadrature(mp, mode=mode, Mb=Mb):
        H = np.zeros((n_orb, n_orb))
        H[0, 0] = eps + mp.eps_d + mp.Sigma_inf - p.mu
        off = 1
        for a in range(Mh):
            H[off + a, off + a] = p.eta[a]
            H[0, off + a] = H[off + a, 0] = p.W[a]
        off += Mh
        for a in range(Mb):
            H[off + a, off + a] = p.eta_b[a]
            amp = p.B_h[a] * ckx
            H[0, off + a] = H[off + a, 0] = amp
        off += Mb
        if mp.use_y_bond:
            for a in range(Mb):
                H[off + a, off + a] = p.eta_b[a]
                amp = p.B_h[a] * cky
                H[0, off + a] = H[off + a, 0] = amp
            off += Mb
        if anti:
            for a in range(Mb):
                H[off + a, off + a] = p.eta_a[a]
                amp = p.B_ha[a] * skx
                H[0, off + a] = H[off + a, 0] = amp
            off += Mb
            if mp.use_y_bond:
                for a in range(Mb):
                    H[off + a, off + a] = p.eta_a[a]
                    amp = p.B_ha[a] * sky
                    H[0, off + a] = H[off + a, 0] = amp
        out += wk * _omega_quadratic(eigh(H)[0], mp.beta)
    return float(out)


def gw1_grand_potential(p, mp, Mh: int, Mg: int | None = None):
    """Quadratic single-site gateway grand potential."""
    if Mg is None:
        Mg = Mh
    n_orb = 1 + Mg + Mh
    H = np.zeros((n_orb, n_orb))
    H[0, 0] = mp.eps_d + mp.Sigma_inf - p.mu
    og, oh = 1, 1 + Mg
    for a in range(Mg):
        H[og + a, og + a] = p.eps1[a]
        H[0, og + a] = H[og + a, 0] = p.V1[a]
    for a in range(Mh):
        H[oh + a, oh + a] = p.eta1[a]
        H[0, oh + a] = H[oh + a, 0] = p.W1[a]
    return _omega_quadratic(eigh(H)[0], mp.beta)


def gw2_grand_potential(p, mp, Mh: int, Mg: int, Mb: int | None = None, mode: str = MODE_BONDING_ONLY):
    """Quadratic two-site gateway grand potential for the full cluster."""
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    anti = _has_antibond(mode, Mb)
    d1, d2 = 0, 1
    oh1 = 2
    oh2 = oh1 + Mh
    ohbp = oh2 + Mh
    ohbm = ohbp + Mb if anti else ohbp
    og1 = ohbm + (Mb if anti else 0)
    og2 = og1 + Mg
    ogbp = og2 + Mg
    ogbm = ogbp + Mb
    n_orb = (ogbm + Mb) if anti else (ogbp + Mb)
    H = np.zeros((n_orb, n_orb))
    shift = mp.eps_d + mp.Sigma_inf - p.mu
    H[d1, d1] = H[d2, d2] = shift
    H[d1, d2] = H[d2, d1] = -mp.t
    for a in range(Mh):
        H[oh1 + a, oh1 + a] = H[oh2 + a, oh2 + a] = p.eta2[a]
        H[d1, oh1 + a] = H[oh1 + a, d1] = p.W2[a]
        H[d2, oh2 + a] = H[oh2 + a, d2] = p.W2[a]
    for b in range(Mb):
        H[ohbp + b, ohbp + b] = p.eta_b2[b]
        amp = p.B_h2[b] / 2.0
        H[d1, ohbp + b] = H[ohbp + b, d1] = amp
        H[d2, ohbp + b] = H[ohbp + b, d2] = amp
    if anti:
        for b in range(Mb):
            H[ohbm + b, ohbm + b] = p.eta_a2[b]
            amp = p.B_ha2[b] / 2.0
            H[d1, ohbm + b] = H[ohbm + b, d1] = amp
            H[d2, ohbm + b] = H[ohbm + b, d2] = -amp
    for a in range(Mg):
        H[og1 + a, og1 + a] = H[og2 + a, og2 + a] = p.eps2[a]
        H[d1, og1 + a] = H[og1 + a, d1] = p.V2[a]
        H[d2, og2 + a] = H[og2 + a, d2] = p.V2[a]
    for b in range(Mb):
        H[ogbp + b, ogbp + b] = p.eps_b[b]
        amp = p.B_g[b] / 2.0
        H[d1, ogbp + b] = H[ogbp + b, d1] = amp
        H[d2, ogbp + b] = H[ogbp + b, d2] = amp
    if anti:
        for b in range(Mb):
            H[ogbm + b, ogbm + b] = p.eps_a[b]
            amp = p.B_ga[b] / 2.0
            H[d1, ogbm + b] = H[ogbm + b, d1] = amp
            H[d2, ogbm + b] = H[ogbm + b, d2] = -amp
    return _omega_quadratic(eigh(H)[0], mp.beta)


def compute_omega_scheme(
    p,
    mp,
    Mh: int,
    Mg: int,
    Mb: int | None = None,
    mode: str = MODE_BONDING_ONLY,
    imp1=None,
    imp2=None,
):
    """Compute Omega_imp + Omega_lat - Omega_gateway in the code's K=H-muN convention."""
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    mode = _normalize_mode(mode)
    if _is_single_impurity(mode) and Mb != 0:
        raise ValueError("single_impurity mode requires Mb=0")
    imp1 = imp1 if imp1 is not None else imp1_obs(p, mp, Mg)
    omega_lat = lat_grand_potential(p, mp, Mh, Mb, mode=mode)
    omega_gw1 = gw1_grand_potential(p, mp, Mh, Mg)
    omega_imp1 = float(imp1["omega"])
    if _is_single_impurity(mode):
        omega_imp = omega_imp1
        omega_gateway = omega_gw1
        out = dict(
            Omega_imp=omega_imp,
            Omega_lat=omega_lat,
            Omega_gateway=omega_gateway,
            Omega_total=omega_imp + omega_lat - omega_gateway,
            Omega_imp1=omega_imp1,
            Omega_imp2=np.nan,
            Omega_imp2_per_site=np.nan,
            Omega_gateway1=omega_gw1,
            Omega_gateway2=np.nan,
            Omega_gateway2_per_site=np.nan,
        )
    else:
        imp2 = imp2 if imp2 is not None else imp2_obs(p, mp, Mg, Mb, mode=mode)
        omega_imp2 = float(imp2["omega"])
        omega_imp2_per_site = float(imp2["omega_per_site"])
        omega_gw2 = gw2_grand_potential(p, mp, Mh, Mg, Mb, mode=mode)
        omega_gw2_per_site = 0.5 * omega_gw2
        z = mp.z
        omega_imp = (1.0 - z) * omega_imp1 + z * omega_imp2_per_site
        omega_gateway = (1.0 - z) * omega_gw1 + z * omega_gw2_per_site
        out = dict(
            Omega_imp=omega_imp,
            Omega_lat=omega_lat,
            Omega_gateway=omega_gateway,
            Omega_total=omega_imp + omega_lat - omega_gateway,
            Omega_imp1=omega_imp1,
            Omega_imp2=omega_imp2,
            Omega_imp2_per_site=omega_imp2_per_site,
            Omega_gateway1=omega_gw1,
            Omega_gateway2=omega_gw2,
            Omega_gateway2_per_site=omega_gw2_per_site,
        )
    out["Omega_convention"] = "K=H-mu*N; Omega=-T*log(Tr exp(-beta*K)); Omega_total=Omega_imp+Omega_lat-Omega_gateway"
    return out


def mom_lat(p, m, mode: str = MODE_BONDING_ONLY):
    s = float(np.sum(p.W**2 * p.eta**m))
    s += float(np.sum(p.B_h**2 * p.eta_b**m))
    if _has_antibond(mode, len(np.asarray(p.B_h).ravel())):
        s += float(np.sum(np.asarray(p.B_ha, dtype=float) ** 2 * np.asarray(p.eta_a, dtype=float) ** m))
    return s


def mom_imp1(p, m):
    return float(np.sum(p.W1**2 * p.eta1**m))


def mom_imp2(p, m, mode: str = MODE_BONDING_ONLY):
    s = float(np.sum(p.W2**2 * p.eta2**m))
    s += float(np.sum(p.B_h2**2 * p.eta_b2**m))
    if _has_antibond(mode, len(np.asarray(p.B_h2).ravel())):
        s += float(np.sum(np.asarray(p.B_ha2, dtype=float) ** 2 * np.asarray(p.eta_a2, dtype=float) ** m))
    return s


def residual_min(
    p,
    mp_base,
    Mh: int,
    Mg: int,
    Mb: int | None = None,
    mode: str = MODE_BONDING_ONLY,
):
    """Residual for site+bond scheme with optional anti-bond channel."""
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    mode = _normalize_mode(mode)
    if _is_single_impurity(mode) and Mb != 0:
        raise ValueError("single_impurity mode requires Mb=0")
    anti = _has_antibond(mode, Mb)
    z = mp_base.z
    imp1 = imp1_obs(p, mp_base, Mg)
    if _is_single_impurity(mode):
        n_avg = imp1["dens"]
        Sigma_inf_iter = mp_base.U * n_avg / 2.0
        mp = replace(mp_base, Sigma_inf=Sigma_inf_iter)
        lat = lat_obs(p, mp, Mh, Mb, mode=mode)
        gw1 = gw1_obs(p, mp, Mh, Mg)
        r = []
        r.extend((lat["hh"] - gw1["hh"]).tolist())
        r.extend((lat["dh"] - gw1["dh"]).tolist())
        r.extend((imp1["gg"] - gw1["gg"]).tolist())
        r.extend((imp1["dg"] - gw1["dg"]).tolist())
        r.append(n_avg - mp_base.filling_target)
        r.append(lat["dens"] - mp_base.filling_target)
        for m in range(mp_base.n_moments):
            r.append(mom_lat(p, m, mode=mode) - mom_imp1(p, m))
        return np.array(r, dtype=float)

    imp2 = imp2_obs(p, mp_base, Mg, Mb, mode=mode)
    n_avg = (1 - z) * imp1["dens"] + z * imp2["dens_per_site"]
    Sigma_inf_iter = mp_base.U * n_avg / 2.0
    mp = replace(mp_base, Sigma_inf=Sigma_inf_iter)
    lat = lat_obs(p, mp, Mh, Mb, mode=mode)
    gw1 = gw1_obs(p, mp, Mh, Mg)
    gw2 = gw2_obs(p, mp, Mh, Mg, Mb, mode=mode)

    r = []
    r.extend((lat["hh"] - ((1 - z) * gw1["hh"] + z * gw2["hh"])).tolist())
    r.extend((lat["dh"] - ((1 - z) * gw1["dh"] + z * gw2["dh"])).tolist())
    r.extend((lat["hbp_hbp"] - gw2["hbp_hbp"]).tolist())
    r.extend((lat["hbp_d"] - gw2["hbp_dplus"]).tolist())
    r.extend((imp1["gg"] - gw1["gg"]).tolist())
    r.extend((imp1["dg"] - gw1["dg"]).tolist())
    r.extend((imp2["gg"] - gw2["gg"]).tolist())
    r.extend((imp2["dg"] - gw2["dg"]).tolist())
    r.extend((imp2["gbp_gbp"] - gw2["gbp_gbp"]).tolist())
    r.extend((imp2["gbp_dplus"] - gw2["gbp_dplus"]).tolist())
    if anti:
        r.extend((lat["hbm_hbm"] - gw2["hbm_hbm"]).tolist())
        r.extend((lat["hbm_d"] - gw2["hbm_dminus"]).tolist())
        r.extend((imp2["gbm_gbm"] - gw2["gbm_gbm"]).tolist())
        r.extend((imp2["gbm_dminus"] - gw2["gbm_dminus"]).tolist())
    r.append(n_avg - mp_base.filling_target)
    r.append(lat["dens"] - mp_base.filling_target)
    r.append(lat["bond_x"] - imp2["bond_kinetic_per_bond"])
    for m in range(mp_base.n_moments):
        lhs = mom_lat(p, m, mode=mode)
        rhs = (1 - z) * mom_imp1(p, m) + z * mom_imp2(p, m, mode=mode)
        r.append(lhs - rhs)
    return np.array(r, dtype=float)


def make_bounds_min(
    Mh: int,
    Mg: int | None = None,
    Mb: int | None = None,
    E=5.0,
    C=3.0,
    mu_lo=-5.0,
    mu_hi=5.0,
    mode: str = MODE_BONDING_ONLY,
    fixed_mu: float | None = None,
    E_eta: float | None = None,
):
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    mode = _normalize_mode(mode)
    if _is_single_impurity(mode) and Mb != 0:
        raise ValueError("single_impurity mode requires Mb=0")
    anti = _has_antibond(mode, Mb)
    # Self-energy (eta) poles may use a separate cap Eh from the bath (eps)
    # energies; E_eta=None -> share the bath bound E (back-compatible default).
    Eh = E if E_eta is None else E_eta
    if _is_single_impurity(mode):
        fields = [
            ("eta", Mh, -Eh, Eh),
            ("W", Mh, 1e-8, C),
            ("eps1", Mg, -E, E),
            ("V1", Mg, 1e-8, C),
            ("eta1", Mh, -Eh, Eh),
            ("W1", Mh, 1e-8, C),
        ]
    else:
        fields = [
            ("eta", Mh, -Eh, Eh),
            ("W", Mh, 1e-8, C),
            ("eta_b", Mb, -Eh, Eh),
            ("B_h", Mb, 1e-8, C),
            ("eps1", Mg, -E, E),
            ("V1", Mg, 1e-8, C),
            ("eta1", Mh, -Eh, Eh),
            ("W1", Mh, 1e-8, C),
            ("eps2", Mg, -E, E),
            ("V2", Mg, 1e-8, C),
            ("eta2", Mh, -Eh, Eh),
            ("W2", Mh, 1e-8, C),
            ("eta_b2", Mb, -Eh, Eh),
            ("B_h2", Mb, 1e-8, C),
            ("eps_b", Mb, -E, E),
            ("B_g", Mb, 1e-8, C),
        ]
    if anti:
        fields.extend(
            [
                ("eta_a", Mb, -Eh, Eh),
                ("B_ha", Mb, 1e-8, C),
                ("eta_a2", Mb, -Eh, Eh),
                ("B_ha2", Mb, 1e-8, C),
                ("eps_a", Mb, -E, E),
                ("B_ga", Mb, 1e-8, C),
            ]
        )
    lo = []
    hi = []
    for _, n, l, h in fields:
        lo.extend([l] * n)
        hi.extend([h] * n)
    if fixed_mu is None:
        lo.append(mu_lo)
        hi.append(mu_hi)
    return np.array(lo), np.array(hi)


def _first(arr):
    aa = np.asarray(arr, dtype=float).ravel()
    return float(aa[0]) if len(aa) else float("nan")


def solve_min(
    mp0,
    Mh: int,
    Mg: int,
    Mb: int,
    filling_target,
    p_init=None,
    max_nfev=400,
    ftol=1e-12,
    xtol=1e-12,
    verbose=False,
    mode: str = MODE_BONDING_ONLY,
):
    mode = _normalize_mode(mode)
    mp = replace(mp0, filling_target=filling_target)
    codec = CodecMin(Mh, Mg, Mb, mode=mode)
    lo, hi = make_bounds_min(Mh, Mg, Mb, mode=mode)
    if p_init is None:
        mu0 = mp.U * filling_target / 2.0
        p_init = init_min(Mh, Mg, Mb, W0=0.3, V0=0.3, B0=0.1, base_mu=mu0, mode=mode)
    x0 = codec.pack(p_init)
    x0 = np.clip(x0, lo + 1e-8, hi - 1e-8)
    t0 = time.time()
    niter = [0]

    def fn(x):
        niter[0] += 1
        pp = codec.unpack(x)
        r = residual_min(pp, mp, Mh, Mg, Mb, mode=mode)
        if verbose and niter[0] % 30 == 1:
            print(f"    nfev={niter[0]:3d}  ||r||={np.linalg.norm(r):.3e}  t={time.time()-t0:.0f}s", flush=True)
        return r

    sol = least_squares(fn, x0, method="trf", bounds=(lo, hi), ftol=ftol, xtol=xtol, max_nfev=max_nfev, verbose=0)
    p = codec.unpack(sol.x)
    z = mp.z
    imp1 = imp1_obs(p, mp, Mg)
    if _is_single_impurity(mode):
        imp2 = None
        n_avg = imp1["dens"]
    else:
        imp2 = imp2_obs(p, mp, Mg, Mb, mode=mode)
        n_avg = (1 - z) * imp1["dens"] + z * imp2["dens_per_site"]
    Sigma_inf_final = mp.U * n_avg / 2.0
    mp_final = replace(mp, Sigma_inf=Sigma_inf_final)
    lat = lat_obs(p, mp_final, Mh, Mb, mode=mode)
    D_lat = (
        imp1["double_occ"]
        if _is_single_impurity(mode)
        else (1 - z) * imp1["double_occ"] + z * imp2["double_occ_per_site"]
    )
    info = dict(
        Mh=int(Mh),
        Mg=int(Mg),
        Mb=int(Mb),
        M=int(Mh),
        n_target=filling_target,
        n_avg=n_avg,
        n_lat=lat["dens"],
        n_imp1=imp1["dens"],
        n_imp2=np.nan if imp2 is None else imp2["dens_per_site"],
        D_imp1=imp1["double_occ"],
        D_imp2=np.nan if imp2 is None else imp2["double_occ_per_site"],
        D_lat=D_lat,
        mu=p.mu,
        Sigma_inf=Sigma_inf_final,
        resnorm=float(np.linalg.norm(sol.fun)),
        nfev=sol.nfev,
        wall=time.time() - t0,
        mode=mode,
        W=_first(p.W),
        V1=_first(p.V1),
        V2=_first(p.V2),
        W1=_first(p.W1),
        W2=_first(p.W2),
        B_h=_first(p.B_h),
        B_h2=_first(p.B_h2),
        B_g=_first(p.B_g),
        eta=_first(p.eta),
        eta_b=_first(p.eta_b),
        eps1=_first(p.eps1),
        eps2=_first(p.eps2),
        eps_b=_first(p.eps_b),
        eta1=_first(p.eta1),
        eta2=_first(p.eta2),
        B_ha=_first(getattr(p, "B_ha", [])),
        B_ha2=_first(getattr(p, "B_ha2", [])),
        B_ga=_first(getattr(p, "B_ga", [])),
        eta_a=_first(getattr(p, "eta_a", [])),
        eta_a2=_first(getattr(p, "eta_a2", [])),
        eps_a=_first(getattr(p, "eps_a", [])),
    )
    return p, mp_final, info


if __name__ == "__main__":
    mp0 = ModelParamsMin(U=1.3, t=0.5, beta=0.5, Nk=16)
    Mh, Mg, Mb = 2, 3, 1
    mode = MODE_BONDING_ONLY
    print("Minimal solver test at U=1.3, T=2, half filling")
    p0 = init_min(Mh, Mg, Mb, mode=mode)
    print(
        f"  n_params = {CodecMin(Mh, Mg, Mb, mode=mode).size}, "
        f"n_eqs = {len(residual_min(p0, mp0, Mh, Mg, Mb, mode=mode))}"
    )
    p, mp_f, info = solve_min(mp0, Mh, Mg, Mb, 1.0, max_nfev=80, verbose=True, mode=mode)
    print(f"\nResult: ||r||={info['resnorm']:.3e}  wall={info['wall']:.1f}s  nfev={info['nfev']}")
    print(f"  n_avg={info['n_avg']:.6f}  mu={info['mu']:+.4f}  Sigma_inf={info['Sigma_inf']:+.4f}")
    print(f"  D_imp1={info['D_imp1']:.5f} D_imp2={info['D_imp2']:.5f} D_lat={info['D_lat']:.5f}")
    print(f"  W={info['W']:.4f} V2={info['V2']:.4f} B_h={info['B_h']:.4f} B_g={info['B_g']:.4f}")
