"""PH-reduced NCS site+bond layer — the R4 rebuild (runbook section 5).

A thin layer over the audited observable stack (solve_min residual blocks =
the professor's row set, draft Table 1): a particle-hole-reduced coordinate
vector x is expanded to the full SParMin, the residual is the standard
gateway_plus_impfill_moments objective with the filling rows dropped (they are
identically satisfied at half filling with mu = U/2 pinned), and Omega comes
from compute_omega_scheme. Nothing here re-implements physics.

Truncations (Mg=1 impurity baths; the h-ghosts never enter the impurities):

  (Mh, Mg, Mb, Ma) = (2, 1, 1, 1) — 8 unknowns:
      x = (e1, w1, eta_b, B_h, V1, V2, eps_b, B_g)
  (Mh, Mg, Mb, Ma) = (4, 1, 1, 1) — 10 unknowns:
      x = (e1, w1, e2, w2, eta_b, B_h, V1, V2, eps_b, B_g)
      Renormalizer variant: e2 FROZEN (default 100), w2 fitted; the fitted
      slope is lam = 2 w2^2 / e2^2. The floor must fall like 1/e2^2 when e2
      is swept (his measured ratio 15.4 vs 16).

Particle-hole structure imposed on the full parameter set:
  local h-poles in +- pairs with equal weights; the gateway copies eta1/W1,
  eta2/W2 mirror eta/W; bath levels eps1 = eps2 = 0; the antibonding channels
  mirror the bonding ones with flipped energies (eta_a = -eta_b, B_ha = B_h,
  eps_a = -eps_b, B_ga = B_g); mu = U/2 and Sigma_inf = U/2 pinned.

Physicality guards (his Appendix A): V1, V2 in [V_LO, V_HI]; e1 <= E1_MAX
(the insulator is e1 -> 0 at finite w1 — e1 needs NO lower floor). A point
whose solution PINS a guard at acceptance is rejected from thermodynamics.
Bond kick: lift the bond couplings off the exactly-flat B = 0 manifold at
every continuation step.
"""

from __future__ import annotations

from dataclasses import replace

import numpy as np
from scipy.optimize import least_squares

from BHFM2.core.solve_min import (
    MODE_BONDING_PLUS_ANTIBONDING,
    ModelParamsMin,
    SParMin,
    compute_omega_scheme,
    imp1_obs,
    imp2_obs,
    lat_obs,
)
from BHFM2.runners.run_bonding_systematic import (
    _grouped_residuals,
    _objective_vector,
)

MODE = MODE_BONDING_PLUS_ANTIBONDING

# guards (his Appendix A); a solution pinning one of these is excluded
V_LO, V_HI = 0.02, 2.5
E1_MAX = 12.0
W_MAX = 8.0
ETA_B_MAX = 12.0
EPS_B_MAX = 20.0
B_MAX = 5.0
BOND_KICK = 0.05

NAMES_MH2 = ("e1", "w1", "eta_b", "B_h", "V1", "V2", "eps_b", "B_g")
NAMES_MH4 = ("e1", "w1", "e2", "w2", "eta_b", "B_h", "V1", "V2", "eps_b", "B_g")


def names(Mh):
    return NAMES_MH2 if Mh == 2 else NAMES_MH4


def bounds(Mh, e2_frozen=None):
    """(lo, hi) for the reduced vector. e2_frozen pins e2 to a constant."""
    # eta_b and eps_b CARRY SIGN (the antibond mirror maps them to -eta_b and
    # -eps_b; the bonding channel's position relative to the Fermi level is
    # physical). Weights (w, B, V) and the paired e's are non-negative.
    lo = dict(e1=1e-8, w1=1e-8, e2=1e-8, w2=1e-8, eta_b=-ETA_B_MAX, B_h=1e-8,
              V1=V_LO, V2=V_LO, eps_b=-EPS_B_MAX, B_g=1e-8)
    hi = dict(e1=E1_MAX, w1=W_MAX, e2=200.0, w2=W_MAX, eta_b=ETA_B_MAX,
              B_h=B_MAX, V1=V_HI, V2=V_HI, eps_b=EPS_B_MAX, B_g=B_MAX)
    if e2_frozen is not None:
        lo["e2"] = e2_frozen - 1e-12
        hi["e2"] = e2_frozen + 1e-12
    nm = names(Mh)
    return (np.array([lo[n] for n in nm]), np.array([hi[n] for n in nm]))


def unpack(x, Mh, U):
    """Reduced x -> full SParMin with the PH structure (mu = U/2)."""
    x = np.asarray(x, dtype=float)
    if Mh == 2:
        e1, w1, eta_b, B_h, V1, V2, eps_b, B_g = x
        eta = np.array([e1, -e1])
        W = np.array([w1, w1])
    else:
        e1, w1, e2, w2, eta_b, B_h, V1, V2, eps_b, B_g = x
        eta = np.array([e1, -e1, e2, -e2])
        W = np.array([w1, w1, w2, w2])
    one = np.array([1.0])
    return SParMin(
        eta=eta, W=W,
        eta_b=eta_b * one, B_h=B_h * one,
        eps1=np.array([0.0]), V1=V1 * one,
        eta1=eta.copy(), W1=W.copy(),
        eps2=np.array([0.0]), V2=V2 * one,
        eta2=eta.copy(), W2=W.copy(),
        eta_b2=eta_b * one, B_h2=B_h * one,
        eps_b=eps_b * one, B_g=B_g * one,
        eta_a=-eta_b * one, B_ha=B_h * one,
        eta_a2=-eta_b * one, B_ha2=B_h * one,
        eps_a=-eps_b * one, B_ga=B_g * one,
        mu=0.5 * U,
    )


def make_mp(U, T, Nk=16, z=4.0, t=0.5):
    return ModelParamsMin(U=U, t=t, eps_d=0.0, z=z, Sigma_inf=0.5 * U, Nk=Nk,
                          n_moments=0, filling_target=1.0, beta=1.0 / T,
                          lattice="square")


def residual(x, mp, Mh):
    """The audited matching rows (filling dropped: identically satisfied at
    PH with mu pinned). 16 rows at Mh=2, 20 at Mh=4."""
    p = unpack(x, Mh, mp.U)
    _r_all, blocks, _ev = _grouped_residuals(
        p, mp, Mh, 1, 1, MODE, pin_sigma_inf=0.5 * mp.U)
    return _objective_vector(blocks, "gateway_plus_impfill_moments",
                             drop_filling=True)


def solve_point(x0, mp, Mh, e2_frozen=None, max_nfev=4000):
    """Bounded TRF from x0. Returns (x, maxr, resnorm, pins)."""
    lo, hi = bounds(Mh, e2_frozen=e2_frozen)
    x0 = np.clip(np.asarray(x0, dtype=float), lo + 1e-10, hi - 1e-10)
    sol = least_squares(residual, x0, args=(mp, Mh), method="trf",
                        bounds=(lo, hi), xtol=1e-14, ftol=1e-14,
                        max_nfev=max_nfev)
    x = sol.x
    # Guard set per his Appendix A: the V window and the e1 ceiling. Weights
    # (w, B) are ALLOWED to vanish — B_h ~ 0 IS his metal, B_g <= 0.02 IS his
    # RVB insulator (the B's discriminate branches, they are not guards).
    guarded = {"V1", "V2", "e1"}
    pins = [n for n, v, l, h in zip(names(Mh), x, lo, hi)
            if n in guarded
            and ((v - l) < 1e-6 * max(1.0, abs(l)) + 1e-9
                 or (h - v) < 1e-6 * max(1.0, abs(h)) + 1e-9)]
    return x, float(np.max(np.abs(sol.fun))), float(np.linalg.norm(sol.fun)), pins


def observables(x, mp, Mh):
    """D1, D2, D_lat, Z (pole form from the local h-poles), Omega."""
    p = unpack(x, Mh, mp.U)
    i1 = imp1_obs(p, mp, 1)
    i2 = imp2_obs(p, mp, 1, 1, mode=MODE)
    lat = lat_obs(p, mp, Mh, 1, mode=MODE)
    om = compute_omega_scheme(p, mp, Mh, 1, 1, mode=MODE, imp1=i1, imp2=i2)
    # pole-Z from the full local self-energy pole set (site + bond + antibond)
    S = (np.sum(np.asarray(p.W) ** 2 / np.asarray(p.eta) ** 2)
         + np.sum(np.asarray(p.B_h) ** 2 / np.asarray(p.eta_b) ** 2)
         + np.sum(np.asarray(p.B_ha) ** 2 / np.asarray(p.eta_a) ** 2))
    Z = 1.0 / (1.0 + S)
    z = float(mp.z)
    D1 = float(i1["double_occ"])
    D2 = float(i2["double_occ_per_site"])
    return dict(
        D1=D1,
        D2=D2,
        # the NCS-weighted double occupancy (verified against his Table 7:
        # (1-z)*D1 + z*D2 reproduces his D column to 6 digits at U=0.2)
        D=(1.0 - z) * D1 + z * D2,
        n_lat=float(lat["dens"]),
        Z=Z,
        omega=float(om["Omega_total"]),
    )


def seed_metal(U):
    """Metal seed at the growth point U ~ 0.7 (not below ~0.6: the
    g-matchings degenerate and V becomes gauge-like). Structure from his
    Table 7 metal: B_g ~ 0.33 (bond-g open), B_h ~ 0, and the local pole
    carrying the whole slope S = 2 w1^2/e1^2 = 1/Z - 1 (~0.044 at U=0.7)."""
    S = max(1.0 / max(0.99 - 0.17 * U, 0.05) - 1.0, 1e-3)
    e1 = 2.0
    return dict(
        e1=e1, w1=e1 * np.sqrt(S / 2.0), eta_b=1.0, B_h=0.02,
        V1=0.6, V2=0.6, eps_b=0.5, B_g=0.33,
    )


def seed_insulator(U):
    """Deep-Mott descent seed: e1 -> 0 at finite w1 (the omega = 0 self-energy
    pole IS the insulator; e1 needs no artificial floor)."""
    return dict(
        e1=0.02, w1=0.3 * U, eta_b=0.5, B_h=0.05,
        V1=0.05, V2=0.05, eps_b=1.0, B_g=0.05,
    )


def seed_vec(d, Mh, e2=100.0, w2=0.5):
    nm = names(Mh)
    full = dict(d)
    full.setdefault("e2", e2)
    full.setdefault("w2", w2)
    return np.array([full[n] for n in nm])


def kick(x, Mh):
    """Bond kick: lift the bond couplings off the exactly-flat B=0 manifold."""
    x = np.asarray(x, dtype=float).copy()
    nm = names(Mh)
    for key in ("B_h", "B_g"):
        i = nm.index(key)
        x[i] = max(x[i], BOND_KICK)
    return x
