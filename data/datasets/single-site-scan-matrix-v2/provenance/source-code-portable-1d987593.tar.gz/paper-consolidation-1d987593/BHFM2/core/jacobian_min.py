#!/usr/bin/env python3
"""Linear-response (analytic) Jacobian for residual_min.

Every fitted parameter enters the one-body matrices linearly, so all dH
directions are exact matrix differences of the existing builders (no
finite-difference truncation error anywhere). The Jacobian of the matching
residual then follows from two closed-form responses evaluated on the same
spectra the residual itself needs:

- interacting impurities (imp1, imp2): finite-T first-order perturbation
  theory on the full ED spectrum. For a one-body perturbation h, observable
  A, and global grand-canonical weights p_n,

      d<A> = sum_{n,m} K_nm A_nm h_nm + beta <A><h>,
      K_nm = (p_n - p_m)/(E_n - E_m),  K -> -beta (p_n + p_m)/2 degenerate,

  which contains the Hellmann-Feynman weight shift (diagonal, K_nn = -beta
  p_n) and the wavefunction response (off-diagonal) in one kernel. A and h
  conserve (N_up, N_dn), so the kernel sum is intra-sector; <A> and <h> are
  global across sectors.

- free-fermion components (lat, gw1, gw2): Daleckii-Krein derivative of the
  thermal density matrix C = f(H):

      dC = U (K1 o (U^T dH U)) U^T,
      K1_ab = (f_a - f_b)/(e_a - e_b),  K1_aa = -beta f_a (1 - f_a).

- Sigma_inf = U * n_avg / 2 feeds lat/gw1/gw2 (residual_min line ~795).
  This is feed-forward, not a fixed point, so the total derivative adds
  (dR/dSigma_inf) * (U/2) * dn_avg/dtheta with dn_avg from the ED response.

Row order matches residual_min exactly; columns follow CodecMin.pack
(fields in CodecMin._fields order, mu last).

Memory note: per ED sector this stores all transformed direction matrices
(n_dirs * dim^2 doubles). Fine for the exact PH-study models (dim <= 4900);
the Mh=2/Mg=3 production model (dim 63504) needs the blocked/back-transform
variant before this runs on GPU.
"""
from __future__ import annotations

from dataclasses import replace

import numpy as np
from numpy.linalg import eigh

from . import solve_min as _sm
from .ed_fast import build_H_sector_fast
from .ed_sparse import build_H_sparse_cached
from .solve_min import (
    MODE_BONDING_ONLY,
    MODE_SINGLE_IMPURITY,
    CodecMin,
    _fermi,
    _has_antibond,
    _is_single_impurity,
    _normalize_mode,
    _resolve_dims,
    _sector_basis,
    imp2_h1,
)

_DEG_TOL = 1e-8
_EMPTY_ORBS = np.zeros(0, dtype=np.int64)
# Above this sector dimension, assemble one-body operators sparse (COO via the
# cached topology) instead of dense, and apply them as Op @ V before the
# eigenbasis transform. Keeps the per-operator memory at dim x n_retained.
_SPARSE_OP_DIM = 3000


# ---------------------------------------------------------------------------
# Generic responses
# ---------------------------------------------------------------------------

def _dm_and_response(H, beta, dH_list):
    """Thermal density matrix C = f(H) and dC along each dH (Daleckii-Krein).

    The errstate guard matches solve_min._dm: Accelerate sets spurious FP
    status flags on denormal Boltzmann factors.
    """
    with np.errstate(over="ignore", divide="ignore", invalid="ignore", under="ignore"):
        return _dm_and_response_impl(H, beta, dH_list)


def _dm_and_response_impl(H, beta, dH_list):
    e, Uv = eigh(H)
    f = _fermi(e, beta)
    de = e[:, None] - e[None, :]
    deg = np.abs(de) < _DEG_TOL * max(1.0, float(np.max(np.abs(e))))
    fp = -beta * f * (1.0 - f)
    K1 = np.where(
        deg,
        0.5 * (fp[:, None] + fp[None, :]),
        (f[:, None] - f[None, :]) / np.where(deg, 1.0, de),
    )
    C = (Uv * f[None, :]) @ Uv.T
    dCs = []
    for dH in dH_list:
        if dH is None:
            dCs.append(None)
            continue
        dCs.append(Uv @ (K1 * (Uv.T @ dH @ Uv)) @ Uv.T)
    return C, dCs


def _ed_obs_and_response(h1, U, U_orbs, N_orb, beta, obs_specs, dh1_list):
    """Thermal observables and their parameter response from one full ED solve.

    obs_specs: list of (h1_A, scale); each observable is
               scale * <spin-summed one-body operator built from h1_A>.
    dh1_list:  one-body perturbation matrices (or None for zero directions).

    Returns (obs[nA], dobs[nA, nJ]).
    """
    with np.errstate(over="ignore", divide="ignore", invalid="ignore", under="ignore"):
        return _ed_obs_and_response_impl(h1, U, U_orbs, N_orb, beta, obs_specs, dh1_list)


def _op_transform(h1_op, N_orb, sector_key, basis, keys, vals, V):
    """V^T Op V for a spin-summed one-body operator on one sector.

    V may be truncated (dim x n_retained) on Lanczos-solved sectors; the
    transform is then n_retained x n_retained.
    """
    dim = len(basis)
    h1_op = np.ascontiguousarray(h1_op)
    if dim >= _SPARSE_OP_DIM:
        A, _b, _k, _v = build_H_sparse_cached(
            h1_op, 0.0, _EMPTY_ORBS, N_orb, sector_key[0], sector_key[1]
        )
        return V.T @ (A @ V)
    A = build_H_sector_fast(h1_op, 0.0, _EMPTY_ORBS, N_orb, basis, keys, vals)
    return V.T @ A @ V


def _ed_obs_and_response_impl(h1, U, U_orbs, N_orb, beta, obs_specs, dh1_list):
    # Late-bound sector solve: solve_min_gpu.patch_all() replaces
    # solve_min._sector_eigh with the Lanczos/dense-auto backend, and the
    # global tail certificate below enforces the same certification the
    # residual path enforces. On truncated sectors the response is the
    # retained-window approximation; steps are still validated against the
    # true residual by the optimizer.
    sectors = []
    sector_meta = []
    for N_up in range(N_orb + 1):
        for N_dn in range(N_orb + 1):
            basis, keys, vals = _sector_basis(N_orb, N_up, N_dn)
            if len(basis) == 0:
                continue
            e, V, meta = _sm._sector_eigh(
                h1, U, U_orbs, N_orb, basis, keys, vals, beta, sector_key=(N_up, N_dn)
            )
            sectors.append(
                (np.asarray(e, dtype=float), np.asarray(V, dtype=float),
                 basis, keys, vals, (N_up, N_dn))
            )
            sector_meta.append(meta)

    E0 = min(float(e[0]) for e, *_ in sectors)
    ws = [np.exp(np.clip(-beta * (e - E0), -700.0, 700.0)) for e, *_ in sectors]
    Z = sum(float(w.sum()) for w in ws)
    ps = [w / Z for w in ws]
    _sm._certify_global_tail(sector_meta, E0, Z, beta)

    nA = len(obs_specs)
    nJ = len(dh1_list)
    obs = np.zeros(nA)
    hexp = np.zeros(nJ)
    kern = np.zeros((nA, nJ))

    for (e, V, basis, keys, vals, skey), p in zip(sectors, ps):
        de = e[:, None] - e[None, :]
        deg = np.abs(de) < _DEG_TOL * max(1.0, abs(float(e[0])), abs(float(e[-1])))
        K = np.where(
            deg,
            -beta * 0.5 * (p[:, None] + p[None, :]),
            (p[:, None] - p[None, :]) / np.where(deg, 1.0, de),
        )

        Hts = []
        for dh1 in dh1_list:
            if dh1 is None:
                Hts.append(None)
                continue
            Hts.append(_op_transform(dh1, N_orb, skey, basis, keys, vals, V))
        for j, Ht in enumerate(Hts):
            if Ht is not None:
                hexp[j] += float(p @ np.diag(Ht))

        for a, (h1A, scale) in enumerate(obs_specs):
            At = _op_transform(h1A, N_orb, skey, basis, keys, vals, V)
            obs[a] += scale * float(p @ np.diag(At))
            W = K * At
            for j, Ht in enumerate(Hts):
                if Ht is not None:
                    kern[a, j] += scale * float(np.sum(W * Ht))

    dobs = kern + beta * np.outer(obs, hexp)
    return obs, dobs


# ---------------------------------------------------------------------------
# One-body H builders (copies of the residual_min component Hamiltonians)
# ---------------------------------------------------------------------------

def _imp1_h1(p, mp, Mg):
    N_orb = 1 + Mg
    h1 = np.zeros((N_orb, N_orb))
    h1[0, 0] = mp.eps_d - p.mu
    for a in range(Mg):
        h1[1 + a, 1 + a] = p.eps1[a]
        h1[0, 1 + a] = h1[1 + a, 0] = p.V1[a]
    return h1


def _gw1_H(p, mp, Mh, Mg):
    n_orb = 1 + Mg + Mh
    H = np.zeros((n_orb, n_orb))
    H[0, 0] = mp.eps_d + mp.Sigma_inf - p.mu
    og, oh = 1, 1 + Mg
    for a in range(Mg):
        H[og + a, og + a] = p.eps1[a]
        H[0, og + a] = H[og + a, 0] = p.V1[a]
    for a in range(Mh):
        H[oh + a, oh + a] = p.eta1[a]
        H[0, oh + a] = H[oh + a, 0] = p.W1[a]
    return H


def _gw2_offsets(Mh, Mg, Mb, anti):
    oh1 = 2
    oh2 = oh1 + Mh
    ohbp = oh2 + Mh
    ohbm = ohbp + Mb if anti else ohbp
    og1 = ohbm + (Mb if anti else 0)
    og2 = og1 + Mg
    ogbp = og2 + Mg
    ogbm = ogbp + Mb
    n_orb = (ogbm + Mb) if anti else (ogbp + Mb)
    return oh1, oh2, ohbp, ohbm, og1, og2, ogbp, ogbm, n_orb


def _gw2_H(p, mp, Mh, Mg, Mb, anti):
    oh1, oh2, ohbp, ohbm, og1, og2, ogbp, ogbm, n_orb = _gw2_offsets(Mh, Mg, Mb, anti)
    d1, d2 = 0, 1
    H = np.zeros((n_orb, n_orb))
    shift = mp.eps_d + mp.Sigma_inf - p.mu
    H[d1, d1] = H[d2, d2] = shift
    H[d1, d2] = H[d2, d1] = -mp.t
    for a in range(Mh):
        H[oh1 + a, oh1 + a] = H[oh2 + a, oh2 + a] = p.eta2[a]
        H[d1, oh1 + a] = H[oh1 + a, d1] = p.W2[a]
        H[d2, oh2 + a] = H[oh2 + a, d2] = p.W2[a]
    for b in range(Mb):
        H[ohbp + b, ohbp + b] = p.eta_b2[b]
        amp = p.B_h2[b] / 2.0
        H[d1, ohbp + b] = H[ohbp + b, d1] = amp
        H[d2, ohbp + b] = H[ohbp + b, d2] = amp
    if anti:
        for b in range(Mb):
            H[ohbm + b, ohbm + b] = p.eta_a2[b]
            amp = p.B_ha2[b] / 2.0
            H[d1, ohbm + b] = H[ohbm + b, d1] = amp
            H[d2, ohbm + b] = H[ohbm + b, d2] = -amp
    for a in range(Mg):
        H[og1 + a, og1 + a] = H[og2 + a, og2 + a] = p.eps2[a]
        H[d1, og1 + a] = H[og1 + a, d1] = p.V2[a]
        H[d2, og2 + a] = H[og2 + a, d2] = p.V2[a]
    for b in range(Mb):
        H[ogbp + b, ogbp + b] = p.eps_b[b]
        amp = p.B_g[b] / 2.0
        H[d1, ogbp + b] = H[ogbp + b, d1] = amp
        H[d2, ogbp + b] = H[ogbp + b, d2] = amp
    if anti:
        for b in range(Mb):
            H[ogbm + b, ogbm + b] = p.eps_a[b]
            amp = p.B_ga[b] / 2.0
            H[d1, ogbm + b] = H[ogbm + b, d1] = amp
            H[d2, ogbm + b] = H[ogbm + b, d2] = -amp
    return H


def _lat_Hk(p, mp, Mh, Mb, anti, eps_k, ck, cky, sk, sky):
    ndir = 2 if mp.use_y_bond else 1
    n_orb = 1 + Mh + Mb * ndir + (Mb * ndir if anti else 0)
    H = np.zeros((n_orb, n_orb))
    H[0, 0] = eps_k + mp.eps_d + mp.Sigma_inf - p.mu
    off = 1
    for a in range(Mh):
        H[off + a, off + a] = p.eta[a]
        H[0, off + a] = H[off + a, 0] = p.W[a]
    off += Mh
    for a in range(Mb):
        H[off + a, off + a] = p.eta_b[a]
        amp = p.B_h[a] * ck
        H[0, off + a] = H[off + a, 0] = amp
    off += Mb
    if mp.use_y_bond:
        for a in range(Mb):
            H[off + a, off + a] = p.eta_b[a]
            amp = p.B_h[a] * cky
            H[0, off + a] = H[off + a, 0] = amp
        off += Mb
    if anti:
        for a in range(Mb):
            H[off + a, off + a] = p.eta_a[a]
            amp = p.B_ha[a] * sk
            H[0, off + a] = H[off + a, 0] = amp
        off += Mb
        if mp.use_y_bond:
            for a in range(Mb):
                H[off + a, off + a] = p.eta_a[a]
                amp = p.B_ha[a] * sky
                H[0, off + a] = H[off + a, 0] = amp
    return H


# ---------------------------------------------------------------------------
# Linear functionals: observable extraction from C (applies equally to dC)
# ---------------------------------------------------------------------------

def _lat_extract(C, Mh, Mb, anti, use_y_bond, ck, cky, sk, sky, cos_kx, wk):
    """Per-k contribution to [hh, dh, hbp_hbp, hbp_d, (hbm_hbm, hbm_d), dens, bond_x]."""
    spin = 2.0
    ndir = 2 if use_y_bond else 1
    out = []
    for a in range(Mh):
        out.append(spin * C[1 + a, 1 + a] * wk)
    for a in range(Mh):
        out.append(spin * C[0, 1 + a] * wk)
    off2 = 1 + Mh
    hbp_occ = [spin * C[off2 + a, off2 + a] * wk / ndir for a in range(Mb)]
    hbp_coh = [spin * 2.0 * ck * C[off2 + a, 0] * wk / ndir for a in range(Mb)]
    if use_y_bond:
        off2_y = off2 + Mb
        for a in range(Mb):
            hbp_occ[a] += spin * C[off2_y + a, off2_y + a] * wk / ndir
            hbp_coh[a] += spin * 2.0 * cky * C[off2_y + a, 0] * wk / ndir
    out.extend(hbp_occ)
    out.extend(hbp_coh)
    if anti:
        offm = 1 + Mh + Mb * ndir
        hbm_occ = [spin * C[offm + a, offm + a] * wk / ndir for a in range(Mb)]
        hbm_coh = [spin * 2.0 * sk * C[offm + a, 0] * wk / ndir for a in range(Mb)]
        if use_y_bond:
            offm_y = offm + Mb
            for a in range(Mb):
                hbm_occ[a] += spin * C[offm_y + a, offm_y + a] * wk / ndir
                hbm_coh[a] += spin * 2.0 * sky * C[offm_y + a, 0] * wk / ndir
        out.extend(hbm_occ)
        out.extend(hbm_coh)
    out.append(spin * C[0, 0] * wk)
    out.append(spin * cos_kx * C[0, 0] * wk)
    return np.array(out)


def _gw1_extract(C, Mh, Mg):
    """[gg, dg, hh, dh, dens]."""
    spin = 2.0
    og, oh = 1, 1 + Mg
    out = []
    out.extend(spin * C[og + a, og + a] for a in range(Mg))
    out.extend(spin * C[0, og + a] for a in range(Mg))
    out.extend(spin * C[oh + a, oh + a] for a in range(Mh))
    out.extend(spin * C[0, oh + a] for a in range(Mh))
    out.append(spin * C[0, 0])
    return np.array(out)


def _gw2_extract(C, Mh, Mg, Mb, anti):
    """[hh, dh, gg, dg, hbp_hbp, hbp_dplus, gbp_gbp, gbp_dplus,
        (hbm_hbm, hbm_dminus, gbm_gbm, gbm_dminus), dens_per_site, bond_kin]."""
    spin = 2.0
    d1, d2 = 0, 1
    oh1, oh2, ohbp, ohbm, og1, og2, ogbp, ogbm, _ = _gw2_offsets(Mh, Mg, Mb, anti)
    out = []
    out.extend(spin * 0.5 * (C[oh1 + a, oh1 + a] + C[oh2 + a, oh2 + a]) for a in range(Mh))
    out.extend(spin * 0.5 * (C[d1, oh1 + a] + C[d2, oh2 + a]) for a in range(Mh))
    out.extend(spin * 0.5 * (C[og1 + a, og1 + a] + C[og2 + a, og2 + a]) for a in range(Mg))
    out.extend(spin * 0.5 * (C[d1, og1 + a] + C[d2, og2 + a]) for a in range(Mg))
    out.extend(spin * C[ohbp + b, ohbp + b] for b in range(Mb))
    out.extend(spin * (C[d1, ohbp + b] + C[d2, ohbp + b]) for b in range(Mb))
    out.extend(spin * C[ogbp + b, ogbp + b] for b in range(Mb))
    out.extend(spin * (C[d1, ogbp + b] + C[d2, ogbp + b]) for b in range(Mb))
    if anti:
        out.extend(spin * C[ohbm + b, ohbm + b] for b in range(Mb))
        out.extend(spin * (C[d1, ohbm + b] - C[d2, ohbm + b]) for b in range(Mb))
        out.extend(spin * C[ogbm + b, ogbm + b] for b in range(Mb))
        out.extend(spin * (C[d1, ogbm + b] - C[d2, ogbm + b]) for b in range(Mb))
    out.append(spin * 0.5 * (C[d1, d1] + C[d2, d2]))
    out.append(spin * C[d1, d2])
    return np.array(out)


def _free_component(build, extract, mp, mp_sig, p0, p_dirs, beta):
    """Observables and Jacobian (n_dirs + Sigma column) of one free component."""
    H0 = build(p0, mp)
    dHs = []
    for pj in p_dirs:
        dH = build(pj, mp) - H0
        dHs.append(dH if np.any(dH) else None)
    dHs.append(build(p0, mp_sig) - H0)  # Sigma_inf direction
    C, dCs = _dm_and_response(H0, beta, dHs)
    obs = extract(C)
    jac = np.zeros((len(obs), len(dHs)))
    for j, dC in enumerate(dCs):
        if dC is not None:
            jac[:, j] = extract(dC)
    return obs, jac


# ---------------------------------------------------------------------------
# Moment rows (explicit polynomials, hand-coded gradients)
# ---------------------------------------------------------------------------

def _mom_pair_grad(amp, eta, m):
    """d/d(amp), d/d(eta) of sum(amp^2 * eta^m)."""
    damp = 2.0 * amp * eta**m
    deta = m * amp**2 * eta ** (m - 1) if m >= 1 else np.zeros_like(eta)
    return damp, deta


def _moment_rows(p, z, n_moments, anti, slices, n_par, single=False):
    rows = []
    jac = np.zeros((n_moments, n_par))
    if single:
        pairs = [
            ("W", "eta", 1.0),
            ("W1", "eta1", -1.0),
        ]
    else:
        pairs = [
            # (amp_name, eta_name, weight)
            ("W", "eta", 1.0),
            ("B_h", "eta_b", 1.0),
            ("W1", "eta1", -(1.0 - z)),
            ("W2", "eta2", -z),
            ("B_h2", "eta_b2", -z),
        ]
    if anti and not single:
        pairs.append(("B_ha", "eta_a", 1.0))
        pairs.append(("B_ha2", "eta_a2", -z))
    for m in range(n_moments):
        val = 0.0
        for amp_name, eta_name, wgt in pairs:
            amp = np.asarray(getattr(p, amp_name), dtype=float)
            eta = np.asarray(getattr(p, eta_name), dtype=float)
            val += wgt * float(np.sum(amp**2 * eta**m))
            damp, deta = _mom_pair_grad(amp, eta, m)
            jac[m, slices[amp_name]] += wgt * damp
            jac[m, slices[eta_name]] += wgt * deta
        rows.append(val)
    return np.array(rows), jac


# ---------------------------------------------------------------------------
# Main entry point
# ---------------------------------------------------------------------------

def _sym(n_orb, i, j):
    h = np.zeros((n_orb, n_orb))
    h[i, j] += 1.0
    h[j, i] += 1.0
    return h


def _diag(n_orb, idx, w=1.0):
    h = np.zeros((n_orb, n_orb))
    for i in np.atleast_1d(idx):
        h[i, i] += w
    return h


def block_slices(Mh, Mg, Mb, mode=MODE_BONDING_ONLY, n_moments=4):
    """Row slices of residual_min / residual_and_jacobian_min output, keyed by
    the block names of run_bonding_systematic._grouped_residuals.

    Lets objective modes select Jacobian rows exactly as _objective_vector
    selects residual blocks.
    """
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    mode = _normalize_mode(mode)
    if _is_single_impurity(mode):
        spec = [
            ("local_h_occ", Mh), ("local_h_coh", Mh),
            ("g1_occ", Mg), ("g1_coh", Mg),
            ("fill_imp", 1), ("fill_lat", 1), ("moments", n_moments),
        ]
    else:
        anti = _has_antibond(mode, Mb)
        spec = [
            ("local_h_occ", Mh), ("local_h_coh", Mh),
            ("bond_h_occ", Mb), ("bond_h_coh", Mb),
            ("g1_occ", Mg), ("g1_coh", Mg),
            ("g2_occ", Mg), ("g2_coh", Mg),
            ("bond_g_occ", Mb), ("bond_g_coh", Mb),
        ]
        if anti:
            spec += [
                ("bondm_h_occ", Mb), ("bondm_h_coh", Mb),
                ("bondm_g_occ", Mb), ("bondm_g_coh", Mb),
            ]
        spec += [("fill_imp", 1), ("fill_lat", 1), ("bond_kinetic", 1), ("moments", n_moments)]
    out = {}
    i = 0
    for name, nrows in spec:
        out[name] = slice(i, i + nrows)
        i += nrows
    return out


def residual_and_jacobian_min(p, mp_base, Mh, Mg, Mb=None, mode=MODE_BONDING_ONLY,
                              pin_sigma_inf=None, fixed_mu=None, return_aux=False):
    """Residual (identical rows to residual_min) and its analytic Jacobian.

    Returns (r, J) with J of shape (len(r), CodecMin(...).size); columns
    follow CodecMin.pack ordering (mu last when fitted).

    pin_sigma_inf: when set, Sigma_inf is held at this value (PH pinning)
    instead of the U*n_avg/2 feed-forward, and the corresponding chain-rule
    term is dropped (it is exactly zero for a pinned Sigma_inf).

    fixed_mu: when set, mu is held at this value and omitted from the packed
    parameter vector/Jacobian columns.

    return_aux: when True (single_impurity only), also return a dict with
    ``dSigma_dx`` = d Sigma_inf / d x (over the same bare columns as J) -- the
    feed-forward gradient the physical-gauge chain rule needs to differentiate
    ebar = eps_d + Sigma_inf - mu. Returns (r, J, aux).
    """
    Mh, Mg, Mb = _resolve_dims(Mh, Mg, Mb)
    mode = _normalize_mode(mode)
    if _is_single_impurity(mode) and Mb != 0:
        raise ValueError("single_impurity mode requires Mb=0")
    anti = _has_antibond(mode, Mb)
    z = mp_base.z
    beta = mp_base.beta

    codec = CodecMin(Mh, Mg, Mb, mode=mode, fixed_mu=fixed_mu)
    x0 = codec.pack(p)
    n_par = len(x0)
    p0 = codec.unpack(x0)
    p_dirs = []
    for j in range(n_par):
        xj = x0.copy()
        xj[j] += 1.0
        p_dirs.append(codec.unpack(xj))

    slices = {}
    i0 = 0
    for name, n in codec._fields():
        slices[name] = slice(i0, i0 + n)
        i0 += n
    slices["mu"] = slice(i0, i0 + (0 if fixed_mu is not None else 1))

    # ---- imp1 ED response: obs = [dens, gg(Mg), dg(Mg)]
    N1 = 1 + Mg
    h1_imp1 = _imp1_h1(p0, mp_base, Mg)
    dh1_imp1 = []
    for pj in p_dirs:
        d = _imp1_h1(pj, mp_base, Mg) - h1_imp1
        dh1_imp1.append(d if np.any(d) else None)
    specs1 = [(_diag(N1, 0), 1.0)]
    specs1 += [(_diag(N1, 1 + a), 1.0) for a in range(Mg)]
    specs1 += [(_sym(N1, 1 + a, 0), 0.5) for a in range(Mg)]
    obs1, dobs1 = _ed_obs_and_response(
        h1_imp1, mp_base.U, np.array([0], dtype=np.int64), N1, beta, specs1, dh1_imp1
    )
    imp1_dens, dimp1_dens = obs1[0], dobs1[0]
    imp1_gg, dimp1_gg = obs1[1 : 1 + Mg], dobs1[1 : 1 + Mg]
    imp1_dg, dimp1_dg = obs1[1 + Mg :], dobs1[1 + Mg :]

    if _is_single_impurity(mode):
        n_avg = imp1_dens
        dn_avg = dimp1_dens
        if pin_sigma_inf is None:
            Sigma = mp_base.U * n_avg / 2.0
            dSigma_dx = (mp_base.U / 2.0) * dn_avg
        else:
            Sigma = float(pin_sigma_inf)
            dSigma_dx = np.zeros(n_par)
        mp = replace(mp_base, Sigma_inf=Sigma)
        mp_sig = replace(mp_base, Sigma_inf=Sigma + 1.0)

        def fold(jac):
            return jac[:, :n_par] + np.outer(jac[:, n_par], dSigma_dx)

        lat_obs_vec = np.zeros(2 * Mh + 2)
        lat_jac = np.zeros((2 * Mh + 2, n_par + 1))
        for eps_k, wk, ck, cky, sk, sky, cos_kx in _sm._lattice_quadrature(mp, mode=mode, Mb=Mb):
            def bld(pp, mpp):
                return _lat_Hk(pp, mpp, Mh, Mb, False, eps_k, ck, cky, sk, sky)

            H0 = bld(p0, mp)
            dHs = []
            for pj in p_dirs:
                dH = bld(pj, mp) - H0
                dHs.append(dH if np.any(dH) else None)
            dHs.append(bld(p0, mp_sig) - H0)
            C, dCs = _dm_and_response(H0, beta, dHs)
            lat_obs_vec += _lat_extract(
                C, Mh, Mb, False, mp.use_y_bond, ck, cky, sk, sky, cos_kx, wk
            )
            for j, dC in enumerate(dCs):
                if dC is not None:
                    lat_jac[:, j] += _lat_extract(
                        dC, Mh, Mb, False, mp.use_y_bond, ck, cky, sk, sky, cos_kx, wk
                    )
        lat_jac = fold(lat_jac)
        i = 0
        lat_hh, dlat_hh = lat_obs_vec[i : i + Mh], lat_jac[i : i + Mh]
        i += Mh
        lat_dh, dlat_dh = lat_obs_vec[i : i + Mh], lat_jac[i : i + Mh]
        i += Mh
        lat_dens, dlat_dens = lat_obs_vec[i], lat_jac[i]

        gw1_vec, gw1_jac = _free_component(
            lambda pp, mpp: _gw1_H(pp, mpp, Mh, Mg),
            lambda C: _gw1_extract(C, Mh, Mg),
            mp, mp_sig, p0, p_dirs, beta,
        )
        gw1_jac = fold(gw1_jac)
        i = 0
        gw1_gg, dgw1_gg = gw1_vec[i : i + Mg], gw1_jac[i : i + Mg]
        i += Mg
        gw1_dg, dgw1_dg = gw1_vec[i : i + Mg], gw1_jac[i : i + Mg]
        i += Mg
        gw1_hh, dgw1_hh = gw1_vec[i : i + Mh], gw1_jac[i : i + Mh]
        i += Mh
        gw1_dh, dgw1_dh = gw1_vec[i : i + Mh], gw1_jac[i : i + Mh]

        rows = []
        jrows = []

        def add(vals, jacs):
            vals = np.atleast_1d(np.asarray(vals, dtype=float))
            jacs = np.atleast_2d(np.asarray(jacs, dtype=float))
            for v, jr in zip(vals, jacs):
                rows.append(float(v))
                jrows.append(jr)

        add(lat_hh - gw1_hh, dlat_hh - dgw1_hh)
        add(lat_dh - gw1_dh, dlat_dh - dgw1_dh)
        add(imp1_gg - gw1_gg, dimp1_gg - dgw1_gg)
        add(imp1_dg - gw1_dg, dimp1_dg - dgw1_dg)
        add(n_avg - mp_base.filling_target, dn_avg)
        add(lat_dens - mp_base.filling_target, dlat_dens)
        mom_vals, mom_jac = _moment_rows(
            p0, z, mp_base.n_moments, anti, slices, n_par, single=True
        )
        add(mom_vals, mom_jac)
        r_out, J_out = np.array(rows), np.vstack(jrows)
        if return_aux:
            return r_out, J_out, {"dSigma_dx": np.asarray(dSigma_dx, float)}
        return r_out, J_out

    # ---- imp2 ED response
    h1_imp2, U_orbs2 = imp2_h1(p0, mp_base, Mg, Mb, mode=mode)
    N2 = h1_imp2.shape[0]
    dh1_imp2 = []
    for pj in p_dirs:
        d = imp2_h1(pj, mp_base, Mg, Mb, mode=mode)[0] - h1_imp2
        dh1_imp2.append(d if np.any(d) else None)
    d1, d2 = 0, 1
    og1, og2 = 2, 2 + Mg
    ogbp = 2 + 2 * Mg
    ogbm = ogbp + Mb
    specs2 = [(_diag(N2, [d1, d2]), 0.5)]  # dens_per_site
    specs2 += [(_diag(N2, [og1 + a, og2 + a]), 0.5) for a in range(Mg)]  # gg
    specs2 += [
        (_sym(N2, og1 + a, d1) + _sym(N2, og2 + a, d2), 0.25) for a in range(Mg)
    ]  # dg
    specs2 += [(_diag(N2, ogbp + b), 1.0) for b in range(Mb)]  # gbp_gbp
    specs2 += [
        (_sym(N2, ogbp + b, d1) + _sym(N2, ogbp + b, d2), 0.5) for b in range(Mb)
    ]  # gbp_dplus
    if anti:
        specs2 += [(_diag(N2, ogbm + b), 1.0) for b in range(Mb)]  # gbm_gbm
        specs2 += [
            (_sym(N2, ogbm + b, d1) - _sym(N2, ogbm + b, d2), 0.5) for b in range(Mb)
        ]  # gbm_dminus
    specs2.append((_sym(N2, d1, d2), 0.5))  # bond_kinetic_per_bond
    obs2, dobs2 = _ed_obs_and_response(
        h1_imp2, mp_base.U, U_orbs2, N2, beta, specs2, dh1_imp2
    )
    k = 0
    imp2_dens, dimp2_dens = obs2[k], dobs2[k]
    k += 1
    imp2_gg, dimp2_gg = obs2[k : k + Mg], dobs2[k : k + Mg]
    k += Mg
    imp2_dg, dimp2_dg = obs2[k : k + Mg], dobs2[k : k + Mg]
    k += Mg
    imp2_gbp_gbp, dimp2_gbp_gbp = obs2[k : k + Mb], dobs2[k : k + Mb]
    k += Mb
    imp2_gbp_dplus, dimp2_gbp_dplus = obs2[k : k + Mb], dobs2[k : k + Mb]
    k += Mb
    if anti:
        imp2_gbm_gbm, dimp2_gbm_gbm = obs2[k : k + Mb], dobs2[k : k + Mb]
        k += Mb
        imp2_gbm_dminus, dimp2_gbm_dminus = obs2[k : k + Mb], dobs2[k : k + Mb]
        k += Mb
    imp2_bond_kin, dimp2_bond_kin = obs2[k], dobs2[k]

    # ---- Sigma_inf feed-forward (or PH pin)
    n_avg = (1 - z) * imp1_dens + z * imp2_dens
    dn_avg = (1 - z) * dimp1_dens + z * dimp2_dens
    if pin_sigma_inf is None:
        Sigma = mp_base.U * n_avg / 2.0
        dSigma_dx = (mp_base.U / 2.0) * dn_avg
    else:
        Sigma = float(pin_sigma_inf)
        dSigma_dx = np.zeros(n_par)
    mp = replace(mp_base, Sigma_inf=Sigma)
    mp_sig = replace(mp_base, Sigma_inf=Sigma + 1.0)

    # ---- free components (jac has n_par explicit columns + Sigma column)
    def fold(jac):
        return jac[:, :n_par] + np.outer(jac[:, n_par], dSigma_dx)

    # lattice: k-sum
    n_lat_obs = 2 * Mh + 2 * Mb + (2 * Mb if anti else 0) + 2
    lat_obs_vec = np.zeros(n_lat_obs)
    lat_jac = np.zeros((n_lat_obs, n_par + 1))
    for eps_k, wk, ck, cky, sk, sky, cos_kx in _sm._lattice_quadrature(mp, mode=mode, Mb=Mb):
        def bld(pp, mpp):
            return _lat_Hk(pp, mpp, Mh, Mb, anti, eps_k, ck, cky, sk, sky)

        H0 = bld(p0, mp)
        dHs = []
        for pj in p_dirs:
            dH = bld(pj, mp) - H0
            dHs.append(dH if np.any(dH) else None)
        dHs.append(bld(p0, mp_sig) - H0)
        C, dCs = _dm_and_response(H0, beta, dHs)
        lat_obs_vec += _lat_extract(
            C, Mh, Mb, anti, mp.use_y_bond, ck, cky, sk, sky, cos_kx, wk
        )
        for j, dC in enumerate(dCs):
            if dC is not None:
                lat_jac[:, j] += _lat_extract(
                    dC, Mh, Mb, anti, mp.use_y_bond, ck, cky, sk, sky, cos_kx, wk
                )
    lat_jac = fold(lat_jac)
    i = 0
    lat_hh, dlat_hh = lat_obs_vec[i : i + Mh], lat_jac[i : i + Mh]
    i += Mh
    lat_dh, dlat_dh = lat_obs_vec[i : i + Mh], lat_jac[i : i + Mh]
    i += Mh
    lat_hbp_hbp, dlat_hbp_hbp = lat_obs_vec[i : i + Mb], lat_jac[i : i + Mb]
    i += Mb
    lat_hbp_d, dlat_hbp_d = lat_obs_vec[i : i + Mb], lat_jac[i : i + Mb]
    i += Mb
    if anti:
        lat_hbm_hbm, dlat_hbm_hbm = lat_obs_vec[i : i + Mb], lat_jac[i : i + Mb]
        i += Mb
        lat_hbm_d, dlat_hbm_d = lat_obs_vec[i : i + Mb], lat_jac[i : i + Mb]
        i += Mb
    lat_dens, dlat_dens = lat_obs_vec[i], lat_jac[i]
    lat_bond_x, dlat_bond_x = lat_obs_vec[i + 1], lat_jac[i + 1]

    # gw1
    gw1_vec, gw1_jac = _free_component(
        lambda pp, mpp: _gw1_H(pp, mpp, Mh, Mg),
        lambda C: _gw1_extract(C, Mh, Mg),
        mp, mp_sig, p0, p_dirs, beta,
    )
    gw1_jac = fold(gw1_jac)
    i = 0
    gw1_gg, dgw1_gg = gw1_vec[i : i + Mg], gw1_jac[i : i + Mg]
    i += Mg
    gw1_dg, dgw1_dg = gw1_vec[i : i + Mg], gw1_jac[i : i + Mg]
    i += Mg
    gw1_hh, dgw1_hh = gw1_vec[i : i + Mh], gw1_jac[i : i + Mh]
    i += Mh
    gw1_dh, dgw1_dh = gw1_vec[i : i + Mh], gw1_jac[i : i + Mh]

    # gw2
    gw2_vec, gw2_jac = _free_component(
        lambda pp, mpp: _gw2_H(pp, mpp, Mh, Mg, Mb, anti),
        lambda C: _gw2_extract(C, Mh, Mg, Mb, anti),
        mp, mp_sig, p0, p_dirs, beta,
    )
    gw2_jac = fold(gw2_jac)
    i = 0
    gw2_hh, dgw2_hh = gw2_vec[i : i + Mh], gw2_jac[i : i + Mh]
    i += Mh
    gw2_dh, dgw2_dh = gw2_vec[i : i + Mh], gw2_jac[i : i + Mh]
    i += Mh
    gw2_gg, dgw2_gg = gw2_vec[i : i + Mg], gw2_jac[i : i + Mg]
    i += Mg
    gw2_dg, dgw2_dg = gw2_vec[i : i + Mg], gw2_jac[i : i + Mg]
    i += Mg
    gw2_hbp_hbp, dgw2_hbp_hbp = gw2_vec[i : i + Mb], gw2_jac[i : i + Mb]
    i += Mb
    gw2_hbp_dplus, dgw2_hbp_dplus = gw2_vec[i : i + Mb], gw2_jac[i : i + Mb]
    i += Mb
    gw2_gbp_gbp, dgw2_gbp_gbp = gw2_vec[i : i + Mb], gw2_jac[i : i + Mb]
    i += Mb
    gw2_gbp_dplus, dgw2_gbp_dplus = gw2_vec[i : i + Mb], gw2_jac[i : i + Mb]
    i += Mb
    if anti:
        gw2_hbm_hbm, dgw2_hbm_hbm = gw2_vec[i : i + Mb], gw2_jac[i : i + Mb]
        i += Mb
        gw2_hbm_dminus, dgw2_hbm_dminus = gw2_vec[i : i + Mb], gw2_jac[i : i + Mb]
        i += Mb
        gw2_gbm_gbm, dgw2_gbm_gbm = gw2_vec[i : i + Mb], gw2_jac[i : i + Mb]
        i += Mb
        gw2_gbm_dminus, dgw2_gbm_dminus = gw2_vec[i : i + Mb], gw2_jac[i : i + Mb]
        i += Mb

    # ---- assemble rows in residual_min order
    rows = []
    jrows = []

    def add(vals, jacs):
        vals = np.atleast_1d(np.asarray(vals, dtype=float))
        jacs = np.atleast_2d(np.asarray(jacs, dtype=float))
        for v, jr in zip(vals, jacs):
            rows.append(float(v))
            jrows.append(jr)

    add(lat_hh - ((1 - z) * gw1_hh + z * gw2_hh),
        dlat_hh - ((1 - z) * dgw1_hh + z * dgw2_hh))
    add(lat_dh - ((1 - z) * gw1_dh + z * gw2_dh),
        dlat_dh - ((1 - z) * dgw1_dh + z * dgw2_dh))
    add(lat_hbp_hbp - gw2_hbp_hbp, dlat_hbp_hbp - dgw2_hbp_hbp)
    add(lat_hbp_d - gw2_hbp_dplus, dlat_hbp_d - dgw2_hbp_dplus)
    add(imp1_gg - gw1_gg, dimp1_gg - dgw1_gg)
    add(imp1_dg - gw1_dg, dimp1_dg - dgw1_dg)
    add(imp2_gg - gw2_gg, dimp2_gg - dgw2_gg)
    add(imp2_dg - gw2_dg, dimp2_dg - dgw2_dg)
    add(imp2_gbp_gbp - gw2_gbp_gbp, dimp2_gbp_gbp - dgw2_gbp_gbp)
    add(imp2_gbp_dplus - gw2_gbp_dplus, dimp2_gbp_dplus - dgw2_gbp_dplus)
    if anti:
        add(lat_hbm_hbm - gw2_hbm_hbm, dlat_hbm_hbm - dgw2_hbm_hbm)
        add(lat_hbm_d - gw2_hbm_dminus, dlat_hbm_d - dgw2_hbm_dminus)
        add(imp2_gbm_gbm - gw2_gbm_gbm, dimp2_gbm_gbm - dgw2_gbm_gbm)
        add(imp2_gbm_dminus - gw2_gbm_dminus, dimp2_gbm_dminus - dgw2_gbm_dminus)
    add(n_avg - mp_base.filling_target, dn_avg)
    add(lat_dens - mp_base.filling_target, dlat_dens)
    add(lat_bond_x - imp2_bond_kin, dlat_bond_x - dimp2_bond_kin)

    mom_vals, mom_jac = _moment_rows(p0, z, mp_base.n_moments, anti, slices, n_par)
    add(mom_vals, mom_jac)

    r_out, J_out = np.array(rows), np.vstack(jrows)
    if return_aux:
        # dSigma_dx (line ~709) is the NCS feed-forward gradient d Sigma_inf/dx
        # over the same bare columns as J_out -- the B+AB R-gauge chain-rule needs
        # it for the ebar coupling (delta 4 of SHUTTLE_PHYSICAL_GAUGE_PLAN 4c).
        return r_out, J_out, {"dSigma_dx": np.asarray(dSigma_dx, float)}
    return r_out, J_out
