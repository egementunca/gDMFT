#!/usr/bin/env python3
"""Custom Levenberg-Marquardt / Gauss-Newton solver in the physical-(lambda,R)
gauge, using the exact analytic Jacobian ``reparam_R.jacobian_min_R``.

Why this exists (TO-DO #8, Phase 3 "Newton shuttle"): cold-seed scipy TRF in the
R-gauge settles at a trust-region-bounded stationary residual (~5.8e-8 for
Mh2/Mg1 bethe) INDEPENDENT of the nfev budget -- not the bare global floor 1e-8.
With J_R exact we can run a bespoke LM loop that is not bounded by a trust
region and drive the residual to machine zero where a true solution exists.

It is also the decisive diagnostic for the single-site Mg=3 case (#6): with an
exact Jacobian and a proper second-order step, does ||r|| -> 0 (a genuine
solution of the matching conditions exists, so the prior "rank-deficiency" was a
solver/FD artifact), or does ||r|| stall at an irreducible floor while the
gradient ||J^T r|| -> 0 (a stationary-but-nonzero residual = the U(Mg-1)
dark-mode / gauge obstruction, no exact solution)? The two outcomes are
physically distinct and this loop separates them.

Algorithm: Marquardt-scaled LM on the least-squares objective f = 1/2 ||r||^2:

    (J^T J + mu * diag(J^T J)) dx = -J^T r

with step acceptance by actual cost decrease, geometric mu adaptation, and
simple box projection of the trial point. Reports the full ||r|| / ||J^T r||
trajectory so metal/dark/stationary behaviour is visible.

single_impurity only (matches reparam_R Phase 1). Needs ED -> run under the
py3.12 numba venv  .venv-numba/bin/python3 .
"""
from __future__ import annotations

from dataclasses import replace
import time

import numpy as np

from .solve_min import (
    init_min,
    MODE_SINGLE_IMPURITY,
    _normalize_mode,
    _is_single_impurity,
)
from . import reparam_R as rr


def _seed_pR(mp, Mh, Mg, filling_target, p_init_bare, pR_init, fixed_mu, mode):
    """Mirror solve_min_R's seeding (bare init -> spread -> R gauge)."""
    if pR_init is not None:
        return pR_init
    if p_init_bare is None:
        mu0 = fixed_mu if fixed_mu is not None else mp.U * filling_target / 2.0
        p_init_bare = init_min(Mh, Mg, 0, W0=0.3, V0=0.3, base_mu=mu0, mode=mode)
        if Mh > 1:
            spread = np.linspace(-0.4, 0.4, Mh)
            p_init_bare = replace(p_init_bare, eta=spread.copy(), eta1=spread.copy())
    return rr.seed_R_from_bare(p_init_bare, mp, Mh, Mg)


def solve_newton_R(
    mp0, Mh, Mg, filling_target,
    p_init_bare=None, pR_init=None, fixed_mu=None,
    max_iter=200, tol=1e-12, gtol=1e-14,
    mu0=1e-3, mu_min=1e-12, mu_max=1e12,
    step_tol=1e-14, mode=MODE_SINGLE_IMPURITY, verbose=False,
):
    """Levenberg-Marquardt in the physical gauge with the analytic J_R.

    Returns a dict with the solved physical params, reconstructed bare params,
    final ||r|| and ||J^T r||, the per-iteration trajectory, and Z (fermi).
    """
    mode = _normalize_mode(mode)
    if not _is_single_impurity(mode):
        raise NotImplementedError("solve_newton_R: single_impurity only.")
    mp = replace(mp0, filling_target=filling_target)
    codec = rr.CodecMinR(Mh, Mg, 0, mode=mode, fixed_mu=fixed_mu)
    lo, hi = rr.make_bounds_R(Mh, Mg, 0, mode=mode, fixed_mu=fixed_mu)

    pR = _seed_pR(mp, Mh, Mg, filling_target, p_init_bare, pR_init, fixed_mu, mode)
    x = np.clip(codec.pack(pR), lo + 1e-9, hi - 1e-9)

    def resid(xv):
        return rr.residual_min_R(codec.unpack(xv), mp, Mh, Mg, 0, mode=mode)

    def _fd_jac(xv, r0):
        """Central-difference Jacobian of the (robust) residual_min_R -- fallback
        when the analytic J_R raises/goes non-finite at a near-degenerate point."""
        n = xv.size
        J = np.empty((r0.size, n))
        for k in range(n):
            h = 1e-7 * (1.0 + abs(xv[k]))
            xp = xv.copy(); xp[k] = min(xp[k] + h, hi[k])
            xm = xv.copy(); xm[k] = max(xm[k] - h, lo[k])
            dh = xp[k] - xm[k]
            J[:, k] = (resid(xp) - resid(xm)) / (dh if dh != 0 else h)
        return J

    def resid_jac(xv):
        """(r, J, used_fd). Analytic J_R, falling back to FD if it raises or is
        non-finite (the arrowhead inverse is fragile near decoupled ghosts)."""
        try:
            r, J = rr.jacobian_min_R(codec.unpack(xv), mp, Mh, Mg, 0, mode=mode,
                                     fixed_mu=fixed_mu)
            if np.all(np.isfinite(J)):
                return r, J, False
        except (ValueError, FloatingPointError, np.linalg.LinAlgError):
            r = resid(xv)
        return r, _fd_jac(xv, r), True

    t0 = time.time()
    r = resid(x)
    nrm = float(np.linalg.norm(r))
    mu = mu0
    traj = [nrm]
    gnorm = np.nan
    status = "max_iter"
    nfev = 1
    njev = 0

    for it in range(max_iter):
        if nrm < tol:
            status = "converged_r"
            break
        r, J, used_fd = resid_jac(x)
        njev += 1
        JTJ = J.T @ J
        g = J.T @ r
        gnorm = float(np.linalg.norm(g))
        if gnorm < gtol:
            status = "stationary"  # grad ~ 0 (true min; ||r|| may be > tol => no exact soln)
            break
        diagJTJ = np.clip(np.diag(JTJ), 1e-30, None)

        accepted = False
        while mu <= mu_max:
            A = JTJ + mu * np.diag(diagJTJ)
            try:
                dx = np.linalg.solve(A, -g)
            except np.linalg.LinAlgError:
                mu *= 10.0
                continue
            if np.linalg.norm(dx) < step_tol * (1.0 + np.linalg.norm(x)):
                status = "step_too_small"
                accepted = None  # signal outer stop
                break
            x_try = np.clip(x + dx, lo, hi)
            r_try = resid(x_try)
            nfev += 1
            nrm_try = float(np.linalg.norm(r_try))
            if np.isfinite(nrm_try) and nrm_try < nrm:
                x, r, nrm = x_try, r_try, nrm_try
                mu = max(mu * 0.4, mu_min)
                accepted = True
                break
            mu *= 2.5
        traj.append(nrm)
        if verbose and (it % 10 == 0 or accepted is not True):
            print(f"  it={it:3d} ||r||={nrm:.6e} ||J^Tr||={gnorm:.2e} "
                  f"mu={mu:.1e} t={time.time()-t0:.0f}s", flush=True)
        if accepted is None:
            status = "step_too_small"
            break
        if not accepted:
            status = "mu_max"  # cannot find a decreasing step
            break

    pR_sol = codec.unpack(x)
    p_bare, ebar = rr.to_bare(pR_sol, mp, Mh, Mg)
    from . import canonical_gauge as cg
    lamL, RL = cg.forward(ebar, p_bare.eta, p_bare.W)
    Z_lat, _ = cg.fermi_Z(lamL, RL)
    lamG, RG = cg.forward(ebar, p_bare.eta1, p_bare.W1)
    Z_gw, _ = cg.fermi_Z(lamG, RG)

    return dict(
        pR=pR_sol, p_bare=p_bare, ebar=ebar, x=x,
        resid_norm=nrm, grad_norm=gnorm, status=status,
        n_iter=it + 1, nfev=nfev, njev=njev, traj=np.array(traj),
        Z_lat=Z_lat, Z_gw=Z_gw, mu_final=mu, elapsed=time.time() - t0,
    )
