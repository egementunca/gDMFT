"""PH-symmetric reparametrization for the site+bond (B+AB) codec.

This is a *change of coordinates*, not a new constraint. It restricts the full
codec parameter vector to the particle-hole (PH) symmetric subspace via a linear
map ``x_full = A @ y``, where ``y`` are the independent symmetric degrees of
freedom. The gateway objective is untouched; the optimizer simply searches the
PH slice instead of the full space.

Why this is defensible (vs a sum-rule / pin):
  * It adds no equation to ``gateway_plus_impfill_moments``. It only reduces the
    coordinate count (36 -> 18 for Mh=2,Mg=3,Mb=1).
  * It is a *mirror* (PH) reduction only -- it does NOT impose a paramagnetic /
    spin symmetry, so antiferromagnetic ordering on the insulator stays open
    (AF is PH-even at half filling).
  * At half filling the physical fixed point IS PH symmetric (ReSigma_0 = U/2,
    eta_a = -eta_b, B_ha = B_h, eps_a = -eps_b, B_ga = B_g -- verified in the
    02_v4 report), so the true solution lives inside this subspace. If it does
    not, the symmetric residual will not reach zero -- an informative failure,
    not a hidden bias.

PH rules applied per codec field (mu is pinned to U/2 by fixed_mu, outside A):
  * ghost levels  eta / eta1 / eta2 (len Mh): +/- pairs  [-a, ..., +a]  (odd -> middle 0)
  * ghost coupls  W   / W1   / W2   (len Mh): equal within pair  [w, ..., w]
  * g-bath levels eps1 / eps2        (len Mg): +/- pairs  [-e, ..., +e]  (odd -> middle 0)
  * g-bath hybs   V1   / V2          (len Mg): equal within pair + own for middle
  * bond ghost    eta_b / eta_b2     (len Mb): free level
  * bond hybs     B_h / B_h2 / B_g   (len Mb): free
  * bond g-level  eps_b              (len Mb): free
  * antibond      eta_a=-eta_b, B_ha=B_h, eta_a2=-eta_b2, B_ha2=B_h2,
                  eps_a=-eps_b, B_ga=B_g   (tied mirrors -- no new dof)

Because every full-codec row is written by at most one symmetric parameter, the
columns of A have disjoint support: A^T A is diagonal, so ``project`` (used for
warm-start / resume from a full-codec checkpoint) is exact for any x already in
range(A) and a least-squares symmetrization otherwise.
"""

from __future__ import annotations

import numpy as np

from BHFM2.core.solve_min import CodecMin

# Match make_bounds_min defaults (E for levels, C for hybridizations).
_E = 5.0
_C = 3.0

# Antibond fields tied to a bond source field with the PH sign.
_MIRROR = {
    "eta_a": ("eta_b", -1.0),
    "eta_a2": ("eta_b2", -1.0),
    "B_ha": ("B_h", 1.0),
    "B_ha2": ("B_h2", 1.0),
    "eps_a": ("eps_b", -1.0),
    "B_ga": ("B_g", 1.0),
}
_LEVEL_FIELDS = {"eta_b", "eta_b2", "eps_b"}   # free single levels -> bound [-E, E]
_HYB_FIELDS = {"B_h", "B_h2", "B_g"}           # free single hybs   -> bound [1e-8, C]


class SymReparam:
    """Linear PH-symmetric reparametrization x_full = A @ y."""

    def __init__(self, Mh: int, Mg: int, Mb: int, mode: str):
        # fixed_mu=0.0 -> structural fields only (mu is handled by the codec's
        # fixed_mu path in _solve_point, never by A).
        codec = CodecMin(Mh, Mg, Mb, mode=mode, fixed_mu=0.0)
        fields = codec._fields()
        n_full = int(sum(n for _, n in fields))

        rows: list[tuple[int, int, float]] = []   # (full_row, sym_col, coeff)
        params: list[tuple[str, float, float]] = []  # (name, lo, hi)
        name2idx: dict[tuple[str, int], int] = {}

        def newp(name, lo, hi):
            params.append((name, lo, hi))
            return len(params) - 1

        off = 0
        for fname, size in fields:
            if fname in ("eta", "eta1", "eta2"):
                for i in range(size // 2):
                    j = newp(f"{fname}.a{i}", 1e-6, _E)
                    rows.append((off + i, j, -1.0))
                    rows.append((off + size - 1 - i, j, +1.0))
                # odd Mh -> middle ghost level pinned to 0 (no parameter)
            elif fname in ("W", "W1", "W2"):
                for i in range(size // 2):
                    j = newp(f"{fname}.w{i}", 1e-8, _C)
                    rows.append((off + i, j, +1.0))
                    rows.append((off + size - 1 - i, j, +1.0))
                if size % 2 == 1:
                    j = newp(f"{fname}.wm", 1e-8, _C)
                    rows.append((off + size // 2, j, +1.0))
            elif fname in ("eps1", "eps2"):
                for i in range(size // 2):
                    j = newp(f"{fname}.e{i}", 1e-6, _E)
                    rows.append((off + i, j, -1.0))
                    rows.append((off + size - 1 - i, j, +1.0))
                # odd Mg -> middle bath level pinned to 0 (no parameter)
            elif fname in ("V1", "V2"):
                for i in range(size // 2):
                    j = newp(f"{fname}.vp{i}", 1e-8, _C)
                    rows.append((off + i, j, +1.0))
                    rows.append((off + size - 1 - i, j, +1.0))
                if size % 2 == 1:
                    j = newp(f"{fname}.v0", 1e-8, _C)
                    rows.append((off + size // 2, j, +1.0))
            elif fname in _LEVEL_FIELDS:
                for k in range(size):
                    j = newp(f"{fname}.{k}", -_E, _E)
                    name2idx[(fname, k)] = j
                    rows.append((off + k, j, +1.0))
            elif fname in _HYB_FIELDS:
                for k in range(size):
                    j = newp(f"{fname}.{k}", 1e-8, _C)
                    name2idx[(fname, k)] = j
                    rows.append((off + k, j, +1.0))
            elif fname in _MIRROR:
                src, coeff = _MIRROR[fname]
                for k in range(size):
                    rows.append((off + k, name2idx[(src, k)], coeff))
            else:
                raise ValueError(f"SymReparam: unhandled codec field {fname!r}")
            off += size

        n_sym = len(params)
        A = np.zeros((n_full, n_sym))
        for r, c, coeff in rows:
            A[r, c] = coeff

        self.Mh, self.Mg, self.Mb, self.mode = Mh, Mg, Mb, mode
        self.A = A
        self.n_full = n_full
        self.n_sym = n_sym
        self.names = [p[0] for p in params]
        self.lo = np.array([p[1] for p in params], dtype=float)
        self.hi = np.array([p[2] for p in params], dtype=float)
        # disjoint column supports -> A^T A is diagonal (== per-column row count)
        self._col_norm2 = np.einsum("ij,ij->j", A, A)

    def to_full(self, y):
        """Symmetric dof -> full codec vector (fixed-mu, length n_full)."""
        return self.A @ np.asarray(y, dtype=float)

    def project(self, x_full):
        """Full codec vector -> symmetric dof (exact if x_full in range(A))."""
        return (self.A.T @ np.asarray(x_full, dtype=float)) / self._col_norm2

    def bounds(self):
        return self.lo.copy(), self.hi.copy()

    def jac_full_to_sym(self, J_rows):
        """Chain the objective Jacobian (n_eq x n_full) into sym space (n_eq x n_sym)."""
        return np.asarray(J_rows) @ self.A
