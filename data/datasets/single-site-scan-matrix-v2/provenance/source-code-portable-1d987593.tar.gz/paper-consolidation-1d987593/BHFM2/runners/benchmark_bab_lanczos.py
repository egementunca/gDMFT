#!/usr/bin/env python3
"""Benchmark adaptive retained-state ladders for one Mg3 B+AB impurity sector."""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
import time
from pathlib import Path

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from BHFM2.core.ed_fast import expect_cdag_c_fast, expect_double_fast, expect_n_fast
from BHFM2.core.ed_sparse import build_H_sparse_cached, sparse_topology_cache_info
from BHFM2.core.solve_min import (
    MODE_BONDING_PLUS_ANTIBONDING,
    ModelParamsMin,
    imp2_h1,
)
from BHFM2.core.solve_min_gpu import _sorted_eigsh, _tail_bound, init_gpu
from BHFM2.runners.run_bonding_systematic import _default_init


def _parse_k_list(text):
    vals = sorted({int(x.strip()) for x in text.split(",") if x.strip()})
    if not vals or vals[0] < 1:
        raise ValueError("--k-list must contain positive integers.")
    return vals


def _parse_temperature_list(text, fallback):
    vals = sorted({float(x.strip()) for x in text.split(",") if x.strip()}) if text else [fallback]
    if not vals or vals[0] <= 0.0:
        raise ValueError("--T-list must contain positive temperatures.")
    return vals


def _load_params(p, path, case_key):
    if not path:
        return p
    obj = json.loads(Path(path).read_text())
    data = obj[case_key] if case_key else obj
    for name, value in data.items():
        if name == "residual_norm" or not hasattr(p, name):
            continue
        old = getattr(p, name)
        setattr(p, name, np.asarray(value, dtype=float) if isinstance(old, np.ndarray) else float(value))
    return p


def _sector_observables(e, evec, basis, keys, vals, n_orb, beta):
    """Return retained-spectrum observables within one particle sector."""
    weights = np.exp(np.clip(-beta * (e - e[0]), -700, 700))
    weights /= weights.sum()
    d1, d2 = 0, 1
    n_phys = 0.0
    double_occ = 0.0
    bond = 0.0
    for j, w in enumerate(weights):
        psi = evec[:, j]
        n_phys += w * 0.5 * (
            expect_n_fast(d1, psi, basis, n_orb) + expect_n_fast(d2, psi, basis, n_orb)
        )
        double_occ += w * 0.5 * (
            expect_double_fast(d1, psi, basis, n_orb) + expect_double_fast(d2, psi, basis, n_orb)
        )
        bond += w * expect_cdag_c_fast(d1, d2, psi, basis, keys, vals, n_orb)
    return dict(
        sector_n_phys_per_site=float(n_phys),
        sector_double_occ_per_site=float(double_occ),
        sector_bond_kinetic=float(bond),
    )


def _delta(current, previous, key):
    if previous is None:
        return float("nan")
    return abs(float(current[key]) - float(previous[key]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Mh", type=int, default=2)
    ap.add_argument("--Mg", type=int, default=3)
    ap.add_argument("--Mb", type=int, default=1)
    ap.add_argument("--U", type=float, default=2.0)
    ap.add_argument("--t-hop", type=float, default=0.5)
    ap.add_argument("--T", type=float, default=0.05)
    ap.add_argument(
        "--T-list",
        default="",
        help="Comma-separated temperatures evaluated from each retained spectrum. Overrides --T.",
    )
    ap.add_argument("--n-target", type=float, default=1.0)
    ap.add_argument("--k-list", default="250,500,1000,2000")
    ap.add_argument("--tail-tol", type=float, default=1e-10)
    ap.add_argument("--observable-tol", type=float, default=1e-4)
    ap.add_argument("--sector-up", type=int, default=-1)
    ap.add_argument("--sector-dn", type=int, default=-1)
    ap.add_argument("--params-json", default="")
    ap.add_argument("--case-key", default="")
    ap.add_argument("--outdir", default="results/bhfm2_lanczos_benchmark")
    ap.add_argument("--allow-cpu", action="store_true", help="Permit local CPU probing without CuPy.")
    args = ap.parse_args()

    gpu_active = init_gpu()
    if not gpu_active and not args.allow_cpu:
        raise RuntimeError("GPU initialization failed. Use --allow-cpu only for small local probes.")

    mode = MODE_BONDING_PLUS_ANTIBONDING
    temperatures = _parse_temperature_list(args.T_list, args.T)
    mu0 = args.U * args.n_target / 2.0
    p = _default_init(args.Mh, args.Mg, args.Mb, mu0=mu0, mode=mode)
    p = _load_params(p, args.params_json, args.case_key)
    mp = ModelParamsMin(
        U=args.U,
        t=args.t_hop,
        beta=1.0 / temperatures[0],
        filling_target=args.n_target,
        Sigma_inf=args.U * args.n_target / 2.0,
    )
    h1, u_orbs = imp2_h1(p, mp, args.Mg, args.Mb, mode=mode)
    n_orb = int(h1.shape[0])
    n_up = args.sector_up if args.sector_up >= 0 else n_orb // 2
    n_dn = args.sector_dn if args.sector_dn >= 0 else n_orb // 2

    t0 = time.time()
    H, basis, keys, vals = build_H_sparse_cached(h1, args.U, u_orbs, n_orb, n_up, n_dn)
    assembly_wall = time.time() - t0
    dim = int(H.shape[0])
    k_list = sorted({min(k, dim - 2) for k in _parse_k_list(args.k_list) if min(k, dim - 2) >= 1})
    if not k_list:
        raise ValueError(f"Sector dimension {dim} is too small for a retained-state Lanczos ladder.")

    print("B+AB Lanczos retained-state benchmark")
    print(f"  GPU active: {gpu_active}")
    print(
        f"  Mh={args.Mh} Mg={args.Mg} Mb={args.Mb} U={args.U} t={args.t_hop} "
        f"T={','.join(f'{T:g}' for T in temperatures)}"
    )
    print(f"  sector=(N_up={n_up}, N_dn={n_dn}) N_orb={n_orb} dim={dim} nnz={H.nnz}")
    print(f"  sparse assembly: {assembly_wall:.2f}s cache={sparse_topology_cache_info()}")

    rows = []
    previous_by_temperature = {}
    for k in k_list:
        tk = time.time()
        e, evec = _sorted_eigsh(H, k)
        eig_wall = time.time() - tk
        for T in temperatures:
            beta = 1.0 / T
            previous = previous_by_temperature.get(T)
            tobs = time.time()
            row = dict(
                k=int(k),
                dim=dim,
                n_orb=n_orb,
                n_up=int(n_up),
                n_dn=int(n_dn),
                beta=float(beta),
                T=float(T),
                energy_min=float(e[0]),
                energy_max=float(e[-1]),
                energy_window=float(e[-1] - e[0]),
                thermal_tail_bound=float(_tail_bound(e, dim, beta)),
                eig_wall=float(eig_wall),
                assembly_wall=float(assembly_wall),
            )
            row.update(_sector_observables(e, evec, basis, keys, vals, n_orb, beta))
            row["observable_wall"] = float(time.time() - tobs)
            row["delta_n_phys"] = _delta(row, previous, "sector_n_phys_per_site")
            row["delta_double_occ"] = _delta(row, previous, "sector_double_occ_per_site")
            row["delta_bond_kinetic"] = _delta(row, previous, "sector_bond_kinetic")
            row["tail_certified"] = bool(row["thermal_tail_bound"] <= args.tail_tol)
            row["observable_stable"] = bool(
                previous is not None
                and max(row["delta_n_phys"], row["delta_double_occ"], row["delta_bond_kinetic"])
                <= args.observable_tol
            )
            rows.append(row)
            previous_by_temperature[T] = row
            print(
                f"  T={T:g} k={k:5d} window={row['energy_window']:.6f} "
                f"tail={row['thermal_tail_bound']:.3e} "
                f"n={row['sector_n_phys_per_site']:.8f} D={row['sector_double_occ_per_site']:.8f} "
                f"bond={row['sector_bond_kinetic']:.8f} eig={eig_wall:.2f}s "
                f"stable={row['observable_stable']} certified={row['tail_certified']}",
                flush=True,
            )

    outdir = Path(args.outdir)
    outdir.mkdir(parents=True, exist_ok=True)
    temperature_tag = (
        f"T{temperatures[0]:g}"
        if len(temperatures) == 1
        else "Tladder-" + "-".join(f"{T:g}" for T in temperatures)
    )
    stem = f"bab_Mh{args.Mh}_Mg{args.Mg}_Mb{args.Mb}_U{args.U:g}_{temperature_tag}_sector{n_up}-{n_dn}"
    csv_path = outdir / f"{stem}.csv"
    json_path = outdir / f"{stem}.json"
    with csv_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    json_path.write_text(json.dumps(dict(config=vars(args), rows=rows), indent=2) + "\n")
    print(f"Wrote {csv_path}")
    print(f"Wrote {json_path}")


if __name__ == "__main__":
    main()
