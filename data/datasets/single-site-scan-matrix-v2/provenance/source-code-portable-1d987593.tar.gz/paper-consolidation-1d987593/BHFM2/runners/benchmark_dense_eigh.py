#!/usr/bin/env python3
"""Dense GPU eigendecomposition benchmark for the big imp2 sectors.

Prices the dense-diagonalization route indicated by the 2026-06-11 profiler
verdict: full-spectrum cusolver eigh per sector instead of retained-state
Lanczos. For each sector above --dim-min it measures

  - sparse assembly (cached topology, host)
  - host->device transfer of the sparse matrix + densification ON DEVICE
    (avoids a 32 GB dense host allocation)
  - cp.linalg.eigh (cusolver syevd, full spectrum + eigenvectors)
  - optionally one V^T (A V) transform at full size (--with-transform):
    the unit cost of one analytic-Jacobian operator transform

and writes a CSV plus a per-residual-evaluation estimate.

Spin symmetry note: H commutes with the global spin flip, so (N_up, N_dn)
and (N_dn, N_up) are exactly isospectral with eigenvectors related by the
flip. This benchmark measures N_up <= N_dn sectors only and counts the
mirror cost as zero-extra; production imp2_obs currently solves both, so
exploiting this is an exact ~2x saving on top of everything else.

Run on a GPU node only.
"""
from __future__ import annotations

import argparse
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from BHFM2.core.solve_min import ModelParamsMin, init_min, imp2_h1, _sector_basis
from BHFM2.core.ed_sparse import build_H_sparse_cached


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Mh", type=int, default=2)
    ap.add_argument("--Mg", type=int, default=3)
    ap.add_argument("--Mb", type=int, default=1)
    ap.add_argument("--mode", default="bonding_plus_antibonding")
    ap.add_argument("--U", type=float, default=2.0)
    ap.add_argument("--dim-min", type=int, default=8000,
                    help="benchmark sectors with dim >= this (production "
                    "Lanczos cutoff is dim > 8k = 4000 at k=500)")
    ap.add_argument("--dim-max", type=int, default=10**9)
    ap.add_argument("--with-transform", action="store_true",
                    help="also time one V^T (A V) operator transform per sector")
    ap.add_argument("--outdir", default="results/bhfm2_dense_eigh_benchmark")
    args = ap.parse_args()

    import cupy as cp
    import cupyx.scipy.sparse as cps

    dev = cp.cuda.Device(0)
    free0, total = dev.mem_info
    print(f"GPU: {cp.cuda.runtime.getDeviceProperties(0)['name'].decode()} "
          f"free={free0/2**30:.0f}GiB / total={total/2**30:.0f}GiB", flush=True)

    mp = ModelParamsMin(U=args.U, t=0.5, eps_d=0.0, z=0.5, Sigma_inf=args.U / 2,
                        beta=20.0, Nk=16, filling_target=1.0)
    p = init_min(args.Mh, args.Mg, args.Mb, base_mu=args.U / 2, mode=args.mode)
    h1, U_orbs = imp2_h1(p, mp, args.Mg, args.Mb, mode=args.mode)
    N_orb = h1.shape[0]
    print(f"imp2: N_orb={N_orb} mode={args.mode}", flush=True)

    # unique sectors up to spin flip, in the benchmark window
    sectors = []
    for nu in range(N_orb + 1):
        for nd in range(nu, N_orb + 1):
            basis, _k, _v = _sector_basis(N_orb, nu, nd)
            dim = len(basis)
            if args.dim_min <= dim <= args.dim_max:
                sectors.append((dim, nu, nd))
    sectors.sort()
    print(f"benchmarking {len(sectors)} unique sectors (dims "
          f"{sectors[0][0]}..{sectors[-1][0]})", flush=True)

    rows = []
    for dim, nu, nd in sectors:
        pool = cp.get_default_memory_pool()
        pool.free_all_blocks()

        t0 = time.time()
        H_sp, basis, keys, vals = build_H_sparse_cached(h1, mp.U, U_orbs, N_orb, nu, nd)
        t_asm = time.time() - t0

        t0 = time.time()
        H_dev_sp = cps.csr_matrix(H_sp.astype(np.float64))
        H_dev = H_dev_sp.toarray()          # densify on device: no big host alloc
        del H_dev_sp
        cp.cuda.Stream.null.synchronize()
        t_h2d = time.time() - t0

        t0 = time.time()
        w, V = cp.linalg.eigh(H_dev)
        cp.cuda.Stream.null.synchronize()
        t_eig = time.time() - t0
        del H_dev

        t_gemm = float("nan")
        if args.with_transform:
            # one-body operator (d1 density) as the representative transform
            a1 = np.zeros((N_orb, N_orb)); a1[0, 0] = 1.0
            A_sp, *_ = build_H_sparse_cached(a1, 0.0, np.zeros(0, np.int64), N_orb, nu, nd)
            A_dev = cps.csr_matrix(A_sp.astype(np.float64))
            t0 = time.time()
            At = V.T @ (A_dev @ V)
            cp.cuda.Stream.null.synchronize()
            t_gemm = time.time() - t0
            del A_dev, At

        e0, e1 = float(w[0]), float(w[-1])
        del w, V
        pool.free_all_blocks()
        free_now = dev.mem_info[0]
        rows.append(dict(dim=dim, N_up=nu, N_dn=nd, assembly_s=t_asm,
                         h2d_densify_s=t_h2d, eigh_s=t_eig, transform_s=t_gemm,
                         e_min=e0, e_max=e1, free_GiB=free_now / 2**30))
        print(f"  ({nu},{nd}) dim={dim:6d}: assemble {t_asm:6.1f}s  "
              f"densify {t_h2d:6.1f}s  eigh {t_eig:7.1f}s  "
              f"transform {t_gemm:6.1f}s  free {free_now/2**30:.0f}GiB", flush=True)

    os.makedirs(args.outdir, exist_ok=True)
    import csv
    out = os.path.join(args.outdir,
                       f"dense_eigh_Mh{args.Mh}_Mg{args.Mg}_Mb{args.Mb}_{args.mode}.csv")
    with open(out, "w", newline="") as fh:
        wtr = csv.DictWriter(fh, fieldnames=list(rows[0]))
        wtr.writeheader(); wtr.writerows(rows)

    # per-eval estimate: every benchmarked unique sector counts once; its spin
    # mirror is free via the flip; sectors below dim-min stay on the existing
    # dense-exact path (negligible per the profiler: <2% of an eval).
    tot = sum(r["assembly_s"] + r["h2d_densify_s"] + r["eigh_s"] for r in rows)
    print(f"\nwrote {out}")
    print(f"dense big-sector cost per residual eval (unique sectors, spin "
          f"mirror reused): {tot:.0f}s")
    print("compare: profiled retained-state Lanczos big-sector cost = 2119 s/eval "
          "(45 sectors incl. mirrors), full eval 2848 s.")


if __name__ == "__main__":
    main()
