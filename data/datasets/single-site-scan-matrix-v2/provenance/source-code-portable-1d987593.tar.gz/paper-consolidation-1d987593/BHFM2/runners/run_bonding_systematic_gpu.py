#!/usr/bin/env python3
"""GPU-accelerated launcher for run_bonding_systematic.py.

Initializes GPU (CuPy) and patches solve_min + run_bonding_systematic
with accelerated routines before running the standard main().
"""
import sys
import os
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from BHFM2.core import solve_min_gpu

# Keep login-node CLI discovery usable without requiring an allocated GPU.
if any(arg in {"-h", "--help"} for arg in sys.argv[1:]):
    from BHFM2.runners.run_bonding_systematic import main

    main()
    raise SystemExit(0)

# Step 1: Require GPU. A cluster GPU job must not silently become a slow CPU job.
if not solve_min_gpu.init_gpu():
    raise RuntimeError("GPU initialization failed; refusing to run GPU launcher on CPU fallback.")

# Step 2: Patch accelerated routines into both modules
solve_min_gpu.patch_all()

# Step 3: Run the standard main
from BHFM2.runners.run_bonding_systematic import main
main()
