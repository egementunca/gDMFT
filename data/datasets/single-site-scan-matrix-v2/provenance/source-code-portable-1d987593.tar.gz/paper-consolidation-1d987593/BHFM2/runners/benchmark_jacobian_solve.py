#!/usr/bin/env python3
"""End-to-end optimizer benchmark: analytic Jacobian vs scipy 2-point FD.

Runs the same least_squares minimization of residual_min twice from the same
seed -- once with jac="2-point" (the production default, which hides n_par
residual evaluations per Jacobian build) and once with the analytic
linear-response Jacobian -- and compares wall time, evaluation counts, and
the converged residual.

Example:
  python3 -m BHFM2.runners.benchmark_jacobian_solve --Mh 1 --Mg 1 --Mb 1 \
      --mode bonding_plus_antibonding --n-moments 8 --max-nfev 60
"""
from __future__ import annotations

import argparse
import time

import numpy as np
from scipy.optimize import least_squares

from BHFM2.core.jacobian_min import residual_and_jacobian_min
from BHFM2.core.solve_min import (
    CodecMin,
    ModelParamsMin,
    init_min,
    make_bounds_min,
)
from BHFM2.runners.run_bonding_systematic import (
    _grouped_residuals,
    _objective_row_index,
    _objective_vector,
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Mh", type=int, default=1)
    ap.add_argument("--Mg", type=int, default=1)
    ap.add_argument("--Mb", type=int, default=1)
    ap.add_argument("--mode", default="bonding_plus_antibonding")
    ap.add_argument("--U", type=float, default=2.0)
    ap.add_argument("--t", type=float, default=0.5)
    ap.add_argument("--T", type=float, default=0.2)
    ap.add_argument("--z", type=float, default=0.5)
    ap.add_argument("--Nk", type=int, default=16)
    ap.add_argument("--n-target", type=float, default=1.0)
    ap.add_argument("--n-moments", type=int, default=8)
    ap.add_argument("--max-nfev", type=int, default=60)
    ap.add_argument(
        "--objective",
        choices=["gateway_only", "gateway_plus_impfill_moments",
                 "gateway_plus_closures", "legacy_full"],
        default="gateway_plus_impfill_moments",
    )
    args = ap.parse_args()

    mp = ModelParamsMin(
        t=args.t, eps_d=0.0, U=args.U, z=args.z,
        filling_target=args.n_target, Sigma_inf=args.U * args.n_target / 2.0,
        beta=1.0 / args.T, Nk=args.Nk, use_y_bond=True, n_moments=args.n_moments,
    )
    codec = CodecMin(args.Mh, args.Mg, args.Mb, mode=args.mode)
    lo, hi = make_bounds_min(args.Mh, args.Mg, args.Mb, mode=args.mode)
    p0 = init_min(args.Mh, args.Mg, args.Mb,
                  base_mu=args.U * args.n_target / 2.0, mode=args.mode)
    x0 = np.clip(codec.pack(p0), lo + 1e-8, hi - 1e-8)

    row_idx = _objective_row_index(
        args.Mh, args.Mg, args.Mb, args.mode, args.n_moments, args.objective
    )
    counts = {"fun": 0, "jac": 0}

    def fun(x):
        counts["fun"] += 1
        _r, blocks, _ = _grouped_residuals(
            codec.unpack(x), mp, args.Mh, args.Mg, args.Mb, args.mode
        )
        return _objective_vector(blocks, args.objective)

    def jac(x):
        counts["jac"] += 1
        return residual_and_jacobian_min(
            codec.unpack(x), mp, args.Mh, args.Mg, args.Mb, mode=args.mode
        )[1][row_idx]

    fun(x0)  # warm numba before timing

    results = {}
    for label, jac_arg in [("2-point FD", "2-point"), ("analytic", jac)]:
        counts["fun"] = counts["jac"] = 0
        t0 = time.time()
        sol = least_squares(
            fun, x0, jac=jac_arg, method="trf", bounds=(lo, hi),
            x_scale="jac", max_nfev=args.max_nfev,
        )
        wall = time.time() - t0
        results[label] = (wall, sol)
        true_evals = counts["fun"] + (sol.njev * len(x0) if jac_arg == "2-point" else 0)
        print(f"{label:>10}: ||r||={np.linalg.norm(sol.fun):.3e}  "
              f"nfev={sol.nfev} njev={sol.njev}  "
              f"true residual evals~{true_evals}  wall={wall:.1f}s  [{sol.message}]")

    w_fd, s_fd = results["2-point FD"]
    w_an, s_an = results["analytic"]
    print(f"\nspeedup x{w_fd / max(w_an, 1e-9):.1f} at "
          f"||r|| {np.linalg.norm(s_fd.fun):.3e} (FD) vs {np.linalg.norm(s_an.fun):.3e} (analytic)")


if __name__ == "__main__":
    main()
