#!/usr/bin/env python3
"""Systematic site+bond study runner with decoupled Mh/Mg and explicit mode."""
from __future__ import annotations

import argparse
import csv
import json
import os
import pickle
import sys
import time
from dataclasses import replace

import numpy as np
from scipy.optimize import least_squares

if __package__ in {None, ""}:
    sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "..", "..")))

from BHFM2.core.solve_min import (
    ModelParamsMin,
    CodecMin,
    LATTICE_BETHE,
    LATTICE_SQUARE,
    VALID_LATTICES,
    MODE_BONDING_ONLY,
    MODE_BONDING_PLUS_ANTIBONDING,
    MODE_SINGLE_IMPURITY,
    SParMin,
    ThermalTruncationError,
    _normalize_lattice,
    compute_omega_scheme,
    init_min,
    make_bounds_min,
    imp1_obs,
    imp2_obs,
    lat_obs,
    gw1_obs,
    gw2_obs,
    mom_lat,
    mom_imp1,
    mom_imp2,
)


def _grid(name: str):
    if name == "quick":
        return [1.25], [0.90], [0.10]
    if name == "prioritized":
        return [1.25, 2.0, 3.0, 4.0], [0.95, 0.90], [0.10, 0.05]
    if name == "mott":
        return [1.25, 2.0, 3.0, 4.0, 5.0], [1.00, 0.95, 0.90], [0.20, 0.10, 0.05]
    raise ValueError(f"unknown grid: {name}")


def _parse_csv_floats(s: str):
    s = s.strip()
    if not s:
        return None
    return [float(x) for x in s.split(",") if x.strip()]


def _default_init(Mh: int, Mg: int, Mb: int, mu0: float, mode: str):
    p = init_min(Mh, Mg, Mb, W0=0.3, V0=0.3, B0=0.1, base_mu=mu0, mode=mode)
    if Mh > 0:
        poles_h = np.linspace(-0.75, 0.75, Mh)
        p.eta = poles_h.copy()
        p.eta1 = poles_h.copy()
        p.eta2 = poles_h.copy()
    if Mg > 0:
        poles_g = np.linspace(-0.75, 0.75, Mg)
        p.eps1 = poles_g.copy()
        if mode != MODE_SINGLE_IMPURITY:
            p.eps2 = poles_g.copy()
    if mode == MODE_BONDING_PLUS_ANTIBONDING and Mb > 0:
        poles_b = np.linspace(-0.5, 0.5, Mb)
        p.eta_a = poles_b.copy()
        p.eta_a2 = poles_b.copy()
        p.eps_a = poles_b.copy()
    return p


def _dark_init(Mh: int, Mg: int, Mb: int, U: float, n: float, mode: str, cap: float = 3.0):
    """Atomic / local-moment seed for the insulating (dark) branch.

    Starts from the default pole layout, then (a) decouples the impurity
    bath(s) (V -> ~0, the runner's dark_bath criterion is sum V^2 < 1e-3) and
    (b) loads the lattice ghost with the atomic self-energy weight
    sum W^2 = U^2/4 with poles pulled toward omega=0, so Sigma_loc ~ U/2 +
    (U/2)^2/(iw) and the Hubbard bands sit near +/-U/2. This biases the
    optimizer toward the decoupled (insulating) stationary point rather than
    the metallic one; pair with --retry-dark 0 to keep it there.
    """
    p = _default_init(Mh, Mg, Mb, mu0=U * n / 2.0, mode=mode)
    small = 0.02
    # Cap the per-pole ghost amplitude just under the weight bound C (--weight-cap).
    w_cap = max(cap - 0.05, 0.1)
    w_atomic = min(0.5 * U / np.sqrt(max(Mh, 1)), w_cap)
    p.W = np.full(Mh, w_atomic)
    p.eta = np.linspace(-0.05, 0.05, Mh) if Mh > 1 else np.zeros(Mh)
    p.V1 = np.full(Mg, small)
    if mode != MODE_SINGLE_IMPURITY:
        p.V2 = np.full(Mg, small)
        if Mb > 0:
            # split atomic weight across site + bond lattice-ghost channels
            b_atomic = min(0.5 * w_atomic, w_cap)
            p.B_h = np.full(Mb, b_atomic)
            p.B_g = np.full(Mb, small)
            if mode == MODE_BONDING_PLUS_ANTIBONDING:
                p.B_ha = np.full(Mb, b_atomic)
                p.B_ga = np.full(Mb, small)
    return p


def _coherent_init(Mh: int, Mg: int, Mb: int, U: float, n: float, mode: str):
    """Coherent-metal seed: eta ~ +/-0.5, finite bath coupling.

    For Mh=2 the +/-pair sits at eta = [-0.5, +0.5], placing the
    quasiparticle pole structure at the coherence scale rather than
    at omega ~ 0 (atomic skeleton from _dark_init) or omega ~ +/-0.75
    (default spread from _default_init).  The impurity baths stay
    coupled (V ~ 0.3) and the ghost weight is set to U/2 / sqrt(Mh),
    same as _dark_init but with the poles pulled OUT from zero.

    Use with --seed-mode coherent at specific U/t values to test
    whether the optimizer can find a genuinely coherent correlated-
    metal fixed point distinct from the atomic-skeleton one.
    """
    p = _default_init(Mh, Mg, Mb, mu0=U * n / 2.0, mode=mode)
    w_coh = min(0.5 * U / np.sqrt(max(Mh, 1)), 2.95)
    p.W = np.full(Mh, w_coh)
    # Place poles at +/-0.5 (coherent scale), NOT near zero
    p.eta = np.linspace(-0.5, 0.5, Mh) if Mh > 1 else np.array([0.5])
    p.eta1 = p.eta.copy()
    p.eta2 = p.eta.copy()
    return p


def _sigma_loc_matsubara(p, Sigma_inf, beta, anti, n_pts):
    """Local self-energy on the first n_pts fermionic Matsubara frequencies,
    from the SAME lattice-ghost pole representation used for Zloc:

        Sigma_loc(iw_n) = Sigma_inf + sum_k W_k^2/(iw_n - eta_k)
                          + sum_k B_h,k^2/(iw_n - eta_b,k)  [+ antibonding]

    Pure numpy, identical convention to the iw0 Zloc at line ~411 (NOT the
    pole set the artifact builder reconstructs, which is a different object).
    """
    wn = (2 * np.arange(n_pts) + 1) * np.pi / beta
    iwn = 1j * wn
    sig = np.full(n_pts, float(Sigma_inf), dtype=complex)

    def _add(amp, pole):
        amp = np.asarray(amp, dtype=float)
        pole = np.asarray(pole, dtype=float)
        if amp.size:
            nonlocal sig
            sig = sig + (amp[None, :] ** 2 / (iwn[:, None] - pole[None, :])).sum(axis=1)

    _add(p.W, p.eta)
    _add(p.B_h, p.eta_b)
    if anti:
        _add(getattr(p, "B_ha", np.zeros(0)), getattr(p, "eta_a", np.zeros(0)))
    return wn, sig


def _coherence_diagnostic(p, Sigma_inf, beta, anti, n_pts=16, n_fit=6):
    """Coherence diagnostic from the low-frequency ImSigma(iw_n) curve.

    Tracks the WHOLE low-frequency self-energy and its slope toward w->0,
    rather than the single first-Matsubara proxy Z(w_0 = pi T), which drifts
    with T because pi T samples the curve at different points. Two readings of
    the lowest n_fit Matsubara points:

    (1) Free line fit ImSigma ~ slope*w + intercept. For a clean Fermi liquid
        ImSigma(iw->0) -> 0, so ``ImSigma_intercept_lowfreq`` ~ 0 with high
        ``Z_slope_fit_quality`` (coefficient of determination). A finite
        NEGATIVE intercept / low fit quality flags an incoherent ImSigma ~
        -A/w (pseudogap/Mott), i.e. the "metal" is scattering-dominated at
        w->0 regardless of where pi T lands.

    (2) Through-origin slope (FL form ImSigma ~ w (1 - 1/Z), forced through 0)
        gives the T-robust quasiparticle weight ``Z_slope = 1/(1 - slope0)``.
        Bounded in (0,1] and far less T-sensitive than the proxy; read it
        together with the intercept (its FL-validity comes from (1)).

    ``Z_slope_fit_quality`` is a throwaway linearity gauge of the
    extrapolation only -- NOT any gauge-transformation / R-vector object.
    """
    wn, sig = _sigma_loc_matsubara(p, Sigma_inf, beta, anti, n_pts)
    im = np.imag(sig)
    k = int(min(max(n_fit, 2), n_pts))
    x, y = wn[:k], im[:k]
    # (1) free fit -> intercept (FL validity) + linearity gauge
    A = np.vstack([x, np.ones_like(x)]).T
    coef, *_ = np.linalg.lstsq(A, y, rcond=None)
    slope, intercept = float(coef[0]), float(coef[1])
    yhat = A @ coef
    ss_res = float(np.sum((y - yhat) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    fit_quality = float(1.0 - ss_res / ss_tot) if ss_tot > 0 else float("nan")
    # (2) through-origin slope -> T-robust FL quasiparticle weight
    sxx = float(np.sum(x * x))
    slope0 = float(np.sum(x * y) / sxx) if sxx > 0 else float("nan")
    z_slope = 1.0 / (1.0 - slope0) if np.isfinite(slope0) and (1.0 - slope0) != 0 else float("nan")
    return dict(
        omega_n=wn.tolist(),
        ImSigma_loc_iwn=im.tolist(),
        ReSigma_loc_iwn=np.real(sig).tolist(),
        ImSigma_slope_lowfreq=slope,
        ImSigma_slope0_lowfreq=slope0,
        ImSigma_intercept_lowfreq=intercept,
        Z_slope=z_slope,
        Z_slope_fit_quality=fit_quality,
        coherence_n_fit=k,
        coherence_n_pts=int(n_pts),
    )


def _pole_coherence_diagnostic(p, anti):
    """Z_pole and eta diagnostics from the lattice-ghost pole sum.

    The local self-energy is an exact pole sum:

        Sigma_loc(w) = Sigma_inf + sum_k W_k^2 / (w - eta_k)
                     + sum_k B_h_k^2 / (w - eta_b_k)  [+ antibonding]

    The quasiparticle weight at w=0 is:

        Z_pole = 1 / (1 + sum_k W_k^2 / eta_k^2 + ...)

    This is the exact, T-independent coherence measure.  When eta_k -> 0
    the pole weight diverges and Z_pole -> 0 (Mott / atomic skeleton).
    When eta_k ~ +/-0.5, Z_pole is finite (coherent metal).  Reading the
    poles directly does what three rounds of Matsubara line-fitting could
    not -- which is the whole point of the pole-sum framework.
    """
    weight_sum = 0.0
    all_eta = []

    eta = np.asarray(p.eta, dtype=float)
    W = np.asarray(p.W, dtype=float)
    if eta.size:
        all_eta.extend(eta.tolist())
        # Guard: eta_k = 0 exactly -> W^2/eta^2 = inf, Z_pole = 0
        with np.errstate(divide="ignore", invalid="ignore"):
            weight_sum += float(np.sum(W**2 / np.where(np.abs(eta) > 1e-15, eta**2, 1e-30)))

    eta_b = np.asarray(p.eta_b, dtype=float)
    B_h = np.asarray(p.B_h, dtype=float)
    if eta_b.size:
        all_eta.extend(eta_b.tolist())
        with np.errstate(divide="ignore", invalid="ignore"):
            weight_sum += float(np.sum(B_h**2 / np.where(np.abs(eta_b) > 1e-15, eta_b**2, 1e-30)))

    if anti:
        eta_a = np.asarray(getattr(p, "eta_a", np.zeros(0)), dtype=float)
        B_ha = np.asarray(getattr(p, "B_ha", np.zeros(0)), dtype=float)
        if eta_a.size:
            all_eta.extend(eta_a.tolist())
            with np.errstate(divide="ignore", invalid="ignore"):
                weight_sum += float(np.sum(B_ha**2 / np.where(np.abs(eta_a) > 1e-15, eta_a**2, 1e-30)))

    z_pole = 1.0 / (1.0 + weight_sum) if np.isfinite(weight_sum) else 0.0
    eta_arr = np.array(all_eta, dtype=float)
    eta_min_abs = float(np.min(np.abs(eta_arr))) if eta_arr.size else float("nan")

    return dict(
        Z_pole=z_pole,
        eta_min_abs=eta_min_abs,
        eta_poles=eta_arr.tolist(),
        pole_weight_sum=weight_sum,
    )


def _nearest_warm_start(U, T, n, param_map):
    if not param_map:
        return None
    same_u = [((u, tt, nn), p) for (u, tt, nn), p in param_map.items() if abs(u - U) < 1e-12]
    if same_u:
        same_u.sort(key=lambda kv: abs(kv[0][1] - T) + 3.0 * abs(kv[0][2] - n))
        return same_u[0][1], f"same-U nearest {same_u[0][0]}"
    allp = list(param_map.items())
    allp.sort(key=lambda kv: abs(kv[0][0] - U) + abs(kv[0][1] - T) + 4.0 * abs(kv[0][2] - n))
    return allp[0][1], f"cross-U nearest {allp[0][0]}"


def _json_safe(obj):
    if isinstance(obj, dict):
        return {str(k): _json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_json_safe(v) for v in obj]
    if isinstance(obj, np.ndarray):
        return _json_safe(obj.tolist())
    if isinstance(obj, (np.floating, np.integer)):
        return obj.item()
    if isinstance(obj, np.bool_):
        return bool(obj)
    if isinstance(obj, float) and not np.isfinite(obj):
        return None
    return obj


def _parameter_payload(p):
    names = [
        "eta", "W", "eta_b", "B_h", "eps1", "V1", "eta1", "W1",
        "eps2", "V2", "eta2", "W2", "eta_b2", "B_h2", "eps_b", "B_g",
        "eta_a", "B_ha", "eta_a2", "B_ha2", "eps_a", "B_ga",
    ]
    out = {name: np.asarray(getattr(p, name, []), dtype=float).tolist() for name in names}
    out["mu"] = float(p.mu)
    return out


def _params_from_mapping(pars, codec):
    kw = {}
    for name, n in codec._fields():
        arr = np.asarray(pars.get(name, []), dtype=float).ravel()
        if len(arr) != n:
            raise ValueError(f"{name}: expected {n} entries, got {len(arr)}")
        kw[name] = arr
    mu = codec.fixed_mu if codec.fixed_mu is not None else float(np.asarray(pars["mu"]).ravel()[0])
    for name in (
        "eta", "W", "eta_b", "B_h", "eps1", "V1", "eta1", "W1",
        "eps2", "V2", "eta2", "W2", "eta_b2", "B_h2", "eps_b", "B_g",
    ):
        kw.setdefault(name, np.zeros(0))
    return SParMin(mu=float(mu), **kw)


def _load_warm_start(path, codec):
    if not path:
        return None
    if path.endswith(".json"):
        with open(path, encoding="utf-8") as f:
            d = json.load(f)
        pars = d.get("optimized_parameters") or d.get("observables") or d
        return _params_from_mapping(pars, codec)
    with open(path, "rb") as f:
        obj = pickle.load(f)
    if isinstance(obj, dict) and "x" in obj:
        x = np.asarray(obj["x"], dtype=float)
        if len(x) == codec.size:
            return codec.unpack(x)
        full_codec = CodecMin(codec.Mh, codec.Mg, codec.Mb, mode=codec.mode)
        if codec.fixed_mu is not None and len(x) == full_codec.size:
            p = full_codec.unpack(x)
            return replace(p, mu=codec.fixed_mu)
        raise ValueError(f"checkpoint x has length {len(x)}, expected {codec.size}")
    if isinstance(obj, dict) and all(name in obj for name, _n in codec._fields()):
        return _params_from_mapping(obj, codec)
    raise ValueError(f"Unsupported warm-start format: {path}")


def _attempt_stem(info, attempt_label):
    lattice = _normalize_lattice(info.get("lattice", LATTICE_SQUARE))
    lattice_tag = "" if lattice == LATTICE_SQUARE else f"_lat-{lattice}"
    return (
        f"attempt_{attempt_label}_mode-{info['mode']}{lattice_tag}"
        f"_Mh{info['Mh']}_Mg{info['Mg']}_Mb{info['Mb']}"
        f"_U{info['U']:.6g}_T{info['T']:.6g}_n{info['n_target']:.6g}"
    ).replace("/", "_")


def _write_attempt_json(study_dir, info, p, attempt_label):
    attempt_dir = os.path.join(study_dir, "attempts")
    os.makedirs(attempt_dir, exist_ok=True)
    payload = dict(observables=info, optimized_parameters=_parameter_payload(p))
    path = os.path.join(attempt_dir, _attempt_stem(info, attempt_label) + ".json")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(_json_safe(payload), f, indent=2, sort_keys=True)
    return path


def _csv_cell(v):
    if isinstance(v, np.ndarray):
        v = v.tolist()
    if isinstance(v, (list, tuple)):
        return ";".join("" if x is None else f"{float(x):.12g}" for x in v)
    if isinstance(v, dict):
        return json.dumps(_json_safe(v), sort_keys=True)
    if isinstance(v, (np.floating, np.integer)):
        v = v.item()
    if isinstance(v, float) and not np.isfinite(v):
        return ""
    return v


def _write_summary_csv(path, results):
    if not results:
        return
    preferred = [
        "mode", "lattice", "branch_label", "half_filling_ph", "Mh", "Mg", "Mb",
        "U", "U_over_t", "t", "T", "beta", "n_target", "resnorm", "resmax",
        "n_avg", "n_lat", "n_imp1", "n_imp2", "mu", "mu_minus_U_over_2", "Sigma_inf",
        "D_imp1", "D_imp2", "D_ncs", "D_lat",
        "Z_pole", "eta_min_abs", "Z_mats", "ImSigma_iw0",
        "Z_slope", "Z_slope_fit_quality", "ImSigma_slope_lowfreq",
        "ImSigma_slope0_lowfreq", "ImSigma_intercept_lowfreq",
        "Omega_imp", "Omega_lat", "Omega_gateway", "Omega_total",
        "sum_V2_imp1", "sum_V2_imp2", "sum_W2_lattice", "U2_over_4",
        "sum_W2_minus_U2_over_4", "dark_bath", "nfev", "wall",
    ]
    keys = []
    for k in preferred:
        if any(k in r for r in results):
            keys.append(k)
    for r in results:
        for k in r:
            if k not in keys and not isinstance(r[k], dict):
                keys.append(k)
    with open(path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        writer.writeheader()
        for r in results:
            writer.writerow({k: _csv_cell(r.get(k, "")) for k in keys})


def _grouped_residuals(p, mp_base, Mh: int, Mg: int, Mb: int, mode: str, pin_sigma_inf=None):
    anti = mode == MODE_BONDING_PLUS_ANTIBONDING and Mb > 0
    z = mp_base.z
    imp1 = imp1_obs(p, mp_base, Mg)
    if mode == MODE_SINGLE_IMPURITY:
        if Mb != 0:
            raise ValueError("single_impurity mode requires Mb=0")
        n_avg = float(imp1["dens"])
        Sigma_inf_iter = mp_base.U * n_avg / 2.0 if pin_sigma_inf is None else float(pin_sigma_inf)
        mp = replace(mp_base, Sigma_inf=Sigma_inf_iter)
        lat = lat_obs(p, mp, Mh, Mb, mode=mode)
        gw1 = gw1_obs(p, mp, Mh, Mg)
        blocks = {}
        blocks["local_h_occ"] = np.asarray(lat["hh"] - gw1["hh"], dtype=float).ravel()
        blocks["local_h_coh"] = np.asarray(lat["dh"] - gw1["dh"], dtype=float).ravel()
        blocks["g1_occ"] = np.asarray(imp1["gg"] - gw1["gg"], dtype=float).ravel()
        blocks["g1_coh"] = np.asarray(imp1["dg"] - gw1["dg"], dtype=float).ravel()
        blocks["fill_imp"] = np.asarray([n_avg - mp_base.filling_target], dtype=float)
        blocks["fill_lat"] = np.asarray([lat["dens"] - mp_base.filling_target], dtype=float)
        mres = []
        for m in range(mp_base.n_moments):
            mres.append(mom_lat(p, m, mode=mode) - mom_imp1(p, m))
        blocks["moments"] = np.asarray(mres, dtype=float)
        r = np.concatenate([v for v in blocks.values()]) if blocks else np.array([], dtype=float)
        return r, blocks, dict(
            imp1=imp1,
            imp2=None,
            lat=lat,
            gw1=gw1,
            gw2=None,
            n_avg=n_avg,
            Sigma_inf=float(Sigma_inf_iter),
        )

    imp2 = imp2_obs(p, mp_base, Mg, Mb, mode=mode)
    n_avg = (1 - z) * imp1["dens"] + z * imp2["dens_per_site"]
    # --pin-ph: hold Sigma_inf at the PH value instead of the n_avg feed-forward
    Sigma_inf_iter = mp_base.U * n_avg / 2.0 if pin_sigma_inf is None else float(pin_sigma_inf)
    mp = replace(mp_base, Sigma_inf=Sigma_inf_iter)
    lat = lat_obs(p, mp, Mh, Mb, mode=mode)
    gw1 = gw1_obs(p, mp, Mh, Mg)
    gw2 = gw2_obs(p, mp, Mh, Mg, Mb, mode=mode)

    blocks = {}
    blocks["local_h_occ"] = np.asarray(lat["hh"] - ((1 - z) * gw1["hh"] + z * gw2["hh"]), dtype=float).ravel()
    blocks["local_h_coh"] = np.asarray(lat["dh"] - ((1 - z) * gw1["dh"] + z * gw2["dh"]), dtype=float).ravel()
    blocks["bond_h_occ"] = np.asarray(lat["hbp_hbp"] - gw2["hbp_hbp"], dtype=float).ravel()
    blocks["bond_h_coh"] = np.asarray(lat["hbp_d"] - gw2["hbp_dplus"], dtype=float).ravel()
    blocks["g1_occ"] = np.asarray(imp1["gg"] - gw1["gg"], dtype=float).ravel()
    blocks["g1_coh"] = np.asarray(imp1["dg"] - gw1["dg"], dtype=float).ravel()
    blocks["g2_occ"] = np.asarray(imp2["gg"] - gw2["gg"], dtype=float).ravel()
    blocks["g2_coh"] = np.asarray(imp2["dg"] - gw2["dg"], dtype=float).ravel()
    blocks["bond_g_occ"] = np.asarray(imp2["gbp_gbp"] - gw2["gbp_gbp"], dtype=float).ravel()
    blocks["bond_g_coh"] = np.asarray(imp2["gbp_dplus"] - gw2["gbp_dplus"], dtype=float).ravel()
    if anti:
        blocks["bondm_h_occ"] = np.asarray(lat["hbm_hbm"] - gw2["hbm_hbm"], dtype=float).ravel()
        blocks["bondm_h_coh"] = np.asarray(lat["hbm_d"] - gw2["hbm_dminus"], dtype=float).ravel()
        blocks["bondm_g_occ"] = np.asarray(imp2["gbm_gbm"] - gw2["gbm_gbm"], dtype=float).ravel()
        blocks["bondm_g_coh"] = np.asarray(imp2["gbm_dminus"] - gw2["gbm_dminus"], dtype=float).ravel()
    blocks["fill_imp"] = np.asarray([n_avg - mp_base.filling_target], dtype=float)
    blocks["fill_lat"] = np.asarray([lat["dens"] - mp_base.filling_target], dtype=float)
    blocks["bond_kinetic"] = np.asarray([lat["bond_x"] - imp2["bond_kinetic_per_bond"]], dtype=float)

    mres = []
    for m in range(mp_base.n_moments):
        lhs = mom_lat(p, m, mode=mode)
        rhs = (1 - z) * mom_imp1(p, m) + z * mom_imp2(p, m, mode=mode)
        mres.append(lhs - rhs)
    blocks["moments"] = np.asarray(mres, dtype=float)

    r = np.concatenate([v for v in blocks.values()]) if blocks else np.array([], dtype=float)
    return r, blocks, dict(imp1=imp1, imp2=imp2, lat=lat, gw2=gw2, n_avg=float(n_avg), Sigma_inf=float(Sigma_inf_iter))


def _objective_keys(objective: str, drop_filling: bool = False, include_lat_filling: bool = False):
    gateway = [
        "local_h_occ",
        "local_h_coh",
        "bond_h_occ",
        "bond_h_coh",
        "g1_occ",
        "g1_coh",
        "g2_occ",
        "g2_coh",
        "bond_g_occ",
        "bond_g_coh",
        "bondm_h_occ",
        "bondm_h_coh",
        "bondm_g_occ",
        "bondm_g_coh",
    ]
    if objective == "legacy_full":
        keys = gateway + ["fill_imp", "fill_lat", "bond_kinetic", "moments"]
    elif objective == "gateway_only":
        keys = gateway
    elif objective == "gateway_plus_impfill_moments":
        keys = gateway + ["fill_imp", "moments"]
    elif objective == "gateway_plus_closures":
        keys = gateway + ["fill_imp", "fill_lat", "moments"]
    else:
        raise ValueError(f"unknown objective mode: {objective}")
    if include_lat_filling and "fill_imp" in keys and "fill_lat" not in keys:
        keys = [
            item
            for key in keys
            for item in ([key, "fill_lat"] if key == "fill_imp" else [key])
        ]
    if drop_filling:
        keys = [k for k in keys if k not in {"fill_imp", "fill_lat"}]
    return keys


def _objective_vector(blocks, objective: str, drop_filling: bool = False, include_lat_filling: bool = False):
    vecs = [
        blocks[k]
        for k in _objective_keys(
            objective, drop_filling=drop_filling, include_lat_filling=include_lat_filling
        )
        if k in blocks
    ]
    return np.concatenate(vecs) if vecs else np.array([], dtype=float)


def _objective_row_index(
    Mh, Mg, Mb, mode, n_moments, objective,
    drop_filling: bool = False,
    include_lat_filling: bool = False,
):
    """Indices selecting objective rows from residual_and_jacobian_min output."""
    from BHFM2.core.jacobian_min import block_slices

    sl = block_slices(Mh, Mg, Mb, mode=mode, n_moments=n_moments)
    parts = [
        np.arange(sl[k].start, sl[k].stop)
        for k in _objective_keys(
            objective, drop_filling=drop_filling, include_lat_filling=include_lat_filling
        )
        if k in sl
    ]
    return np.concatenate(parts).astype(int)


def _objective_n_eq(
    Mh: int,
    Mg: int,
    Mb: int,
    n_moments: int,
    objective: str,
    mode: str,
    drop_filling: bool = False,
    include_lat_filling: bool = False,
) -> int:
    from BHFM2.core.jacobian_min import block_slices

    sl = block_slices(Mh, Mg, Mb, mode=mode, n_moments=n_moments)
    return int(
        sum(
            sl[k].stop - sl[k].start
            for k in _objective_keys(
                objective, drop_filling=drop_filling, include_lat_filling=include_lat_filling
            )
            if k in sl
        )
    )


def _summarize(
    p,
    mp_base,
    Mh: int,
    Mg: int,
    Mb: int,
    target_n,
    objective_mode,
    opt_meta,
    mode: str,
    pin_sigma_inf=None,
    half_filling_ph: bool = False,
    drop_filling: bool = False,
    include_lat_filling: bool = False,
):
    anti = mode == MODE_BONDING_PLUS_ANTIBONDING and Mb > 0
    single = mode == MODE_SINGLE_IMPURITY
    r_all, blocks, ev = _grouped_residuals(p, mp_base, Mh, Mg, Mb, mode, pin_sigma_inf=pin_sigma_inf)
    r_obj = _objective_vector(
        blocks,
        objective_mode,
        drop_filling=drop_filling,
        include_lat_filling=include_lat_filling,
    )
    imp1 = ev["imp1"]
    imp2 = ev["imp2"]
    lat = ev["lat"]
    gw2 = ev["gw2"]
    z = mp_base.z

    # Matsubara Z cross-checks (Z_mats/Zloc, ImSigma slope) are T->0 properties
    # evaluated on a beta-grid. At ground_state (beta=1e8) the first Matsubara
    # frequency ~3e-8 makes ImSigma(iw0) catastrophically cancel -> garbage/neg Z;
    # cap beta=1000 (T=1e-3, plenty cold) for these probes only. The physical Z is
    # Z_pole (pole-sum, beta-independent) from _pole_coherence_diagnostic below.
    beta_diag = min(float(mp_base.beta), 1000.0)
    iw0 = 1j * np.pi / beta_diag
    sigma_loc_iw0 = ev["Sigma_inf"] + np.sum(p.W**2 / (iw0 - p.eta)) + np.sum(p.B_h**2 / (iw0 - p.eta_b))
    if anti:
        sigma_loc_iw0 += np.sum(np.asarray(p.B_ha, dtype=float) ** 2 / (iw0 - np.asarray(p.eta_a, dtype=float)))
    zloc = 1.0 / (1.0 + abs(float(np.imag(sigma_loc_iw0))) / iw0.imag)
    coherence = _coherence_diagnostic(p, ev["Sigma_inf"], beta_diag, anti)
    pole_diag = _pole_coherence_diagnostic(p, anti)

    # Bath-coupling health metric (see PH-study NUMBERS_DEEP_DIVE 2026-06-11):
    # the matching objective admits decoupled stationary points where impurity
    # bath amplitudes go dark and D/Z report free-impurity physics. Flag them.
    bath_w1 = float(np.sum(np.asarray(p.V1, dtype=float) ** 2))
    if single:
        bath_w2 = float("nan")
        dark_bath = bool(bath_w1 < 1e-3)
        n_imp2 = float("nan")
        D_imp2 = float("nan")
        D_ncs = float(imp1["double_occ"])
        imp2_tail = {}
        bond_x_imp2 = float("nan")
    else:
        bath_w2 = float(
            np.sum(np.asarray(p.V2, dtype=float) ** 2)
            + np.sum(np.asarray(p.B_g, dtype=float) ** 2)
            + np.sum(np.asarray(getattr(p, "B_ga", np.zeros(0)), dtype=float) ** 2)
        )
        dark_bath = bool(bath_w1 < 1e-3 or bath_w2 < 1e-3)
        n_imp2 = float(imp2["dens_per_site"])
        D_imp2 = float(imp2["double_occ_per_site"])
        D_ncs = float((1 - z) * imp1["double_occ"] + z * imp2["double_occ_per_site"])
        imp2_tail = dict(imp2.get("thermal_audit", {}))
        bond_x_imp2 = float(imp2["bond_kinetic_per_bond"])

    sum_W2_lattice = float(
        np.sum(np.asarray(p.W, dtype=float) ** 2)
        + np.sum(np.asarray(p.B_h, dtype=float) ** 2)
        + np.sum(np.asarray(getattr(p, "B_ha", np.zeros(0)), dtype=float) ** 2)
    )
    sum_W2_imp1 = float(np.sum(np.asarray(p.W1, dtype=float) ** 2))
    sum_W2_imp2 = float(
        np.sum(np.asarray(p.W2, dtype=float) ** 2)
        + np.sum(np.asarray(p.B_h2, dtype=float) ** 2)
        + np.sum(np.asarray(getattr(p, "B_ha2", np.zeros(0)), dtype=float) ** 2)
    )
    u2_over_4 = float(mp_base.U**2 / 4.0)
    symmetry_broken = bool(
        half_filling_ph
        and (
            abs(float(ev["n_avg"]) - 1.0) > 5e-3
            or abs(float(lat["dens"]) - 1.0) > 5e-3
            or (not single and abs(float(imp1["dens"]) - n_imp2) > 5e-3)
        )
    )
    if dark_bath:
        branch_label = "dark"
    elif symmetry_broken:
        branch_label = "symmetry-broken"
    else:
        branch_label = "coupled"

    mp_omega = replace(mp_base, Sigma_inf=float(ev["Sigma_inf"]))
    omega = compute_omega_scheme(p, mp_omega, Mh, Mg, Mb, mode=mode, imp1=imp1, imp2=imp2)
    lattice = _normalize_lattice(getattr(mp_base, "lattice", LATTICE_SQUARE))
    if lattice == LATTICE_BETHE:
        k_grid = "bethe_semicircular_gauss_chebyshev_u"
        gamma_k_form = ""
        dos = "semicircular"
        dos_m2 = float(mp_base.t**2)
    else:
        k_grid = "square_uniform"
        gamma_k_form = "cos(kx)+cos(ky)"
        dos = "square_nearest_neighbor"
        dos_m2 = float(4.0 * mp_base.t**2)

    info = dict(
        Mh=int(Mh),
        Mg=int(Mg),
        Mb=int(Mb),
        M=int(Mh),
        U=float(mp_base.U),
        U_over_t=float(mp_base.U / mp_base.t),
        t=float(mp_base.t),
        T=float(1.0 / mp_base.beta),
        beta=float(mp_base.beta),
        Nk=int(mp_base.Nk),
        lattice=lattice,
        dos=dos,
        dos_m2=dos_m2,
        k_grid=k_grid,
        gamma_k_form=gamma_k_form,
        use_y_bond=bool(mp_base.use_y_bond),
        z_ncs=float(mp_base.z),
        n_target=float(target_n),
        n_avg=float(ev["n_avg"]),
        n_lat=float(lat["dens"]),
        n_imp1=float(imp1["dens"]),
        n_imp2=n_imp2,
        density_error_imp=float(ev["n_avg"] - target_n),
        density_error_lat=float(lat["dens"] - target_n),
        D_imp1=float(imp1["double_occ"]),
        D_imp2=D_imp2,
        D_ncs=D_ncs,
        D_lat=D_ncs,
        thermal_audit_imp1=dict(imp1.get("thermal_audit", {})),
        thermal_audit_imp2=imp2_tail,
        mu=float(p.mu),
        mu_minus_U_over_2=float(p.mu - 0.5 * mp_base.U),
        Sigma_inf=float(ev["Sigma_inf"]),
        Zloc=float(zloc),
        Z_mats=float(zloc),
        Sigma_iw0_real=float(np.real(sigma_loc_iw0)),
        Sigma_iw0_imag=float(np.imag(sigma_loc_iw0)),
        ImSigma_iw0=float(np.imag(sigma_loc_iw0)),
        Z_slope=float(coherence["Z_slope"]),
        Z_slope_fit_quality=float(coherence["Z_slope_fit_quality"]),
        ImSigma_slope_lowfreq=float(coherence["ImSigma_slope_lowfreq"]),
        ImSigma_slope0_lowfreq=float(coherence["ImSigma_slope0_lowfreq"]),
        ImSigma_intercept_lowfreq=float(coherence["ImSigma_intercept_lowfreq"]),
        Z_pole=float(pole_diag["Z_pole"]),
        eta_min_abs=float(pole_diag["eta_min_abs"]),
        eta_poles=pole_diag["eta_poles"],
        pole_weight_sum=float(pole_diag["pole_weight_sum"]),
        coherence_n_fit=int(coherence["coherence_n_fit"]),
        omega_n=coherence["omega_n"],
        ImSigma_loc_iwn=coherence["ImSigma_loc_iwn"],
        ReSigma_loc_iwn=coherence["ReSigma_loc_iwn"],
        bath_weight_imp1=bath_w1,
        bath_weight_imp2=bath_w2,
        sum_V2_imp1=bath_w1,
        sum_V2_imp2=bath_w2,
        sum_W2_lattice=sum_W2_lattice,
        sum_W2_imp1=sum_W2_imp1,
        sum_W2_imp2=sum_W2_imp2,
        U2_over_4=u2_over_4,
        sum_W2_minus_U2_over_4=float(sum_W2_lattice - u2_over_4),
        sum_W2_over_U2_over_4=float(sum_W2_lattice / u2_over_4) if u2_over_4 else float("nan"),
        dark_bath=dark_bath,
        symmetry_broken=symmetry_broken,
        branch_label=branch_label,
        half_filling_ph=bool(half_filling_ph),
        mode=str(mode),
        objective_mode=str(objective_mode),
        objective_drop_filling=bool(drop_filling),
        objective_include_lat_filling=bool(include_lat_filling),
        resnorm=float(np.linalg.norm(r_obj)),
        resmax=float(np.max(np.abs(r_obj))) if len(r_obj) else 0.0,
        resnorm_all=float(np.linalg.norm(r_all)),
        resmax_all=float(np.max(np.abs(r_all))) if len(r_all) else 0.0,
        residual_blocks={k: float(np.linalg.norm(v)) for k, v in blocks.items()},
        optimizer_success=bool(opt_meta["success"]),
        optimizer_status=int(opt_meta["status"]),
        optimizer_message=str(opt_meta["message"]),
        optimizer_cost=float(opt_meta["cost"]),
        nfev=int(opt_meta["nfev"]),
        wall=float(opt_meta["wall"]),
        bond_x_lat=float(lat["bond_x"]),
        bond_x_imp2=bond_x_imp2,
        bond_x_mismatch=float(lat["bond_x"] - bond_x_imp2) if not single else float("nan"),
        bond_h_occ_lat=lat["hbp_hbp"].tolist(),
        bond_h_occ_gw2=[] if gw2 is None else gw2["hbp_hbp"].tolist(),
        bond_h_coh_lat=lat["hbp_d"].tolist(),
        bond_h_coh_gw2=[] if gw2 is None else gw2["hbp_dplus"].tolist(),
        bond_g_occ_imp2=[] if imp2 is None else imp2["gbp_gbp"].tolist(),
        bond_g_occ_gw2=[] if gw2 is None else gw2["gbp_gbp"].tolist(),
        bond_g_coh_imp2=[] if imp2 is None else imp2["gbp_dplus"].tolist(),
        bond_g_coh_gw2=[] if gw2 is None else gw2["gbp_dplus"].tolist(),
        eta=p.eta.tolist(),
        W=p.W.tolist(),
        eta_b=p.eta_b.tolist(),
        B_h=p.B_h.tolist(),
        eps1=p.eps1.tolist(),
        V1=p.V1.tolist(),
        eta1=p.eta1.tolist(),
        W1=p.W1.tolist(),
        eps2=p.eps2.tolist(),
        V2=p.V2.tolist(),
        eta2=p.eta2.tolist(),
        W2=p.W2.tolist(),
        eta_b2=p.eta_b2.tolist(),
        B_h2=p.B_h2.tolist(),
        eps_b=p.eps_b.tolist(),
        B_g=p.B_g.tolist(),
        eta_a=np.asarray(getattr(p, "eta_a", []), dtype=float).tolist(),
        B_ha=np.asarray(getattr(p, "B_ha", []), dtype=float).tolist(),
        eta_a2=np.asarray(getattr(p, "eta_a2", []), dtype=float).tolist(),
        B_ha2=np.asarray(getattr(p, "B_ha2", []), dtype=float).tolist(),
        eps_a=np.asarray(getattr(p, "eps_a", []), dtype=float).tolist(),
        B_ga=np.asarray(getattr(p, "B_ga", []), dtype=float).tolist(),
        scheme=(
            "single_impurity_single_site"
            if single
            else (
                "site_plus_bond_bonding_plus_antibonding"
                if anti
                else "site_plus_bond_bonding_only"
            )
        ),
    )
    info.update(omega)
    return info


def _solve_point(
    U,
    T,
    n_target,
    p_init,
    Mh,
    Mg,
    Mb,
    t_hop,
    nk,
    z,
    n_moments,
    objective_mode,
    target_res,
    max_chunks,
    max_nfev_per_chunk,
    ckpt_dir,
    mode,
    lattice=LATTICE_SQUARE,
    jac_mode="2-point",
    pin_ph=False,
    ground_state=False,
    resume=True,
    reparam=None,
    bath_E=5.0,
    pole_E=None,
    weight_cap=3.0,
):
    if pin_ph and abs(float(n_target) - 1.0) > 1e-12:
        raise ValueError("--half-filling-ph requires n_target=1.0")
    lattice = _normalize_lattice(lattice)
    if lattice == LATTICE_BETHE and (mode != MODE_SINGLE_IMPURITY or int(Mb) != 0):
        raise ValueError("--lattice bethe is only implemented for --mode single_impurity --Mb 0")
    mp_base = ModelParamsMin(
        U=U,
        t=t_hop,
        eps_d=0.0,
        z=z,
        Sigma_inf=0.5 * U if pin_ph else U * n_target / 2.0,
        Nk=nk,
        n_moments=n_moments,
        filling_target=n_target,
        beta=(1.0 / T if (T and T > 0) else 1.0),
        lattice=lattice,
        ground_state=ground_state,
    )
    pin_sigma_inf = None
    fixed_mu = None
    if pin_ph:
        # PH half filling: mu and Sigma_inf are held, not fitted.
        fixed_mu = 0.5 * U
        pin_sigma_inf = 0.5 * U
        p_init = replace(p_init, mu=fixed_mu)
    codec = CodecMin(Mh, Mg, Mb, mode=mode, fixed_mu=fixed_mu)
    if pin_ph:
        lo, hi = make_bounds_min(Mh, Mg, Mb, mode=mode, fixed_mu=fixed_mu, E=bath_E, C=weight_cap, E_eta=pole_E)
    else:
        lo, hi = make_bounds_min(Mh, Mg, Mb, mode=mode, E=bath_E, C=weight_cap, E_eta=pole_E)
    x = np.clip(codec.pack(p_init), lo + 1e-9, hi - 1e-9)

    os.makedirs(ckpt_dir, exist_ok=True)
    ph_tag = "_ph" if pin_ph else ""
    lattice_tag = "" if lattice == LATTICE_SQUARE else f"_lat-{lattice}"
    ckpt = os.path.join(
        ckpt_dir,
        f"mode-{mode}{ph_tag}{lattice_tag}_Mh{Mh}_Mg{Mg}_Mb{Mb}_U{U:.2f}_T{T:.3f}_n{n_target:.3f}.pkl",
    )
    if resume and os.path.exists(ckpt):
        with open(ckpt, "rb") as f:
            c = pickle.load(f)
        if len(c.get("x", [])) == len(x):
            x = np.clip(np.asarray(c["x"], dtype=float), lo + 1e-9, hi - 1e-9)
            print(f"    resumed ckpt: ||r||={c['r']:.3e}")
        elif fixed_mu is not None:
            full_codec = CodecMin(Mh, Mg, Mb, mode=mode)
            if len(c.get("x", [])) == full_codec.size:
                p_old = replace(full_codec.unpack(np.asarray(c["x"], dtype=float)), mu=fixed_mu)
                x = np.clip(codec.pack(p_old), lo + 1e-9, hi - 1e-9)
                print(f"    resumed full-mu ckpt into fixed-mu codec: ||r||={c['r']:.3e}")

    # Optimizer coordinate layer. Default: identity (variable == full codec x).
    # With a SymReparam, the optimizer variable is the PH-symmetric y and
    # x_full = A @ y; best/checkpoint stay in FULL codec coordinates so the
    # export/report pipeline is untouched. jac chains as J[row_idx] @ A.
    if reparam is not None:
        _to_full = reparam.to_full
        _to_var = reparam.project
        var_lo, var_hi = reparam.bounds()
        _Acols = reparam.A
        x = np.clip(_to_full(np.clip(_to_var(x), var_lo, var_hi)), lo, hi)
    else:
        _to_full = lambda v: v
        _to_var = lambda xf: xf
        var_lo, var_hi = lo, hi
        _Acols = None

    best = [np.inf, x.copy()]                        # best[1]: FULL codec x
    var_best = [np.asarray(_to_var(x), dtype=float)]  # optimizer-space start
    drop_filling = False
    include_lat_filling = bool(pin_ph and mode == MODE_SINGLE_IMPURITY)
    n_eq = _objective_n_eq(
        Mh, Mg, Mb, mp_base.n_moments, objective_mode, mode,
        drop_filling=drop_filling,
        include_lat_filling=include_lat_filling,
    )
    try:
        _r0_all, r0_blocks, _ = _grouped_residuals(codec.unpack(x), mp_base, Mh, Mg, Mb, mode, pin_sigma_inf=pin_sigma_inf)
        r0 = _objective_vector(
            r0_blocks,
            objective_mode,
            drop_filling=drop_filling,
            include_lat_filling=include_lat_filling,
        )
        best[0] = float(np.linalg.norm(r0))
    except ThermalTruncationError as err:
        print(f"    [tail-guard] start point not certified; optimizer must move away: {err}", flush=True)
    total_nfev = 0
    last_sol = None
    t0 = time.time()

    def fn(v):
        xf = _to_full(v)
        try:
            _r_all, r_blocks, _ = _grouped_residuals(codec.unpack(xf), mp_base, Mh, Mg, Mb, mode, pin_sigma_inf=pin_sigma_inf)
        except ThermalTruncationError as err:
            # Penalize the point instead of crashing the job: the optimizer
            # retreats from uncertified parameter regions, and best/checkpoint
            # are only ever written from certified evaluations.
            print(f"    [tail-guard] uncertified eval penalized: {err}", flush=True)
            return np.full(n_eq, 1.0e3)
        r = _objective_vector(
            r_blocks,
            objective_mode,
            drop_filling=drop_filling,
            include_lat_filling=include_lat_filling,
        )
        rn = float(np.linalg.norm(r))
        if rn < best[0]:
            best[0] = rn
            best[1] = xf.copy()
            var_best[0] = np.asarray(v, dtype=float).copy()
            with open(ckpt, "wb") as fp:
                pickle.dump({"x": xf.copy(), "r": rn}, fp)
        return r

    jac_arg = "2-point"
    if jac_mode == "analytic":
        from BHFM2.core.jacobian_min import residual_and_jacobian_min

        row_idx = _objective_row_index(
            Mh, Mg, Mb, mode, mp_base.n_moments, objective_mode,
            drop_filling=drop_filling,
            include_lat_filling=include_lat_filling,
        )

        def jac_arg(v):
            xf = _to_full(v)
            try:
                _r, J = residual_and_jacobian_min(
                    codec.unpack(xf), mp_base, Mh, Mg, Mb, mode=mode,
                    pin_sigma_inf=pin_sigma_inf, fixed_mu=fixed_mu,
                )
            except ThermalTruncationError as err:
                # Mirror fn's penalty behavior: the constant penalty vector has
                # zero Jacobian, so the optimizer stops instead of stepping
                # deeper into the uncertified region.
                print(f"    [tail-guard] uncertified jac eval, returning zero J: {err}", flush=True)
                return np.zeros((n_eq, np.asarray(v).size))
            # A near-singular arrowhead iterate can make the analytic Jacobian
            # huge (or non-finite); the reparam matmul then overflows. Silence
            # the FP flags and CLIP (do not zero) the offending entries: zeroing
            # strands trf with no gradient at a cold-start seed, whereas clipping
            # preserves the step direction and just bounds magnitude. x_scale=jac
            # then damps the large column.
            _JC = 1.0e8
            with np.errstate(over="ignore", invalid="ignore", divide="ignore"):
                Jr = np.clip(np.nan_to_num(J[row_idx], nan=0.0, posinf=_JC, neginf=-_JC), -_JC, _JC)
                Jout = Jr if _Acols is None else Jr @ _Acols
                Jout = np.clip(np.nan_to_num(Jout, nan=0.0, posinf=_JC, neginf=-_JC), -_JC, _JC)
            return Jout

    if best[0] >= target_res:
        for chunk in range(max_chunks):
            tc = time.time()
            sol = least_squares(
                fn,
                var_best[0],
                jac=jac_arg,
                method="trf",
                bounds=(var_lo, var_hi),
                x_scale="jac",  # auto-scale heterogeneous params (eta/W/eps/V/B/mu); makes each expensive ED nfev count
                ftol=1e-11,
                xtol=1e-11,
                max_nfev=max_nfev_per_chunk,
                verbose=0,
            )
            last_sol = sol
            total_nfev += int(sol.nfev)
            print(f"    chunk {chunk}: nfev={sol.nfev} best={best[0]:.3e} wall={time.time()-tc:.0f}s", flush=True)
            if best[0] < target_res:
                break

    p = codec.unpack(best[1])
    if last_sol is None:
        opt_meta = dict(success=True, status=0, message="warm-start below target", cost=0.5 * best[0] ** 2, nfev=0, wall=time.time() - t0)
    else:
        opt_meta = dict(
            success=last_sol.success,
            status=last_sol.status,
            message=last_sol.message,
            cost=last_sol.cost,
            nfev=total_nfev,
            wall=time.time() - t0,
        )
    info = _summarize(
        p, mp_base, Mh, Mg, Mb, n_target, objective_mode, opt_meta, mode,
        pin_sigma_inf=pin_sigma_inf,
        half_filling_ph=pin_ph,
        drop_filling=drop_filling,
        include_lat_filling=include_lat_filling,
    )
    info["ckpt_path"] = ckpt
    return p, info


def _resolve_dims(args):
    if args.Mh is not None and args.Mg is not None:
        return int(args.Mh), int(args.Mg)
    if args.M is not None:
        return int(args.M), int(args.M)
    if args.Mh is not None:
        return int(args.Mh), 2
    if args.Mg is not None:
        return 2, int(args.Mg)
    return 2, 2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--M", type=int, default=None, help="Legacy shortcut: sets Mh=Mg=M")
    ap.add_argument("--Mh", type=int, default=None, help="Number of h-ghost poles")
    ap.add_argument("--Mg", type=int, default=None, help="Number of g-bath poles")
    ap.add_argument("--Mb", type=int, default=1)
    ap.add_argument(
        "--mode",
        choices=[MODE_SINGLE_IMPURITY, MODE_BONDING_ONLY, MODE_BONDING_PLUS_ANTIBONDING],
        default=MODE_BONDING_ONLY,
        help="Self-consistency mode: plus-only or plus+minus bond channels.",
    )
    ap.add_argument("--grid", choices=["quick", "prioritized", "mott"], default="prioritized")
    ap.add_argument("--U-list", default="")
    ap.add_argument("--n-list", default="")
    ap.add_argument("--T-list", default="")
    ap.add_argument(
        "--ground-state",
        dest="ground_state",
        action="store_true",
        help="T=0 ground-state mode: beta->inf (only the ground manifold). Warm-start from a converged finite-T solution.",
    )
    ap.add_argument("--tag", default="bonding_systematic")
    ap.add_argument("--outdir", default=os.path.join("results", "bhfm2_bonding"))
    ap.add_argument("--checkpoint-dir", default="")
    ap.add_argument("--warm-start-json", default="", help="Seed all points from an attempt JSON with optimized_parameters.")
    ap.add_argument("--warm-start-checkpoint", default="", help="Seed all points from a checkpoint PKL containing x.")
    ap.add_argument("--t-hop", type=float, default=0.5)
    ap.add_argument("--Nk", type=int, default=16)
    ap.add_argument(
        "--lattice",
        choices=sorted(VALID_LATTICES),
        default=LATTICE_SQUARE,
        help="Lattice DOS for single_impurity mode; square is the default.",
    )
    ap.add_argument("--z", type=float, default=4.0, help="Square-lattice coordination number for NCS/B+AB mixing.")
    ap.add_argument("--bath-E", dest="bath_E", type=float, default=5.0,
                    help="Bound (+/-) on bath energies eps* (default 5.0).")
    ap.add_argument("--pole-E", dest="pole_E", type=float, default=None,
                    help="Bound (+/-) on self-energy poles eta* (default: same as --bath-E).")
    ap.add_argument("--weight-cap", dest="weight_cap", type=float, default=3.0,
                    help="Upper bound C on pole/bath weights W,V (default 3.0). Raise for "
                         "deep Mott where the self-energy pole weight grows like W ~ U/2 "
                         "(code units); e.g. C>=U/2 to avoid clipping the Hubbard-band weight.")
    ap.add_argument("--n-moments", type=int, default=-1, help="If < 0, auto-calculate for delta=0")
    ap.add_argument(
        "--objective",
        choices=["gateway_only", "gateway_plus_impfill_moments", "gateway_plus_closures", "legacy_full"],
        default="gateway_plus_impfill_moments",
        help=(
            "Objective rows to optimize: gateway-only matching; gateway + impurity/NCS "
            "filling + moments (default); gateway + impurity/lattice filling + moments; "
            "or legacy full including direct bond kinetic row."
        ),
    )
    ap.add_argument("--max-chunks", type=int, default=12)
    ap.add_argument("--max-nfev-per-chunk", type=int, default=20)
    ap.add_argument("--target-res", type=float, default=1e-3)
    ap.add_argument(
        "--half-filling-ph",
        dest="half_filling_ph",
        action="store_true",
        help=(
            "PH half filling: require n=1 and hold mu = U/2 and Sigma_inf = U/2. "
            "mu is removed from the optimization codec and filling rows become diagnostics."
        ),
    )
    ap.add_argument(
        "--pin-ph",
        dest="half_filling_ph",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    ap.add_argument(
        "--seed-mode",
        choices=["auto", "metal", "dark", "coherent"],
        default="auto",
        help=(
            "Fresh-point seed: 'auto'/'metal' use the default finite-V metal "
            "seed; 'dark' uses the atomic/local-moment skeleton (impurity "
            "baths decoupled, lattice ghost loaded to sum W^2 = U^2/4); "
            "'coherent' places the lattice-ghost poles at eta ~ +/-0.5 "
            "(coherent-metal scale) instead of near zero (atomic). Only "
            "affects points with no warm start; chained points still inherit "
            "the previous solution. Pair --seed-mode dark with --retry-dark 0 "
            "and a descending --U-list for an insulator-following down-sweep."
        ),
    )
    ap.add_argument(
        "--no-warm-start",
        dest="no_warm_start",
        action="store_true",
        help=(
            "Force the chosen --seed-mode at every point instead of "
            "warm-starting from the nearest converged neighbor. Use for "
            "independent per-U two-branch LOCATE runs."
        ),
    )
    ap.add_argument(
        "--retry-dark",
        type=int,
        default=0,
        help=(
            "If a converged point flags dark_bath, retry up to N times from a "
            "fresh seed with progressively stronger bath couplings (no "
            "checkpoint resume on retries). Keeps the first non-dark solution; "
            "otherwise the last attempt."
        ),
    )
    ap.add_argument(
        "--multistart",
        type=int,
        default=0,
        help=(
            "Run N EXTRA fresh seeds (beyond the primary warm/fresh attempt) "
            "at each point with a spread of bath-coupling amplitudes, then "
            "among the CONVERGED candidates keep the most-coupled one "
            "(--multistart-keep coupled, default) instead of the "
            "lowest-residual one. Fixes the metal branch getting trapped in a "
            "weakly-coupled minimum (e.g. Z scatter 0.11-0.68 at fixed U). "
            "Set --multistart-keep decoupled for the dark/insulator branch."
        ),
    )
    ap.add_argument(
        "--multistart-keep",
        choices=["coupled", "decoupled"],
        default="coupled",
        help=(
            "Among multistart candidates with resnorm < --multistart-accept-res, "
            "keep the one with the largest (coupled) or smallest (decoupled) "
            "sum_V2_imp1. Coupled selects the metal; decoupled selects the "
            "atomic/insulating fixed point."
        ),
    )
    ap.add_argument(
        "--multistart-accept-res",
        type=float,
        default=1e-3,
        help=(
            "A multistart candidate counts as converged (eligible for the "
            "coupled/decoupled selection) when its objective resnorm is below "
            "this. If no candidate converges, the lowest-resnorm attempt is "
            "kept and flagged."
        ),
    )
    ap.add_argument(
        "--jac",
        choices=["2-point", "analytic"],
        default="2-point",
        help=(
            "Jacobian for least_squares: scipy 2-point finite differences "
            "(default; costs n_params hidden residual evaluations per build) "
            "or the analytic linear-response Jacobian from one ED solve "
            "(exact on dense sectors, retained-window approximation on "
            "truncated Lanczos sectors)."
        ),
    )
    ap.add_argument(
        "--symmetric",
        action="store_true",
        help=(
            "Optimize in the PH-symmetric subspace via a linear reparametrization "
            "x_full = A @ y (change of coordinates, NOT a new constraint). Halves "
            "the parameter count (36->18 for Mh2Mg3Mb1), removes the dark-ghost "
            "basin hop, and pins mu=U/2. Mirror-only (PH), so AF ordering stays "
            "open. Implies --half-filling-ph and requires --n-list 1.0. The "
            "checkpoint still stores the full codec x, so export/report are "
            "unchanged."
        ),
    )
    args = ap.parse_args()
    args.lattice = _normalize_lattice(args.lattice)

    Mh, Mg = _resolve_dims(args)
    mode = str(args.mode)
    if Mh <= 0 or Mg <= 0:
        raise ValueError("Mh and Mg must be positive integers")
    if args.Mb < 0:
        raise ValueError("Mb must be a non-negative integer")
    if mode == MODE_SINGLE_IMPURITY and args.Mb != 0:
        raise ValueError("--mode single_impurity requires --Mb 0")
    if args.lattice == LATTICE_BETHE and mode != MODE_SINGLE_IMPURITY:
        raise ValueError("--lattice bethe is only implemented for --mode single_impurity")

    U, n_list, T = _grid(args.grid)
    x = _parse_csv_floats(args.U_list)
    if x is not None:
        U = x
    x = _parse_csv_floats(args.n_list)
    if x is not None:
        n_list = x
    x = _parse_csv_floats(args.T_list)
    if x is not None:
        T = x
    if args.symmetric and not args.half_filling_ph:
        args.half_filling_ph = True
        print("--symmetric -> enabling --half-filling-ph (PH pins mu=U/2)")
    if args.half_filling_ph and any(abs(nn - 1.0) > 1e-12 for nn in n_list):
        raise ValueError("--half-filling-ph requires --n-list 1.0")

    study_dir = os.path.join(args.outdir, args.tag)
    os.makedirs(study_dir, exist_ok=True)
    ckpt_dir = args.checkpoint_dir.strip() or os.path.join(study_dir, "checkpoints")
    mode_tag = (
        "single"
        if mode == MODE_SINGLE_IMPURITY
        else ("bonding" if mode == MODE_BONDING_ONLY else "bonding_ab")
    )
    ph_tag = "_ph" if args.half_filling_ph else ""
    lattice_tag = "" if args.lattice == LATTICE_SQUARE else f"_{args.lattice}"
    res_path = os.path.join(study_dir, f"{mode_tag}{ph_tag}{lattice_tag}_Mh{Mh}_Mg{Mg}_Mb{args.Mb}.pkl")
    par_path = os.path.join(study_dir, f"{mode_tag}{ph_tag}{lattice_tag}_Mh{Mh}_Mg{Mg}_Mb{args.Mb}_params.pkl")
    csv_path = os.path.join(study_dir, f"{mode_tag}{ph_tag}{lattice_tag}_Mh{Mh}_Mg{Mg}_Mb{args.Mb}_summary.csv")

    results = []
    params = {}
    if os.path.exists(res_path):
        with open(res_path, "rb") as f:
            results = pickle.load(f)
    if os.path.exists(par_path):
        import BHFM2.core as core
        import sys
        sys.modules['core'] = core
        with open(par_path, "rb") as f:
            params = pickle.load(f)

    done = {
        (
            round(r["U"], 6),
            round(r["T"], 6),
            round(r["n_target"], 6),
            int(r.get("Mh", r.get("M", len(r.get("W", []))))),
            int(r.get("Mg", r.get("M", len(r.get("V1", []))))),
            int(r["Mb"]),
            str(r.get("mode", MODE_BONDING_ONLY)),
            _normalize_lattice(r.get("lattice", LATTICE_SQUARE)),
            bool(r.get("half_filling_ph", False)),
        )
        for r in results
    }

    codec = CodecMin(Mh, Mg, args.Mb, mode=mode, fixed_mu=(0.0 if args.half_filling_ph else None))

    reparam = None
    if args.symmetric:
        from BHFM2.core.reparam_sym import SymReparam
        reparam = SymReparam(Mh, Mg, args.Mb, mode)

    if args.n_moments < 0:
        # Auto moment count = free optimizer dof - base rows, so the objective
        # stays ~exactly determined (delta=1). Under --symmetric the free dof is
        # n_sym (18 for Mh2Mg3Mb1), NOT the full codec (36): matching the full
        # codec's ~22 moments with an 18-dof PH bath is overdetermined by 19 and
        # floors the residual. Tracking n_sym keeps delta=1 -- the same mild
        # overdetermination as the full-codec run.
        base_eqs = _objective_n_eq(
            Mh, Mg, args.Mb, 0, args.objective, mode,
            drop_filling=args.half_filling_ph,
        )
        opt_dof = reparam.n_sym if reparam is not None else codec.size
        args.n_moments = max(0, opt_dof - base_eqs)

    neq = _objective_n_eq(
        Mh, Mg, args.Mb, args.n_moments, args.objective, mode,
        drop_filling=False,
        include_lat_filling=bool(args.half_filling_ph and mode == MODE_SINGLE_IMPURITY),
    )

    print("Site+bond systematic run")
    print(f"  outdir={study_dir}")
    print(
        f"  mode={mode} Mh={Mh} Mg={Mg} Mb={args.Mb} objective={args.objective} "
        f"half_filling_ph={args.half_filling_ph} lattice={args.lattice} U={U} n={n_list} T={T}"
    )
    n_opt = reparam.n_sym if reparam is not None else codec.size
    sym_note = f" (sym; full codec {codec.size})" if reparam is not None else ""
    print(f"  n_params={n_opt}{sym_note} n_eqs(objective)={neq} delta={neq - n_opt} jac={args.jac}")
    if neq < n_opt:
        print("  WARNING: objective is underdetermined (n_eqs < n_params).")
    elif neq > n_opt:
        print("  NOTE: objective is overdetermined (least-squares fit).")
    if reparam is not None:
        print(
            f"  symmetric reparam: optimizing n_sym={reparam.n_sym} PH-symmetric dof "
            f"in x_full={codec.size}; n_eqs={neq} (delta_sym={neq - reparam.n_sym}); "
            f"mirror-only -> AF stays open"
        )
    explicit_warm = None
    if args.warm_start_json and args.warm_start_checkpoint:
        raise ValueError("Use only one of --warm-start-json or --warm-start-checkpoint")
    if args.warm_start_json or args.warm_start_checkpoint:
        explicit_warm = _load_warm_start(args.warm_start_json or args.warm_start_checkpoint, codec)
        print(f"  explicit warm start: {args.warm_start_json or args.warm_start_checkpoint}")

    for u in U:
        for nn in n_list:
            for tt in T:
                key = (
                    round(u, 6), round(tt, 6), round(nn, 6),
                    Mh, Mg, args.Mb, mode, args.lattice, args.half_filling_ph,
                )
                if key in done:
                    print(f"U={u:.2f} n={nn:.3f} T={tt:.3f}: already done")
                    continue

                print(
                    f"\n===== mode={mode} Mh={Mh} Mg={Mg} Mb={args.Mb} U={u:.2f} (U/t={u/args.t_hop:.2f}) "
                    f"n={nn:.3f} T={tt:.3f} =====",
                    flush=True,
                )
                def _fresh_seed():
                    if args.seed_mode == "dark":
                        print("  start: dark/atomic seed")
                        return _dark_init(Mh, Mg, args.Mb, u, nn, mode, cap=args.weight_cap)
                    if args.seed_mode == "coherent":
                        print("  start: coherent-metal seed (eta~+/-0.5)")
                        return _coherent_init(Mh, Mg, args.Mb, u, nn, mode)
                    print("  start: fresh init")
                    return _default_init(Mh, Mg, args.Mb, mu0=u * nn / 2.0, mode=mode)

                warm = None if args.no_warm_start else _nearest_warm_start(u, tt, nn, params)
                if args.no_warm_start:
                    p0 = _fresh_seed()
                elif explicit_warm is not None:
                    p0 = replace(explicit_warm, mu=0.5 * u if args.half_filling_ph else explicit_warm.mu)
                    print("  start: explicit warm start")
                elif warm is None:
                    p0 = _fresh_seed()
                else:
                    p0, src = warm
                    print(f"  start: {src}")

                def _run_point(seed_p, allow_resume):
                    return _solve_point(
                        U=u,
                        T=tt,
                        n_target=nn,
                        p_init=seed_p,
                        Mh=Mh,
                        Mg=Mg,
                        Mb=args.Mb,
                        t_hop=args.t_hop,
                        nk=args.Nk,
                        z=args.z,
                        n_moments=args.n_moments,
                        objective_mode=args.objective,
                        target_res=args.target_res,
                        max_chunks=args.max_chunks,
                        max_nfev_per_chunk=args.max_nfev_per_chunk,
                        ckpt_dir=ckpt_dir,
                        mode=mode,
                        lattice=args.lattice,
                        jac_mode=args.jac,
                        pin_ph=args.half_filling_ph,
                        ground_state=args.ground_state,
                        resume=allow_resume,
                        reparam=reparam,
                        bath_E=args.bath_E,
                        pole_E=args.pole_E,
                        weight_cap=args.weight_cap,
                    )

                p, info = _run_point(p0, True)
                initial_json = _write_attempt_json(study_dir, info, p, "initial")
                print(f"  wrote attempt JSON: {initial_json}", flush=True)
                retry = 0
                while info.get("dark_bath") and retry < args.retry_dark:
                    retry += 1
                    amp = min(0.3 * 1.8**retry, 1.5)
                    seed = init_min(Mh, Mg, args.Mb, W0=amp, V0=amp, B0=amp / 2,
                                    base_mu=u * nn / 2.0, mode=mode)
                    print(f"  dark bath -> retry {retry}/{args.retry_dark} "
                          f"with coupling seed amp={amp:.2f}", flush=True)
                    p_r, info_r = _run_point(seed, False)
                    retry_json = _write_attempt_json(study_dir, info_r, p_r, f"retry{retry}")
                    print(f"  wrote retry JSON: {retry_json}", flush=True)
                    if not info_r.get("dark_bath") or info_r["resnorm"] < info["resnorm"]:
                        p, info = p_r, info_r
                    if not info.get("dark_bath"):
                        break

                if args.multistart > 0:
                    # Collect the primary attempt plus N fresh seeds spanning a
                    # spread of bath-coupling amplitudes, then re-select among the
                    # CONVERGED candidates by coupling (not by residual). This is
                    # the metal-trap fix: at fixed U the optimizer can land in a
                    # weakly-coupled minimum at low residual; keeping max sum_V2
                    # follows the genuine coupled metal instead.
                    candidates = [(p, info)]
                    amps = np.linspace(0.45, 1.15, args.multistart)
                    for i, amp in enumerate(amps):
                        seed = init_min(
                            Mh, Mg, args.Mb, W0=float(amp), V0=float(amp),
                            B0=float(amp) / 2.0, base_mu=u * nn / 2.0, mode=mode,
                        )
                        print(f"  multistart {i+1}/{args.multistart} seed amp={amp:.2f}",
                              flush=True)
                        p_ms, info_ms = _run_point(seed, False)
                        ms_json = _write_attempt_json(study_dir, info_ms, p_ms, f"ms{i+1}")
                        print(f"    -> ||r||={info_ms['resnorm']:.3e} "
                              f"sum_V2={info_ms['sum_V2_imp1']:.4f} "
                              f"Z={info_ms['Zloc']:.4f}  ({ms_json})", flush=True)
                        candidates.append((p_ms, info_ms))

                    accept = args.multistart_accept_res
                    converged = [c for c in candidates if c[1]["resnorm"] < accept]
                    if converged:
                        if args.multistart_keep == "coupled":
                            p, info = max(converged, key=lambda c: c[1]["sum_V2_imp1"])
                        else:
                            p, info = min(converged, key=lambda c: c[1]["sum_V2_imp1"])
                        zs = [c[1]["Zloc"] for c in converged]
                        z_scatter = float(max(zs) - min(zs))
                        info["multistart_n_converged"] = len(converged)
                        info["z_scatter"] = z_scatter
                        info["z_scatter_flag"] = bool(z_scatter > 0.05)
                        print(f"  multistart: kept {args.multistart_keep} of "
                              f"{len(converged)}/{len(candidates)} converged "
                              f"(sum_V2={info['sum_V2_imp1']:.4f} Z={info['Zloc']:.4f}); "
                              f"Z scatter={z_scatter:.4f}"
                              + ("  [FLAG: Z scatter > 0.05]" if z_scatter > 0.05 else ""),
                              flush=True)
                    else:
                        p, info = min(candidates, key=lambda c: c[1]["resnorm"])
                        info["multistart_n_converged"] = 0
                        info["z_scatter"] = float("nan")
                        info["z_scatter_flag"] = True
                        print(f"  multistart: NO candidate below accept-res={accept:.1e}; "
                              f"kept lowest-resnorm ||r||={info['resnorm']:.3e}  "
                              "[FLAG: unconverged]", flush=True)

                if (args.multistart > 0 or args.retry_dark > 0) and info.get("ckpt_path"):
                    # The per-eval checkpoint keeps the LOWEST-RESIDUAL x seen
                    # across ALL attempts at this point — but with an
                    # overdetermined objective the junk families (weak-coupled,
                    # dark) zero the system while the physical root has a
                    # genuine nonzero floor, so any junk-visiting secondary
                    # attempt poisons the checkpoint even when the selection
                    # above kept the physical candidate. The checkpoint is the
                    # continuation state: it must hold the KEPT solution.
                    codec_k = CodecMin(Mh, Mg, args.Mb, mode=mode,
                                       fixed_mu=(0.5 * u if args.half_filling_ph else None))
                    with open(info["ckpt_path"], "wb") as fp:
                        pickle.dump({"x": codec_k.pack(p), "r": float(info["resnorm"])}, fp)
                    print(f"  checkpoint <- kept solution (||r||={info['resnorm']:.3e})",
                          flush=True)

                print(
                    f"  done: ||r||={info['resnorm']:.3e} max|r|={info['resmax']:.3e} "
                    f"(all: {info['resnorm_all']:.3e}) n_avg={info['n_avg']:.6f} D_ncs={info['D_ncs']:.6f} "
                    f"Zloc={info['Zloc']:.6f} Z_pole={info['Z_pole']:.6f} "
                    f"eta_min={info['eta_min_abs']:.4f} mu={info['mu']:+.4f} wall={info['wall']:.0f}s "
                    + ("[DARK BATH: D/Z are free-impurity artifacts] " if info.get("dark_bath") else "")
                    + f"imp2_tail={info['thermal_audit_imp2'].get('max_thermal_tail_bound', 0.0):.3e} "
                    f"imp2_kmax={info['thermal_audit_imp2'].get('max_states_returned', 0)}",
                    flush=True,
                )

                results.append(info)
                params[(u, tt, nn)] = p
                with open(res_path, "wb") as f:
                    pickle.dump(results, f)
                with open(par_path, "wb") as f:
                    pickle.dump(params, f)
                _write_summary_csv(csv_path, results)

    print(f"\nSaved results: {res_path}")
    print(f"Saved params:  {par_path}")
    print(f"Saved CSV:     {csv_path}")


if __name__ == "__main__":
    main()
