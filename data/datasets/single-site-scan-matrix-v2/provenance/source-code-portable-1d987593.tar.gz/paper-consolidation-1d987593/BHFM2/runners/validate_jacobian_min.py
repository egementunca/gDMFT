#!/usr/bin/env python3
"""Validate the analytic linear-response Jacobian against central differences.

Checks, at a chosen parameter point:
  1. residual_and_jacobian_min reproduces residual_min row-for-row.
  2. The analytic Jacobian matches a central finite-difference Jacobian of
     residual_min column-for-column (the FD reference uses the production
     residual, so any divergence in the reimplemented builders shows up here
     too).
  3. Wall-time comparison: one analytic (residual+Jacobian) call vs the
     2*n_par residual evaluations the FD Jacobian costs.

Examples:
  python3 -m BHFM2.runners.validate_jacobian_min --Mh 1 --Mg 1 --Mb 1 \
      --mode bonding_plus_antibonding --n-moments 8 --point random --seed 1
  python3 -m BHFM2.runners.validate_jacobian_min --Mh 2 --Mg 2 --Mb 1 \
      --mode bonding_plus_antibonding --n-moments 12 \
      --json path/to/attempt.json
"""
from __future__ import annotations

import argparse
import json
import time
from dataclasses import replace

import numpy as np

from BHFM2.core.jacobian_min import residual_and_jacobian_min
from BHFM2.core.solve_min import (
    CodecMin,
    LATTICE_BETHE,
    LATTICE_SQUARE,
    VALID_LATTICES,
    MODE_SINGLE_IMPURITY,
    ModelParamsMin,
    SParMin,
    _normalize_lattice,
    _normalize_mode,
    init_min,
    residual_min,
)


def _col_names(codec):
    names = []
    for name, n in codec._fields():
        names.extend(f"{name}[{a}]" if n > 1 else name for a in range(n))
    if codec.fixed_mu is None:
        names.append("mu")
    return names


def _point_from_json(path, codec):
    with open(path) as fh:
        d = json.load(fh)
    pars = d.get("optimized_parameters") or d.get("observables")
    kw = {}
    for name, n in codec._fields():
        arr = np.asarray(pars[name], dtype=float).ravel()
        if len(arr) != n:
            raise ValueError(f"{name}: expected {n} entries, got {len(arr)}")
        kw[name] = arr
    return SParMin(mu=float(np.asarray(pars["mu"]).ravel()[0]), **kw)


def _random_point(codec, seed):
    rng = np.random.default_rng(seed)
    p = init_min(codec.Mh, codec.Mg, codec.Mb, mode=codec.mode)
    x = codec.pack(p)
    x = x + rng.uniform(-0.15, 0.15, size=len(x))
    # keep amplitude-like fields safely positive
    i = 0
    for name, n in codec._fields():
        if name in {"W", "B_h", "V1", "W1", "V2", "W2", "B_h2", "B_g",
                    "B_ha", "B_ha2", "B_ga"}:
            x[i : i + n] = np.abs(x[i : i + n]) + 0.05
        i += n
    return codec.unpack(x)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Mh", type=int, default=1)
    ap.add_argument("--Mg", type=int, default=1)
    ap.add_argument("--Mb", type=int, default=1)
    ap.add_argument("--mode", default="bonding_plus_antibonding")
    ap.add_argument("--U", type=float, default=2.0)
    ap.add_argument("--t", type=float, default=0.5)
    ap.add_argument("--T", type=float, default=0.2)
    ap.add_argument("--z", type=float, default=0.5)
    ap.add_argument("--Nk", type=int, default=16)
    ap.add_argument("--lattice", choices=sorted(VALID_LATTICES), default=LATTICE_SQUARE)
    ap.add_argument("--n-target", type=float, default=1.0)
    ap.add_argument("--n-moments", type=int, default=4)
    ap.add_argument("--point", choices=["init", "random"], default="random")
    ap.add_argument("--json", default=None, help="attempt/case JSON with optimized_parameters")
    ap.add_argument("--seed", type=int, default=0)
    ap.add_argument("--eps", type=float, default=1e-6)
    ap.add_argument(
        "--half-filling-ph",
        dest="half_filling_ph",
        action="store_true",
        help="Validate PH fixed-mu codec: require n=1, hold mu=Sigma_inf=U/2, and omit mu column.",
    )
    ap.add_argument("--pin-ph", dest="half_filling_ph", action="store_true", help=argparse.SUPPRESS)
    args = ap.parse_args()
    args.lattice = _normalize_lattice(args.lattice)
    args.mode = _normalize_mode(args.mode)

    if args.half_filling_ph and abs(args.n_target - 1.0) > 1e-12:
        raise SystemExit("--half-filling-ph requires --n-target 1.0")
    if args.lattice == LATTICE_BETHE and (args.mode != MODE_SINGLE_IMPURITY or int(args.Mb) != 0):
        raise SystemExit("--lattice bethe is only implemented for --mode single_impurity --Mb 0")
    fixed_mu = 0.5 * args.U if args.half_filling_ph else None
    pin_sigma_inf = 0.5 * args.U if args.half_filling_ph else None

    mp = ModelParamsMin(
        t=args.t, eps_d=0.0, U=args.U, z=args.z,
        filling_target=args.n_target,
        Sigma_inf=(0.5 * args.U if args.half_filling_ph else args.U * args.n_target / 2.0),
        beta=1.0 / args.T, Nk=args.Nk, use_y_bond=True, n_moments=args.n_moments,
        lattice=args.lattice,
    )
    codec = CodecMin(args.Mh, args.Mg, args.Mb, mode=args.mode, fixed_mu=fixed_mu)
    if args.json:
        p = _point_from_json(args.json, codec)
        point_label = f"json:{args.json}"
    elif args.point == "init":
        p = init_min(args.Mh, args.Mg, args.Mb, mode=args.mode,
                     base_mu=args.U * args.n_target / 2.0)
        point_label = "init"
    else:
        p = _random_point(codec, args.seed)
        point_label = f"random(seed={args.seed})"
    if fixed_mu is not None:
        p = replace(p, mu=fixed_mu)

    names = _col_names(codec)
    x0 = codec.pack(p)
    n = len(x0)
    print(f"Mh={args.Mh} Mg={args.Mg} Mb={args.Mb} mode={args.mode} "
          f"U={args.U} T={args.T} z={args.z} Nk={args.Nk} lattice={args.lattice} "
          f"n_moments={args.n_moments}")
    print(f"point={point_label}  n_par={n}")

    def residual_ref(pp):
        if args.half_filling_ph:
            from BHFM2.runners.run_bonding_systematic import _grouped_residuals

            return _grouped_residuals(
                pp, mp, args.Mh, args.Mg, args.Mb, args.mode,
                pin_sigma_inf=pin_sigma_inf,
            )[0]
        return residual_min(pp, mp, args.Mh, args.Mg, args.Mb, mode=args.mode)

    # warm up numba before timing anything
    r_ref = residual_ref(p)

    t0 = time.time()
    r_an, J_an = residual_and_jacobian_min(
        p, mp, args.Mh, args.Mg, args.Mb, mode=args.mode,
        pin_sigma_inf=pin_sigma_inf,
        fixed_mu=fixed_mu,
    )
    t_an = time.time() - t0

    if len(r_an) != len(r_ref):
        raise SystemExit(f"row count mismatch: analytic {len(r_an)} vs residual_min {len(r_ref)}")
    dr = float(np.max(np.abs(r_an - r_ref)))
    print(f"\nresidual rows: {len(r_ref)}   max|r_analytic - residual_min| = {dr:.3e}")
    print(f"||r|| = {np.linalg.norm(r_ref):.6e}")

    t0 = time.time()
    J_fd = np.zeros_like(J_an)
    for j in range(n):
        ej = args.eps * max(1.0, abs(x0[j]))
        xp, xm = x0.copy(), x0.copy()
        xp[j] += ej
        xm[j] -= ej
        rp = residual_ref(codec.unpack(xp))
        rm = residual_ref(codec.unpack(xm))
        J_fd[:, j] = (rp - rm) / (2.0 * ej)
    t_fd = time.time() - t0

    # Near-decoupled poles give Jacobian columns orders of magnitude below the
    # global scale; there the central-FD reference's own noise dominates any
    # per-column relative error. Judge each column against max(its own scale,
    # 1e-3 * global scale) so flat directions are held to an absolute bar.
    global_scale = max(float(np.max(np.abs(J_fd))), 1e-10)
    print(f"\n{'column':<14} {'max|J_an|':>12} {'max abs err':>12} {'mixed err':>10}")
    worst, worst_name = 0.0, ""
    for j in range(n):
        scale = max(float(np.max(np.abs(J_fd[:, j]))), 1e-3 * global_scale)
        abs_err = float(np.max(np.abs(J_an[:, j] - J_fd[:, j])))
        rel = abs_err / scale
        if rel > worst:
            worst, worst_name = rel, names[j]
        print(f"{names[j]:<14} {np.max(np.abs(J_an[:, j])):>12.4e} {abs_err:>12.4e} {rel:>10.2e}")

    print(f"\nworst column: {worst_name}  mixed err = {worst:.3e}  "
          f"(global |J| scale {global_scale:.3e})")
    print(f"timing: analytic residual+J = {t_an:.2f}s; "
          f"central-FD J = {t_fd:.2f}s ({2*n} residual evals); "
          f"speedup x{t_fd / max(t_an, 1e-9):.1f}")
    ok = worst < 1e-5 and dr < 1e-10
    print("PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
