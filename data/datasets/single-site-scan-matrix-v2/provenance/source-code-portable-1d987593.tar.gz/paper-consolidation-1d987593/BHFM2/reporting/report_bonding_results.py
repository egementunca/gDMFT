#!/usr/bin/env python3
"""Create clean tables/plots for site+bond BHFM2 systematic runs."""
from __future__ import annotations

import argparse
import csv
import os
import pickle
from collections import defaultdict

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt


BASE_FIELDS = [
    "mode",
    "Mh",
    "Mg",
    "M",
    "Mb",
    "U",
    "U_over_t",
    "t",
    "T",
    "beta",
    "n_target",
    "n_avg",
    "n_lat",
    "density_error_imp",
    "density_error_lat",
    "D_imp1",
    "D_imp2",
    "D_ncs",
    "mu",
    "Sigma_inf",
    "Zloc",
    "objective_mode",
    "resnorm",
    "resmax",
    "resnorm_all",
    "resmax_all",
    "optimizer_success",
    "optimizer_status",
    "optimizer_cost",
    "nfev",
    "wall",
    "bond_x_lat",
    "bond_x_imp2",
    "bond_x_mismatch",
    "thermal_imp1_truncated_sectors",
    "thermal_imp1_max_sector_dim",
    "thermal_imp1_max_states_returned",
    "thermal_imp1_max_tail_bound",
    "thermal_imp2_truncated_sectors",
    "thermal_imp2_max_sector_dim",
    "thermal_imp2_max_states_returned",
    "thermal_imp2_max_tail_bound",
]

BLOCK_KEYS = [
    "local_h_occ",
    "local_h_coh",
    "bond_h_occ",
    "bond_h_coh",
    "g1_occ",
    "g1_coh",
    "g2_occ",
    "g2_coh",
    "bond_g_occ",
    "bond_g_coh",
    "bondm_h_occ",
    "bondm_h_coh",
    "bondm_g_occ",
    "bondm_g_coh",
    "fill_imp",
    "fill_lat",
    "bond_kinetic",
    "moments",
]


def _load_rows(paths):
    rows = []
    for p in paths:
        with open(p, "rb") as f:
            obj = pickle.load(f)
        if isinstance(obj, list):
            rows.extend(obj)
        else:
            raise ValueError(f"Unexpected PKL content in {p}: expected list of records.")
    rows.sort(key=lambda r: (float(r["n_target"]), float(r["T"]), float(r["U"])))
    return rows


def _safe_float(x, default=np.nan):
    try:
        return float(x)
    except Exception:
        return float(default)


def _flatten(rows):
    out = []
    for r in rows:
        rec = {}
        for k in BASE_FIELDS:
            v = r.get(k, np.nan)
            if k in {"objective_mode", "mode"}:
                rec[k] = str(v)
            elif k in {"optimizer_success"}:
                rec[k] = int(bool(v))
            else:
                rec[k] = _safe_float(v)
        blocks = r.get("residual_blocks", {}) or {}
        for b in BLOCK_KEYS:
            rec[f"res_{b}"] = _safe_float(blocks.get(b, np.nan))
        for prefix, key in [("thermal_imp1", "thermal_audit_imp1"), ("thermal_imp2", "thermal_audit_imp2")]:
            audit = r.get(key, {}) or {}
            rec[f"{prefix}_truncated_sectors"] = _safe_float(audit.get("truncated_sectors", np.nan))
            rec[f"{prefix}_max_sector_dim"] = _safe_float(audit.get("max_sector_dim", np.nan))
            rec[f"{prefix}_max_states_returned"] = _safe_float(audit.get("max_states_returned", np.nan))
            rec[f"{prefix}_max_tail_bound"] = _safe_float(audit.get("max_thermal_tail_bound", np.nan))

        bh_lat = np.asarray(r.get("bond_h_occ_lat", []), dtype=float).ravel()
        bh_gw = np.asarray(r.get("bond_h_occ_gw2", []), dtype=float).ravel()
        bc_lat = np.asarray(r.get("bond_h_coh_lat", []), dtype=float).ravel()
        bc_gw = np.asarray(r.get("bond_h_coh_gw2", []), dtype=float).ravel()
        bg_imp = np.asarray(r.get("bond_g_occ_imp2", []), dtype=float).ravel()
        bg_gw = np.asarray(r.get("bond_g_occ_gw2", []), dtype=float).ravel()
        bgg_imp = np.asarray(r.get("bond_g_coh_imp2", []), dtype=float).ravel()
        bgg_gw = np.asarray(r.get("bond_g_coh_gw2", []), dtype=float).ravel()

        rec["bond_h_occ_l2"] = float(np.linalg.norm(bh_lat - bh_gw)) if len(bh_lat) and len(bh_gw) else np.nan
        rec["bond_h_coh_l2"] = float(np.linalg.norm(bc_lat - bc_gw)) if len(bc_lat) and len(bc_gw) else np.nan
        rec["bond_g_occ_l2"] = float(np.linalg.norm(bg_imp - bg_gw)) if len(bg_imp) and len(bg_gw) else np.nan
        rec["bond_g_coh_l2"] = float(np.linalg.norm(bgg_imp - bgg_gw)) if len(bgg_imp) and len(bgg_gw) else np.nan
        out.append(rec)
    return out


def _write_csv(rows, path):
    fields = list(rows[0].keys()) if rows else []
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow(r)


def _by_group(rows):
    g = defaultdict(list)
    for r in rows:
        key = (_safe_float(r["n_target"]), _safe_float(r["T"]))
        g[key].append(r)
    for key in g:
        g[key].sort(key=lambda x: _safe_float(x["U_over_t"]))
    return g


def _line_label(n, t):
    return f"n={n:.2f}, T={t:.2f}"


def _plot_metric(rows, ykey, ylabel, out_path, logy=False):
    groups = _by_group(rows)
    fig, ax = plt.subplots(figsize=(8.0, 5.2))
    for (n, t), vals in sorted(groups.items()):
        x = np.asarray([_safe_float(v["U_over_t"]) for v in vals], dtype=float)
        y = np.asarray([_safe_float(v[ykey]) for v in vals], dtype=float)
        ax.plot(x, y, marker="o", linewidth=1.6, markersize=5, label=_line_label(n, t))
    ax.set_xlabel("U/t")
    ax.set_ylabel(ylabel)
    if logy:
        ax.set_yscale("log")
    ax.grid(True, alpha=0.3)
    ax.legend(fontsize=8, ncol=2)
    fig.tight_layout()
    fig.savefig(out_path, dpi=170)
    plt.close(fig)


def _plot_density_errors(rows, out_path):
    groups = _by_group(rows)
    fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.2), sharex=True)
    for (n, t), vals in sorted(groups.items()):
        x = np.asarray([_safe_float(v["U_over_t"]) for v in vals], dtype=float)
        y_imp = np.asarray([abs(_safe_float(v["density_error_imp"])) for v in vals], dtype=float)
        y_lat = np.asarray([abs(_safe_float(v["density_error_lat"])) for v in vals], dtype=float)
        axes[0].plot(x, y_imp, marker="o", linewidth=1.5, markersize=4, label=_line_label(n, t))
        axes[1].plot(x, y_lat, marker="s", linewidth=1.5, markersize=4, label=_line_label(n, t))
    axes[0].set_title("|n_avg - n_target|")
    axes[1].set_title("|n_lat - n_target|")
    for ax in axes:
        ax.set_xlabel("U/t")
        ax.set_yscale("log")
        ax.grid(True, alpha=0.3)
    axes[0].set_ylabel("absolute error")
    axes[1].legend(fontsize=7, ncol=2)
    fig.tight_layout()
    fig.savefig(out_path, dpi=170)
    plt.close(fig)


def _plot_overview(rows, out_path):
    groups = _by_group(rows)
    fig, axes = plt.subplots(2, 2, figsize=(11.0, 8.0), sharex=True)
    for (n, t), vals in sorted(groups.items()):
        x = np.asarray([_safe_float(v["U_over_t"]) for v in vals], dtype=float)
        d = np.asarray([_safe_float(v["D_ncs"]) for v in vals], dtype=float)
        z = np.asarray([_safe_float(v["Zloc"]) for v in vals], dtype=float)
        rn = np.asarray([_safe_float(v["resnorm"]) for v in vals], dtype=float)
        bm = np.asarray([abs(_safe_float(v["bond_x_mismatch"])) for v in vals], dtype=float)
        lbl = _line_label(n, t)
        axes[0, 0].plot(x, d, marker="o", linewidth=1.4, markersize=4, label=lbl)
        axes[0, 1].plot(x, z, marker="o", linewidth=1.4, markersize=4, label=lbl)
        axes[1, 0].plot(x, rn, marker="o", linewidth=1.4, markersize=4, label=lbl)
        axes[1, 1].plot(x, bm, marker="o", linewidth=1.4, markersize=4, label=lbl)

    axes[0, 0].set_title("NCS Double Occupancy")
    axes[0, 0].set_ylabel("D_ncs")
    axes[0, 1].set_title("Local Quasiparticle Weight")
    axes[0, 1].set_ylabel("Zloc")
    axes[1, 0].set_title("Objective Residual Norm")
    axes[1, 0].set_ylabel("||r_obj||")
    axes[1, 1].set_title("Bond Kinetic Mismatch (diagnostic)")
    axes[1, 1].set_ylabel("|bond_x_lat - bond_x_imp2|")
    axes[1, 0].set_xlabel("U/t")
    axes[1, 1].set_xlabel("U/t")
    axes[1, 0].set_yscale("log")
    axes[1, 1].set_yscale("log")

    for ax in axes.ravel():
        ax.grid(True, alpha=0.3)
    axes[0, 1].legend(fontsize=7, ncol=2, loc="best")
    fig.tight_layout()
    fig.savefig(out_path, dpi=170)
    plt.close(fig)


def _write_summary(rows, out_path, src_files):
    if not rows:
        text = "# Bonding Report\n\nNo rows found.\n"
        with open(out_path, "w", encoding="utf-8") as f:
            f.write(text)
        return

    uvals = sorted({_safe_float(r["U_over_t"]) for r in rows})
    nvals = sorted({_safe_float(r["n_target"]) for r in rows})
    tvals = sorted({_safe_float(r["T"]) for r in rows})
    objectives = sorted({str(r.get("objective_mode", "")) for r in rows})

    worst_res = max(rows, key=lambda r: _safe_float(r["resnorm"]))
    worst_den_imp = max(rows, key=lambda r: abs(_safe_float(r["density_error_imp"])))
    worst_den_lat = max(rows, key=lambda r: abs(_safe_float(r["density_error_lat"])))

    lines = [
        "# Site+Bond Results Report",
        "",
        f"Input files: {', '.join(src_files)}",
        f"Points: {len(rows)}",
        f"Objective mode(s): {', '.join(objectives)}",
        f"U/t grid: {', '.join(f'{u:.2f}' for u in uvals)}",
        f"n grid: {', '.join(f'{n:.2f}' for n in nvals)}",
        f"T grid: {', '.join(f'{t:.2f}' for t in tvals)}",
        "",
        "## Quick Checks",
        "",
        f"- Worst objective residual: U/t={_safe_float(worst_res['U_over_t']):.2f}, "
        f"n={_safe_float(worst_res['n_target']):.2f}, T={_safe_float(worst_res['T']):.2f}, "
        f"||r_obj||={_safe_float(worst_res['resnorm']):.3e}",
        f"- Largest impurity filling error: U/t={_safe_float(worst_den_imp['U_over_t']):.2f}, "
        f"n={_safe_float(worst_den_imp['n_target']):.2f}, T={_safe_float(worst_den_imp['T']):.2f}, "
        f"|n_avg-n|={abs(_safe_float(worst_den_imp['density_error_imp'])):.3e}",
        f"- Largest lattice filling error (diagnostic): U/t={_safe_float(worst_den_lat['U_over_t']):.2f}, "
        f"n={_safe_float(worst_den_lat['n_target']):.2f}, T={_safe_float(worst_den_lat['T']):.2f}, "
        f"|n_lat-n|={abs(_safe_float(worst_den_lat['density_error_lat'])):.3e}",
        "",
        "## Per-Point Table",
        "",
        "| U/t | n | T | D_ncs | Zloc | ||r_obj|| | |n_avg-n| | |n_lat-n| |",
        "|---:|---:|---:|---:|---:|---:|---:|---:|",
    ]
    for r in rows:
        lines.append(
            f"| {_safe_float(r['U_over_t']):.2f} | {_safe_float(r['n_target']):.2f} | {_safe_float(r['T']):.2f} "
            f"| {_safe_float(r['D_ncs']):.5f} | {_safe_float(r['Zloc']):.5f} "
            f"| {_safe_float(r['resnorm']):.2e} | {abs(_safe_float(r['density_error_imp'])):.2e} "
            f"| {abs(_safe_float(r['density_error_lat'])):.2e} |"
        )

    with open(out_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+", help="Result PKL(s) from run_bonding_systematic.py")
    ap.add_argument("--outdir", default="", help="Output directory (default: first input directory)")
    ap.add_argument("--prefix", default="bonding_report")
    args = ap.parse_args()

    rows_raw = _load_rows(args.inputs)
    flat = _flatten(rows_raw)
    if not flat:
        raise SystemExit("No records loaded.")

    outdir = args.outdir.strip() or os.path.dirname(os.path.abspath(args.inputs[0]))
    os.makedirs(outdir, exist_ok=True)

    csv_path = os.path.join(outdir, f"{args.prefix}_table.csv")
    md_path = os.path.join(outdir, f"{args.prefix}_summary.md")
    fig_overview = os.path.join(outdir, f"{args.prefix}_overview.png")
    fig_d = os.path.join(outdir, f"{args.prefix}_Dncs_vs_Ut.png")
    fig_z = os.path.join(outdir, f"{args.prefix}_Zloc_vs_Ut.png")
    fig_r = os.path.join(outdir, f"{args.prefix}_residual_vs_Ut.png")
    fig_n = os.path.join(outdir, f"{args.prefix}_density_errors_vs_Ut.png")

    _write_csv(flat, csv_path)
    _write_summary(flat, md_path, args.inputs)
    _plot_overview(flat, fig_overview)
    _plot_metric(flat, "D_ncs", "D_ncs", fig_d)
    _plot_metric(flat, "Zloc", "Zloc", fig_z)
    _plot_metric(flat, "resnorm", "||r_obj||", fig_r, logy=True)
    _plot_density_errors(flat, fig_n)

    print(f"Wrote {csv_path}")
    print(f"Wrote {md_path}")
    print(f"Wrote {fig_overview}")
    print(f"Wrote {fig_d}")
    print(f"Wrote {fig_z}")
    print(f"Wrote {fig_r}")
    print(f"Wrote {fig_n}")


if __name__ == "__main__":
    main()
