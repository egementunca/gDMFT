#!/usr/bin/env python3
"""Export converged pole/coupling parameters for site+bond runs."""
from __future__ import annotations

import argparse
import csv
import os
import pickle

import numpy as np


FAMILIES = [
    "eta", "W",
    "eta_b", "B_h",
    "eps1", "V1",
    "eta1", "W1",
    "eps2", "V2",
    "eta2", "W2",
    "eta_b2", "B_h2",
    "eps_b", "B_g",
    "eta_a", "B_ha",
    "eta_a2", "B_ha2",
    "eps_a", "B_ga",
]


def _load(paths):
    rows = []
    for p in paths:
        with open(p, "rb") as f:
            rows.extend(pickle.load(f))
    rows.sort(key=lambda r: (float(r["U"]), float(r["n_target"]), float(r["T"])))
    return rows


def _arr(rec, name):
    return np.asarray(rec.get(name, []), dtype=float).ravel()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("inputs", nargs="+", help="Result PKL(s) from run_bonding_systematic.py")
    ap.add_argument("--prefix", default="bonding_params")
    ap.add_argument("--zero-threshold", type=float, default=1e-2)
    args = ap.parse_args()

    rows = _load(args.inputs)
    if not rows:
        raise SystemExit("No rows loaded.")

    outdir = os.path.dirname(os.path.abspath(args.inputs[0]))
    wide_path = os.path.join(outdir, f"{args.prefix}_wide.csv")
    long_path = os.path.join(outdir, f"{args.prefix}_long.csv")
    md_path = os.path.join(outdir, f"{args.prefix}_summary.md")

    maxlen = {f: max((len(_arr(r, f)) for r in rows), default=0) for f in FAMILIES}

    fixed = ["mode", "Mh", "Mg", "Mb", "M", "U", "U_over_t", "T", "n_target", "n_avg", "D_ncs", "Zloc", "mu", "resnorm"]
    cols = fixed[:]
    for f in FAMILIES:
        cols.extend([f"{f}_{i}" for i in range(maxlen[f])])

    with open(wide_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for rec in rows:
            row = {
                "Mh": int(rec.get("Mh", rec.get("M", len(_arr(rec, "W"))))),
                "Mg": int(rec.get("Mg", rec.get("M", len(_arr(rec, "V1"))))),
                "M": int(rec.get("M", len(_arr(rec, "W")))),
                "Mb": int(rec.get("Mb", len(_arr(rec, "B_h")))),
                "mode": str(rec.get("mode", "bonding_only")),
                "U": float(rec["U"]),
                "U_over_t": float(rec["U_over_t"]),
                "T": float(rec["T"]),
                "n_target": float(rec["n_target"]),
                "n_avg": float(rec["n_avg"]),
                "D_ncs": float(rec.get("D_ncs", np.nan)),
                "Zloc": float(rec.get("Zloc", np.nan)),
                "mu": float(rec["mu"]),
                "resnorm": float(rec["resnorm"]),
            }
            for fam in FAMILIES:
                arr = _arr(rec, fam)
                for i in range(maxlen[fam]):
                    row[f"{fam}_{i}"] = float(arr[i]) if i < len(arr) else np.nan
            w.writerow(row)

    long_cols = ["mode", "Mh", "Mg", "Mb", "M", "U", "U_over_t", "T", "n_target", "resnorm", "family", "index", "value"]
    with open(long_path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=long_cols)
        w.writeheader()
        for rec in rows:
            base = {
                "Mh": int(rec.get("Mh", rec.get("M", len(_arr(rec, "W"))))),
                "Mg": int(rec.get("Mg", rec.get("M", len(_arr(rec, "V1"))))),
                "M": int(rec.get("M", len(_arr(rec, "W")))),
                "Mb": int(rec.get("Mb", len(_arr(rec, "B_h")))),
                "mode": str(rec.get("mode", "bonding_only")),
                "U": float(rec["U"]),
                "U_over_t": float(rec["U_over_t"]),
                "T": float(rec["T"]),
                "n_target": float(rec["n_target"]),
                "resnorm": float(rec["resnorm"]),
            }
            for fam in FAMILIES:
                arr = _arr(rec, fam)
                for i, v in enumerate(arr):
                    r = base.copy()
                    r["family"] = fam
                    r["index"] = int(i)
                    r["value"] = float(v)
                    w.writerow(r)

    thr = float(args.zero_threshold)
    lines = ["# Bonding Parameter Summary", "", f"Points: {len(rows)}", f"Zero threshold: {thr:g}", "",
             "| U/t | U | n | T | ||r|| | near-zero couplings |",
             "|---:|---:|---:|---:|---:|---|"]
    for rec in rows:
        small = []
        for fam in ["W", "B_h", "V1", "W1", "V2", "W2", "B_h2", "B_g", "B_ha", "B_ha2", "B_ga"]:
            arr = _arr(rec, fam)
            for i, v in enumerate(arr):
                if abs(v) < thr:
                    small.append(f"{fam}[{i}]={v:+.2e}")
        small_txt = ", ".join(small) if small else "none"
        lines.append(
            f"| {float(rec['U_over_t']):.2f} | {float(rec['U']):.2f} | {float(rec['n_target']):.3f} "
            f"| {float(rec['T']):.3f} | {float(rec['resnorm']):.2e} | {small_txt} |"
        )
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines) + "\n")

    print(f"Wrote {wide_path}")
    print(f"Wrote {long_path}")
    print(f"Wrote {md_path}")


if __name__ == "__main__":
    main()
