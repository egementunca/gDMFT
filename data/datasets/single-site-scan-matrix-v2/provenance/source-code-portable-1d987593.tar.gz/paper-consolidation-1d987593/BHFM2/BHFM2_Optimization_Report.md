# BHFM2 Optimization & Physics Analysis Report

## 0. Status Update (June 2, 2026)
- `solve_min.py` and `run_bonding_systematic.py` now support **decoupled dimensions**:
  - `Mh` = h-ghost poles
  - `Mg` = g-bath poles
  - `Mb` = bond poles
- Current production setting for this study is **`Mh=2, Mg=3, Mb=1`**.
- In `gateway_plus_impfill_moments` mode, the runner auto-selects
  **`n_moments=10`** to get a balanced 31-equation / 31-parameter system.
- Job scripts were updated to run this decoupled setup.
- The sparse Lanczos GPU path is guarded experimental infrastructure. It must
  certify an omitted Boltzmann-weight bound before its output is accepted.
- A local representative `Mh=2, Mg=3, Mb=1`, `T=0.2` bonding-only sector probe
  rejected `k=250` with `tail_bound=3.46e3`. Do not treat fixed-250 Lanczos as
  production-ready.
- The next SCC action is the one-point H200 B+AB retained-state ladder:
  `qsub jobs/current/bhfm2_bab_lanczos_benchmark_h200.sh`.

## 1. Code Changes Implemented (Already Running)
To dramatically speed up the `M=3` grid calculations, we introduced a non-invasive wrapper that monkey-patches the bottleneck functions without modifying the core logic. 

**New Files Added:**
- `solve_min_gpu.py`: Contains the accelerated replacement functions.
- `run_bonding_systematic_gpu.py`: A wrapper launcher that applies the patches and calls the standard `main()`.
- `jobs/current/bhfm2_bonding_mg3_*_gpu.sh`: guarded validation scripts targeting SCC H200 GPU nodes.

### Performance Upgrades:
1. **CPU Batched `lat_obs`**: 
   - **Problem**: The original `lat_obs` performed 256 individual `numpy.linalg.eigh` calls in a Python for-loop for every residual evaluation.
   - **Solution**: Vectorized the k-sum into a single batched `numpy.linalg.eigh` call. Because these matrices are tiny ($6 \times 6$), CPU vectorization outperforms GPU (which suffers from host-to-device memory overhead for small matrices). 
   - **Result**: ~60x speedup ($64$ ms $\rightarrow$ $1.1$ ms per evaluation).

2. **Guarded Sparse Lanczos Dispatch for `imp2_obs` Large Sectors**:
   - **Problem**: At $M=3$, the interacting two-site impurity has 9 orbitals per spin, generating dense particle sectors up to $15,876 \times 15,876$.
   - **Solution**: Added a sector-solver boundary that avoids constructing the
     dense matrix for sectors of dimension `>=1024`. The GPU launcher builds a
     sparse Hamiltonian and computes low-energy states with CuPy Lanczos.
   - **Safety condition**: The run aborts with `ThermalTruncationError` unless
     discarded thermal weight is conservatively bounded below tolerance.

---

## 2. The Equation vs Parameter Imbalance (CRITICAL)
In the old wrapper layout (`BHFM2/solve_min.py`; now `BHFM2/core/solve_min.py`), the number of local bath sites was hardcoded to a single variable `M`. This forced the number of hybridization ghosts ($M_h$) and interacting ghosts ($M_g$) to be identical ($M_h = M_g = M$).

When we ran `--M 3`, it forced $M_h=3$ and $M_g=3$, leading to a mathematically underdetermined system:

* **Parameters** (37 total): $\mu$ (1), $M_h$ vars (6), $M_g$ vars (12), $M_b$ vars (18). 
* **Equations** (33 total in `legacy_full`): gateway (22) + closures (3) + moments (8).

Because there are more parameters (37) than equations (33), the `least_squares` Jacobian is rank-deficient. The optimizer wanders blindly through an infinite manifold of solutions, which is why it requires so many chunks to converge.

### The Fix: Decouple $M_h$ and $M_g$
If we decouple the code to allow **$M_h=2$** and **$M_g=3$** (with $M_b=1$):
* **Parameters**: $6(2) + 4(3) + 6(1) + 1 = 31$ parameters.
* **Equations**: $2(2) + 4(3) + 4(1) + 3 + 8 = 31$ equations.

> [!IMPORTANT]  
> **$M_h=2, M_g=3$ perfectly balances the system!** Exactly 31 equations and 31 unknowns. You **must** decouple these two variables in your local development so the solver is properly posed.

---

## 3. The Ultimate Bottleneck: Lanczos Sparse ED
Even with GPU acceleration, the $M_g=3$ interacting matrix is massively slowing down the computation.

**Scaling Profile for $M_g=3$ ($N_{orb}=9$):**
* Largest sector: 15,876 states.
* Dense matrix size: 252 million entries (2.0 GB).
* Full Dense `eigh` cost: $\sim 5.3$ trillion FLOPs per matrix.

That profile is for bonding-only. With `Mh=2, Mg=3, Mb=1` and
`bonding_plus_antibonding`, the two-site impurity has `N_orb=10`, and its
largest half-filled sector contains 63,504 states. This is why the first H200
measurement targets B+AB directly.

The number of states required at finite temperature is not assumed in advance.
It must be measured from the retained-state ladder and checked against both the
conservative thermal-tail bound and observable stability.

> [!IMPORTANT]
> Sparse Lanczos is implemented, but choosing a fixed small `k` is not enough.
> Finite-temperature observables require a retained-state convergence study.
> The current implementation aborts when its conservative thermal-tail bound
> fails. A more scalable finite-temperature method may still be needed.

### Current Feasibility Sequence

1. Run `jobs/current/bhfm2_bab_lanczos_benchmark_h200.sh`.
2. Review H200 eigensolver time, thermal-tail bounds, and retained-sector
   density/double-occupancy/bond-coherence deltas for `k=250,500,1000,2000`.
3. Permit optimizer scans only if a practical retained-state count is stable
   and certified.
4. If the ladder remains too expensive or uncertified, implement FTLM/LTLM as
   the next solver milestone rather than forcing broad fixed-`k` scans.
