#!/usr/bin/env python3
"""Phase-1 Ferrero bridge diagnostics (post-processing probes, no refit).

Purpose
-------
Use converged BHFM2 pole parameters as a baseline, then compare three
explicit k-structure choices at fixed point:

1) bond_plus_only:
   Sigma = Sigma_loc + F_plus(k) * Sigma_plus

2) plus_antibond:
   Sigma = Sigma_loc + F_plus(k) * Sigma_plus + F_minus(k) * Sigma_minus

3) plus_plaquette:
   Sigma = Sigma_loc + F_plus(k) * Sigma_plus + F_plaq(k) * Sigma_plaq

This is a structural diagnostic layer (Ferrero benchmark bridge), not a
self-consistent new solver.

Outputs
-------
results/reports/exports/phase1_ferrero_bridge.csv
results/reports/figures/phase1_spectral_AN_vs_N.png
results/reports/figures/phase1_A0_Z_summary.png
"""

from __future__ import annotations

import argparse
import csv
import os
import pickle
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np


def _load(path):
    with open(path, "rb") as f:
        return pickle.load(f)


def _ensure_sigma_inf(rec):
    if "Sigma_inf" in rec:
        return rec
    rr = dict(rec)
    n = float(rr.get("n_target", rr.get("n_avg", 1.0)))
    rr["Sigma_inf"] = float(rr["U"]) * n / 2.0
    return rr


def _pick_point(records, n_target=None, T=None):
    rs = [_ensure_sigma_inf(r) for r in records]
    if n_target is not None:
        rs = [r for r in rs if abs(float(r.get("n_target", r.get("n_avg", 1.0))) - n_target) < 1e-6]
    if T is not None:
        rs = [r for r in rs if abs(float(r["T"]) - T) < 1e-12]
    if not rs:
        raise ValueError("No records found for selection.")
    rs.sort(key=lambda r: (float(r["T"]), -float(r.get("n_target", r.get("n_avg", 1.0)))))
    return rs[0]


def _iwn_grid(beta, n=64):
    wn = (2 * np.arange(n) + 1) * np.pi / beta
    return 1j * wn, wn


def _sigma_loc(iw, rec):
    W = np.asarray(rec["W"], dtype=float)
    eta = np.asarray(rec["eta"], dtype=float)
    return float(rec["Sigma_inf"]) + np.sum(W[None, :] ** 2 / (iw[:, None] - eta[None, :]), axis=1)


def _pole(iw, amp, eta):
    return (amp ** 2) / (iw - eta)


def _F_plus(kx, ky):
    return 0.5 * (2.0 + np.cos(kx) + np.cos(ky))


def _F_minus(kx, ky):
    return 0.5 * (2.0 - np.cos(kx) - np.cos(ky))


def _F_plaq(kx, ky):
    return np.cos(kx) * np.cos(ky)


def sigma_bond_plus(kvec, iw, rec):
    """Current scheme: bond_plus (d_plus-coupled) only."""
    kx, ky = kvec
    s_loc = _sigma_loc(iw, rec)
    eta_b = float(np.asarray(rec["eta_b"]).item())
    B_h = float(np.asarray(rec["B_h"]).item())
    s_plus = _pole(iw, B_h, eta_b)
    return s_loc + _F_plus(kx, ky) * s_plus


def sigma_plus_minus(kvec, iw, rec, A_h=0.05, eta_a=0.30):
    """Add antibonding auxiliary channel coupled to d_minus."""
    kx, ky = kvec
    s_loc = _sigma_loc(iw, rec)
    eta_b = float(np.asarray(rec["eta_b"]).item())
    B_h = float(np.asarray(rec["B_h"]).item())
    s_plus = _pole(iw, B_h, eta_b)
    s_minus = _pole(iw, A_h, eta_a)
    return s_loc + _F_plus(kx, ky) * s_plus + _F_minus(kx, ky) * s_minus


def sigma_plus_plaquette(kvec, iw, rec, P_h=0.08, eta_p=0.40):
    """Add plaquette-like auxiliary channel."""
    kx, ky = kvec
    s_loc = _sigma_loc(iw, rec)
    eta_b = float(np.asarray(rec["eta_b"]).item())
    B_h = float(np.asarray(rec["B_h"]).item())
    s_plus = _pole(iw, B_h, eta_b)
    s_p = _pole(iw, P_h, eta_p)
    return s_loc + _F_plus(kx, ky) * s_plus + _F_plaq(kx, ky) * s_p


def _A_of_w(kvec, omega, eta_broad, rec, sigma_fn):
    t = 0.5
    mu = float(rec["mu"])
    kx, ky = kvec
    eps_k = -2.0 * t * (np.cos(kx) + np.cos(ky))
    z = omega.astype(complex) + 1j * eta_broad
    Sig = sigma_fn(kvec, z, rec)
    G = 1.0 / (z + mu - eps_k - Sig)
    return -1.0 / np.pi * G.imag


def _Z_from_sigma_iw0(kvec, rec, sigma_fn):
    iw, wn = _iwn_grid(float(rec["beta"]), 2)
    s0 = sigma_fn(kvec, np.array([iw[0]]), rec)[0]
    w0 = wn[0]
    return 1.0 / (1.0 - s0.imag / w0), s0


def run_phase1(rec, out_csv, out_fig_aw, out_fig_sum, eta_broad=0.05):
    k_node = (np.pi / 2.0, np.pi / 2.0)
    k_antinode = (np.pi, 0.0)

    omega = np.linspace(-2.5, 2.5, 501)
    iw, wn = _iwn_grid(float(rec["beta"]), 64)

    schemes = [
        ("bond_plus_only", sigma_bond_plus, {}),
        ("plus_antibond", sigma_plus_minus, {"A_h": 0.05, "eta_a": 0.30}),
        ("plus_plaquette", sigma_plus_plaquette, {"P_h": 0.08, "eta_p": 0.40}),
    ]

    rows = []
    spectra = []
    for name, fn, kwargs in schemes:
        sf = (lambda f, kw: (lambda k, z, r: f(k, z, r, **kw)))(fn, kwargs)
        A_N = _A_of_w(k_node, omega, eta_broad, rec, sf)
        A_AN = _A_of_w(k_antinode, omega, eta_broad, rec, sf)

        zN, sN0 = _Z_from_sigma_iw0(k_node, rec, sf)
        zAN, sAN0 = _Z_from_sigma_iw0(k_antinode, rec, sf)

        # A(omega=0)
        i0 = int(np.argmin(np.abs(omega)))
        A0_N = float(A_N[i0])
        A0_AN = float(A_AN[i0])

        rows.append(
            dict(
                scheme=name,
                n_target=float(rec.get("n_target", rec.get("n_avg", np.nan))),
                T=float(rec["T"]),
                beta=float(rec["beta"]),
                ImSigma_node_iw0=float(sN0.imag),
                ImSigma_antinode_iw0=float(sAN0.imag),
                Delta_ImSigma_AN_minus_N=float((sAN0 - sN0).imag),
                Z_node=float(zN),
                Z_antinode=float(zAN),
                Delta_Z_AN_minus_N=float(zAN - zN),
                A0_node=A0_N,
                A0_antinode=A0_AN,
                A0_ratio_AN_over_N=(A0_AN / A0_N) if abs(A0_N) > 1e-15 else np.nan,
            )
        )
        spectra.append((name, A_N, A_AN))

    # CSV
    headers = list(rows[0].keys())
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        for r in rows:
            w.writerow(r)

    # Spectral AN/N plot
    fig, axes = plt.subplots(1, len(schemes), figsize=(5.2 * len(schemes), 4.5), sharey=True, constrained_layout=True)
    if len(schemes) == 1:
        axes = [axes]
    styles = {
        "node": dict(color="tab:blue", ls="--", lw=1.8),
        "antinode": dict(color="tab:red", ls="-", lw=1.8),
    }
    for ax, (name, A_N, A_AN) in zip(axes, spectra):
        ax.plot(omega, A_N, label="A_node(omega)", **styles["node"])
        ax.plot(omega, A_AN, label="A_antinode(omega)", **styles["antinode"])
        ax.axvline(0.0, color="black", lw=0.7, alpha=0.5)
        ax.set_title(name.replace("_", " "))
        ax.set_xlabel("omega")
        ax.grid(alpha=0.25)
        ax.legend(fontsize=8, loc="best")
    axes[0].set_ylabel("A(k, omega)")
    fig.suptitle(f"Phase-1 AN vs N spectral comparison (T={rec['T']}, n={rec.get('n_target', rec.get('n_avg'))})")
    fig.savefig(out_fig_aw, dpi=160)
    plt.close(fig)

    # Summary bars
    labels = [r["scheme"] for r in rows]
    A_ratio = [r["A0_ratio_AN_over_N"] for r in rows]
    dIm = [r["Delta_ImSigma_AN_minus_N"] for r in rows]
    dZ = [r["Delta_Z_AN_minus_N"] for r in rows]
    x = np.arange(len(labels))

    fig, ax = plt.subplots(1, 3, figsize=(13.5, 4.2), constrained_layout=True)
    ax[0].bar(x, A_ratio, color="tab:purple", alpha=0.85)
    ax[0].axhline(1.0, color="black", lw=0.7, ls="--", alpha=0.6)
    ax[0].set_title("A_antinode(0) / A_node(0)")
    ax[0].set_xticks(x); ax[0].set_xticklabels(labels, rotation=15, ha="right")

    ax[1].bar(x, dIm, color="tab:orange", alpha=0.85)
    ax[1].axhline(0.0, color="black", lw=0.7, ls="--", alpha=0.6)
    ax[1].set_title("Delta ImSigma(iw0): AN - N")
    ax[1].set_xticks(x); ax[1].set_xticklabels(labels, rotation=15, ha="right")

    ax[2].bar(x, dZ, color="tab:green", alpha=0.85)
    ax[2].axhline(0.0, color="black", lw=0.7, ls="--", alpha=0.6)
    ax[2].set_title("Delta Z: AN - N")
    ax[2].set_xticks(x); ax[2].set_xticklabels(labels, rotation=15, ha="right")

    for a in ax:
        a.grid(alpha=0.25, axis="y")
    fig.suptitle("Phase-1 structural probes: which channel can split AN/N?")
    fig.savefig(out_fig_sum, dpi=160)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=None)
    ap.add_argument("--outdir-fig", default="results/reports/figures")
    ap.add_argument("--outdir-csv", default="results/reports/exports")
    ap.add_argument("--n-target", type=float, default=0.90)
    ap.add_argument("--T", type=float, default=0.05)
    ap.add_argument("--eta", type=float, default=0.05)
    args = ap.parse_args()

    root = Path(_HERE).parent
    in_path = Path(args.input) if args.input else root / "bhfm2_results" / "prof" / "doping_M2_U1.25.pkl"
    out_fig = Path(args.outdir_fig) if Path(args.outdir_fig).is_absolute() else root / args.outdir_fig
    out_csv = Path(args.outdir_csv) if Path(args.outdir_csv).is_absolute() else root / args.outdir_csv
    out_fig.mkdir(parents=True, exist_ok=True)
    out_csv.mkdir(parents=True, exist_ok=True)

    records = _load(in_path)
    rec = _pick_point(records, n_target=args.n_target, T=args.T)
    print(f"Selected point: n={rec.get('n_target', rec.get('n_avg'))}, T={rec['T']}, U={rec['U']}, res={rec['resnorm']:.3e}")

    run_phase1(
        rec,
        out_csv / "phase1_ferrero_bridge.csv",
        out_fig / "phase1_spectral_AN_vs_N.png",
        out_fig / "phase1_A0_Z_summary.png",
        eta_broad=args.eta,
    )
    print("Saved:")
    print(f" - {out_csv / 'phase1_ferrero_bridge.csv'}")
    print(f" - {out_fig / 'phase1_spectral_AN_vs_N.png'}")
    print(f" - {out_fig / 'phase1_A0_Z_summary.png'}")


if __name__ == "__main__":
    main()

