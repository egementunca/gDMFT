#!/usr/bin/env python3
"""Per-row residual breakdown and bond observable diagnostics for converged
M=2, Mb=1 doping sweep.

Reconstructs SParMin from each pkl record, re-evaluates lat_obs / gw1_obs /
gw2_obs / imp1_obs / imp2_obs and the 27-element residual vector, then writes:

  results/reports/exports/per_row_residuals.csv
  results/reports/exports/bond_observables.csv
  results/reports/figures/diag_per_row_residuals.png
  results/reports/figures/diag_bond_observables.png

Usage:
  python3 BHFM2/diagnostics/diag_observables.py
  python3 BHFM2/diagnostics/diag_observables.py --input PATH --outdir-csv DIR --outdir-fig DIR
"""
from __future__ import annotations
import argparse
import csv
import os
import pickle
import sys
import time
from dataclasses import replace
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.abspath(os.path.join(_HERE, "..", "..")))

from BHFM2.core.solve_min import (
    ModelParamsMin,
    SParMin,
    lat_obs,
    gw1_obs,
    gw2_obs,
    imp1_obs,
    imp2_obs,
    mom_lat,
    mom_imp1,
    mom_imp2,
)


M, Mb = 2, 1
N_MOMENTS = 8
Z_MIX = 0.5
NK_LAT = 16
USE_Y_BOND = True


ROW_GROUPS = [
    ('Row 1: lat.hh = mix(gw.hh)',           'h-ghost occ',       M),
    ('Row 2: lat.dh = mix(gw.dh)',           'd-h coherence',     M),
    ('Row 3: lat.hbp = gw2.hbp',             'bond h occ',        Mb),
    ('Row 4: lat.hbp_d = gw2.hbp_dplus',     'bond h coh',        Mb),
    ('Row 5: imp1.gg = gw1.gg',              'single g occ',      M),
    ('Row 6: imp1.dg = gw1.dg',              'single d-g coh',    M),
    ('Row 7: imp2.gg = gw2.gg',              'two-site g occ',    M),
    ('Row 8: imp2.dg = gw2.dg',              'two-site d-g coh',  M),
    ('Row 9: imp2.gbp = gw2.gbp',            'bond g occ',        Mb),
    ('Row 10: imp2.gbp_d = gw2.gbp_dplus',   'bond g-d coh',      Mb),
    ('Row 11a: imp filling',                 'filling (imp)',     1),
    ('Row 11b: lat filling',                 'filling (lat)',     1),
    ('Row 12: bond kinetic',                 'bond kinetic',      1),
    ('Row 13: moments (m=0..7)',             'moments',           N_MOMENTS),
]


def _n_target(r) -> float:
    """Half-filling sweeps don't store n_target; fall back to n_avg (~1.0).
    Round to 2 decimal places so float noise doesn't fragment grouping.
    """
    if 'n_target' in r:
        return round(float(r['n_target']), 2)
    return round(float(r.get('n_avg', 1.0)), 2)


def record_to_spar(r) -> SParMin:
    return SParMin(
        eta=np.asarray(r['eta'], dtype=float),
        W=np.asarray(r['W'], dtype=float),
        eta_b=np.asarray(r['eta_b'], dtype=float),
        B_h=np.asarray(r['B_h'], dtype=float),
        eps1=np.asarray(r['eps1'], dtype=float),
        V1=np.asarray(r['V1'], dtype=float),
        eta1=np.asarray(r['eta1'], dtype=float),
        W1=np.asarray(r['W1'], dtype=float),
        eps2=np.asarray(r['eps2'], dtype=float),
        V2=np.asarray(r['V2'], dtype=float),
        eta2=np.asarray(r['eta2'], dtype=float),
        W2=np.asarray(r['W2'], dtype=float),
        eta_b2=np.asarray(r['eta_b2'], dtype=float),
        B_h2=np.asarray(r['B_h2'], dtype=float),
        eps_b=np.asarray(r['eps_b'], dtype=float),
        B_g=np.asarray(r['B_g'], dtype=float),
        mu=float(r['mu']),
    )


def record_to_mp(r, n_moments=N_MOMENTS) -> ModelParamsMin:
    U = float(r['U'])
    # T-sweep pkls don't store Sigma_inf; reconstruct from U*n_avg/2 (Hartree shift).
    Sigma_inf = float(r['Sigma_inf']) if 'Sigma_inf' in r else U * _n_target(r) / 2.0
    # Both sweeps (doping at U=1.25 and T-sweep at U=1.3) use t=0.5
    # (verified in run_M2_doping.py and run_M2_sweep.py).
    return ModelParamsMin(
        t=0.5, eps_d=0.0, U=U, z=Z_MIX,
        filling_target=_n_target(r),
        Sigma_inf=Sigma_inf,
        beta=float(r['beta']),
        Nk=NK_LAT, use_y_bond=USE_Y_BOND,
        n_moments=n_moments,
    )


def evaluate_full(p: SParMin, mp: ModelParamsMin):
    """Compute all observables + the 27-element residual vector, return them."""
    z = mp.z
    imp1 = imp1_obs(p, mp, M)
    imp2 = imp2_obs(p, mp, M, Mb)
    n_avg = (1-z)*imp1['dens'] + z*imp2['dens_per_site']
    Sigma_inf_iter = mp.U * n_avg / 2.0
    mp_eff = replace(mp, Sigma_inf=Sigma_inf_iter)
    lat = lat_obs(p, mp_eff, M, Mb)
    gw1 = gw1_obs(p, mp_eff, M)
    gw2 = gw2_obs(p, mp_eff, M, Mb)

    r = []
    r.extend((lat['hh'] - ((1-z)*gw1['hh'] + z*gw2['hh'])).tolist())
    r.extend((lat['dh'] - ((1-z)*gw1['dh'] + z*gw2['dh'])).tolist())
    r.extend((lat['hbp_hbp'] - gw2['hbp_hbp']).tolist())
    r.extend((lat['hbp_d']   - gw2['hbp_dplus']).tolist())
    r.extend((imp1['gg'] - gw1['gg']).tolist())
    r.extend((imp1['dg'] - gw1['dg']).tolist())
    r.extend((imp2['gg'] - gw2['gg']).tolist())
    r.extend((imp2['dg'] - gw2['dg']).tolist())
    r.extend((imp2['gbp_gbp']   - gw2['gbp_gbp']).tolist())
    r.extend((imp2['gbp_dplus'] - gw2['gbp_dplus']).tolist())
    r.append(n_avg - mp.filling_target)
    r.append(lat['dens'] - mp.filling_target)
    r.append(lat['bond_x'] - imp2['bond_kinetic_per_bond'])
    for m in range(mp.n_moments):
        lhs = mom_lat(p, m)
        rhs = (1-z)*mom_imp1(p, m) + z*mom_imp2(p, m)
        r.append(lhs - rhs)
    return dict(
        residual=np.array(r, dtype=float),
        lat=lat, gw1=gw1, gw2=gw2, imp1=imp1, imp2=imp2,
        n_avg=n_avg, Sigma_inf_eff=Sigma_inf_iter,
    )


def split_residual_by_row(r_vec):
    """Slice the 27-element residual into named groups."""
    out = []
    idx = 0
    for label, short, n in ROW_GROUPS:
        chunk = r_vec[idx:idx+n]
        idx += n
        out.append((label, short, chunk))
    assert idx == len(r_vec), f'index mismatch {idx} != {len(r_vec)}'
    return out


def write_per_row_csv(records, evals, out_csv):
    headers = ['n_target', 'T', 'beta', 'resnorm_stored', 'resnorm_recomputed']
    for label, short, _n in ROW_GROUPS:
        key = label.split(':')[0].replace(' ', '_').lower()
        headers.append(f'{key}_l2')
        headers.append(f'{key}_max')

    rows = []
    for rec, ev in zip(records, evals):
        r_vec = ev['residual']
        groups = split_residual_by_row(r_vec)
        row = dict(
            n_target=_n_target(rec),
            T=float(rec['T']),
            beta=float(rec['beta']),
            resnorm_stored=float(rec['resnorm']),
            resnorm_recomputed=float(np.linalg.norm(r_vec)),
        )
        for label, short, chunk in groups:
            key = label.split(':')[0].replace(' ', '_').lower()
            row[f'{key}_l2'] = float(np.linalg.norm(chunk))
            row[f'{key}_max'] = float(np.max(np.abs(chunk))) if len(chunk) else 0.0
        rows.append(row)

    rows.sort(key=lambda d: (d['n_target'], d['T']))
    with open(out_csv, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f'Wrote {out_csv}  ({len(rows)} rows)')
    return rows


def write_bond_observables_csv(records, evals, out_csv):
    headers = [
        'n_target', 'T', 'beta',
        # bond h-ghost occupation
        'lat_hbp_hbp', 'gw2_hbp_hbp', 'mismatch_hbp_hbp',
        # bond h-ghost coherence
        'lat_hbp_d', 'gw2_hbp_dplus', 'mismatch_hbp_d',
        # bond g-bath occupation
        'imp2_gbp_gbp', 'gw2_gbp_gbp', 'mismatch_gbp_gbp',
        # bond g-bath coherence
        'imp2_gbp_dplus', 'gw2_gbp_dplus', 'mismatch_gbp_dplus',
        # bond kinetic energy
        'lat_bond_x', 'imp2_bond_kinetic_per_bond', 'mismatch_bond_kinetic',
        # NCS-combined double occupancy
        'D_imp1', 'D_imp2', 'D_NCS', 'D_lat_stored',
        # local Zloc from W^2/(omega0^2+eta^2)
        'Zloc_lowest_iwn',
    ]
    rows = []
    for rec, ev in zip(records, evals):
        lat = ev['lat']; gw2 = ev['gw2']; imp1 = ev['imp1']; imp2 = ev['imp2']
        beta = float(rec['beta'])
        omega0 = np.pi / beta
        eta = np.asarray(rec['eta'], dtype=float)
        W = np.asarray(rec['W'], dtype=float)
        Zloc = 1.0 / (1.0 + float(np.sum(W**2 / (omega0**2 + eta**2))))
        D_NCS = (1 - Z_MIX) * imp1['double_occ'] + Z_MIX * imp2['double_occ_per_site']
        row = dict(
            n_target=_n_target(rec),
            T=float(rec['T']),
            beta=beta,
            lat_hbp_hbp=float(lat['hbp_hbp'][0]),
            gw2_hbp_hbp=float(gw2['hbp_hbp'][0]),
            mismatch_hbp_hbp=float(lat['hbp_hbp'][0] - gw2['hbp_hbp'][0]),
            lat_hbp_d=float(lat['hbp_d'][0]),
            gw2_hbp_dplus=float(gw2['hbp_dplus'][0]),
            mismatch_hbp_d=float(lat['hbp_d'][0] - gw2['hbp_dplus'][0]),
            imp2_gbp_gbp=float(imp2['gbp_gbp'][0]),
            gw2_gbp_gbp=float(gw2['gbp_gbp'][0]),
            mismatch_gbp_gbp=float(imp2['gbp_gbp'][0] - gw2['gbp_gbp'][0]),
            imp2_gbp_dplus=float(imp2['gbp_dplus'][0]),
            gw2_gbp_dplus=float(gw2['gbp_dplus'][0]),
            mismatch_gbp_dplus=float(imp2['gbp_dplus'][0] - gw2['gbp_dplus'][0]),
            lat_bond_x=float(lat['bond_x']),
            imp2_bond_kinetic_per_bond=float(imp2['bond_kinetic_per_bond']),
            mismatch_bond_kinetic=float(lat['bond_x'] - imp2['bond_kinetic_per_bond']),
            D_imp1=float(imp1['double_occ']),
            D_imp2=float(imp2['double_occ_per_site']),
            D_NCS=float(D_NCS),
            D_lat_stored=float(rec.get('D_lat', np.nan)),
            Zloc_lowest_iwn=Zloc,
        )
        rows.append(row)
    rows.sort(key=lambda d: (d['n_target'], d['T']))
    with open(out_csv, 'w', newline='', encoding='utf-8') as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f'Wrote {out_csv}  ({len(rows)} rows)')
    return rows


def plot_per_row_residuals(per_row_rows, out_png):
    """Heatmap of per-row L2 residual norms — rows × T, color = log(value).

    Stacked log-bars are visually misleading (bottom segment always looks huge
    because it occupies the full chart range). A heatmap makes each cell's
    magnitude directly readable.
    """
    from matplotlib.colors import LogNorm
    fillings = sorted(set(r['n_target'] for r in per_row_rows))
    group_labels = [g[1] for g in ROW_GROUPS]
    group_keys = [g[0].split(':')[0].replace(' ', '_').lower() for g in ROW_GROUPS]

    # Scale figure size per panel: 4 wide per panel + 4 for ylabels; 9 tall for 14 rows.
    fig_w = 4 + 4.5 * len(fillings)
    fig, axes = plt.subplots(1, len(fillings), figsize=(fig_w, 9),
                             sharey=True, constrained_layout=True)
    if len(fillings) == 1:
        axes = [axes]

    # Global vmin/vmax across all panels for comparability
    all_vals = []
    for n in fillings:
        for r in per_row_rows:
            if r['n_target'] != n:
                continue
            for key in group_keys:
                v = r.get(f'{key}_l2', 0.0)
                if v > 0:
                    all_vals.append(v)
    vmin = max(1e-9, min(all_vals)) if all_vals else 1e-9
    vmax = max(all_vals) if all_vals else 1e-3

    for ax, n in zip(axes, fillings):
        pts = sorted([r for r in per_row_rows if r['n_target'] == n], key=lambda d: d['T'])
        Ts = [p['T'] for p in pts]
        data = np.zeros((len(group_keys), len(Ts)))
        for j, key in enumerate(group_keys):
            for i, p in enumerate(pts):
                data[j, i] = max(p.get(f'{key}_l2', 0.0), vmin * 0.1)
        im = ax.imshow(data, aspect='auto', cmap='viridis',
                       norm=LogNorm(vmin=vmin, vmax=vmax),
                       extent=[-0.5, len(Ts)-0.5, len(group_keys)-0.5, -0.5])
        # Annotate cells
        for j in range(len(group_keys)):
            for i in range(len(Ts)):
                val = data[j, i]
                if val < vmin:
                    continue
                if val >= 1e-3:
                    text_color = 'white'
                elif val >= vmin * 10:
                    text_color = 'white' if val < 10 * vmin * np.sqrt(vmax/vmin) else 'black'
                else:
                    text_color = 'lightgray'
                ax.text(i, j, f'{val:.0e}'.replace('e-0', 'e-').replace('e+0', 'e+'),
                        ha='center', va='center', fontsize=7,
                        color=text_color)
        ax.set_xticks(range(len(Ts)))
        ax.set_xticklabels([f'T={t:g}' for t in Ts], rotation=45, ha='right')
        if ax is axes[0]:
            ax.set_yticks(range(len(group_labels)))
            ax.set_yticklabels(group_labels, fontsize=9)
        else:
            ax.set_yticks([])
        ax.set_title(f'n = {n:g}', fontsize=11)
        ax.set_xlabel('')
    fig.colorbar(im, ax=axes, label='residual L2 per row group  (red dashed = 1e-3 target)',
                 fraction=0.04, pad=0.02)
    # Mark target threshold on colorbar
    fig.suptitle('Per-row residual heatmap (Table 1 groups)', fontsize=12)
    plt.savefig(out_png, dpi=140, bbox_inches='tight')
    plt.close(fig)
    print(f'Saved {out_png}')


def plot_bond_observables(bond_rows, out_png):
    """Four-panel comparison: lattice vs gateway for each bond observable family."""
    fillings = sorted(set(r['n_target'] for r in bond_rows))
    colors = {0.95: 'tab:blue', 0.90: 'tab:orange', 0.85: 'tab:green'}

    fig, axes = plt.subplots(2, 3, figsize=(15, 9), constrained_layout=True)

    panel_specs = [
        (axes[0, 0], 'Bond h-ghost occupation', 'lat_hbp_hbp', 'gw2_hbp_hbp', 'mismatch_hbp_hbp', 'lat', 'gw2'),
        (axes[0, 1], 'Bond h-ghost coherence',  'lat_hbp_d',   'gw2_hbp_dplus', 'mismatch_hbp_d',  'lat', 'gw2'),
        (axes[0, 2], 'Bond kinetic energy',     'lat_bond_x',  'imp2_bond_kinetic_per_bond', 'mismatch_bond_kinetic', 'lat', 'imp2'),
        (axes[1, 0], 'Bond g-bath occupation',  'imp2_gbp_gbp','gw2_gbp_gbp',  'mismatch_gbp_gbp',  'imp2', 'gw2'),
        (axes[1, 1], 'Bond g-bath coherence',   'imp2_gbp_dplus','gw2_gbp_dplus','mismatch_gbp_dplus', 'imp2', 'gw2'),
        (axes[1, 2], 'NCS double occupancy',    'D_NCS',       'D_lat_stored', None,              'D_NCS', 'D_lat'),
    ]

    for spec in panel_specs:
        ax = spec[0]; title = spec[1]
        key_a = spec[2]; key_b = spec[3]; key_mis = spec[4]
        lbl_a = spec[5]; lbl_b = spec[6]
        for n in fillings:
            pts = sorted([r for r in bond_rows if r['n_target'] == n], key=lambda d: d['T'])
            Ts = [p['T'] for p in pts]
            c = colors.get(n, 'gray')
            ax.plot(Ts, [p[key_a] for p in pts], 'o-', color=c, label=f'{lbl_a}, n={n:g}')
            ax.plot(Ts, [p[key_b] for p in pts], 's--', color=c, alpha=0.6, label=f'{lbl_b}, n={n:g}')
        ax.set_xlabel('T'); ax.set_title(title)
        ax.grid(alpha=0.3); ax.legend(fontsize=7, ncol=2)

    fig.suptitle('Bond observable matching across sectors (solid = source, dashed = match target)')
    plt.savefig(out_png, dpi=140)
    plt.close(fig)
    print(f'Saved {out_png}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', default=None,
                    help='doping pkl (default: bhfm2_results/prof/doping_M2_U1.25.pkl)')
    ap.add_argument('--outdir-csv', default='results/reports/exports')
    ap.add_argument('--outdir-fig', default='results/reports/figures')
    args = ap.parse_args()

    root = Path(_HERE).parent
    if args.input is None:
        args.input = str(root / 'bhfm2_results' / 'prof' / 'doping_M2_U1.25.pkl')

    out_csv_dir = Path(args.outdir_csv) if Path(args.outdir_csv).is_absolute() else root / args.outdir_csv
    out_fig_dir = Path(args.outdir_fig) if Path(args.outdir_fig).is_absolute() else root / args.outdir_fig
    out_csv_dir.mkdir(parents=True, exist_ok=True)
    out_fig_dir.mkdir(parents=True, exist_ok=True)

    print(f'Loading {args.input}')
    with open(args.input, 'rb') as f:
        records = pickle.load(f)
    print(f'  {len(records)} points')

    print('Evaluating full observables + residual per point ...')
    evals = []
    for i, rec in enumerate(records):
        t0 = time.time()
        p = record_to_spar(rec)
        mp = record_to_mp(rec)
        ev = evaluate_full(p, mp)
        evals.append(ev)
        print(f'  [{i+1:2d}/{len(records)}] n={_n_target(rec):.2f} T={rec["T"]:.3f}  '
              f'||r||={np.linalg.norm(ev["residual"]):.3e}  '
              f'(stored {rec["resnorm"]:.3e})  '
              f'wall={time.time()-t0:.1f}s', flush=True)

    per_row_rows = write_per_row_csv(records, evals, out_csv_dir / 'per_row_residuals.csv')
    bond_rows = write_bond_observables_csv(records, evals, out_csv_dir / 'bond_observables.csv')

    plot_per_row_residuals(per_row_rows, out_fig_dir / 'diag_per_row_residuals.png')
    plot_bond_observables(bond_rows, out_fig_dir / 'diag_bond_observables.png')

    print('\nDone.')


if __name__ == '__main__':
    main()
