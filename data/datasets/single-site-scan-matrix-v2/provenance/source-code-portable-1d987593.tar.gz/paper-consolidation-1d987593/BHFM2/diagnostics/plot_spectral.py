#!/usr/bin/env python3
"""Real-frequency spectral function A(k, omega) from the converged pole self-energy.

Since Sigma(k, iwn) is a finite sum of poles W_a^2/(iwn - eta_a), it is analytic
in the upper half-plane and can be continued to the real axis exactly by
substitution iwn -> omega + i*eta_broad. No Pade or MaxEnt needed.

Generates:
  results/reports/figures/spectral_Aw_4kpts.png       (A(omega) at 4 k-points, per filling)
  results/reports/figures/spectral_Akw_path.png       (A(k, omega) along high-symmetry path)
  results/reports/figures/spectral_Akw0_BZ.png        (A(k, omega=0) heatmap over BZ)

Usage:
  python3 BHFM2/diagnostics/plot_spectral.py
  python3 BHFM2/diagnostics/plot_spectral.py --input PATH --outdir DIR
"""
from __future__ import annotations
import argparse
import os
import pickle
import sys
from pathlib import Path

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
try:
    from .sigma_k import sigma_k_iwn
except ImportError:
    from sigma_k import sigma_k_iwn


def _n_target(r):
    """Half-filling sweeps don't store n_target; fall back to n_avg (~1.0).
    Round to 2 decimal places so float noise (n_avg=1.00017 vs 0.999999) doesn't
    fragment the grouping into 10 spurious 'fillings'.
    """
    if 'n_target' in r:
        return round(float(r['n_target']), 2)
    return round(float(r.get('n_avg', 1.0)), 2)


def _t_hop(r):
    """Both BHFM2 sweeps (run_M2_doping.py and run_M2_sweep.py) use t=0.5."""
    return 0.5


def _ensure_sigma_inf(r):
    """T-sweep pkls don't store Sigma_inf; sigma_k_iwn needs it. Inject if missing."""
    if 'Sigma_inf' not in r:
        r = dict(r)
        r['Sigma_inf'] = float(r.get('U', 0.0)) * _n_target(r) / 2.0
    return r


def sigma_k_realw(k, omega, eta_broad, params):
    """Sigma(k, omega + i*eta_broad) using the same pole expansion as sigma_k_iwn."""
    z = np.atleast_1d(omega).astype(complex) + 1j * eta_broad
    return sigma_k_iwn(k, z, params)


def spectral_function(k, omega, eta_broad, params, t=None):
    """A(k, omega) = -1/pi Im G^R(k, omega).

    G^R(k, omega) = 1 / (omega + i*eta + mu - eps_k - Sigma(k, omega+i*eta))
    where Sigma already includes Sigma_inf (Hartree shift), matching the
    solver's lattice convention H[0,0] = eps_k + Sigma_inf - mu.
    """
    params = _ensure_sigma_inf(params)
    if t is None:
        t = _t_hop(params)
    k = np.atleast_2d(k)
    kx, ky = k[:, 0], k[:, 1]
    eps_k = -2.0 * t * (np.cos(kx) + np.cos(ky))
    mu = float(params['mu'])
    Sigma = sigma_k_realw(k, omega, eta_broad, params)         # (Nk, Nw)
    z = (np.atleast_1d(omega).astype(complex) + 1j * eta_broad)[None, :]
    G = 1.0 / (z + mu - eps_k[:, None] - Sigma)
    return -1.0 / np.pi * G.imag


# Standard k-points for the square lattice
K_POINTS = {
    'Gamma (0,0)':       np.array([0.0, 0.0]),
    'Antinode (pi,0)':   np.array([np.pi, 0.0]),
    'Node (pi/2,pi/2)':  np.array([np.pi/2, np.pi/2]),
    'M (pi,pi)':         np.array([np.pi, np.pi]),
}


def high_symmetry_path(n_per_segment=40):
    """Gamma -> X (pi,0) -> M (pi,pi) -> Gamma path."""
    corners = [np.array([0.0, 0.0]), np.array([np.pi, 0.0]),
               np.array([np.pi, np.pi]), np.array([0.0, 0.0])]
    pts = []; ticks = [0]; total = 0
    for a, b in zip(corners[:-1], corners[1:]):
        seg = np.linspace(a, b, n_per_segment, endpoint=False)
        pts.append(seg)
        total += n_per_segment
        ticks.append(total)
    pts.append(corners[-1][None, :])
    ticks[-1] += 1
    return np.concatenate(pts, axis=0), ticks


def plot_Aw_at_kpoints(records, out_png, omega=None, eta_broad=0.08):
    """A(omega) curves at 4 k-points, one subplot per filling at lowest T."""
    if omega is None:
        omega = np.linspace(-3.0, 3.0, 401)

    fillings = sorted(set(_n_target(r) for r in records))
    fig, axes = plt.subplots(1, len(fillings), figsize=(5.5*len(fillings), 4.5),
                             sharey=True, constrained_layout=True)
    if len(fillings) == 1:
        axes = [axes]

    styles = {
        'Gamma (0,0)':       ('tab:purple', '-'),
        'Antinode (pi,0)':   ('tab:red',    '-'),
        'Node (pi/2,pi/2)':  ('tab:blue',   '--'),
        'M (pi,pi)':         ('tab:green',  ':'),
    }

    for ax, n in zip(axes, fillings):
        rs = sorted([r for r in records if _n_target(r) == n], key=lambda d: d['T'])
        r = rs[0]  # lowest T
        for lbl, k_vec in K_POINTS.items():
            A = spectral_function(k_vec[None, :], omega, eta_broad, r)[0]
            color, ls = styles[lbl]
            ax.plot(omega, A, ls=ls, color=color, lw=1.6, label=lbl)
        ax.axvline(0.0, color='black', lw=0.6, alpha=0.5)
        ax.set_xlabel('omega')
        ax.set_title(f'n = {n:g}, T = {r["T"]:g}, U = {r["U"]:g}, eta = {eta_broad:g}')
        ax.grid(alpha=0.3)
        if ax is axes[0]:
            ax.set_ylabel('A(k, omega)')
        ax.legend(fontsize=8, loc='best')
    fig.suptitle('Spectral function A(k, omega) from converged pole self-energy '
                 '(no analytic continuation needed)')
    plt.savefig(out_png, dpi=140)
    plt.close(fig)
    print(f'Saved {out_png}')


def plot_Akw_path(records, out_png, omega=None, eta_broad=0.08, n_per_seg=40):
    """A(k, omega) heatmap along Gamma-X-M-Gamma path, one panel per filling."""
    if omega is None:
        omega = np.linspace(-3.0, 3.0, 301)
    kpath, ticks = high_symmetry_path(n_per_seg)

    fillings = sorted(set(_n_target(r) for r in records))
    fig, axes = plt.subplots(1, len(fillings), figsize=(5.5*len(fillings), 5),
                             sharey=True, constrained_layout=True)
    if len(fillings) == 1:
        axes = [axes]

    vmax = 0.0
    A_cache = []
    for n in fillings:
        rs = sorted([r for r in records if _n_target(r) == n], key=lambda d: d['T'])
        r = rs[0]
        A = spectral_function(kpath, omega, eta_broad, r)
        A_cache.append((n, r, A))
        vmax = max(vmax, float(np.nanpercentile(A, 99)))

    for ax, (n, r, A) in zip(axes, A_cache):
        im = ax.imshow(A.T, origin='lower', aspect='auto', cmap='inferno',
                       extent=[0, len(kpath)-1, omega.min(), omega.max()],
                       vmin=0, vmax=vmax)
        ax.axhline(0.0, color='white', lw=0.8, alpha=0.6)
        ax.set_xticks(ticks)
        ax.set_xticklabels(['Gamma', 'X', 'M', 'Gamma'])
        ax.set_ylabel('omega')
        ax.set_title(f'n = {n:g}, T = {r["T"]:g}')
        fig.colorbar(im, ax=ax, label='A(k, omega)')
    fig.suptitle('A(k, omega) along high-symmetry path (lowest T per filling)')
    plt.savefig(out_png, dpi=140)
    plt.close(fig)
    print(f'Saved {out_png}')


def plot_Akw0_BZ(records, out_png, eta_broad=0.08, Nk=49):
    """A(k, omega=0) heatmap over the Brillouin zone for the lowest T per filling."""
    fillings = sorted(set(_n_target(r) for r in records))
    fig, axes = plt.subplots(1, len(fillings), figsize=(5*len(fillings), 5),
                             constrained_layout=True)
    if len(fillings) == 1:
        axes = [axes]

    kx = np.linspace(-np.pi, np.pi, Nk)
    ky = np.linspace(-np.pi, np.pi, Nk)
    KX, KY = np.meshgrid(kx, ky, indexing='ij')
    k_flat = np.column_stack([KX.ravel(), KY.ravel()])

    vmax = 0.0
    A_cache = []
    for n in fillings:
        rs = sorted([r for r in records if _n_target(r) == n], key=lambda d: d['T'])
        r = rs[0]
        A = spectral_function(k_flat, np.array([0.0]), eta_broad, r)[:, 0].reshape(Nk, Nk)
        A_cache.append((n, r, A))
        vmax = max(vmax, float(A.max()))

    for ax, (n, r, A) in zip(axes, A_cache):
        im = ax.imshow(A.T, origin='lower', cmap='inferno',
                       extent=[-np.pi, np.pi, -np.pi, np.pi],
                       vmin=0, vmax=vmax)
        ax.set_xlabel('kx'); ax.set_ylabel('ky')
        ax.set_title(f'n = {n:g}, T = {r["T"]:g}')
        # mark high-symmetry points
        ax.scatter([0, np.pi, np.pi/2, np.pi], [0, 0, np.pi/2, np.pi],
                   c=['purple', 'red', 'cyan', 'lime'], s=60,
                   edgecolors='white', linewidths=1.2, zorder=5)
        ax.set_xticks([-np.pi, 0, np.pi])
        ax.set_xticklabels(['-pi', '0', 'pi'])
        ax.set_yticks([-np.pi, 0, np.pi])
        ax.set_yticklabels(['-pi', '0', 'pi'])
        fig.colorbar(im, ax=ax, label='A(k, omega=0)')
    fig.suptitle('A(k, omega=0) Brillouin-zone map (Fermi surface contour)')
    plt.savefig(out_png, dpi=140)
    plt.close(fig)
    print(f'Saved {out_png}')


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--input', default=None)
    ap.add_argument('--outdir', default='results/reports/figures')
    ap.add_argument('--eta', type=float, default=0.08, help='broadening eta')
    ap.add_argument('--omega-max', type=float, default=None,
                    help='|omega| range for spectral plots (default: auto, 3 for t=0.5, 5 for t=1)')
    args = ap.parse_args()

    root = Path(_HERE).parent
    if args.input is None:
        args.input = str(root / 'bhfm2_results' / 'prof' / 'doping_M2_U1.25.pkl')

    out_dir = Path(args.outdir) if Path(args.outdir).is_absolute() else root / args.outdir
    out_dir.mkdir(parents=True, exist_ok=True)

    print(f'Loading {args.input}')
    with open(args.input, 'rb') as f:
        records = pickle.load(f)
    print(f'  {len(records)} points')

    # Pick omega range: at t=1.0 (T-sweep) the band runs to +/- 4, so go to +/- 5;
    # at t=0.5 (doping) the band runs to +/- 2, so +/- 3 suffices.
    if args.omega_max is None:
        args.omega_max = 5.0 if abs(_t_hop(records[0]) - 1.0) < 0.01 else 3.0
    omega_line = np.linspace(-args.omega_max, args.omega_max, 401)
    omega_grid = np.linspace(-args.omega_max, args.omega_max, 301)

    plot_Aw_at_kpoints(records, out_dir / 'spectral_Aw_4kpts.png',
                       omega=omega_line, eta_broad=args.eta)
    plot_Akw_path(records, out_dir / 'spectral_Akw_path.png',
                  omega=omega_grid, eta_broad=args.eta)
    plot_Akw0_BZ(records, out_dir / 'spectral_Akw0_BZ.png', eta_broad=args.eta)

    print('\nDone.')


if __name__ == '__main__':
    main()
