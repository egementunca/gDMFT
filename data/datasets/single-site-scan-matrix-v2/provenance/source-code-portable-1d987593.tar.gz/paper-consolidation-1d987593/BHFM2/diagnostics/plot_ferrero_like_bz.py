#!/usr/bin/env python3
"""Ferrero-style Brillouin-zone visualization from BHFM2 converged PKLs.

Outputs:
  - ferrero_patch_geometry.png        (equal-area 2-patch geometry + guides)
  - ferrero_arc_map_lowT.png          (A(k,0) maps with patch overlay, lowest T per filling)
  - ferrero_an_vs_n_lowT.csv          (AN/N observables at lowest T per filling)
"""

from __future__ import annotations

import argparse
import csv
import os
import pickle
import sys
from pathlib import Path

import numpy as np
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

_HERE = os.path.dirname(os.path.abspath(__file__))
try:
    from .sigma_k import sigma_k_iwn, iwn_grid, quasiparticle_weight_k
except ImportError:
    from sigma_k import sigma_k_iwn, iwn_grid, quasiparticle_weight_k


def _load(path):
    with open(path, "rb") as f:
        return pickle.load(f)


def _n_target(r):
    if "n_target" in r:
        return round(float(r["n_target"]), 2)
    return round(float(r.get("n_avg", 1.0)), 2)


def _ensure_sigma_inf(r):
    if "Sigma_inf" in r:
        return r
    rr = dict(r)
    rr["Sigma_inf"] = float(rr["U"]) * _n_target(rr) / 2.0
    return rr


def _t_hop(_r):
    # BHFM2 prof sweep/doping runners use t=0.5
    return 0.5


def spectral_A0_map(r, Nk=121, eta=0.05):
    """Compute A(k, omega=0) over the full BZ."""
    r = _ensure_sigma_inf(r)
    kx = np.linspace(-np.pi, np.pi, Nk)
    ky = np.linspace(-np.pi, np.pi, Nk)
    KX, KY = np.meshgrid(kx, ky, indexing="ij")
    k_flat = np.column_stack([KX.ravel(), KY.ravel()])

    t = _t_hop(r)
    eps_k = -2.0 * t * (np.cos(k_flat[:, 0]) + np.cos(k_flat[:, 1]))
    mu = float(r["mu"])
    z = np.array([0.0 + 1j * eta], dtype=complex)
    Sigma = sigma_k_iwn(k_flat, z, r)[:, 0]
    G = 1.0 / (z[0] + mu - eps_k - Sigma)
    A0 = (-1.0 / np.pi) * G.imag
    return kx, ky, A0.reshape(Nk, Nk)


def _draw_patch_overlay(ax):
    # Equal-area central square in Ferrero 2-patch setup:
    # side = sqrt(2)*pi, so half-side k0 = pi/sqrt(2)
    k0 = np.pi / np.sqrt(2.0)
    xs = [-k0, k0, k0, -k0, -k0]
    ys = [-k0, -k0, k0, k0, -k0]
    ax.plot(xs, ys, color="white", lw=1.4, ls="--", alpha=0.95, label="P+ boundary")

    # Gamma-X-M-Gamma guides
    ax.plot([0, np.pi], [0, 0], color="cyan", lw=0.8, alpha=0.75)
    ax.plot([np.pi, np.pi], [0, np.pi], color="cyan", lw=0.8, alpha=0.75)
    ax.plot([np.pi, 0], [np.pi, 0], color="cyan", lw=0.8, alpha=0.75)

    # High-symmetry markers
    ax.scatter([0, np.pi, np.pi / 2, np.pi], [0, 0, np.pi / 2, np.pi],
               c=["white", "red", "deepskyblue", "lime"], s=45, edgecolors="black", linewidths=0.6, zorder=5)
    ax.text(np.pi + 0.08, 0.0, "AN", color="red", fontsize=9, va="center")
    ax.text(np.pi / 2 + 0.08, np.pi / 2, "N", color="deepskyblue", fontsize=9, va="center")


def plot_patch_geometry(out_png):
    fig, ax = plt.subplots(figsize=(5.5, 5.5), constrained_layout=True)
    ax.set_facecolor("#0b0f1a")
    # Full BZ boundary
    bz = [-np.pi, np.pi, np.pi, -np.pi, -np.pi]
    by = [-np.pi, -np.pi, np.pi, np.pi, -np.pi]
    ax.plot(bz, by, color="gold", lw=1.5, label="BZ")
    _draw_patch_overlay(ax)

    # Free-FS guide for nearest-neighbor square lattice (half-filled shape)
    kx = np.linspace(-np.pi, np.pi, 600)
    ky1 = np.arccos(np.clip(-np.cos(kx), -1, 1))
    ky2 = -ky1
    ax.plot(kx, ky1, color="orange", lw=1.0, alpha=0.85, label="cos kx + cos ky = 0")
    ax.plot(kx, ky2, color="orange", lw=1.0, alpha=0.85)

    ax.set_xlim(-np.pi, np.pi)
    ax.set_ylim(-np.pi, np.pi)
    ax.set_xticks([-np.pi, 0, np.pi]); ax.set_xticklabels(["-pi", "0", "pi"])
    ax.set_yticks([-np.pi, 0, np.pi]); ax.set_yticklabels(["-pi", "0", "pi"])
    ax.set_xlabel("kx"); ax.set_ylabel("ky")
    ax.set_title("Ferrero-style two-patch geometry (equal-area central square)")
    ax.grid(alpha=0.2, color="white")
    ax.legend(fontsize=8, loc="lower left")
    fig.savefig(out_png, dpi=160)
    plt.close(fig)
    print(f"Saved {out_png}")


def plot_arc_map(records, out_png, eta=0.05, Nk=121):
    fillings = sorted(set(_n_target(r) for r in records))
    lowT = []
    for n in fillings:
        rs = [r for r in records if _n_target(r) == n]
        rs.sort(key=lambda x: float(x["T"]))
        lowT.append(rs[0])

    fig, axes = plt.subplots(1, len(lowT), figsize=(5.6 * len(lowT), 5.2), constrained_layout=True)
    if len(lowT) == 1:
        axes = [axes]

    vmax = 0.0
    cache = []
    for r in lowT:
        kx, ky, A0 = spectral_A0_map(r, Nk=Nk, eta=eta)
        cache.append((r, kx, ky, A0))
        vmax = max(vmax, float(np.nanpercentile(A0, 99.5)))

    for ax, (r, kx, ky, A0) in zip(axes, cache):
        im = ax.imshow(
            A0.T,
            origin="lower",
            cmap="inferno",
            extent=[-np.pi, np.pi, -np.pi, np.pi],
            vmin=0.0,
            vmax=vmax,
            aspect="equal",
        )
        _draw_patch_overlay(ax)

        # Arc-like contours (relative levels)
        levels = [0.25, 0.45, 0.65]
        for lv, ls in zip(levels, [":", "--", "-"]):
            ax.contour(kx, ky, A0.T, levels=[lv * vmax], colors="white", linewidths=0.7, linestyles=ls, alpha=0.8)

        ax.set_xlim(-np.pi, np.pi); ax.set_ylim(-np.pi, np.pi)
        ax.set_xticks([-np.pi, 0, np.pi]); ax.set_xticklabels(["-pi", "0", "pi"])
        ax.set_yticks([-np.pi, 0, np.pi]); ax.set_yticklabels(["-pi", "0", "pi"])
        ax.set_xlabel("kx"); ax.set_ylabel("ky")
        ax.set_title(f"n={_n_target(r):g}, T={float(r['T']):g}, U={float(r['U']):g}")
        fig.colorbar(im, ax=ax, label="A(k, omega=0)")

    fig.suptitle(f"Ferrero-style BZ map with patch overlay (eta={eta:g})")
    fig.savefig(out_png, dpi=160)
    plt.close(fig)
    print(f"Saved {out_png}")


def export_an_n_lowT(records, out_csv):
    headers = [
        "n_target",
        "T",
        "beta",
        "A0_antinode",
        "A0_node",
        "A0_ratio_AN_over_N",
        "ImSigma_AN_w0",
        "ImSigma_N_w0",
        "Delta_ImSigma_AN_minus_N",
        "Z_AN",
        "Z_N",
        "Delta_Z_AN_minus_N",
    ]
    rows = []
    fillings = sorted(set(_n_target(r) for r in records))
    for n in fillings:
        rs = [r for r in records if _n_target(r) == n]
        rs.sort(key=lambda x: float(x["T"]))
        r = _ensure_sigma_inf(rs[0])  # lowest T

        # A(0) at AN and N
        eta = 0.05
        z = np.array([0.0 + 1j * eta], dtype=complex)
        k_an = np.array([[np.pi, 0.0]])
        k_n = np.array([[np.pi / 2.0, np.pi / 2.0]])
        t = _t_hop(r)
        mu = float(r["mu"])
        eps_an = -2.0 * t * (np.cos(np.pi) + np.cos(0.0))
        eps_n = -2.0 * t * (np.cos(np.pi / 2.0) + np.cos(np.pi / 2.0))
        sig_an = sigma_k_iwn(k_an, z, r)[0, 0]
        sig_n = sigma_k_iwn(k_n, z, r)[0, 0]
        G_an = 1.0 / (z[0] + mu - eps_an - sig_an)
        G_n = 1.0 / (z[0] + mu - eps_n - sig_n)
        A_an = float((-1.0 / np.pi) * G_an.imag)
        A_n = float((-1.0 / np.pi) * G_n.imag)

        iwn = iwn_grid(float(r["beta"]), 2)
        s0_an = sigma_k_iwn(k_an, iwn, r)[0, 0]
        s0_n = sigma_k_iwn(k_n, iwn, r)[0, 0]
        z_an = float(quasiparticle_weight_k(k_an, r, float(r["beta"])))
        z_n = float(quasiparticle_weight_k(k_n, r, float(r["beta"])))

        rows.append(
            dict(
                n_target=_n_target(r),
                T=float(r["T"]),
                beta=float(r["beta"]),
                A0_antinode=A_an,
                A0_node=A_n,
                A0_ratio_AN_over_N=(A_an / A_n) if abs(A_n) > 1e-14 else np.nan,
                ImSigma_AN_w0=float(s0_an.imag),
                ImSigma_N_w0=float(s0_n.imag),
                Delta_ImSigma_AN_minus_N=float((s0_an - s0_n).imag),
                Z_AN=z_an,
                Z_N=z_n,
                Delta_Z_AN_minus_N=z_an - z_n,
            )
        )

    rows.sort(key=lambda x: float(x["n_target"]))
    with open(out_csv, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=headers)
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"Saved {out_csv}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default=None)
    ap.add_argument("--outdir", default="results/reports/figures")
    ap.add_argument("--csvdir", default="results/reports/exports")
    ap.add_argument("--eta", type=float, default=0.05)
    ap.add_argument("--Nk", type=int, default=121)
    args = ap.parse_args()

    root = Path(_HERE).parent
    in_path = Path(args.input) if args.input else root / "bhfm2_results" / "prof" / "doping_M2_U1.25.pkl"
    outdir = Path(args.outdir) if Path(args.outdir).is_absolute() else root / args.outdir
    csvdir = Path(args.csvdir) if Path(args.csvdir).is_absolute() else root / args.csvdir
    outdir.mkdir(parents=True, exist_ok=True)
    csvdir.mkdir(parents=True, exist_ok=True)

    print(f"Loading {in_path}")
    records = _load(in_path)
    print(f"Loaded {len(records)} points")

    plot_patch_geometry(outdir / "ferrero_patch_geometry.png")
    plot_arc_map(records, outdir / "ferrero_arc_map_lowT.png", eta=args.eta, Nk=args.Nk)
    export_an_n_lowT(records, csvdir / "ferrero_an_vs_n_lowT.csv")
    print("Done.")


if __name__ == "__main__":
    main()
