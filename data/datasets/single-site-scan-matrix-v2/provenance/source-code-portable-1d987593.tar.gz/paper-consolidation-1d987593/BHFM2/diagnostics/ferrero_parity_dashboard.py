#!/usr/bin/env python3
"""Build a Ferrero figure-parity dashboard from BHFM2 PKL outputs.

This script compares current BHFM2 observables against key targets from:
  - Ferrero et al., PRB 80, 064501 (2009)
  - Ferrero et al., arXiv:0806.4383v1 (2008)

It writes a markdown report with a figure-by-figure status table.
"""
from __future__ import annotations

import argparse
import datetime as _dt
import os
import pickle
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

import numpy as np

try:
    from .sigma_k import iwn_grid, sigma_k_iwn, quasiparticle_weight_k, fermi_surface_k_points
except ImportError:
    from sigma_k import iwn_grid, sigma_k_iwn, quasiparticle_weight_k, fermi_surface_k_points


def _load_pickle(path: Path):
    with path.open("rb") as f:
        return pickle.load(f)


def _by_key(rows: Iterable[dict], key: str) -> Dict[float, List[dict]]:
    out: Dict[float, List[dict]] = {}
    for r in rows:
        out.setdefault(float(r[key]), []).append(r)
    return out


def _lowest_t_rows_by_filling(doping_rows: List[dict]) -> List[dict]:
    out = []
    by_n = _by_key(doping_rows, "n_target")
    for n in sorted(by_n):
        rs = sorted(by_n[n], key=lambda r: float(r["T"]))
        out.append(rs[0])
    return out


def _compute_an_n_metrics(doping_rows: List[dict]) -> dict:
    k_an = np.array([[np.pi, 0.0]])
    k_n = np.array([[np.pi / 2.0, np.pi / 2.0]])
    all_im_delta = []
    all_re_delta = []
    per_point = []

    for r in doping_rows:
        iwn = iwn_grid(float(r["beta"]), 1)
        s_an = sigma_k_iwn(k_an, iwn, r)[0, 0]
        s_n = sigma_k_iwn(k_n, iwn, r)[0, 0]
        d_im = float((s_an - s_n).imag)
        d_re = float((s_an - s_n).real)
        all_im_delta.append(abs(d_im))
        all_re_delta.append(abs(d_re))
        per_point.append(
            {
                "n": float(r["n_target"]),
                "T": float(r["T"]),
                "ImS_AN": float(s_an.imag),
                "ImS_N": float(s_n.imag),
                "ReS_AN": float(s_an.real),
                "ReS_N": float(s_n.real),
                "dIm": d_im,
                "dRe": d_re,
            }
        )

    lowt_rows = _lowest_t_rows_by_filling(doping_rows)
    lowt_summary = []
    for r in lowt_rows:
        iwn = iwn_grid(float(r["beta"]), 1)
        s_an = sigma_k_iwn(k_an, iwn, r)[0, 0]
        s_n = sigma_k_iwn(k_n, iwn, r)[0, 0]
        lowt_summary.append(
            {
                "n": float(r["n_target"]),
                "T": float(r["T"]),
                "ImS_AN": float(s_an.imag),
                "ImS_N": float(s_n.imag),
                "dIm_abs": float(abs((s_an - s_n).imag)),
                "dRe_abs": float(abs((s_an - s_n).real)),
            }
        )

    return {
        "max_abs_dIm": float(max(all_im_delta)) if all_im_delta else float("nan"),
        "max_abs_dRe": float(max(all_re_delta)) if all_re_delta else float("nan"),
        "per_point": per_point,
        "lowt_summary": lowt_summary,
    }


def _compute_z_metrics(doping_rows: List[dict]) -> dict:
    k_an = np.array([[np.pi, 0.0]])
    k_n = np.array([[np.pi / 2.0, np.pi / 2.0]])
    k_path = fermi_surface_k_points(41)
    lowt_rows = _lowest_t_rows_by_filling(doping_rows)
    rows = []

    for r in lowt_rows:
        z_an = float(quasiparticle_weight_k(k_an, r, float(r["beta"])))
        z_n = float(quasiparticle_weight_k(k_n, r, float(r["beta"])))
        z_path = np.array([quasiparticle_weight_k(np.atleast_2d(k), r, float(r["beta"])) for k in k_path])
        rows.append(
            {
                "n": float(r["n_target"]),
                "T": float(r["T"]),
                "Z_AN": z_an,
                "Z_N": z_n,
                "dZ_AN_N_abs": abs(z_an - z_n),
                "Z_path_min": float(np.min(z_path)),
                "Z_path_max": float(np.max(z_path)),
                "Z_path_spread": float(np.max(z_path) - np.min(z_path)),
            }
        )

    max_dz = max((x["dZ_AN_N_abs"] for x in rows), default=float("nan"))
    max_path_spread = max((x["Z_path_spread"] for x in rows), default=float("nan"))
    return {"rows": rows, "max_dz": float(max_dz), "max_path_spread": float(max_path_spread)}


def _compute_sweep_monotonicity(sweep_rows: List[dict]) -> dict:
    rs = sorted(sweep_rows, key=lambda r: float(r["T"]), reverse=True)  # high T -> low T
    dvals = [float(r["D_lat"]) for r in rs]
    tvals = [float(r["T"]) for r in rs]
    mono = True
    for i in range(1, len(dvals)):
        if dvals[i] > dvals[i - 1] + 1e-10:
            mono = False
            break
    return {
        "is_nonincreasing": mono,
        "D_highT": dvals[0] if dvals else float("nan"),
        "D_lowT": dvals[-1] if dvals else float("nan"),
        "T_high": tvals[0] if tvals else float("nan"),
        "T_low": tvals[-1] if tvals else float("nan"),
    }


def _compute_parity_metrics(prof_rows: List[dict], internal_rows: List[dict]) -> dict:
    p_map = {(float(r["n_target"]), float(r["T"])): r for r in prof_rows}
    i_map = {(float(r["n_target"]), float(r["T"])): r for r in internal_rows}
    common = sorted(set(p_map).intersection(i_map))
    if not common:
        return {"count": 0, "max_dD": float("nan"), "mean_dD": float("nan"), "max_dmu": float("nan")}

    dD = []
    dmu = []
    for k in common:
        p = p_map[k]
        i = i_map[k]
        dD.append(abs(float(p["D_lat"]) - float(i["D_lat"])))
        dmu.append(abs(float(p["mu"]) - float(i["mu"])))

    return {
        "count": len(common),
        "max_dD": float(max(dD)),
        "mean_dD": float(np.mean(dD)),
        "max_dmu": float(max(dmu)),
    }


def _fmt(x: float, prec: int = 6) -> str:
    if np.isnan(x):
        return "nan"
    return f"{x:.{prec}g}"


def _status(an_n: dict, z: dict) -> List[Tuple[str, str, str, str, str]]:
    d_im = an_n["max_abs_dIm"]
    d_re = an_n["max_abs_dRe"]
    d_z = z["max_dz"]
    z_spread = z["max_path_spread"]

    # Thresholds chosen as practical signal checks, not strict physics truth.
    has_im_diff = d_im > 1e-3
    has_re_diff = d_re > 1e-3
    has_z_diff = d_z > 1e-3 or z_spread > 1e-3

    rows = []
    rows.append(
        (
            "PRB 2009 Fig. 1",
            "Nodal/antinodal two-sector viewpoint",
            "AN and N k-point sampling in `sigma_k.py`",
            "PARTIAL",
            "Sampling exists, but not full DCA patch construction in post-processing.",
        )
    )
    rows.append(
        (
            "PRB 2009 Fig. 3",
            "Re Sigma separation (even/odd) vs doping",
            "Re Sigma(AN,iw0) vs Re Sigma(N,iw0)",
            "PASS" if has_re_diff else "MISS",
            f"max abs(ReSigma_AN-ReSigma_N) = {_fmt(d_re, 4)}",
        )
    )
    rows.append(
        (
            "PRB 2009 Fig. 5",
            "Coherence differentiation (Z+ vs Z-)",
            "Z_AN, Z_N and Z(k) spread at lowest T",
            "PASS" if has_z_diff else "MISS",
            f"max abs(Z_AN-Z_N) = {_fmt(d_z, 4)}; max Z(k) spread = {_fmt(z_spread, 4)}",
        )
    )
    rows.append(
        (
            "PRB 2009 Fig. 7-8",
            "Odd-orbital pseudogap + gap scale",
            "Real-frequency A(omega) extraction",
            "BLOCKED",
            "Current pipeline produces Matsubara Sigma diagnostics, not robust A-(omega) extraction.",
        )
    )
    rows.append(
        (
            "PRB 2009 Fig. 12-13",
            "Im Sigma differentiation (AN vs N)",
            "Im Sigma(AN,iw0) vs Im Sigma(N,iw0)",
            "PASS" if has_im_diff else "MISS",
            f"max abs(ImSigma_AN-ImSigma_N) = {_fmt(d_im, 4)}",
        )
    )
    rows.append(
        (
            "PRB 2009 Fig. 22-23",
            "A(k,0) arc maps and angular intensity",
            "Direct A(k,0) and A(phi,0)/A(0,0)",
            "BLOCKED",
            "No direct A(k,0) map in current scripts.",
        )
    )
    rows.append(
        (
            "arXiv 0806 Fig. 1-4",
            "Compact precursor of same AN/N differentiation + arcs",
            "Same metrics as above",
            "PARTIAL",
            "Two-temperature/two-k proxies are available, full spectral map is not.",
        )
    )
    return rows


def build_dashboard(
    prof_doping: Path,
    prof_sweep: Path,
    out_path: Path,
    internal_doping: Path | None = None,
) -> Path:
    doping = _load_pickle(prof_doping)
    sweep = _load_pickle(prof_sweep)
    an_n = _compute_an_n_metrics(doping)
    z = _compute_z_metrics(doping)
    sweep_diag = _compute_sweep_monotonicity(sweep)
    parity = None
    if internal_doping is not None and internal_doping.exists():
        parity = _compute_parity_metrics(doping, _load_pickle(internal_doping))

    today = _dt.date.today().isoformat()
    lines: List[str] = []
    lines.append(f"# BHFM2 Ferrero Figure Parity Dashboard ({today})")
    lines.append("")
    lines.append("Inputs:")
    lines.append(f"- `prof_doping`: `{prof_doping}`")
    lines.append(f"- `prof_sweep`: `{prof_sweep}`")
    if internal_doping is not None:
        lines.append(f"- `internal_doping`: `{internal_doping}`")
    lines.append("")
    lines.append("## Quick Diagnostics")
    lines.append(
        f"- Half-filling sweep monotone D_lat(T): "
        f"{'yes' if sweep_diag['is_nonincreasing'] else 'no'} "
        f"(`{_fmt(sweep_diag['D_highT'])}` at T={_fmt(sweep_diag['T_high'])} -> "
        f"`{_fmt(sweep_diag['D_lowT'])}` at T={_fmt(sweep_diag['T_low'])})"
    )
    lines.append(f"- Max `|ImSigma_AN - ImSigma_N|`: `{_fmt(an_n['max_abs_dIm'], 8)}`")
    lines.append(f"- Max `|ReSigma_AN - ReSigma_N|`: `{_fmt(an_n['max_abs_dRe'], 8)}`")
    lines.append(f"- Max `|Z_AN - Z_N|` (lowest T per filling): `{_fmt(z['max_dz'], 8)}`")
    lines.append(f"- Max `Z(k)` spread along AN->N->AN path: `{_fmt(z['max_path_spread'], 8)}`")
    if parity is not None:
        lines.append(
            f"- Prof/Internal doping parity (`{parity['count']}` common points): "
            f"max `|Delta D_lat|` = `{_fmt(parity['max_dD'], 8)}`, "
            f"mean `|Delta D_lat|` = `{_fmt(parity['mean_dD'], 8)}`, "
            f"max `|Delta mu|` = `{_fmt(parity['max_dmu'], 8)}`"
        )
    lines.append("")
    lines.append("## Figure Status Table")
    lines.append("")
    lines.append("| Ferrero figure | Target observable | BHFM2 proxy | Status | Evidence |")
    lines.append("|---|---|---|---|---|")
    for fig, target, proxy, st, ev in _status(an_n, z):
        lines.append(f"| {fig} | {target} | {proxy} | **{st}** | {ev} |")
    lines.append("")
    lines.append("## Low-T AN/N Snapshot (per filling)")
    lines.append("")
    lines.append("| n | T | ImSigma_AN(iw0) | ImSigma_N(iw0) | abs Delta Im | abs Delta Re |")
    lines.append("|---|---:|---:|---:|---:|---:|")
    for r in sorted(an_n["lowt_summary"], key=lambda x: x["n"]):
        lines.append(
            f"| {r['n']:.2f} | {r['T']:.3f} | {r['ImS_AN']:.6f} | {r['ImS_N']:.6f} | "
            f"{r['dIm_abs']:.6g} | {r['dRe_abs']:.6g} |"
        )
    lines.append("")
    lines.append("## Low-T Z Snapshot (per filling)")
    lines.append("")
    lines.append("| n | T | Z_AN | Z_N | abs Delta Z | Zmin(path) | Zmax(path) | spread |")
    lines.append("|---|---:|---:|---:|---:|---:|---:|---:|")
    for r in sorted(z["rows"], key=lambda x: x["n"]):
        lines.append(
            f"| {r['n']:.2f} | {r['T']:.3f} | {r['Z_AN']:.6f} | {r['Z_N']:.6f} | "
            f"{r['dZ_AN_N_abs']:.6g} | {r['Z_path_min']:.6f} | {r['Z_path_max']:.6f} | "
            f"{r['Z_path_spread']:.6g} |"
        )
    lines.append("")
    lines.append("## What To Add Next For Full Ferrero Parity")
    lines.append("")
    lines.append("1. Add a real-frequency continuation workflow to obtain `A(k,0)` maps.")
    lines.append("2. Extend momentum structure beyond the current pair-manifold degeneracy at AN/N.")
    lines.append("3. Rebuild Ferrero-like angular intensity `A(phi,0)/A(0,0)` from the reconstructed map.")
    lines.append("")
    lines.append("Interpretation note:")
    lines.append("- `MISS` here means the current observable does not show differentiation.")
    lines.append("- `BLOCKED` means the current pipeline does not yet produce that observable.")

    out_path.parent.mkdir(parents=True, exist_ok=True)
    out_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return out_path


def _resolve_default_paths(script_dir: Path) -> Tuple[Path, Path, Path, Path]:
    root = script_dir.parent
    prof_doping = root / "bhfm2_results" / "prof" / "doping_M2_U1.25.pkl"
    prof_sweep = root / "bhfm2_results" / "prof" / "Tsweep_M2_U1.3.pkl"
    internal_doping = root / "bhfm2_results" / "internal" / "doping_M2_U1.25.pkl"
    out = root / "results" / "reports" / f"BHFM2_FERRERO_PARITY_DASHBOARD_{_dt.date.today().isoformat()}.md"
    return prof_doping, prof_sweep, internal_doping, out


def main():
    here = Path(os.path.abspath(os.path.dirname(__file__)))
    d_prof_doping, d_prof_sweep, d_internal_doping, d_out = _resolve_default_paths(here)

    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--prof-doping", type=Path, default=d_prof_doping)
    ap.add_argument("--prof-sweep", type=Path, default=d_prof_sweep)
    ap.add_argument("--internal-doping", type=Path, default=d_internal_doping)
    ap.add_argument("--out", type=Path, default=d_out)
    args = ap.parse_args()

    missing = [p for p in [args.prof_doping, args.prof_sweep] if not p.exists()]
    if missing:
        raise FileNotFoundError(
            "Missing required input file(s): " + ", ".join(str(p) for p in missing)
        )

    out = build_dashboard(
        prof_doping=args.prof_doping,
        prof_sweep=args.prof_sweep,
        internal_doping=args.internal_doping if args.internal_doping.exists() else None,
        out_path=args.out,
    )
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
