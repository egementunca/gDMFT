"""Profile ONE residual evaluation for the B+AB Mh2/Mg3/Mb1 low-T point.

Two modes (env BHFM2_PROFILE_MODE):
  full      (default) : warmup -> timed eval -> cProfile -> writes json/.prof/txt
  workload            : warmup -> N evals only (so an EXTERNAL profiler such as
                        py-spy / nsys / scalene can wrap it cleanly without
                        fighting the internal cProfile)

Run on a GPU node only (jobs/current/bhfm2_profile_onepoint_h200.sh). It calls
the real solver internals; it does NOT run the optimizer or write checkpoints.

Mirrors jobs/current/bhfm2_bab_mg3_lowT_onepoint_h200.sh:
  U=2.0, n=1.0, T=0.05, Mh=2, Mg=3, Mb=1, B+AB, z=0.5, t=0.5, Nk=16, k=500.
"""
import os
import io
import json
import time
import cProfile
import pstats
from collections import defaultdict

import numpy as np

from BHFM2.core import solve_min, solve_min_gpu
from BHFM2.core.solve_min import ModelParamsMin, CodecMin, init_min, residual_min
from BHFM2.runners.run_bonding_systematic import _objective_n_eq

# ---- config (mirror the one-point job) ----
U, T, N_TARGET = 2.0, 0.05, 1.0
Mh, Mg, Mb = 2, 3, 1
MODE = "bonding_plus_antibonding"
OBJECTIVE = "gateway_plus_impfill_moments"
T_HOP, NK, Z = 0.5, 16, 0.5
OUTDIR = os.environ.get("BHFM2_PROFILE_OUTDIR", "results/bhfm2_bonding/profile")
PROFILE_MODE = os.environ.get("BHFM2_PROFILE_MODE", "full")          # full | workload
N_WORKLOAD = int(os.environ.get("BHFM2_PROFILE_NEVALS", "2"))
USE_NVTX = os.environ.get("BHFM2_PROFILE_NVTX", "0") == "1"          # label nsys timeline

# ---- NVTX range shim (cupy's nvtx needs no extra install; else `nvtx` pkg; else no-op) ----
import contextlib
_NVTX = None
try:
    from cupy.cuda import nvtx as _cunvtx
    _NVTX = "cupy"
except Exception:
    try:
        import nvtx as _pynvtx
        _NVTX = "pkg"
    except Exception:
        _NVTX = None


@contextlib.contextmanager
def _rng(name):
    if not USE_NVTX or _NVTX is None:
        yield
        return
    if _NVTX == "cupy":
        _cunvtx.RangePush(name)
        try:
            yield
        finally:
            _cunvtx.RangePop()
    else:
        with _pynvtx.annotate(message=name):
            yield


def install_nvtx_labels():
    """Wrap the residual's components so the nsys timeline shows named ranges."""
    if not USE_NVTX:
        return
    for fname in ("imp1_obs", "imp2_obs", "lat_obs", "gw1_obs", "gw2_obs"):
        orig = getattr(solve_min, fname, None)
        if orig is None:
            continue

        def make(o, nm):
            def wrapped(*a, **k):
                with _rng(nm):
                    return o(*a, **k)
            return wrapped

        setattr(solve_min, fname, make(orig, fname))


def build_point():
    codec = CodecMin(Mh, Mg, Mb, mode=MODE)
    base_eqs = _objective_n_eq(Mh, Mg, Mb, 0, OBJECTIVE, MODE)
    n_moments = max(0, codec.size - base_eqs)
    mp = ModelParamsMin(
        U=U, t=T_HOP, eps_d=0.0, z=Z, Sigma_inf=U * N_TARGET / 2.0,
        Nk=NK, n_moments=n_moments, filling_target=N_TARGET, beta=1.0 / T,
    )
    p = init_min(Mh, Mg, Mb, mode=MODE)  # representative start; timings depend on dims, not values
    return p, mp, codec, n_moments


def install_sector_timer():
    """Wrap the (already GPU-patched) sector solver to record per-sector timing."""
    sector_log = []
    orig = solve_min._sector_eigh

    def timed(h1, U_, U_orbs, N_orb, basis, keys, vals, beta, sector_key=None):
        t0 = time.perf_counter()
        with _rng(f"ED_N{N_orb}_{sector_key}"):
            out = orig(h1, U_, U_orbs, N_orb, basis, keys, vals, beta, sector_key=sector_key)
        dt = time.perf_counter() - t0
        meta = out[2] if isinstance(out, (tuple, list)) and len(out) >= 3 else None
        sector_log.append({
            "N_orb": int(N_orb),
            "dim": int(getattr(meta, "dim", len(basis))),
            "backend": str(getattr(meta, "backend", "?")),
            "sector": list(sector_key) if sector_key else None,
            "seconds": dt,
        })
        return out

    solve_min._sector_eigh = timed
    return sector_log


def main():
    gpu_ok = bool(solve_min_gpu.init_gpu())
    solve_min_gpu.patch_all()
    p, mp, codec, n_moments = build_point()
    sector_log = install_sector_timer()
    install_nvtx_labels()   # no-op unless BHFM2_PROFILE_NVTX=1 (set by the nsys pass)
    n_params = codec.size

    # warmup (always): numba JIT + GPU first-kernel + topology cache, NOT counted
    print(f"[{PROFILE_MODE}] warming up (JIT/GPU/cache)...", flush=True)
    _ = residual_min(p, mp, Mh, Mg, Mb, mode=MODE)
    sector_log.clear()

    # ---- workload mode: just run the work for an external profiler to capture ----
    if PROFILE_MODE == "workload":
        for i in range(N_WORKLOAD):
            t0 = time.perf_counter()
            _ = residual_min(p, mp, Mh, Mg, Mb, mode=MODE)
            print(f"  eval {i}: {time.perf_counter() - t0:.2f}s", flush=True)
        gpu_used = any("gpu" in s["backend"] for s in sector_log)
        print(f"[workload] gpu_init={gpu_ok} gpu_used={gpu_used} "
              f"sectors/eval={len(sector_log)//max(1, N_WORKLOAD)} done", flush=True)
        return

    # ---- full mode: timed eval + cProfile + outputs ----
    t0 = time.perf_counter()
    r = residual_min(p, mp, Mh, Mg, Mb, mode=MODE)
    t_residual = time.perf_counter() - t0

    pr = cProfile.Profile()
    pr.enable()
    _ = residual_min(p, mp, Mh, Mg, Mb, mode=MODE)
    pr.disable()

    # aggregate per-sector
    imp1_norb = 1 + Mg          # 4  (imp2 has N_orb=10)
    imp1_t = sum(s["seconds"] for s in sector_log if s["N_orb"] == imp1_norb)
    imp2_t = sum(s["seconds"] for s in sector_log if s["N_orb"] != imp1_norb)
    ed_t = imp1_t + imp2_t
    gpu_used = any("gpu" in s["backend"] for s in sector_log)
    biggest = max(sector_log, key=lambda s: s["dim"]) if sector_log else None

    by_kind = defaultdict(lambda: {"seconds": 0.0, "count": 0, "max_dim": 0})
    for s in sector_log:
        kind = "imp1(1site)" if s["N_orb"] == imp1_norb else "imp2(2site)"
        k = f"{kind} [{s['backend']}]"
        by_kind[k]["seconds"] += s["seconds"]
        by_kind[k]["count"] += 1
        by_kind[k]["max_dim"] = max(by_kind[k]["max_dim"], s["dim"])

    est = {
        "one_residual_eval_s": t_residual,
        "ed_solve_share": (ed_t / t_residual) if t_residual else None,
        "one_gradient_finite_diff_s": t_residual * (n_params + 1),
        "one_chunk_80_nfev_s": t_residual * 80,
        "full_budget_16_chunks_s": t_residual * 80 * 16,
        "one_gradient_analytic_jac_s_est": t_residual * 2,
        "per_iter_speedup_if_analytic_jac": (n_params + 1) / 2.0,
    }

    os.makedirs(OUTDIR, exist_ok=True)
    report = {
        "config": {"U": U, "T": T, "n": N_TARGET, "Mh": Mh, "Mg": Mg, "Mb": Mb,
                   "mode": MODE, "objective": OBJECTIVE,
                   "k": os.environ.get("BHFM2_LANCZOS_K", "?"),
                   "n_params": n_params, "n_moments": n_moments},
        "gpu_initialized": gpu_ok,
        "gpu_used_for_big_sectors": gpu_used,
        "n_sectors_solved": len(sector_log),
        "imp1_total_s": imp1_t,
        "imp2_total_s": imp2_t,
        "biggest_sector": biggest,
        "by_kind": by_kind,
        "estimates": est,
    }
    with open(os.path.join(OUTDIR, "profile_onepoint.json"), "w") as f:
        json.dump(report, f, indent=2, default=str)

    # binary stats for visualizers (snakeviz sunburst / gprof2dot call graph / tuna)
    pr.dump_stats(os.path.join(OUTDIR, "profile_onepoint.prof"))
    for sort_key, suffix in (("cumulative", "cumtime"), ("tottime", "tottime")):
        buf = io.StringIO()
        pstats.Stats(pr, stream=buf).sort_stats(sort_key).print_stats(30)
        with open(os.path.join(OUTDIR, f"profile_onepoint_{suffix}.txt"), "w") as f:
            f.write(buf.getvalue())

    # human-readable summary -> job .out log
    print("\n" + "=" * 64)
    print(f"GPU initialized = {gpu_ok} | GPU used for big sectors = {gpu_used}")
    print(f"one residual eval        : {t_residual:8.2f} s")
    print(f"  imp2 (2-site ED)       : {imp2_t:8.2f} s   ({100*imp2_t/t_residual:5.1f}%)")
    print(f"  imp1 (1-site ED)       : {imp1_t:8.2f} s   ({100*imp1_t/t_residual:5.1f}%)")
    print(f"  rest (lat/gw/assemble) : {t_residual-ed_t:8.2f} s   ({100*(t_residual-ed_t)/t_residual:5.1f}%)")
    if biggest:
        print(f"  biggest sector dim={biggest['dim']} backend={biggest['backend']}: {biggest['seconds']:.2f} s")
    print("-" * 64)
    for k, v in sorted(by_kind.items()):
        print(f"  {k:34s} count={v['count']:3d}  max_dim={v['max_dim']:6d}  {v['seconds']:7.2f} s")
    print("-" * 64)
    print(f"finite-diff gradient (x{n_params+1}) : {est['one_gradient_finite_diff_s']/60:8.1f} min")
    print(f"one chunk (80 nfev)            : {est['one_chunk_80_nfev_s']/3600:8.2f} h")
    print(f"full budget (16 chunks)        : {est['full_budget_16_chunks_s']/3600:8.2f} h")
    print(f"analytic-jac gradient (est)    : {est['one_gradient_analytic_jac_s_est']/60:8.1f} min   "
          f"(~{est['per_iter_speedup_if_analytic_jac']:.0f}x fewer ED solves/iter)")
    print("=" * 64)
    print(f"\nwrote to {OUTDIR}/ : profile_onepoint.{{json,prof}} + _cumtime.txt + _tottime.txt")
    print("visualize locally:  pip install snakeviz && snakeviz profile_onepoint.prof")


if __name__ == "__main__":
    main()
