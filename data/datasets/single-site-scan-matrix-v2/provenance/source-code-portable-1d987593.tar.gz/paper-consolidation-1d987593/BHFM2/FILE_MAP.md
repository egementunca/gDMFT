# BHFM2 File Map

Legend:
- `core`: physics/solver implementation
- `runner`: run orchestration
- `gpu`: acceleration wrapper/patch
- `diag`: diagnostics/postprocessing
- `report`: export/summary tooling
- `doc`: docs/

## Core (`BHFM2/core/`)

| File | Category | Purpose |
|---|---|---|
| `core/solve_min.py` | core | Main model, observables, residuals, solver loop (`bonding_only` and `bonding_plus_antibonding`). |
| `core/solve_min_gpu.py` | gpu | Lat-obs batching + sparse Lanczos ED routing + certified thermal-tail guard + smoke tests. |
| `core/ed_fast.py` | core | Numba dense ED kernels and expectation values. |
| `core/ed_sparse.py` | core | Cached sparse interacting-sector topology and Hamiltonian assembly used by guarded Lanczos acceleration. |
| `core/ghost_dmft_bond.py` | core | Basis/sector construction and low-level helpers. |

## Runners (`BHFM2/runners/`)

| File | Category | Purpose |
|---|---|---|
| `runners/run_bonding_systematic.py` | runner | Primary systematic scan runner. |
| `runners/run_bonding_systematic_gpu.py` | gpu | GPU launcher for systematic runner. |
| `runners/benchmark_bab_lanczos.py` | gpu | One-point `Mh=2, Mg=3`, B+AB retained-state ladder benchmark for H200 feasibility measurements. |
| `runners/run_M2_sweep.py` | runner | Canonical/reference M=2 temperature sweep. |
| `runners/run_M2_doping.py` | runner | Canonical/reference M=2 doping sweep. |
| `runners/check_setup.py` | runner | Environment/import/runtime sanity check. |

## Diagnostics (`BHFM2/diagnostics/`)

| File | Category | Purpose |
|---|---|---|
| `diagnostics/sigma_k.py` | diag | Sigma(k,iwn), Z(k), FS helper functions. |
| `diagnostics/plot_fermi_arcs.py` | diag | Ferrero-style AN/N diagnostics plots. |
| `diagnostics/plot_spectral.py` | diag | A(k,ω) real-frequency visualization. |
| `diagnostics/plot_ferrero_like_bz.py` | diag | BZ/patch-style visualization helpers. |
| `diagnostics/diag_observables.py` | diag | Residual block and bond observable extraction. |
| `diagnostics/ferrero_parity_dashboard.py` | diag | Paper-parity markdown dashboard. |
| `diagnostics/phase1_ferrero_bridge.py` | diag | Exploratory Ferrero-bridge checks. |

## Reporting (`BHFM2/reporting/`)

| File | Category | Purpose |
|---|---|---|
| `reporting/export_bonding_parameters.py` | report | Wide/long CSV export of converged parameters. |
| `reporting/report_bonding_results.py` | report | Summary tables and overview plots for run outputs. |

## Docs

- `README.md` (this folder guide)
- `FILE_MAP.md` (this map)
- `BHFM2_Optimization_Report.md` (performance notes)
