"""Single home for gate -> classify -> FE-select (Paper Plan v3; runbook section 1.5).

Every figure/table script imports THIS module. It consolidates the four
previously drifting copies (feat/single-site-study: plot_seed_relax_compare.py,
method_compare.py, relaxed_ghost_table.py, report_quarto/report.qmd) and the
protocol detectors of the 2026-07-07 solution-selection draft
(solve_protocol.py, rescued to scripts/nablaF_protocol_bethe.py).

Order is law:  gate  ->  classify  ->  fe_select.
Never free-energy first: junk families undercut the true Omega by ~0.1, so F is
compared ONLY among gated, rejection-free candidates.

The h-sector Sigma-weight boundary (THE declared boundary)
----------------------------------------------------------
H_W2_REJECT = 1.3, applied to ratio = sum W^2 / (U^2/4) in pole-mode h only.

Re-derived 2026-07-10 from the junk atlas + finding-18 data, superseding BOTH
prior copies (finding-18 ">1.5" and the protocol window "[0.5, 1.7]"):
  * physical rows: 426 gated square-lattice seed-relax rows (T in {0.00625,
    0.025}, up+down ladders) have ratio <= 1.051 (ceiling = collapse-edge metal
    at U/t=10.5); the 104 gated Bethe protocol-census rows sit at 0.86-0.90.
    Typical: metal 0.86-0.95 rising toward collapse, insulator ~0.95 (atomic
    sum-rule sum W^2 = U^2/4 approached from below).
  * h-escape family (finding 18): observed onset 1.531 (U/t=10.75, with the
    Z-RISES-with-U signature), then 2.31 -> 1e7. The only two rows ever seen in
    (1.4, 2.0] are both escape onset/creep rows -- junk.
  * 1.3 is the geometric midpoint of the observed gap [1.051, 1.531]: 24%
    headroom above the physical ceiling, 18% below the junk onset.
  * why the old numbers disagreed in (1.5, 1.7]: the finding-18 cut 1.5 sat 2%
    under the observed onset (accidentally tight); the protocol's upper edge
    1.7 was a BOX ARTIFACT -- its W-cap 1.3*U/(2*sqrt(2)) caps the ratio at
    1.69, so that frame never saw the escape family at all.

Renormalizer exception: a pole railed/frozen at large |e| with a stable slope
invariant (2w^2/e^2 in the h sector, B^2/|eps| in the bond-g sector) is a
DECLARED representation of a self-energy slope (NCS Mh=4 layer; the iw-
renormalizer of the relaxed Mg=3 bath). It is exempt from the escape cut --
pass renorm_declared=True and report the invariant instead.

Row convention: functions take a NORMALIZED row dict (see normalize_runner_row
/ normalize_protocol_row). Canonical keys:
  U (code units), U_over_t, T, maxr, resnorm, Z, D, V0, V1_outer, eps_g,
  w2_ratio, eta_min, F, renorm_declared, bound_pins (list), Mg
Gate numbers quoted in the runbook refer to max|r| (key "maxr").
"""

from __future__ import annotations

import ast
import math

import numpy as np

# ---------------------------------------------------------------------------
# Declared boundaries (see module docstring for the derivations)
# ---------------------------------------------------------------------------
H_W2_REJECT = 1.3      # pole-mode h: ratio above this = h-escape family -> reject
H_W2_LOW_FLAG = 0.5    # advisory only: under-weighted h -> flag
H_W2_MIN_UD = 1.5      # BOTH w2 tests apply only for U/D >= this: the atomic
                       # denominator U^2/4 vanishes at weak coupling, so the
                       # ratio diverges by construction for ANY finite Sigma
                       # weight (5-param metal at U/D=0.5 has ratio ~11 and is
                       # physical). All derivation data was U/D >= 2.

DARK_V = 1e-3          # dark = ALL impurity channels dead: V0 AND V1_outer < this
                       # (V0 -> 0 alone with V1 alive is the INSULATOR -- never junk)
DEADOUTER_V = 1e-2     # dead outer channel: V1_outer below this (Mg >= 3)
SUBTHERMAL_EPS = 1e-3  # sub-thermal outer: eps_g < max(2T, this)  (Mg >= 3)

FREEHOP_UT = 5.0       # free-state hop filter applies only for U/t > 5 ...
FREEHOP_Z = 0.9        # ... and trips when Z >= 0.9 or D >= 0.2 there
FREEHOP_D = 0.2

WEAK_BATH_FRAC = 0.5   # Mg=1 only: sum V^2 below this fraction of M2 = the
                       # weak-coupled exact junk family. Derived 2026-07-10
                       # (R1 attempt-1 post-mortem): the family solves the
                       # objective to ~1e-8 with sum V^2 ~ 0.19-0.22*M2 and Z
                       # collapsing by U/D~0.9, while the physical Mg=1 metal
                       # sits at 0.55-0.68*M2 there. Boundary 0.5*M2 splits the
                       # observed gap. Mg>=3 is exempt: the relaxed satellite
                       # pair escapes to the iw-renormalizer and sum V^2 is NOT
                       # conserved there (D01: quote V0 + c, not sum V^2).
WEAK_BATH_MAX_UD = 1.5 # ... and it applies ONLY for U/D <= this: the PHYSICAL
                       # metal's sum V^2 declines continuously toward collapse
                       # (through 0.5*M2 at U/D~1.9, to 0.03*M2 at the edge) —
                       # a global cut beheads the real branch at 1.8 (caught by
                       # the R1 collector). The junk/physical gap is a WEAK-
                       # coupling statement; deep junk is caught by h_escape /
                       # free_hop / the running-min prefix.

METAL_PREFIX_TOL = 1e-3  # running-min tolerance (catches ~1e-3/step creep)
Z_COLLAPSED = 0.02       # metal is over once Z drops below this

BRANCH_V0_INS = 0.025  # 2-D branch rule (protocol EXP-B1): insulator attractor
BRANCH_ETA_INS = 0.05  # is fuzzy below thermal resolution; corridor in between

ACCEPTANCE_OVER_FLOOR = 1.5  # acceptance = 1.5 x calibrated floor (3e-5 for the
                             # reference Bethe/Nk=256/T=0.001 floor 2e-5)


# ---------------------------------------------------------------------------
# Gate
# ---------------------------------------------------------------------------
def gate(row, acceptance):
    """A row is a solution iff max|r| < acceptance. Spinodals are located by
    gate FAILURE of an arm (after retry), never by filters."""
    m = row.get("maxr")
    return (m is not None) and math.isfinite(m) and m < acceptance


def calibrate_floor(maxrs):
    """Runbook calibration: solve >=3 known-good points at tight tolerance and
    read their converged floors. Returns dict(floor, acceptance).
    floor = max of the observed per-point floors (conservative);
    acceptance = ACCEPTANCE_OVER_FLOOR * floor.
    Reference (Bethe/Nk=256/T=0.001): floor 6e-6-2e-5 -> acceptance ~3e-5.
    1e-4 is known to admit stall families -- recalibrate per lattice/Nk/T."""
    m = [float(v) for v in maxrs if v == v and math.isfinite(float(v))]
    if len(m) < 3:
        raise ValueError(f"calibrate_floor wants >=3 known-good floors, got {len(m)}")
    floor = max(m)
    return dict(floor=floor, acceptance=ACCEPTANCE_OVER_FLOOR * floor, n=len(m))


# ---------------------------------------------------------------------------
# Classify (rejection-only detectors + advisory flags + invariants)
# ---------------------------------------------------------------------------
def classify(row):
    """-> dict(branch_label, hmode, rejects[], flags[], invariants{}).

    rejects: dark, dead_outer, subthermal_outer, h_escape, free_hop.
    flags (advisory, never exclude on their own): w2_low, bound_pin, corridor.
    branch_label: metal / insulator / corridor (2-D V0-eta rule) -- only
    meaningful when rejects is empty."""
    rejects, flags, inv = [], [], {}
    Mg = int(row.get("Mg", 3))
    T = float(row.get("T", 0.0) or 0.0)
    V0 = row.get("V0")
    V1 = row.get("V1_outer")
    Z = row.get("Z")
    D = row.get("D")
    eps_g = row.get("eps_g")
    eta = row.get("eta_min")
    ut = row.get("U_over_t")
    ud = row.get("U_over_D")

    # dark: every impurity channel dead. At Mg=1 the single channel dying IS
    # total decoupling (that is the R1 story point); at Mg>=3 require BOTH.
    if Mg <= 1:
        dark = V0 is not None and V0 < DARK_V
    else:
        dark = (V0 is not None and V0 < DARK_V) and (V1 is not None and V1 < DARK_V)
    if dark:
        rejects.append("dark")

    # weak-coupled family (Mg=1 only): exact roots with the bath sum rule
    # sum V^2 = M2 violated ~5x; non-dark (V0 alive), sub-h-escape (w2_ratio
    # ~0.07), so only this detector catches it row-wise.
    if Mg <= 1 and not dark:
        sv2, m2 = row.get("sum_V2"), row.get("M2")
        if sv2 is not None and m2:
            inv["V2_over_M2"] = float(sv2 / m2)
            if (sv2 < WEAK_BATH_FRAC * m2
                    and ud is not None and ud <= WEAK_BATH_MAX_UD):
                rejects.append(f"weak_bath:{sv2 / m2:.2f}")

    # dead / sub-thermal outer channels (Mg>=3, non-dark rows): the Mg=3 rows
    # they should carry are trivialized -> effective-Mg=1 masquerading as Mg=3.
    if Mg >= 3 and not dark:
        if V1 is not None and V1 < DEADOUTER_V:
            rejects.append("dead_outer")
        elif eps_g is not None and eps_g < max(2.0 * T, SUBTHERMAL_EPS):
            rejects.append("subthermal_outer")

    # h-mode: pole vs renormalizer. The bare gateway frame legitimately parks
    # the h-pair FAR outside the physical spectral window (|eta| >> U/2 + D)
    # carrying only the slope S = sumW^2/eta^2 (Z = 1/(1+S) verified to 4
    # digits on the released-cap R1 foot: S=0.024 -> Z=0.976). Detect it:
    # eta beyond 2x the spectral window, or pinned at the declared eta bound.
    renorm = bool(row.get("renorm_declared"))
    if not renorm and eta is not None:
        U = row.get("U")
        D_lat = (U / ud) if (U and ud) else None
        win = 2.0 * ((U or 0.0) / 2.0 + (D_lat or 0.0))
        at_bound = (row.get("eta_bound") is not None
                    and eta >= 0.98 * float(row["eta_bound"]))
        renorm = at_bound or (win > 0.0 and eta > win)

    # h-sector Sigma-weight (POLE MODE ONLY; the renormalizer representation
    # is exempt — its invariant is S, not the pole moment)
    ratio = row.get("w2_ratio")
    if ratio is not None and math.isfinite(ratio):
        inv["w2_ratio"] = float(ratio)
        if renorm:
            if row.get("S_renorm") is not None:
                inv["S_renorm"] = float(row["S_renorm"])
            elif row.get("sum_W2") is not None and eta:
                inv["S_renorm"] = float(row["sum_W2"]) / (eta * eta)
        elif ud is not None and ud >= H_W2_MIN_UD:
            if ratio > H_W2_REJECT:
                rejects.append(f"h_escape:{ratio:.2f}")
            elif ratio < H_W2_LOW_FLAG:
                flags.append(f"w2_low:{ratio:.2f}")

    # free-state hop (deep coupling only): a gated exact solution whose Z/D
    # snap back to free-impurity values is the free near-optimum, not a metal.
    if ut is not None and ut > FREEHOP_UT and not dark:
        if (Z is not None and Z >= FREEHOP_Z) or (D is not None and D >= FREEHOP_D):
            rejects.append("free_hop")

    if row.get("bound_pins"):
        flags.append("bound_pin:" + ",".join(map(str, row["bound_pins"])))

    # branch label: 2-D rule with an explicit corridor (the weak-metal corridor
    # near T* sits at V0~0.04, eta~0.07; the insulator attractor is fuzzy below
    # thermal resolution, V0 up to ~0.02 / eta up to ~0.04 at identical docc/F).
    if V0 is None or eta is None:
        branch = "metal" if (Z is not None and Z >= Z_COLLAPSED) else "unknown"
    elif V0 < BRANCH_V0_INS and eta < BRANCH_ETA_INS:
        branch = "insulator"
    elif V0 >= BRANCH_V0_INS and eta >= BRANCH_ETA_INS:
        branch = "metal"
    else:
        branch = "corridor"
        flags.append("corridor")

    hmode = "renormalizer" if renorm else "pole"
    return dict(branch_label=branch, hmode=hmode, rejects=rejects, flags=flags,
                invariants=inv)


# ---------------------------------------------------------------------------
# Branch continuation trims (finding 18)
# ---------------------------------------------------------------------------
def metal_prefix(rows, tol=METAL_PREFIX_TOL):
    """Maximal monotone non-increasing prefix of the U-ascending metal ladder
    (running-min rule; a per-step jump test misses the ~1e-3/step creep onto
    the h-escape family). Stops after the first collapsed point (Z<0.02) or at
    the first row with rejects."""
    out, rmin = [], None
    for r in rows:
        z = r.get("Z")
        if z is None or classify(r)["rejects"]:
            break
        if rmin is not None and z > rmin + tol:
            break
        rmin = z if rmin is None else min(rmin, z)
        out.append(r)
        if z < Z_COLLAPSED:
            break
    return out


def insulator_cut(rows):
    """Insulator branch from the U-descending ladder: walking DOWN in U, cut at
    the revert (Z > 0.02) or at the first row with rejects. Returns rows in
    ascending U."""
    out = []
    for r in sorted(rows, key=lambda r: -(r.get("U_over_t") or 0.0)):
        z = r.get("Z")
        if z is None or z > Z_COLLAPSED or classify(r)["rejects"]:
            break
        out.append(r)
    return sorted(out, key=lambda r: r.get("U_over_t") or 0.0)


# ---------------------------------------------------------------------------
# Free-energy selection (LAST, and only among gated + rejection-free rows)
# ---------------------------------------------------------------------------
def fe_select(cands, acceptance):
    """-> (winner, dF, bookkeeping). Winner = min F among gated, rejection-free
    candidates; dF = F(runner-up distinct branch) - F(winner) (nan if no second
    branch). Bookkeeping records what was excluded and why -- the spinodal /
    coexistence audit trail."""
    audit = []
    ok = []
    for c in cands:
        cls = classify(c)
        g = gate(c, acceptance)
        audit.append(dict(branch=cls["branch_label"], gated=bool(g),
                          rejects=list(cls["rejects"]), F=c.get("F")))
        if g and not cls["rejects"] and c.get("F") is not None and math.isfinite(c["F"]):
            ok.append((c, cls))
    book = dict(n_in=len(cands), n_ok=len(ok), audit=audit)
    if not ok:
        return None, float("nan"), book
    ok.sort(key=lambda t: t[0]["F"])
    winner, wcls = ok[0]
    dF = float("nan")
    for c, cls in ok[1:]:
        if cls["branch_label"] != wcls["branch_label"]:
            dF = float(c["F"] - winner["F"])
            break
    book["winner_branch"] = wcls["branch_label"]
    book["branches_present"] = sorted({cls["branch_label"] for _, cls in ok})
    return winner, dF, book


def omega_crossing(U, dF):
    """First-order line locator: linear-interpolated zero of dF(U) =
    F_metal - F_insulator over coexisting points. Returns U* or None."""
    U = np.asarray(U, dtype=float)
    dF = np.asarray(dF, dtype=float)
    m = np.isfinite(U) & np.isfinite(dF)
    U, dF = U[m], dF[m]
    for a, b, da, db in zip(U, U[1:], dF, dF[1:]):
        if da == 0.0:
            return float(a)
        if np.sign(da) != np.sign(db):
            return float(a - da * (b - a) / (db - da))
    return None


# ---------------------------------------------------------------------------
# Row adapters
# ---------------------------------------------------------------------------
def _f(v):
    try:
        x = float(v)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def _vec(v):
    """Parse a runner-CSV vector cell ('[0.1 0.2]', '0.1;0.2', scalar, ...)."""
    if v is None:
        return []
    if isinstance(v, (list, tuple, np.ndarray)):
        return [float(x) for x in v]
    s = str(v).strip()
    if not s:
        return []
    try:
        out = ast.literal_eval(s)
        if isinstance(out, (list, tuple)):
            return [float(x) for x in out]
        return [float(out)]
    except (ValueError, SyntaxError):
        return [float(x) for x in s.replace("[", " ").replace("]", " ")
                .replace(",", " ").replace(";", " ").split()]


def _split_central_outer(eps, V):
    """(V0, V1_outer, eps_outer) from bath vectors: V0 = weight of the channel
    nearest eps=0, V1_outer = mean |V| of the rest (None when Mg=1)."""
    if not V:
        return None, None, None
    if len(V) == 1:
        return abs(V[0]), None, None
    if eps and len(eps) == len(V):
        i0 = int(np.argmin(np.abs(eps)))
    else:
        i0 = int(np.argmin(np.abs(V)))  # fallback: smallest weight = central
    outer = [abs(v) for j, v in enumerate(V) if j != i0]
    eouter = [abs(e) for j, e in enumerate(eps or []) if j != i0]
    return abs(V[i0]), float(np.mean(outer)), (float(np.mean(eouter)) if eouter else None)


def normalize_runner_row(row, D_scale=None, eta_bound=None):
    """run_bonding_systematic summary-CSV row -> canonical dict.
    D_scale: half-bandwidth in code units (Bethe t=0.5 -> 1.0; square 4t).
    Defaults from the row's lattice/t when omitted.
    eta_bound: the run's --pole-E bound, for at-bound renormalizer detection."""
    t = _f(row.get("t")) or 0.5
    lat = (row.get("lattice") or "square").strip().lower()
    if D_scale is None:
        D_scale = 2.0 * t if lat == "bethe" else 4.0 * t
    U = _f(row.get("U"))
    eps1 = _vec(row.get("eps1"))
    V1v = _vec(row.get("V1"))
    V0, V1_outer, eps_outer = _split_central_outer(eps1, V1v)
    ratio = _f(row.get("sum_W2_over_U2_over_4"))
    if ratio is None:
        sw2, u24 = _f(row.get("sum_W2_lattice")), _f(row.get("U2_over_4"))
        ratio = (sw2 / u24) if (sw2 is not None and u24) else None
    return dict(
        U=U,
        U_over_t=_f(row.get("U_over_t")) or (U / t if U is not None else None),
        U_over_D=(U / D_scale) if U is not None else None,
        T=_f(row.get("T")),
        maxr=_f(row.get("resmax")),
        resnorm=_f(row.get("resnorm")),
        Z=_f(row.get("Z_pole")),
        D=_f(row.get("D_imp1")) or _f(row.get("D_ncs")),
        V0=V0,
        V1_outer=V1_outer,
        eps_g=eps_outer,
        w2_ratio=ratio,
        eta_min=_f(row.get("eta_min_abs")),
        F=_f(row.get("Omega_total")),
        Mg=int(_f(row.get("Mg")) or 1),
        sum_V2=_f(row.get("sum_V2_imp1")),
        M2=(D_scale / 2.0) ** 2,  # (D/2)^2 on both lattices at half filling
        sum_W2=_f(row.get("sum_W2_lattice")),
        eta_bound=eta_bound,
        renorm_declared=False,
        bound_pins=[],
        dark_bath_src=row.get("dark_bath"),
        branch_label_src=row.get("branch_label"),
    )


def normalize_protocol_row(x, U, T, maxr, F=None, docc=None, Mg=3,
                           renorm_declared=False, S_renorm=None, D_scale=1.0):
    """Prof-frame 5-param row (x = V0, V1, eps_g, W, eta; Bethe D=1) ->
    canonical dict. w2_ratio = 2W^2/(U^2/4) (PH pair)."""
    V0, V1, eps_g, W, eta = [float(v) for v in x]
    t = D_scale / 2.0
    return dict(
        U=float(U), U_over_t=float(U) / t, U_over_D=float(U) / D_scale,
        T=float(T), maxr=float(maxr), resnorm=None,
        Z=None, D=docc, V0=V0, V1_outer=V1, eps_g=eps_g,
        w2_ratio=2.0 * W * W / (U * U / 4.0),
        eta_min=abs(eta), F=F, Mg=Mg,
        renorm_declared=bool(renorm_declared), S_renorm=S_renorm,
        bound_pins=[],
    )
