#!/usr/bin/env python3
"""Acceptance tests for the lossless v2 Stage-3 scan matrix (point 10).

Proves: every v2 row carries the complete native vector + full parameter arrays;
all seven grids have exact registered key coverage; every key has >=1 converged
branch; all square cells share one continuum discretization; raw->canonical row
conservation is exact; the tracked deliverable contains all solution data; and
the exact-conversion machine-precision + no-auto-selected invariants hold.

Reads the TRACKED raw_campaign mirror if present (else the run namespace).
Runnable: .venv-numba/bin/python3 tests/test_stage3_v2.py  |  pytest tests/test_stage3_v2.py
"""
from __future__ import annotations

import glob
import json
import math
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")
RAW = os.path.join(OUT, "raw_campaign")
RUNS = os.path.join(_ROOT, "results/runs/20260717_scan_matrix_v2")
CELLS = ["bethe_mg1_bare", "bethe_mg1_Rnative", "bethe_mg3_Rnative",
         "square_mg1_bare", "square_mg1_Rnative", "square_mg3_bare", "square_mg3_Rnative"]
# physical residual-floor gate (see build_stage3_v2.PHYSICAL_GATE): the symmetric
# warm-continuation metals floor at ~1e-3 at warm T + high U/D (D01 note).
CONV_GATE = 3e-3
_CACHE = {}


def _src():
    if glob.glob(os.path.join(RAW, "*", "T*.jsonl")):
        return RAW
    arc = os.path.join(OUT, "raw_campaign.tar.gz")   # clean checkout: extract archive
    if os.path.exists(arc):
        import tarfile
        with tarfile.open(arc) as tf:
            tf.extractall(OUT)
        if glob.glob(os.path.join(RAW, "*", "T*.jsonl")):
            return RAW
    return RUNS


def _grid(lattice):
    import numpy as np
    if lattice == "bethe":
        U = np.unique(np.round(np.concatenate([np.arange(0.5, 4.0 + 1e-9, 0.1),
                                               np.arange(2.0, 3.6 + 1e-9, 0.05)]), 4))
        T = [0.001, 0.002, 0.003, 0.004, 0.005, 0.0065, 0.008, 0.01, 0.015, 0.02,
             0.025, 0.03, 0.05, 0.07, 0.1, 0.15, 0.2]
    else:
        U = np.unique(np.round(np.concatenate([np.arange(0.5, 3.2 + 1e-9, 0.1),
                                               np.arange(2.0, 3.2 + 1e-9, 0.05)]), 4))
        T = [0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.008, 0.01, 0.015, 0.02]
    return set((round(float(u), 4), round(float(t), 6)) for t in T for u in U)


def _recs(cell):
    if cell not in _CACHE:
        rs = []
        for f in sorted(glob.glob(os.path.join(_src(), cell, "T*.jsonl"))):
            with open(f) as fh:
                rs += [json.loads(l) for l in fh if l.strip()]
        _CACHE[cell] = rs
    return _CACHE[cell]


def _native(cell):
    return [r for r in _recs(cell) if r["evidence_type"] in
            ("bare_native", "R_native_continuation")]


def _lat(cell):
    return "bethe" if cell.startswith("bethe") else "square"


def _all_present():
    from collections import defaultdict
    n = {"bethe": 17, "square": 10}
    return all(len(glob.glob(os.path.join(_src(), c, "T*.jsonl"))) == n[_lat(c)] for c in CELLS)


# --------------------------------------------------------------------------
def test_01_every_row_lossless():
    for cell in CELLS:
        for r in _recs(cell):
            if r.get("solver_route") == "solver_failed":
                continue
            assert r.get("x_sol") is not None, f"{cell}: missing x_sol"
            h = r.get("bare_h_sectors")
            assert h and all(len(h[k]) == 2 for k in
                             ("eta_lattice", "W_lattice", "eta_gateway", "W_gateway")), \
                f"{cell}: incomplete bare h arrays"
            c = r.get("canonical_h_sectors")
            assert c and len(c["lambda_lattice"]) == 3 and len(c["R_lattice"]) == 3 \
                and len(c["lambda_gateway"]) == 3, f"{cell}: canonical arrays not 3-mode"
            g = r.get("g_sector")
            assert g and "eps_g" in g and "V_g" in g, f"{cell}: missing g arrays"
            assert r.get("residual", {}).get("vector") is not None, f"{cell}: missing residual vector"
            assert r.get("optimizer") is not None, f"{cell}: missing optimizer block"


def test_02_exact_registered_key_coverage():
    for cell in CELLS:
        keys = set((round(r["U_over_D"], 4), round(r["T_over_D"], 6)) for r in _native(cell))
        grid = _grid(_lat(cell))
        assert keys == grid, (f"{cell}: attempted keys != registered grid "
                              f"(missing {len(grid - keys)}, extra {len(keys - grid)})")


def test_03_every_key_has_a_converged_branch():
    for cell in CELLS:
        by = {}
        for r in _native(cell):
            k = (round(r["U_over_D"], 4), round(r["T_over_D"], 6))
            rn = (r.get("residual") or {}).get("total")
            ok = (rn is not None and rn <= CONV_GATE
                  and (r.get("observables") or {}).get("basin") != "dark")
            by[k] = by.get(k, False) or ok
        bad = [k for k, v in by.items() if not v]
        assert not bad, f"{cell}: {len(bad)} keys with no converged branch (e.g. {bad[:3]})"


def test_04_square_cells_same_continuum_discretization():
    nq = set()
    for cell in CELLS:
        if not cell.startswith("square"):
            continue
        for r in _recs(cell):
            assert r["lattice_quadrature"] == "continuum_elliptic_dos", f"{cell}: not continuum"
            nq.add(r.get("n_eps_dos"))
    assert len(nq) == 1, f"square cells use mixed n_eps: {nq}"


def test_05_raw_to_canonical_conservation():
    for cell in CELLS:
        if "bare" not in cell:
            continue
        bn = [r for r in _recs(cell) if r["evidence_type"] == "bare_native"]
        cv = [r for r in _recs(cell) if r["evidence_type"] == "R_converted_from_bare"]
        ro = [r for r in _recs(cell) if r["evidence_type"] == "R_reoptimized_from_bare"]
        assert len(bn) == len(cv) == len(ro), \
            f"{cell}: 1:1:1 bare/converted/reopt broken ({len(bn)}/{len(cv)}/{len(ro)})"
        # every converted/reopt has a bare parent
        bids = set(r["attempt_id"] for r in bn)
        for r in cv + ro:
            assert r["parent_attempt_id"] in bids, f"{cell}: orphan R record"


def test_06_tracked_deliverable_has_all_solution_data():
    # the aggregate lossless dataset + the tracked raw mirror both exist
    assert os.path.exists(os.path.join(OUT, "stage3_attempts.jsonl"))
    # raw_campaign must be TRACKED (present under the deliverable), not only runs/
    assert glob.glob(os.path.join(RAW, "*", "T*.jsonl")), \
        "raw_campaign/ (tracked) missing -- canonical data would live only in gitignored runs/"


def test_07_exact_conversion_machine_precision():
    for cell in CELLS:
        if "bare" not in cell:
            continue
        bare = {r["attempt_id"]: r for r in _recs(cell) if r["evidence_type"] == "bare_native"}
        for r in _recs(cell):
            if r["evidence_type"] != "R_converted_from_bare":
                continue
            b = bare.get(r["parent_attempt_id"])
            if not b or not r.get("observables") or not b.get("observables"):
                continue
            zc, zb = r["observables"].get("Z_pole"), b["observables"].get("Z_pole")
            if zc is not None and zb is not None:
                assert abs(zc - zb) < 1e-9, f"{cell}: exact conversion dZ={abs(zc-zb):.1e} not machine"


def test_08_never_auto_selected():
    for cell in CELLS:
        for r in _recs(cell):
            assert (r.get("classification") or {}).get("selected") is None, \
                f"{cell}: a row is auto-selected"


def test_09_three_evidence_types_plus_native():
    from collections import Counter
    ev = Counter()
    for cell in CELLS:
        ev.update(r["evidence_type"] for r in _recs(cell))
    for e in ("bare_native", "R_converted_from_bare", "R_reoptimized_from_bare",
              "R_native_continuation"):
        assert ev[e] > 0, f"missing evidence type {e}"


def _run_all():
    tests = sorted((n, f) for n, f in globals().items()
                   if n.startswith("test_") and callable(f))
    if not _all_present():
        print("NOTE: v2 campaign not fully present yet; running on partial data "
              "(coverage tests may fail until complete).")
    npass, fails = 0, []
    for name, fn in tests:
        try:
            fn(); print(f"  PASS  {name}"); npass += 1
        except AssertionError as e:
            print(f"  FAIL  {name}: {e}"); fails.append(name)
        except Exception as e:
            print(f"  ERROR {name}: {type(e).__name__}: {e}"); fails.append(name)
    print(f"\n{npass}/{len(tests)} v2 acceptance checks pass")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(_run_all())
