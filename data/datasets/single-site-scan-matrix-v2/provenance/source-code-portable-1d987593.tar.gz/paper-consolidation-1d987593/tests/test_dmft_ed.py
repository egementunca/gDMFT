#!/usr/bin/env python3
"""Unit tests for the finite-pole DMFT-ED impurity solver (LLK validation item 1).

Exercises ONLY the exact-diagonalization building blocks of
scripts/dmft_ed_bench.py -- the impurity Hamiltonian, the Lehmann Green
function, the Dyson self-energy, causality, spectral sum rules, and
particle-hole symmetry -- at FIXED small bath configurations. It calls no
bath-fit optimizer (least_squares) and runs no DMFT self-consistency loop, so
it is pure linear algebra (np.linalg.eigh on <=36-dim sectors), not a
DMFT-ED production calculation.

Runnable:
  .venv-numba/bin/python3 tests/test_dmft_ed.py
  pytest tests/test_dmft_ed.py
"""
from __future__ import annotations

import importlib.util
import os
import sys

import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_SCRIPT = os.path.join(_ROOT, "scripts", "dmft_ed_bench.py")
_spec = importlib.util.spec_from_file_location("dmft_ed_bench", _SCRIPT)
ED = importlib.util.module_from_spec(_spec)
sys.path.insert(0, os.path.join(_ROOT, "scripts"))
_spec.loader.exec_module(ED)


def _h1(eps, V, U):
    """(1+Nb) one-body cluster matrix: impurity level -U/2, symmetric hyb."""
    eps = np.asarray(eps, float)
    V = np.asarray(V, float)
    nb = eps.size
    h = np.zeros((1 + nb, 1 + nb))
    h[0, 0] = -U / 2.0
    for l in range(nb):
        h[1 + l, 1 + l] = eps[l]
        h[0, 1 + l] = h[1 + l, 0] = V[l]
    return h


# PH-symmetric baths (Nb odd: pole at 0 + mirrored pairs)
BATH_NB1 = (np.array([0.0]), np.array([0.5]))
BATH_NB3 = (np.array([0.0, 0.6, -0.6]), np.array([0.4, 0.3, 0.3]))


def test_hamiltonian_hermitian_real_symmetric():
    for (eps, V), U in ((BATH_NB1, 2.0), (BATH_NB3, 3.0)):
        ns = 1 + eps.size
        ed = ED.SectorED(ns)
        h1 = _h1(eps, V, U)
        for nu in range(ns + 1):
            for nd in range(ns + 1):
                H = ed.sector_H(h1, U, nu, nd)
                assert np.allclose(H, H.T, atol=1e-12), (U, nu, nd)


def test_green_causality_imag_nonpositive():
    for (eps, V), U in ((BATH_NB1, 2.0), (BATH_NB3, 3.0)):
        ed = ED.SectorED(1 + eps.size)
        _, _, _, G = ed.solve(_h1(eps, V, U), U)
        # Im G(iwn) <= 0 for wn > 0 (Lehmann weights are non-negative)
        assert np.all(G.imag <= 1e-10), G.imag.max()


def test_spectral_sum_rule():
    # z G(z) -> sum of all pole weights = <{d,d^dagger}> = 1 as |z|->inf
    for (eps, V), U in ((BATH_NB1, 2.0), (BATH_NB3, 3.0)):
        ed = ED.SectorED(1 + eps.size)
        z = np.array([1e6j])
        G = ed.green_z(_h1(eps, V, U), U, z)
        assert abs((z * G)[0].real - 1.0) < 1e-4, (z * G)[0]


def test_particle_hole_symmetry_reG_zero():
    # at half filling (eps_imp=-U/2, PH-symmetric bath) the impurity G(iwn)
    # is purely imaginary: Re G = 0.
    for (eps, V), U in ((BATH_NB1, 2.0), (BATH_NB3, 3.0)):
        ed = ED.SectorED(1 + eps.size)
        _, docc, n_imp, G = ed.solve(_h1(eps, V, U), U)
        assert np.all(np.abs(G.real) < 1e-9), np.abs(G.real).max()
        assert abs(n_imp - 1.0) < 1e-9, n_imp        # <n0up+n0dn> = 1 at PH
        assert 0.0 <= docc <= 0.25 + 1e-9, docc


def test_dyson_self_energy_hartree_and_causal():
    # Non-interacting reference G0^{-1} = iwn - eps_imp - Delta with the impurity
    # level eps_imp = -U/2, so Sigma_full = iwn + U/2 - Delta(iwn) - 1/G.
    # PH => Re Sigma_full = U/2 (Hartree) exactly, Im Sigma_full <= 0 (causal).
    for (eps, V), U in ((BATH_NB1, 2.0), (BATH_NB3, 3.0)):
        ed = ED.SectorED(1 + eps.size)
        h1 = _h1(eps, V, U)
        _, _, _, G = ed.solve(h1, U)
        wn = ED.WN
        delta = np.zeros_like(G)
        for l in range(eps.size):
            delta += V[l] ** 2 / (1j * wn - eps[l])
        sig_full = 1j * wn + U / 2.0 - delta - 1.0 / G
        assert np.allclose(sig_full.real, U / 2.0, atol=1e-6), \
            (U, float(np.abs(sig_full.real - U / 2.0).max()))
        assert np.all(sig_full.imag <= 1e-8), float(sig_full.imag.max())


def test_u_zero_noninteracting_limit():
    # U=0: docc = <n_up><n_dn> = 0.25, Sigma' = 0 (Im Sigma flat at 0).
    eps, V = BATH_NB3
    ed = ED.SectorED(1 + eps.size)
    _, docc, n_imp, G = ed.solve(_h1(eps, V, 0.0), 0.0)
    assert abs(docc - 0.25) < 1e-6, docc
    assert abs(n_imp - 1.0) < 1e-9, n_imp


# --------------------------------------------------------------------------
# LLK pipeline tests (scripts/dmft_ed_llk.py): CG fit, chi^2, Z, lattice spectrum
# --------------------------------------------------------------------------
_llkspec = importlib.util.spec_from_file_location(
    "dmft_ed_llk", os.path.join(_ROOT, "scripts", "dmft_ed_llk.py"))
LLK = importlib.util.module_from_spec(_llkspec)
_llkspec.loader.exec_module(LLK)


def test_cg_bathfit_matches_lm():
    # CG (paper) and LM (prototype) reach the same bath minimum at fixed Delta.
    for nb, xt in ((1, np.array([0.5])), (3, np.array([0.5, 0.6, 0.3]))):
        dt = LLK.ED.delta_of_sym(xt, nb, LLK.WN)
        _, chi_cg, _, _ = LLK.fit_bath(dt, nb, route="cg")
        _, chi_lm, _, _ = LLK.fit_bath(dt, nb, route="lm")
        assert chi_cg < 1e-6 and chi_lm < 1e-6, (nb, chi_cg, chi_lm)


def test_normalized_chi2_is_twice_scipy_cost():
    # the reported chi2_normalized must be 2x scipy's half-cost (never conflated).
    xt = np.array([0.4, 0.7, 0.25])
    dt = LLK.ED.delta_of_sym(np.array([0.5, 0.6, 0.3]), 3, LLK.WN) + 0.01
    _, chi, cost_half, _ = LLK.fit_bath(dt, 3, x0=xt, route="cg")
    assert abs(chi - 2.0 * cost_half) < 1e-12, (chi, cost_half)


def test_z_extrapolation_converges_at_U0():
    # U=0: Sigma'=0 so Z=1 exactly; the extrapolator must converge and give 1.
    r, _ = LLK.solve(0.0, 3, None, route="cg")
    assert abs(r["Z"] - 1.0) < 1e-6 and r["Z_estimator_converged"] == 1, r["Z"]


def test_dmft_fixed_point_and_energy_at_U0():
    # fixed point converged (dDelta small) and E_kin tail estimator exact at U=0.
    r, _ = LLK.solve(0.0, 3, None, route="cg")
    assert r["fixed_point_converged"] == 1, r["dDelta"]
    assert abs(r["ekin"] + 4.0 / (3.0 * np.pi)) < 3e-3, r["ekin"]
    assert abs(r["docc"] - 0.25) < 1e-6, r["docc"]


def test_lattice_spectrum_differs_from_impurity_cluster():
    # A_latt (from Sigma + lattice DOS) must NOT equal A_imp (impurity cluster),
    # and A_latt must be causal (A>=0) and carry O(1) weight.
    eps, V = np.array([0.0, 0.6, -0.6]), np.array([0.4, 0.3, 0.3])
    ed = LLK.ED.SectorED(4)
    h1 = np.zeros((4, 4)); h1[0, 0] = -3.0 / 2.0
    for l in range(3):
        h1[1 + l, 1 + l] = eps[l]; h1[0, 1 + l] = h1[1 + l, 0] = V[l]
    wgrid = np.linspace(-4, 4, 401)
    sp = LLK.lattice_spectrum(ed, h1, 3.0, 3, np.array([0.4, 0.6, 0.3]), wgrid)
    assert np.max(np.abs(sp["A_latt"] - sp["A_imp"])) > 1e-3, "lattice == impurity"
    assert np.all(sp["A_latt"] >= -1e-9), "lattice A(w) not causal"
    integ = float(np.sum(sp["A_latt"]) * (wgrid[1] - wgrid[0]))
    assert 0.5 < integ < 1.5, f"lattice A integral {integ}"


def _run_all():
    tests = sorted((n, f) for n, f in globals().items()
                   if n.startswith("test_") and callable(f))
    fails = []
    for name, fn in tests:
        try:
            fn(); print(f"  PASS  {name}")
        except AssertionError as e:
            print(f"  FAIL  {name}: {e}"); fails.append(name)
        except Exception as e:
            print(f"  ERROR {name}: {type(e).__name__}: {e}"); fails.append(name)
    print(f"\n{len(tests) - len(fails)}/{len(tests)} ED unit checks pass")
    return 1 if fails else 0


if __name__ == "__main__":
    sys.exit(_run_all())
