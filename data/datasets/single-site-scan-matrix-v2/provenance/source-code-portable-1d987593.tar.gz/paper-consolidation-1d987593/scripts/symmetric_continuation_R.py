#!/usr/bin/env python3
"""R-GAUGE symmetric continuation — the same Mg=3 physics as
scripts/symmetric_continuation.py, fit in canonical (lambda, R) coordinates.

Purpose (paper scans 2026-07-15): certify gauge equivalence ON THE PAPER
GRIDS, at scan scale. The bare route fits x = (V0, V1, eps_g, W, eta); here
the h-sector is reparametrized by its canonical spectrum

    x_R = (V0, V1, eps_g, lam, Rf)

with ghost modes at +/-lam carrying equal d-overlaps Rf and the
quasiparticle mode closing the books at lam_qp = 0 (PH), R_qp =
sqrt(1 - 2 Rf^2), i.e. Z = R_qp^2 = 1 - 2 Rf^2 is a BOUNDED coordinate
(the R-gauge compactification of the W-runaway; D01 Sec. 5.4). The map
(lam, Rf) -> (eta, W) is BHFM2.core.reparam_R.hsector_to_bare (arrowhead
inverse), and the residual is the identical landscape_map.residual_ph — so
stationary points can only be the bare gauge's stationary points, which is
exactly what makes the per-point comparison a gauge certification.

Scope notes (documented D01 properties, not bugs):
  - the R-gauge compactifies only the h-sector; the g-sector (V0, V1, eps_g)
    is bare in both routes;
  - the map is singular at Z = 0; reparam_R.R_FLOOR keeps Z >= 1e-10, so
    deep-insulator rows may sit at the floor where the bare gauge reports
    Z ~ 0 exactly.

Outputs: results/runs/20260715_paper_scans/mg3_bethe_R/
    symmetricR_bethe_T<T>.csv   (bare-schema columns + lam, Rf, Z_R)

Usage:
  .venv-numba/bin/python3 scripts/symmetric_continuation_R.py --rows 0.005,0.025,0.1
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
import time

import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (_ROOT, os.path.join(_ROOT, "scripts")):
    if p not in sys.path:
        sys.path.insert(0, p)

from scipy.optimize import least_squares  # noqa: E402
from BHFM2.core.solve_min import SParMin  # noqa: E402
from BHFM2.core import canonical_gauge as cg  # noqa: E402
from BHFM2.core.reparam_R import hsector_to_bare, R_FLOOR  # noqa: E402
from BHFM2.core.solve_min import ModelParamsMin  # noqa: E402
import landscape_map as L  # noqa: E402
import symmetric_continuation as SC  # noqa: E402
import paper_scan_mg3 as PS  # noqa: E402

OUT = os.path.join(_ROOT, "results/runs/20260715_paper_scans/mg3_bethe_R")
LAT, NK = "bethe", 256
Z0 = np.zeros(0)

# x_R = [V0, V1, eps_g, lam, Rf]
RF_HI = float(np.sqrt((1.0 - R_FLOOR ** 2) / 2.0))
LO_R = np.array([0.0, 0.0, 1e-6, 1e-4, R_FLOOR])
HI_R = np.array([5.0, 5.0, 12.0, 18.0, RF_HI])


def sym_spar_R(xR, mu):
    """Symmetric Mg=3 / Mh=2 config from R-gauge coords (PH, ebar = 0)."""
    V0, V1g, eps_g, lam, Rf = xR
    eta, W = hsector_to_bare(np.array([lam, -lam]), np.array([Rf, Rf]), 0.0)
    return SParMin(eta=eta, W=W, eta_b=Z0, B_h=Z0,
                   eps1=np.array([0.0, eps_g, -eps_g]),
                   V1=np.array([V0, V1g, V1g]),
                   eta1=eta.copy(), W1=W.copy(),
                   eps2=Z0, V2=Z0, eta2=Z0, W2=Z0, eta_b2=Z0, B_h2=Z0,
                   eps_b=Z0, B_g=Z0, mu=float(mu))


def seed_R_from_bare5(x_bare):
    """(V0, V1, eps_g, W, eta) -> (V0, V1, eps_g, lam, Rf).

    QP convention here is the lam ~ 0 mode (PH), NOT the max-weight mode:
    in the insulator the weight lives on the +/-lam ghosts and the lam = 0
    mode goes empty, so reparam_R.hsector_from_bare's max-weight masking
    would misassign it.
    """
    V0, V1g, eps_g, W, eta = x_bare
    lam3, R3 = cg.forward(0.0, np.array([eta, -eta]), np.array([W, W]))
    qp = int(np.argmin(np.abs(lam3)))
    mask = np.ones(3, dtype=bool)
    mask[qp] = False
    lam_g, R_g = lam3[mask], np.abs(R3[mask])
    lam = float(np.mean(np.abs(lam_g)))
    Rf = float(np.clip(np.mean(R_g), R_FLOOR, RF_HI))
    return np.array([V0, V1g, eps_g, max(lam, 1e-4), Rf])


def solve_sym_R(mp, xR0, mu, max_nfev=3000):
    xR0 = np.clip(xR0, LO_R + 1e-9, HI_R - 1e-9)
    sol = least_squares(lambda x: L.residual_ph(sym_spar_R(x, mu), mp, 3), xR0,
                        method="trf", bounds=(LO_R, HI_R),
                        ftol=1e-14, xtol=1e-14, max_nfev=max_nfev)
    return sol.x, float(np.linalg.norm(sol.fun))


def continue_branch_R(uot_grid, xR_seed, label, T, warm_gate):
    rows = []
    xR = np.array(xR_seed, float)
    for uot in uot_grid:
        U = uot * 0.5
        mu = U / 2.0
        mp = ModelParamsMin(t=0.5, eps_d=0.0, U=U, z=4.0, filling_target=1.0,
                            beta=1.0 / T, Nk=NK, lattice=LAT,
                            n_moments=L.N_MOMENTS, Sigma_inf=U / 2.0)
        xsol, r = solve_sym_R(mp, xR, mu)
        p = sym_spar_R(xsol, mu)
        d = L.diagnose(p, mp, 3)
        d["basin"] = L.basin_label(d)
        d.update(uot=float(uot), U=U, branch=label, resnorm=r, T=T,
                 V0=xsol[0], Vg=xsol[1], eps_g=xsol[2],
                 lam=xsol[3], Rf=xsol[4], Z_R=1.0 - 2.0 * xsol[4] ** 2,
                 W=float(p.W[0]), eta=float(p.eta[0]))
        rows.append(d)
        if r < warm_gate:
            xR = xsol
        print(f"  [R {label:10s} U/t={uot:5.2f}] ||r||={r:.1e} "
              f"Z={d['Z_pole']:.4f} Z_R={d['Z_R']:.4f} D={d['D']:.4f} "
              f"Om={d['Omega']:.4f} -> {d['basin']}", flush=True)
    return rows


def run_row(T):
    t0 = time.time()
    warm_gate = 1e-3 if T >= 0.02 else 1e-4
    up, win = PS.row_grid(T)
    ms = 2.0 * PS.MET_START_UD
    hi = [u for u in up if u >= ms - 1e-9]
    lo = [u for u in up if u < ms - 1e-9][::-1]
    print(f"=== R-gauge T/D={T:g}: {len(up)} U-points, window={win} ===",
          flush=True)
    met_seed = seed_R_from_bare5(SC.METAL_X0)
    metal = continue_branch_R(hi, met_seed, "metal-up", T, warm_gate)
    x_grow = np.array([metal[0][k] for k in ("V0", "Vg", "eps_g", "lam", "Rf")])
    metal += continue_branch_R(lo, x_grow, "metal-down", T, warm_gate)
    down = list(up[::-1])
    ins_seed_R = seed_R_from_bare5(SC.ins_seed(down[0] * 0.5))
    ins = continue_branch_R(down, ins_seed_R, "insul-down", T, warm_gate)
    rows = metal + ins
    os.makedirs(OUT, exist_ok=True)
    fn = os.path.join(OUT, f"symmetricR_{LAT}_T{T:g}.csv")
    with open(fn, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"R T/D={T:g}: wrote {os.path.basename(fn)} ({len(rows)} rows, "
          f"{time.time() - t0:.0f}s)", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", default="0.005,0.025,0.1")
    ap.add_argument("--probe", action="store_true")
    a = ap.parse_args()
    if a.probe:
        met_seed = seed_R_from_bare5(SC.METAL_X0)
        t0 = time.time()
        rows = continue_branch_R([4.0, 4.05, 4.1], met_seed, "probe", 0.005,
                                 1e-4)
        print(f"probe: {(time.time() - t0) / len(rows):.2f} s/point; "
              f"seed lam={met_seed[3]:.3f} Rf={met_seed[4]:.3f}")
        return
    for T in [float(x) for x in a.rows.split(",")]:
        run_row(T)


if __name__ == "__main__":
    main()
