#!/usr/bin/env python3
"""DMFT-ED finite-bath benchmark — the LLK protocol, implemented locally.

Reproduces the DMFT-ED column of Lee, Lanata, Kotliar PRB 107, L121104
(2023) Sec. II.B on the half-filled Bethe lattice (D = 1, semicircular),
so our ghost-DMFT can be compared to a conventional finite-pole DMFT at
MATCHED bath budgets (their N_b == our M_g):

  - Matsubara bath fit at fictitious beta = 200, N_wmax = 200 frequencies,
    weight 1/w_n for N_b = 1 and uniform for N_b > 1 (their stated choice),
    chi = sum_n w_n |Delta_fit(iw_n) - Delta_target(iw_n)|^2;
  - exact-diagonalization ground state of the (1 + N_b)-site Anderson
    cluster (dense sector ED; T = 0);
  - impurity Green's function by exact Lehmann sum (dense spectra of the
    N +/- 1 sectors — no Lanczos truncation for N_b <= 5);
  - Bethe self-consistency Delta = (D/2)^2 G_latt with the closed-form
    semicircular Hilbert transform;
  - observables in LLK conventions: docc = <n_up n_dn>, Ekin from the
    lattice Green's function Matsubara sum (exact 1/w^2 tail via
    polygamma), Etot = Ekin + U * docc, Z from the Sigma-slope at iw_0.

N_b = 7 is deliberately NOT in the scan: full-spectrum Lehmann in the
4900-dim sectors costs minutes/iteration; LLK's convergence statement
(all observables < 5% by N_b = 5) is testable without it.

Validation anchors:
  - U = 0: Ekin = -4/(3 pi) = -0.42441 (two spins, half-filled semicircle);
  - LLK Fig. 3 (U = 2.4): DMFT-ED docc/Etot/Ekin/Z vs N_b = 1, 3, 5;
  - CTQMC (beta = 200): docc = 0.0545, Etot = -0.0621.

Output: results/runs/20260715_paper_scans/dmft_ed/dmft_ed_Nb<Nb>.csv
  (columns: Nb, U_over_D, direction, Z, docc, ekin, etot, n_imp,
   fit_chi, dDelta, iters, converged, bath eps/V, wall)

Usage:
  .venv-numba/bin/python3 scripts/dmft_ed_bench.py --Nb 3
  .venv-numba/bin/python3 scripts/dmft_ed_bench.py --validate
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
import time
from itertools import combinations

import numpy as np
from scipy.optimize import least_squares
from scipy.special import polygamma

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
OUT = os.path.join(_ROOT, "results/runs/20260715_paper_scans/dmft_ed")

BETA = 200.0
NW = 200
WN = (2 * np.arange(NW) + 1) * np.pi / BETA
D_HALF = 1.0                       # half bandwidth

U_GRID = np.unique(np.round(np.concatenate([
    np.arange(0.0, 4.0 + 1e-9, 0.1),
    np.arange(2.0, 3.6 + 1e-9, 0.05),
]), 3))

MIX, TOL_D, ITMAX = 0.5, 1e-8, 200


# --------------------------------------------------------------------------
# dense sector ED of the (1 + Nb)-site Anderson cluster
# site 0 = impurity; per-spin one-body matrix h1(ns x ns); U on site 0
# --------------------------------------------------------------------------
class SectorED:
    def __init__(self, ns):
        self.ns = ns
        # per-spin occupation bases for each particle number
        self.basis = {n: list(combinations(range(ns), n))
                      for n in range(ns + 1)}
        self.index = {n: {occ: i for i, occ in enumerate(b)}
                      for n, b in self.basis.items()}

    def _h_spin(self, h1, n):
        """Many-body matrix of a one-body operator in the n-particle
        single-spin sector."""
        b = self.basis[n]
        idx = self.index[n]
        dim = len(b)
        H = np.zeros((dim, dim))
        for i, occ in enumerate(b):
            s = set(occ)
            # diagonal
            H[i, i] = sum(h1[p, p] for p in occ)
            # hops p -> q
            for p in occ:
                for q in range(self.ns):
                    if q in s or h1[q, p] == 0.0:
                        continue
                    new = tuple(sorted(s - {p} | {q}))
                    # fermionic sign: occupied modes strictly between p and q
                    lo, hi = (p, q) if p < q else (q, p)
                    sgn = (-1) ** sum(1 for r in occ if lo < r < hi)
                    H[idx[new], i] += sgn * h1[q, p]
        return H

    def _docc_diag(self, nu, nd):
        """Diagonal of n0_up * n0_dn in the product basis."""
        bu, bd = self.basis[nu], self.basis[nd]
        du = np.array([1.0 if 0 in occ else 0.0 for occ in bu])
        dd = np.array([1.0 if 0 in occ else 0.0 for occ in bd])
        return np.kron(du, dd)

    def sector_H(self, h1, U, nu, nd):
        Hu = self._h_spin(h1, nu)
        Hd = self._h_spin(h1, nd)
        du, dd = len(self.basis[nu]), len(self.basis[nd])
        H = (np.kron(Hu, np.eye(dd)) + np.kron(np.eye(du), Hd)
             + U * np.diag(self._docc_diag(nu, nd)))
        return H

    def _dmat_up(self, nu, dagger):
        """Matrix of d0_up (or d0_up^dagger) between spin-up sectors."""
        n_from = nu
        n_to = nu + 1 if dagger else nu - 1
        bf, bt = self.basis[n_from], self.basis[n_to]
        M = np.zeros((len(bt), len(bf)))
        for i, occ in enumerate(bf):
            s = set(occ)
            if dagger:
                if 0 in s:
                    continue
                new = tuple(sorted(s | {0}))
                M[self.index[n_to][new], i] = 1.0   # site 0 first: sign +1
            else:
                if 0 not in s:
                    continue
                new = tuple(sorted(s - {0}))
                M[self.index[n_to][new], i] = 1.0
        return M

    def solve(self, h1, U):
        """Ground state across half-filling-adjacent sectors + exact G(iwn).

        Returns (E0, docc, n_imp, G(iwn) complex array)."""
        ns = self.ns
        cands = []
        for nu in (ns // 2, ns // 2 + ns % 2):
            for nd in {nu, ns - nu}:
                cands.append((nu, nd))
        # PH-symmetric problem: ground sector is (ns/2, ns/2) for even ns
        # (ns = 1 + Nb with Nb odd -> ns even). Keep a couple of neighbors
        # as a sanity check.
        cands = sorted(set(cands) | {(ns // 2, ns // 2)})
        best = None
        for nu, nd in cands:
            H = self.sector_H(h1, U, nu, nd)
            w, v = np.linalg.eigh(H)
            if best is None or w[0] < best[0]:
                best = (w[0], nu, nd, v[:, 0])
        E0, nu, nd, gs = best
        docc = float(gs @ (self._docc_diag(nu, nd) * gs))
        # n_imp (up + dn)
        bu, bd = self.basis[nu], self.basis[nd]
        nu_diag = np.kron(np.array([1.0 if 0 in o else 0.0 for o in bu]),
                          np.ones(len(bd)))
        nd_diag = np.kron(np.ones(len(bu)),
                          np.array([1.0 if 0 in o else 0.0 for o in bd]))
        n_imp = float(gs @ ((nu_diag + nd_diag) * gs))

        # G_up(iwn) by Lehmann: particle part in (nu+1, nd), hole in (nu-1, nd)
        G = np.zeros(NW, dtype=complex)
        for dagger in (True, False):
            n_to = nu + 1 if dagger else nu - 1
            if n_to < 0 or n_to > ns:
                continue
            Hp = self.sector_H(h1, U, n_to, nd)
            wp, vp = np.linalg.eigh(Hp)
            Md = self._dmat_up(nu, dagger)
            dud, dd_ = len(self.basis[n_to]), len(self.basis[nd])
            psi = (Md @ gs.reshape(len(self.basis[nu]), dd_)).reshape(-1)
            amps = vp.T @ psi
            w2 = np.abs(amps) ** 2
            dE = wp - E0
            if dagger:
                G += (w2[None, :] / (1j * WN[:, None] - dE[None, :])).sum(1)
            else:
                G += (w2[None, :] / (1j * WN[:, None] + dE[None, :])).sum(1)
        return E0, docc, n_imp, G

    def green_z(self, h1, U, zgrid):
        """Impurity G_up(z) on an arbitrary complex grid (real axis: z =
        omega + i delta) by the exact ED Lehmann sum — same spectra as
        solve(), evaluated at z instead of the Matsubara frequencies."""
        ns = self.ns
        cands = sorted({(ns // 2, ns // 2),
                        (ns // 2 + ns % 2, ns - (ns // 2 + ns % 2))})
        best = None
        for nu, nd in cands:
            w, v = np.linalg.eigh(self.sector_H(h1, U, nu, nd))
            if best is None or w[0] < best[0]:
                best = (w[0], nu, nd, v[:, 0])
        E0, nu, nd, gs = best
        z = np.asarray(zgrid, complex)
        G = np.zeros(z.size, dtype=complex)
        for dagger in (True, False):
            n_to = nu + 1 if dagger else nu - 1
            if n_to < 0 or n_to > ns:
                continue
            wp, vp = np.linalg.eigh(self.sector_H(h1, U, n_to, nd))
            dd_ = len(self.basis[nd])
            psi = (self._dmat_up(nu, dagger)
                   @ gs.reshape(len(self.basis[nu]), dd_)).reshape(-1)
            w2 = np.abs(vp.T @ psi) ** 2
            dE = wp - E0
            sign = -1.0 if dagger else 1.0
            G += (w2[None, :] / (z[:, None] + sign * dE[None, :])).sum(1)
        return G


# --------------------------------------------------------------------------
# Bethe pieces
# --------------------------------------------------------------------------
def g_bethe(zeta):
    """Semicircular Hilbert transform on the Matsubara axis:
    G = 2 (zeta - s) / D^2 with the branch Im(s) * Im(zeta) > 0, which gives
    Im G opposite to Im zeta and the 1/zeta large-frequency decay."""
    s = np.sqrt(zeta ** 2 - D_HALF ** 2)
    s = np.where(np.imag(s) * np.imag(zeta) >= 0, s, -s)
    return 2.0 * (zeta - s) / D_HALF ** 2


def bath_from_sym(xp, nb):
    """PH-symmetric bath from free params. Nb odd: one pole pinned at 0
    with coupling V0, plus (Nb-1)/2 mirrored pairs (+/-e_k, V_k).
    xp = [V0, e_1, V_1, e_2, V_2, ...]  (len == nb)."""
    npair = (nb - 1) // 2
    eps = np.zeros(nb)
    V = np.zeros(nb)
    V[0] = xp[0]
    for k in range(npair):
        e, v = xp[1 + 2 * k], xp[2 + 2 * k]
        eps[1 + 2 * k], eps[2 + 2 * k] = e, -e
        V[1 + 2 * k] = V[2 + 2 * k] = v
    return eps, V


def delta_of_sym(xp, nb, wn):
    eps, V = bath_from_sym(xp, nb)
    return (V[None, :] ** 2 / (1j * wn[:, None] - eps[None, :])).sum(1)


def fit_bath(delta_target, nb, x0=None):
    """PH-symmetric fit (exact at half filling; stabilizes the insulator
    against asymmetric junk minima). LLK weights: 1/w_n for Nb=1, uniform
    above."""
    w = 1.0 / WN if nb == 1 else np.ones(NW)
    sw = np.sqrt(w)

    def res(xp):
        d = delta_of_sym(xp, nb, WN) - delta_target
        return np.concatenate([sw * d.real, sw * d.imag])

    npair = (nb - 1) // 2
    seeds = []
    if x0 is not None:
        seeds.append(x0)
    v0 = np.sqrt(max(-delta_target[0].imag * WN[0], 0.01) / nb)
    seeds.append(np.concatenate(
        [[max(v0, 0.05)]] + [[0.4 + 0.5 * k, max(v0, 0.05)]
                             for k in range(npair)]))
    # atomic-like seed (weight pushed to the mirrored pair) for the insulator
    if npair:
        seeds.append(np.concatenate(
            [[0.01]] + [[0.5 + 0.5 * k, 0.3] for k in range(npair)]))
    best = None
    for s in seeds:
        try:
            sol = least_squares(res, s, method="lm", max_nfev=20000)
        except Exception:
            continue
        if best is None or sol.cost < best.cost:
            best = sol
    return best.x, float(best.cost)


def dmft_ed(U, nb, x0=None):
    """One DMFT-ED solve. Returns observables + fitted bath."""
    t0 = time.time()
    ed = SectorED(1 + nb)
    sig = np.zeros(NW, dtype=complex)       # PH-odd part Sigma' (Hartree off)
    x = x0
    dnorm, it = np.inf, 0
    delta = None
    mix = MIX
    hist = []
    for it in range(ITMAX):
        zeta = 1j * WN - sig
        gl = g_bethe(zeta)
        delta_t = (D_HALF / 2.0) ** 2 * gl
        delta = delta_t if delta is None else \
            (1 - mix) * delta + mix * delta_t
        x, chi = fit_bath(delta, nb, x)
        eps, V = bath_from_sym(x, nb)
        # cluster one-body matrix (site 0 = impurity at eps_d = -U/2;
        # Hartree carried explicitly so sig stays the PH-odd part)
        h1 = np.zeros((1 + nb, 1 + nb))
        h1[0, 0] = -U / 2.0
        for l in range(nb):
            h1[1 + l, 1 + l] = eps[l]
            h1[0, 1 + l] = h1[1 + l, 0] = V[l]
        E0, docc, n_imp, G = ed.solve(h1, U)
        # Sigma_full = iwn - eps_d - Delta_fit - 1/G ; Sigma' = Sigma_full - U/2
        sig_new = 1j * WN + U / 2.0 - delta_of_sym(x, nb, WN) - 1.0 / G - U / 2.0
        dnorm = float(np.max(np.abs(sig_new - sig)))
        sig = sig_new
        hist.append(dnorm)
        # oscillation guard: no net progress over 30 iterations -> damp
        if len(hist) >= 30 and hist[-1] > 0.5 * hist[-30] and mix > 0.05:
            mix *= 0.5
            hist = []
        if dnorm < TOL_D and it > 2:
            break
    # observables
    zeta = 1j * WN - sig
    gl = g_bethe(zeta)
    term = (zeta * gl - 1.0).real
    # tail: term ~ -C/wn^2; estimate C from the last 20 points
    C = float(np.mean(-term[-20:] * WN[-20:] ** 2))
    tail = -C * (BETA / (2 * np.pi)) ** 2 * float(polygamma(1, NW + 0.5))
    ekin = 2.0 * (2.0 / BETA) * (term.sum() + tail)
    etot = ekin + U * docc
    Z = 1.0 / (1.0 - sig[0].imag / WN[0])
    eps_f, V_f = bath_from_sym(x, nb)
    return dict(Z=float(Z), docc=float(docc), ekin=float(ekin),
                etot=float(etot), n_imp=float(n_imp), fit_chi=chi,
                dDelta=dnorm, iters=it, converged=int(dnorm < TOL_D),
                eps=";".join(f"{e:.6g}" for e in eps_f),
                V=";".join(f"{v:.6g}" for v in V_f),
                wall=round(time.time() - t0, 2)), x


def run_row(nb):
    rows = []
    for direction, grid in (("up", U_GRID), ("down", U_GRID[::-1])):
        x0 = None
        for U in grid:
            r, x0 = dmft_ed(float(U), nb, x0)
            rows.append(dict(Nb=nb, U_over_D=float(U), direction=direction,
                             **r))
            print(f"  [dmft-ed Nb={nb} {direction:4s} U/D={U:4.2f}] "
                  f"Z={r['Z']:.4f} D={r['docc']:.5f} Etot={r['etot']:.5f} "
                  f"({'ok' if r['converged'] else 'STALL'} it={r['iters']}, "
                  f"{r['wall']}s)", flush=True)
    os.makedirs(OUT, exist_ok=True)
    fn = os.path.join(OUT, f"dmft_ed_Nb{nb}.csv")
    with open(fn, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"dmft-ed Nb={nb}: wrote {os.path.basename(fn)} ({len(rows)} rows)",
          flush=True)


REP_U = {1: [0.5, 1.0, 2.0, 3.0, 3.4], 3: [0.5, 1.0, 1.5, 2.0, 2.5, 2.8,
                                            3.0, 3.2]}
SPEC_WMAX, SPEC_NW, SPEC_DELTA = 4.0, 401, 0.03


def spectral_row(nb):
    """Real-frequency A(w), Im Sigma'(w), Im Delta(w) for the converged
    DMFT-ED solution at representative U (up-swept warm chain), via the exact
    ED impurity Green's function (green_z Lehmann on w + i delta)."""
    ed = SectorED(1 + nb)
    w = np.linspace(-SPEC_WMAX, SPEC_WMAX, SPEC_NW)
    z = w + 1j * SPEC_DELTA
    out, x0 = [], None
    for U in sorted(REP_U[nb]):
        r, x = dmft_ed(float(U), nb, x0)
        x0 = x
        eps, V = bath_from_sym(x, nb)
        h1 = np.zeros((1 + nb, 1 + nb))
        h1[0, 0] = -U / 2.0
        for l in range(nb):
            h1[1 + l, 1 + l] = eps[l]
            h1[0, 1 + l] = h1[1 + l, 0] = V[l]
        G = ed.green_z(h1, U, z)                       # impurity G_up(w+i0)
        dlt = (V[None, :] ** 2 / (z[:, None] - eps[None, :])).sum(1)
        sig = z + U / 2.0 - dlt - 1.0 / G              # Sigma = U/2 + Sigma'
        for i, wi in enumerate(w):
            out.append(dict(U_over_D=float(U), w=round(float(wi), 4),
                            A=round(float(-G[i].imag / np.pi), 6),
                            ImSigma_prime=round(float((sig[i]).imag), 6),
                            ImDelta=round(float(dlt[i].imag), 6),
                            ImG=round(float(G[i].imag), 6)))
        print(f"  Nb={nb} U/D={U}: A(0)~{-G[np.argmin(abs(w))].imag/np.pi:.4f} "
              f"(converged={r['converged']})", flush=True)
    d = os.path.join(OUT, "..", "bethe",
                     "mg3" if nb == 3 else "mg1", "finite_pole_DMFT",
                     "spectral_functions")
    d = os.path.normpath(d)
    os.makedirs(d, exist_ok=True)
    fn = os.path.join(d, "A_ImSigma_ImDelta.csv")
    with open(fn, "w", newline="") as f:
        wr = csv.DictWriter(f, fieldnames=list(out[0].keys()))
        wr.writeheader()
        wr.writerows(out)
    print(f"Nb={nb}: wrote {os.path.relpath(fn, _ROOT)} ({len(out)} rows)")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Nb", type=int, default=None)
    ap.add_argument("--validate", action="store_true")
    ap.add_argument("--spectral", action="store_true",
                    help="write real-frequency A/ImSigma/ImDelta at "
                         "representative U into the organized bethe tree")
    a = ap.parse_args()
    if a.spectral:
        for nb in ([a.Nb] if a.Nb else [1, 3]):
            spectral_row(nb)
        return
    if a.validate:
        r, _ = dmft_ed(0.0, 3)
        print(f"U=0 Nb=3: Ekin={r['ekin']:.5f} "
              f"(exact -4/(3*pi) = {-4 / (3 * np.pi):.5f}) "
              f"docc={r['docc']:.5f} (0.25) Z={r['Z']:.4f} (1)")
        r, _ = dmft_ed(2.4, 3)
        print(f"U=2.4 Nb=3: Z={r['Z']:.4f} docc={r['docc']:.5f} "
              f"ekin={r['ekin']:.5f} etot={r['etot']:.5f} "
              f"(LLK Fig.3: docc~0.043, Etot~-0.059; CTQMC docc 0.0545, "
              f"Etot -0.0621)")
        return
    for nb in ([a.Nb] if a.Nb else [1, 3, 5]):
        run_row(nb)


if __name__ == "__main__":
    main()
