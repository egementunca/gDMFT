#!/usr/bin/env python3
"""Paper scans 2026-07-15 — Bethe Mg=3 symmetric continuation, full T ladder.

Purpose (session: paper consolidation / literature comparison, LLK PRB 107
L121104): one uniform, zero-based Bethe Mg=3 dataset covering
  - U/D 0.5 -> 4.0 (LLK Fig. 2 domain; the 20260710 run capped at 3.2),
  - low T rows (rerun of the 20260710 ladder = free reproducibility check),
  - NEW mid/high T rows (0.025 ... 0.2) for the T-scan / crossover story,
  - dU/D = 0.01 refinement inside [U*-0.15, Uc2+0.15] per low-T row
    (dense-near-critical; window centers read from the 20260710 summary).

Route identical to scripts/r2_mg3_rebuild.py: symmetric 5-param fit +
warm continuation, metal grown at U/D = 2.0 (met-start), insulator from the
atomic-limit seed at the top of the grid. One chain per arm per row; the
fine window is embedded in the same chain (no separate window runs).

Outputs: results/runs/20260715_paper_scans/mg3_bethe/symmetric_bethe_T<T>.csv
(same schema as 20260710 + explicit T column). Collector-compatible.

Usage (rows split across processes for parallelism):
  .venv-numba/bin/python3 scripts/paper_scan_mg3.py --rows 0.025,0.05,0.1
  .venv-numba/bin/python3 scripts/paper_scan_mg3.py --rows all-new
  .venv-numba/bin/python3 scripts/paper_scan_mg3.py --rows all-cold
  [--probe]   (3-point timing probe at T=0.1, no files written)
"""
from __future__ import annotations

import argparse
import csv
import os
import sys
import time

import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for p in (_ROOT, os.path.join(_ROOT, "scripts")):
    if p not in sys.path:
        sys.path.insert(0, p)

import symmetric_continuation as SC  # noqa: E402

OUT = os.path.join(_ROOT, "results/runs/20260715_paper_scans/mg3_bethe")
LAT, NK = "bethe", 256
UD_MIN, UD_MAX, UD_STEP, UD_FINE = 0.5, 4.0, 0.025, 0.01
MET_START_UD = 2.0

# dense-window centers (U*/Uc2 per T) from the 20260710 rebuild summary;
# rows above the endpoint corridor get no window (crossover, nothing to
# resolve beyond the uniform 0.025 grid).
SUMMARY_20260710 = os.path.join(
    _ROOT, "results/runs/20260710_rerun_mg3/r2_summary_bethe.csv")

COLD_ROWS = [0.001, 0.002, 0.003, 0.004, 0.005, 0.0065, 0.008,
             0.01, 0.015, 0.02]
NEW_ROWS = [0.025, 0.03, 0.05, 0.07, 0.1, 0.15, 0.2]


def dense_window(T):
    """[U*-0.15, Uc2+0.15] in U/D from the 20260710 summary (None if no
    transition data for this T)."""
    if not os.path.exists(SUMMARY_20260710):
        return None
    with open(SUMMARY_20260710) as f:
        for r in csv.DictReader(f):
            if abs(float(r["T_over_D"]) - T) < 1e-12:
                uc2 = float(r["Uc2"]) if r["Uc2"] else None
                ust = float(r["Ustar"]) if r["Ustar"] else None
                lo = (ust if ust is not None else (uc2 - 0.25 if uc2 else None))
                if lo is None or uc2 is None:
                    return None
                return (round(lo - 0.15, 3), round(uc2 + 0.15, 3))
    return None


def row_grid(T):
    """Ascending uot grid: uniform 0.025 U/D + 0.01 U/D inside the window."""
    g = np.arange(UD_MIN, UD_MAX + 1e-9, UD_STEP)
    win = dense_window(T)
    if win is not None:
        g = np.concatenate([g, np.arange(win[0], win[1] + 1e-9, UD_FINE)])
    g = np.unique(np.round(2.0 * g, 3))          # U/D -> uot (t = 0.5, D = 1)
    return g, win


def run_row(T):
    t0 = time.time()
    # warm rows sit on a higher (still physical) residual floor; keep the
    # chain warm there. Cold rows keep the exact 20260710 gate.
    SC.WARM_GATE = 1e-3 if T >= 0.02 else 1e-4
    up, win = row_grid(T)
    ms = 2.0 * MET_START_UD
    hi = [u for u in up if u >= ms - 1e-9]
    lo = [u for u in up if u < ms - 1e-9][::-1]
    print(f"=== T/D={T:g}: {len(up)} U-points, window={win} ===", flush=True)
    metal = SC.continue_branch(hi, SC.METAL_X0, "metal-up", T, LAT, NK)
    x_grow = [metal[0][k] for k in ("V0", "Vg", "eps_g", "W", "eta")]
    metal += SC.continue_branch(lo, x_grow, "metal-down", T, LAT, NK)
    down = list(up[::-1])
    ins = SC.continue_branch(down, SC.ins_seed(down[0] * 0.5),
                             "insul-down", T, LAT, NK)
    rows = metal + ins
    for r in rows:
        r["T"] = T
    os.makedirs(OUT, exist_ok=True)
    fn = os.path.join(OUT, f"symmetric_{LAT}_T{T:g}.csv")
    with open(fn, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)
    print(f"T/D={T:g}: wrote {os.path.basename(fn)} ({len(rows)} rows, "
          f"{time.time() - t0:.0f}s)", flush=True)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--rows", default=None,
                    help="comma list of T/D, or all-new / all-cold / all")
    ap.add_argument("--probe", action="store_true")
    a = ap.parse_args()

    if a.probe:
        t0 = time.time()
        rows = SC.continue_branch([4.0, 4.05, 4.1], SC.METAL_X0,
                                  "probe", 0.1, LAT, NK)
        dt = (time.time() - t0) / len(rows)
        print(f"probe: {dt:.2f} s/point at T/D=0.1")
        return

    if a.rows in (None, "all"):
        rows = COLD_ROWS + NEW_ROWS
    elif a.rows == "all-new":
        rows = NEW_ROWS
    elif a.rows == "all-cold":
        rows = COLD_ROWS
    else:
        rows = [float(x) for x in a.rows.split(",")]
    for T in rows:
        run_row(T)


if __name__ == "__main__":
    main()
