#!/usr/bin/env python3
"""SYMMETRIC-CONSTRAINED continuation -- the deterministic recipe that survives
the square lattice.

The single-impurity "luck"/basin-hop comes from the general 14-parameter form's
redundant dark-ghost directions. The professor's minimal Mg=3 form removes them
by SYMMETRY: g0 at 0, g± at ±eps_g (shared coupling), h-poles at ±eta (shared
coupling), PH hard-coded. We impose that same structure on OUR objective
(`residual_ph`, PH-pinned gateway_plus_impfill_moments) -- 5 free reals
[V0, V1, eps_g, W, eta] -- so there is NO dark direction to hop into. Continuation
then tracks ONE physical branch cleanly through the Mott on BOTH lattices.

  - metal-up   : seed the satellite metal at low U/t, warm-start upward.
  - insul-down : seed the Mott structure at high U/t, warm-start downward.

Reports Z, D, sumV2, Omega, and tests reproducibility (re-run => identical) and
lattice transfer (square, where the general form basin-hops at U/t~12, and Bethe,
where it matches the professor).

Local ED. Run under: .venv-numba/bin/python3
"""
from __future__ import annotations

import argparse
import csv
import os
import sys

import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from scipy.optimize import least_squares  # noqa: E402
from BHFM2.core.solve_min import (  # noqa: E402
    ModelParamsMin, SParMin, MODE_SINGLE_IMPURITY as SI,
)
import landscape_map as L  # noqa: E402

OUT = os.environ.get("R2_OUT",
                     os.path.join(_ROOT, "results/runs/20260710_rerun_mg3"))
Z0 = np.zeros(0)

# 5 free params: [V0, V1, eps_g, W, eta]
LO = np.array([0.0, 0.0, 1e-6, 1e-8, 1e-6])
HI = np.array([5.0, 5.0, 12.0, 10.0, 8.0])
METAL_X0 = np.array([0.5, 1.6, 10.0, 0.6, 0.7])     # satellite metal
INSUL_X0 = np.array([0.05, 1.0, 12.0, 2.5, 0.1])    # legacy fixed Mott seed

# Warm-start acceptance for the continuation chain. The 5-param fit is
# overdetermined, so the physical residual floor is T-dependent: ~1e-6..1e-5
# at the cold rows but >1e-4 by T/D ~ 0.1. Cold-row default keeps the exact
# 20260710 protocol; warm-row drivers raise it (floor-limited points are
# legitimate chain parents there).
WARM_GATE = 1e-4


def ins_seed(U):
    """Atomic-limit insulator seed (runbook section 3 / protocol ins_seed3,
    validated at T=0.001-0.02 on Bethe): dead Kondo channel, outer channels
    ALIVE at the renormalizer scale c~0.03, exact atomic Sigma-weight W.
    The legacy fixed INSUL_X0 holds the insulator only at warm T (>~0.02);
    cold-T descents seeded from it fall dark."""
    eg = min(3.0 * U, 9.5)
    return np.array([1e-4, np.sqrt(0.03) * eg, eg, U / (2 * np.sqrt(2)), 3e-3])


def sym_spar(x, mu):
    """Symmetric Mg=3 / Mh=2 config from 5 free reals (prof structure)."""
    V0, V1g, eps_g, W, eta = x
    return SParMin(eta=np.array([eta, -eta]), W=np.array([W, W]), eta_b=Z0, B_h=Z0,
                   eps1=np.array([0.0, eps_g, -eps_g]), V1=np.array([V0, V1g, V1g]),
                   eta1=np.array([eta, -eta]), W1=np.array([W, W]),
                   eps2=Z0, V2=Z0, eta2=Z0, W2=Z0, eta_b2=Z0, B_h2=Z0,
                   eps_b=Z0, B_g=Z0, mu=float(mu))


def solve_sym(mp, x0, mu, max_nfev=3000):
    x0 = np.clip(x0, LO + 1e-9, HI - 1e-9)
    sol = least_squares(lambda x: L.residual_ph(sym_spar(x, mu), mp, 3), x0,
                        method="trf", bounds=(LO, HI),
                        ftol=1e-14, xtol=1e-14, max_nfev=max_nfev)
    return sol.x, float(np.linalg.norm(sol.fun))


def continue_branch(uot_grid, x_seed, label, T, lattice, Nk):
    rows = []
    x = np.array(x_seed, float)
    for uot in uot_grid:
        U = uot * 0.5
        mu = U / 2.0
        mp = ModelParamsMin(t=0.5, eps_d=0.0, U=U, z=4.0, filling_target=1.0,
                            beta=1.0 / T, Nk=Nk, lattice=lattice,
                            n_moments=L.N_MOMENTS, Sigma_inf=U / 2.0)
        xsol, r = solve_sym(mp, x, mu)
        d = L.diagnose(sym_spar(xsol, mu), mp, 3)
        d["basin"] = L.basin_label(d)
        d.update(uot=float(uot), U=U, branch=label, resnorm=r,
                 V0=xsol[0], Vg=xsol[1], eps_g=xsol[2], W=xsol[3], eta=xsol[4])
        rows.append(d)
        if r < WARM_GATE:                     # warm-start only from good points
            x = xsol
        print(f"  [{label:10s} {lattice:6s} U/t={uot:5.2f}] ||r||={r:.1e} "
              f"Z={d['Z_pole']:.4f} D={d['D']:.4f} sumV2={d['sumV2']:.3g} "
              f"Om={d['Omega']:.4f} -> {d['basin']}", flush=True)
    return rows


def max_dZ(a, b):
    za = {round(r["uot"], 3): r["Z_pole"] for r in a if r["resnorm"] < 1e-4}
    m = 0.0
    for r in b:
        u = round(r["uot"], 3)
        if u in za and r["resnorm"] < 1e-4:
            m = max(m, abs(r["Z_pole"] - za[u]))
    return m


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--lattice", default="square")
    ap.add_argument("--Nk", type=int, default=16)
    ap.add_argument("--T", type=float, default=0.025)
    ap.add_argument("--umin", type=float, default=4.0)
    ap.add_argument("--umax", type=float, default=16.0)
    ap.add_argument("--du", type=float, default=0.25)
    ap.add_argument("--met-start", type=float, default=None,
                    help="uot to GROW the metal from (up-chain above it, "
                         "down-chain below it). Chains started at weak coupling "
                         "hit the g-matching degeneracy (outer channels die and "
                         "never revive under warm continuation -> effective-Mg=1 "
                         "masquerading as Mg=3). Default: umin (legacy).")
    ap.add_argument("--repro", action="store_true")
    args = ap.parse_args()
    lat, Nk, T = args.lattice, args.Nk, args.T
    up = np.round(np.arange(args.umin, args.umax + 1e-9, args.du), 3)
    down = up[::-1].copy()

    print(f"=== SYMMETRIC continuation ({lat}, T={T}, Mg=3 symmetric 5-param, PH-pinned) ===")
    if args.met_start is None:
        print("\n-- metal-up --")
        metal = continue_branch(up, METAL_X0, "metal-up", T, lat, Nk)
    else:
        hi = [u for u in up if u >= args.met_start - 1e-9]
        lo = [u for u in up if u < args.met_start - 1e-9][::-1]
        print(f"\n-- metal-up (grown at uot={args.met_start:g}) --")
        metal = continue_branch(hi, METAL_X0, "metal-up", T, lat, Nk)
        x_grow = [metal[0][k] for k in ("V0", "Vg", "eps_g", "W", "eta")]
        print("\n-- metal-down (weak-coupling tail from the grown solution) --")
        metal += continue_branch(lo, x_grow, "metal-down", T, lat, Nk)
    print("\n-- insulator-down --")
    ins = continue_branch(down, ins_seed(down[0] * 0.5), "insul-down", T, lat, Nk)

    rows = metal + ins
    fn = f"{OUT}/symmetric_{lat}_T{T:g}.csv"
    with open(fn, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)
    print(f"\nwrote {os.path.basename(fn)} ({len(rows)} rows)")

    # hop check on metal-up: Z must be monotone non-increasing (no jump-back)
    zseq = [(r["uot"], r["Z_pole"]) for r in metal if r["resnorm"] < 1e-4]
    hops = [(u, z) for (u0, z0), (u, z) in zip(zseq, zseq[1:]) if z > z0 + 0.02]
    print(f"metal-up monotone-Z check: {len(hops)} basin-hop(s)"
          + (f" at U/t={[round(u,2) for u,_ in hops]}" if hops else " -> CLEAN"))

    if args.repro:
        print("\n-- REPRODUCIBILITY: re-run metal-up --")
        metal2 = continue_branch(up, METAL_X0, "metal-up-2", T, lat, Nk)
        print(f"  max |Z_run1 - Z_run2| = {max_dZ(metal, metal2):.2e}")


if __name__ == "__main__":
    main()
