#!/usr/bin/env python3
"""Stage 3 registered scan matrix -- LOSSLESS v2 producer (resumable, immutable).

Supersedes the v1 producer (preserved verbatim as scan_matrix_v1.py; the v1 data
campaign is preserved unchanged at results/runs/20260717_scan_matrix/). v2 stores
EVERY attempt losslessly as a JSON record -- the complete native optimizer
vector, full g/h/canonical arrays (never reduced to sumV2/sumW2), the full
optimizer result (status/message/nfev/njev/cost/optimality/active_mask + bound
distances), the complete residual vector + block norms, continuation parent +
seed provenance, all observables in raw AND reduced units, and quadrature/node/
commit/source identifiers.

For every BARE root three DISTINCT evidence records are written and never
conflated:
  - bare_native                : the bare-gauge solve;
  - R_converted_from_bare      : the exact deterministic arrowhead forward map
                                 (no optimizer);
  - R_reoptimized_from_bare    : an R-gauge re-solve seeded FROM that exact
                                 conversion.
The R-native cells write R_native_continuation (a warm-chained native R solve),
kept separate.

Both square budgets use the SAME continuum discretization n_eps=2001 (certified
by the interacting-node convergence test, square_node_certification.json:
<=1.04e-5 vs n_eps=8001 at interacting metal points).

Output: results/runs/20260717_scan_matrix_v2/<cell>/T<T>.jsonl (+ registry).
Resumable: a complete T-file is skipped. `selected` is never set.

Usage:
  .venv-numba/bin/python3 scripts/gauge_matrix/scan_matrix.py --cell bethe_mg1_bare
  .venv-numba/bin/python3 scripts/gauge_matrix/scan_matrix.py --list
"""
from __future__ import annotations

import argparse
import glob
import hashlib
import json
import os
import sys
import time

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS = os.path.dirname(_HERE)
_ROOT = os.path.dirname(_SCRIPTS)
for p in (_ROOT, _SCRIPTS):
    if p not in sys.path:
        sys.path.insert(0, p)

from scipy.optimize import least_squares  # noqa: E402
from BHFM2.core.solve_min import (ModelParamsMin, SParMin, lat_obs,  # noqa: E402
                                  compute_omega_scheme, imp1_obs,
                                  MODE_SINGLE_IMPURITY as SI)
from BHFM2.core.reparam_R import hsector_to_bare, R_FLOOR  # noqa: E402
from BHFM2.core import canonical_gauge as cg  # noqa: E402
from BHFM2.runners.run_bonding_systematic import (  # noqa: E402
    _grouped_residuals, _objective_vector)
import landscape_map as L  # noqa: E402
import symmetric_continuation as SC  # noqa: E402
import symmetric_continuation_R as SR  # noqa: E402
from dataclasses import replace  # noqa: E402

OUTROOT = os.path.join(_ROOT, "results/runs/20260717_scan_matrix_v2")
REGISTRY = os.path.join(OUTROOT, "scan_run_registry.csv")
OBJECTIVE = "gateway_plus_impfill_moments"
Z0 = np.zeros(0)
N_EPS_DOS = int(os.environ.get("SCAN_N_EPS", "2001"))    # certified common square value
# Convergence / warm-continuation gate = the physical residual floor of the
# symmetric warm-continuation solves (v1 / D01 convention: cold rows ~1e-6, warm
# rows up to ~1e-3). Using 1e-3 keeps the metal chain ALIVE through the
# Brinkman-Rice collapse (U/D>3.5, where the residual floor rises); the full
# resnorm is stored losslessly so a stricter gate can be applied downstream.
CONV_GATE = 1e-3


def _union(*rs):
    v = np.concatenate([np.round(np.arange(a, b + 1e-9, s), 4) for a, b, s in rs])
    return sorted(float(x) for x in np.unique(np.round(v, 4)))


BETHE_T = [0.001, 0.002, 0.003, 0.004, 0.005, 0.0065, 0.008, 0.01, 0.015, 0.02,
           0.025, 0.03, 0.05, 0.07, 0.1, 0.15, 0.2]
BETHE_U = _union((0.5, 4.0, 0.1), (2.0, 3.6, 0.05))            # 52
SQUARE_T = [0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.008, 0.01, 0.015, 0.02]
SQUARE_U = _union((0.5, 3.2, 0.1), (2.0, 3.2, 0.05))          # 40
GRID = {"bethe": (BETHE_U, BETHE_T), "square": (SQUARE_U, SQUARE_T)}
D_OF = {"bethe": 1.0, "square": 2.0}
QUAD_OF = {"bethe": "bethe_semicircle", "square": "continuum_elliptic_dos"}
NODES_OF = {"bethe": 256 * 256, "square": None}      # square set from N_EPS_DOS

# Mg=1 symmetric parametrization (bare + R), bounds, seeds
LO1 = np.array([0.0, 1e-8, 1e-6]);  HI1 = np.array([5.0, 30.0, 40.0])          # V0,W,eta
RF_HI = float(np.sqrt((1.0 - R_FLOOR ** 2) / 2.0))
LO1R = np.array([0.0, 1e-4, R_FLOOR]);  HI1R = np.array([5.0, 30.0, RF_HI])    # V0,lam,Rf
METAL1_X0 = np.array([0.45, 0.6, 0.7])


def sym_spar_mg1(x, mu):
    V0, W, eta = x
    return SParMin(eta=np.array([eta, -eta]), W=np.array([W, W]), eta_b=Z0, B_h=Z0,
                   eps1=np.array([0.0]), V1=np.array([V0]),
                   eta1=np.array([eta, -eta]), W1=np.array([W, W]),
                   eps2=Z0, V2=Z0, eta2=Z0, W2=Z0, eta_b2=Z0, B_h2=Z0,
                   eps_b=Z0, B_g=Z0, mu=float(mu))


def sym_spar_mg1_R(xR, mu):
    V0, lam, Rf = xR
    eta, W = hsector_to_bare(np.array([lam, -lam]), np.array([Rf, Rf]), 0.0)
    return SParMin(eta=eta, W=W, eta_b=Z0, B_h=Z0, eps1=np.array([0.0]),
                   V1=np.array([V0]), eta1=eta.copy(), W1=W.copy(), eps2=Z0, V2=Z0,
                   eta2=Z0, W2=Z0, eta_b2=Z0, B_h2=Z0, eps_b=Z0, B_g=Z0, mu=float(mu))


def seed_mg1_R_from_bare(x_bare):
    V0, W, eta = x_bare
    lam3, R3 = cg.forward(0.0, np.array([eta, -eta]), np.array([W, W]))
    qp = int(np.argmin(np.abs(lam3)))
    m = np.ones(3, bool); m[qp] = False
    lam = float(np.mean(np.abs(lam3[m])))
    Rf = float(np.clip(np.mean(np.abs(R3[m])), R_FLOOR, RF_HI))
    return np.array([V0, max(lam, 1e-4), Rf])


# per-cell (lattice, Mg, gauge) -- gauge in {bare_native, R_native}
CELLS = {
    "bethe_mg1_bare": ("bethe", 1, "bare_native"),
    "bethe_mg1_Rnative": ("bethe", 1, "R_native"),
    "bethe_mg3_Rnative": ("bethe", 3, "R_native"),
    "square_mg1_bare": ("square", 1, "bare_native"),
    "square_mg1_Rnative": ("square", 1, "R_native"),
    "square_mg3_bare": ("square", 3, "bare_native"),
    "square_mg3_Rnative": ("square", 3, "R_native"),
}


def mp_for(lattice, U, T_code):
    kw = dict(t=0.5, eps_d=0.0, U=U, z=4.0, filling_target=1.0, beta=1.0 / T_code,
              Nk=(256 if lattice == "bethe" else 16), lattice=lattice,
              n_moments=L.N_MOMENTS, Sigma_inf=U / 2.0)
    if lattice == "square":
        kw.update(lattice_quadrature="continuum_elliptic_dos", n_eps_dos=N_EPS_DOS)
    return ModelParamsMin(**kw)


def node_count(lattice):
    return 256 * 256 if lattice == "bethe" else N_EPS_DOS


# --------------------------------------------------------------------------
# full-result solve wrappers (capture the entire least_squares result)
# --------------------------------------------------------------------------
def _solve(spar_fn, x0, lo, hi, mp, mu, Mg, max_nfev=3000):
    x0 = np.clip(np.asarray(x0, float), lo + 1e-9, hi - 1e-9)
    sol = least_squares(lambda x: L.residual_ph(spar_fn(x, mu), mp, Mg), x0,
                        method="trf", bounds=(lo, hi), ftol=1e-14, xtol=1e-14,
                        max_nfev=max_nfev)
    return sol


def _bounds(Mg, gauge):
    if gauge == "bare_native":
        return (LO1, HI1) if Mg == 1 else (SC.LO, SC.HI)
    return (LO1R, HI1R) if Mg == 1 else (SR.LO_R, SR.HI_R)


def _spar(Mg, gauge):
    if gauge == "bare_native":
        return sym_spar_mg1 if Mg == 1 else SC.sym_spar
    return sym_spar_mg1_R if Mg == 1 else SR.sym_spar_R


# --------------------------------------------------------------------------
# residual block norms
# --------------------------------------------------------------------------
def _residual_blocks(p, mp, Mg):
    _, blocks, _ = _grouped_residuals(p, mp, 2, Mg, 0, SI, pin_sigma_inf=mp.U / 2.0)
    vec = _objective_vector(blocks, OBJECTIVE)
    bnorms = {}
    for k, v in blocks.items():
        if v is None:
            continue
        a = np.atleast_1d(np.asarray(v, float))
        if a.size:
            bnorms[k] = float(np.linalg.norm(a))
    return [float(x) for x in np.asarray(vec, float).ravel()], bnorms


# --------------------------------------------------------------------------
# canonical forward map (both h-sectors) + diagnostics
# --------------------------------------------------------------------------
def _canon(eta, W, eta1, W1):
    eta = np.asarray(eta, float); W = np.asarray(W, float)
    eta1 = np.asarray(eta1, float); W1 = np.asarray(W1, float)
    lamL, RL = cg.forward(0.0, eta, W)
    lamG, RG = cg.forward(0.0, eta1, W1)

    def diag(lam, R, eta_in, W_in):
        R2 = R ** 2
        norm = float(abs(np.sum(R2) - 1.0))
        clos = float(abs(np.sum(lam * R2) - 0.0))
        floor = bool(np.any(R <= R_FLOOR * (1 + 1e-9)) or np.min(R2) < 1e-16)
        try:
            _, eb, Wb = cg.inverse(lam, R)
            rt = float(max(np.max(np.abs(np.sort(eb) - np.sort(eta_in))),
                           np.max(np.abs(np.sort(Wb) - np.sort(np.abs(W_in))))))
        except Exception:
            rt = float("nan"); floor = True
        return norm, clos, rt, floor
    nL, cL, rtL, flL = diag(lamL, RL, eta, W)
    nG, cG, rtG, flG = diag(lamG, RG, eta1, W1)
    return dict(
        lambda_lattice=[float(x) for x in lamL], R_lattice=[float(x) for x in RL],
        lambda_gateway=[float(x) for x in lamG], R_gateway=[float(x) for x in RG],
        n_modes=int(lamL.size),
        norm_error=max(nL, nG), closure_error=max(cL, cG),
        roundtrip_error=(None if (np.isnan(rtL) or np.isnan(rtG)) else max(rtL, rtG)),
        floor_limited=bool(flL or flG))


# --------------------------------------------------------------------------
# observables (raw + reduced) via the trusted diagnose + lat_obs
# --------------------------------------------------------------------------
def _observables(p, mp, Mg, U, D):
    d = L.diagnose(p, mp, Mg)
    lat = lat_obs(p, replace(mp, Sigma_inf=U / 2.0), 2, 0, mode=SI)
    e_kin = float(lat["e_kin"])
    D_occ = float(d["D"])
    e_pot = U * D_occ
    e_tot = e_kin + e_pot
    Om = float(d["Omega"]) if np.isfinite(d["Omega"]) else None
    return dict(
        Z_pole=float(d["Z_pole"]), Z_mats=float(d["Z_fermi"]), D_occ=D_occ,
        n=float(d["n_avg"]), n_lat=float(d["n_lat"]),
        Omega=Om, Omega_over_D=(Om / D if Om is not None else None),
        E_kin=e_kin, E_kin_over_D=e_kin / D,
        E_pot=e_pot, E_pot_over_D=e_pot / D,
        E_tot=e_tot, E_tot_over_D=e_tot / D,
        basin=L.basin_label(d)), D_occ


# --------------------------------------------------------------------------
# assemble a lossless attempt record
# --------------------------------------------------------------------------
def _aid(cell, branch, ud, td, evidence):
    return hashlib.sha1(f"{cell}|{branch}|U{ud:.4f}|T{td:.6f}|{evidence}".encode()).hexdigest()[:16]


def _record(cell, lattice, Mg, branch, ud, td, U, T_code, evidence, x_sol, sol,
            p, lo, hi, seed_prov, parent_id, commit, dirty):
    D = D_OF[lattice]
    eta = [float(v) for v in np.asarray(p.eta, float)]
    W = [float(v) for v in np.asarray(p.W, float)]
    eta1 = [float(v) for v in np.asarray(p.eta1, float)]
    W1 = [float(v) for v in np.asarray(p.W1, float)]
    eps_g = [float(v) for v in np.asarray(p.eps1, float)]
    V_g = [float(v) for v in np.asarray(p.V1, float)]
    canon = _canon(eta, W, eta1, W1)
    obs, D_occ = _observables(p, mp_for(lattice, U, T_code), Mg, U, D)
    res_vec, bnorms = _residual_blocks(p, mp_for(lattice, U, T_code), Mg)
    resnorm = float(np.linalg.norm(res_vec))
    # optimizer diagnostics
    if sol is not None:
        opt = dict(success=bool(sol.success), status=int(sol.status),
                   message=str(sol.message), nfev=int(sol.nfev),
                   njev=(int(sol.njev) if sol.njev is not None else None),
                   cost=float(sol.cost), optimality=float(sol.optimality),
                   active_mask=[int(v) for v in np.asarray(sol.active_mask, int)])
        xv = [float(v) for v in np.asarray(x_sol, float)]
        dist_lo = [float(a - b) for a, b in zip(xv, lo)]
        dist_hi = [float(b - a) for a, b in zip(hi, xv)]
    else:                       # deterministic conversion: no optimizer
        opt = dict(success=None, status=None, message="deterministic_forward_map",
                   nfev=0, njev=0, cost=None, optimality=None, active_mask=None)
        xv = ([float(v) for v in np.asarray(x_sol, float)] if x_sol is not None else None)
        dist_lo = dist_hi = None
    # symmetry-reduced g coords (distinct keys; full eps_g[]/V_g[] retained)
    if Mg == 3:
        red = dict(V0=V_g[0], Vg=V_g[1], eps_g_reduced=eps_g[1])
    else:
        red = dict(V0=V_g[0], Vg=None, eps_g_reduced=eps_g[0])
    # reduced canonical (PH ghosts +/-lam, Rf)
    def _redcanon(lam, R):
        lam = np.asarray(lam); R = np.abs(np.asarray(R))
        qp = int(np.argmin(np.abs(lam))); m = np.ones(lam.size, bool); m[qp] = False
        return float(np.mean(np.abs(lam[m]))), float(np.mean(R[m]))
    lamL_r, RfL_r = _redcanon(canon["lambda_lattice"], canon["R_lattice"])
    conv_flag = (None if resnorm is None else int(resnorm <= CONV_GATE))
    return dict(
        attempt_id=_aid(cell, branch, ud, td, evidence),
        parent_attempt_id=parent_id, seed_provenance=seed_prov,
        cell=cell, lattice=lattice, M_g=Mg, M_h=2, branch=branch,
        evidence_type=evidence,
        solver_route=("bare_least_squares" if evidence == "bare_native"
                      else ("deterministic_forward_map" if evidence == "R_converted_from_bare"
                            else "R_least_squares")),
        U_over_D=round(ud, 4), T_over_D=round(td, 6), U_raw=U, T_raw=T_code, t=0.5, D=D,
        lattice_quadrature=QUAD_OF[lattice], node_count=node_count(lattice),
        n_eps_dos=(N_EPS_DOS if lattice == "square" else None),
        code_commit=commit, dirty=dirty,
        x_sol=xv,
        g_sector=dict(eps_g=eps_g, V_g=V_g, **red),
        bare_h_sectors=dict(eta_lattice=eta, W_lattice=W, eta_gateway=eta1, W_gateway=W1),
        canonical_h_sectors=dict(
            lambda_lattice=canon["lambda_lattice"], R_lattice=canon["R_lattice"],
            lambda_gateway=canon["lambda_gateway"], R_gateway=canon["R_gateway"],
            lam_reduced=lamL_r, Rf_reduced=RfL_r, n_modes=canon["n_modes"]),
        observables=obs,
        optimizer=opt, bound_distance_lo=dist_lo, bound_distance_hi=dist_hi,
        residual=dict(vector=res_vec, total=resnorm, block_norms=bnorms),
        classification=dict(converged=conv_flag, equation_accepted=None,
                            physical=None, gated=None, branch_continuous=None,
                            selected=None, floor_limited=int(canon["floor_limited"]),
                            norm_error=canon["norm_error"], closure_error=canon["closure_error"],
                            roundtrip_error=canon["roundtrip_error"]))


# --------------------------------------------------------------------------
# one (cell, T) -> list of lossless records (branch-aware continuation)
# --------------------------------------------------------------------------
def _run_cell_T(cell, lattice, Mg, gauge, ud_list, td, commit, dirty):
    U_of = lambda ud: (2.0 if lattice == "bethe" else 4.0) * ud * 0.5
    T_code = td if lattice == "bethe" else 2.0 * td
    ms = 2.0  # grow metal at U/D = 2
    hi = [u for u in ud_list if u >= ms - 1e-9]
    lo = [u for u in ud_list if u < ms - 1e-9][::-1]
    down = list(ud_list[::-1])
    lo_b, hi_b = _bounds(Mg, gauge)
    spar = _spar(Mg, gauge)
    records = []

    def metal_seed():
        if gauge == "bare_native":
            return (METAL1_X0 if Mg == 1 else SC.METAL_X0).copy()
        return (seed_mg1_R_from_bare(METAL1_X0) if Mg == 1 else SR.seed_R_from_bare5(SC.METAL_X0))

    def ins_seed(U):
        if Mg == 3:
            return SC.ins_seed(U) if gauge == "bare_native" else SR.seed_R_from_bare5(SC.ins_seed(U))
        bare = np.array([1e-3, U / (2 * np.sqrt(2)), 3e-3])
        return bare if gauge == "bare_native" else seed_mg1_R_from_bare(bare)

    def do_point(ud, seed, branch, seed_prov):
        U = U_of(ud); mu = U / 2.0
        mp = mp_for(lattice, U, T_code)
        try:
            sol = _solve(spar, seed, lo_b, hi_b, mp, mu, Mg)
        except Exception as exc:
            records.append(_solver_failed(cell, lattice, Mg, gauge, branch, ud, td,
                                          U, T_code, seed_prov, commit, dirty, exc))
            return None
        p = spar(sol.x, mu)
        rec = _record(cell, lattice, Mg, branch, ud, td, U, T_code,
                      (gauge if gauge != "R_native" else "R_native_continuation"),
                      sol.x, sol, p, lo_b, hi_b, seed_prov, None, commit, dirty)
        records.append(rec)
        conv = rec["classification"]["converged"] == 1
        # --- for BARE cells: emit R_converted + R_reoptimized from this bare root ---
        if gauge == "bare_native":
            bare_id = rec["attempt_id"]
            # exact conversion (deterministic, no optimizer)
            if Mg == 1:
                xR = seed_mg1_R_from_bare(sol.x)
                pR = sym_spar_mg1_R(xR, mu)
            else:
                xR = SR.seed_R_from_bare5(sol.x)
                pR = SR.sym_spar_R(xR, mu)
            conv_rec = _record(cell, lattice, Mg, branch, ud, td, U, T_code,
                               "R_converted_from_bare", xR, None, pR,
                               (LO1R if Mg == 1 else SR.LO_R),
                               (HI1R if Mg == 1 else SR.HI_R),
                               f"exact_conversion_of:{bare_id}", bare_id, commit, dirty)
            records.append(conv_rec)
            # R-reoptimized seeded from the exact conversion
            try:
                solR = _solve((sym_spar_mg1_R if Mg == 1 else SR.sym_spar_R), xR,
                              (LO1R if Mg == 1 else SR.LO_R),
                              (HI1R if Mg == 1 else SR.HI_R), mp, mu, Mg)
                pRo = (sym_spar_mg1_R if Mg == 1 else SR.sym_spar_R)(solR.x, mu)
                records.append(_record(cell, lattice, Mg, branch, ud, td, U, T_code,
                                       "R_reoptimized_from_bare", solR.x, solR, pRo,
                                       (LO1R if Mg == 1 else SR.LO_R),
                                       (HI1R if Mg == 1 else SR.HI_R),
                                       f"reopt_from_conversion:{bare_id}", bare_id,
                                       commit, dirty))
            except Exception as exc:
                records.append(_solver_failed(cell, lattice, Mg, "R_reoptimized_from_bare",
                                              branch, ud, td, U, T_code,
                                              f"reopt_from_conversion:{bare_id}", commit, dirty, exc))
        return sol.x if conv else None

    # metal-up -> metal-down -> insulator-down
    seed = metal_seed(); first_x = None
    for ud in hi:
        x = do_point(ud, seed, "metal-up", "metal_seed" if first_x is None else "warm_metal-up")
        if x is not None:
            seed = x
            if first_x is None:
                first_x = x
    seed = first_x if first_x is not None else metal_seed()
    for ud in lo:
        x = do_point(ud, seed, "metal-down", "warm_metal-down")
        if x is not None:
            seed = x
    seed = ins_seed(U_of(down[0]))
    for ud in down:
        x = do_point(ud, seed, "insul-down", "warm_insul-down")
        if x is not None:
            seed = x
    return records


def _solver_failed(cell, lattice, Mg, gauge, branch, ud, td, U, T_code, seed_prov,
                   commit, dirty, exc):
    return dict(
        attempt_id=_aid(cell, branch, ud, td, gauge + "_FAIL"),
        parent_attempt_id=None, seed_provenance=seed_prov, cell=cell,
        lattice=lattice, M_g=Mg, M_h=2, branch=branch,
        evidence_type=(gauge if gauge != "R_native" else "R_native_continuation"),
        solver_route="solver_failed", U_over_D=round(ud, 4), T_over_D=round(td, 6),
        U_raw=U, T_raw=T_code, t=0.5, D=D_OF[lattice],
        lattice_quadrature=QUAD_OF[lattice], node_count=node_count(lattice),
        n_eps_dos=(N_EPS_DOS if lattice == "square" else None),
        code_commit=commit, dirty=dirty, x_sol=None, g_sector=None,
        bare_h_sectors=None, canonical_h_sectors=None, observables=None,
        optimizer=dict(success=False, status=None, message=f"{type(exc).__name__}:{exc}"),
        bound_distance_lo=None, bound_distance_hi=None,
        residual=dict(vector=None, total=None, block_norms=None),
        classification=dict(converged=0, equation_accepted=None, physical=None,
                            gated=None, branch_continuous=None, selected=None,
                            floor_limited=None, solver_failed=1))


# --------------------------------------------------------------------------
# cell runner (resumable per-T JSONL) + registry
# --------------------------------------------------------------------------
def run_cell(cell, commit, dirty):
    lattice, Mg, gauge = CELLS[cell]
    Us, Ts = GRID[lattice]
    ud_list = sorted(Us)
    outdir = os.path.join(OUTROOT, cell)
    os.makedirs(outdir, exist_ok=True)
    done = 0
    for td in Ts:
        fn = os.path.join(outdir, f"T{td:g}.jsonl")
        if os.path.exists(fn) and os.path.getsize(fn) > 0:
            done += 1
            continue
        t0 = time.time()
        recs = _run_cell_T(cell, lattice, Mg, gauge, ud_list, td, commit, dirty)
        tmp = fn + ".tmp"
        with open(tmp, "w") as f:
            for r in recs:
                f.write(json.dumps(r) + "\n")
        os.replace(tmp, fn)      # atomic: a T-file is either absent or complete
        conv = sum(1 for r in recs if r["classification"].get("converged") == 1)
        _register(cell, td, len(recs), conv, fn, time.time() - t0, commit, dirty)
        print(f"[{cell}] T/D={td:g}: {len(recs)} records ({conv} conv) "
              f"-> {os.path.basename(fn)} ({time.time()-t0:.0f}s)", flush=True)
        done += 1
    return done, len(Ts)


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _register(cell, td, n_rec, n_conv, fn, wall, commit, dirty):
    import csv
    os.makedirs(OUTROOT, exist_ok=True)
    new = not os.path.exists(REGISTRY)
    with open(REGISTRY, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["cell", "T_over_D", "n_records", "n_converged", "artifact",
                        "sha256", "wall_s", "n_eps_dos", "code_commit", "dirty"])
        w.writerow([cell, td, n_rec, n_conv, os.path.relpath(fn, _ROOT), _sha(fn),
                    round(wall, 1), (N_EPS_DOS if cell.startswith("square") else ""),
                    commit, dirty])


def _commit_dirty():
    import subprocess
    try:
        c = subprocess.check_output(["git", "-C", _ROOT, "rev-parse", "HEAD"], text=True).strip()
        d = subprocess.check_output(["git", "-C", _ROOT, "status", "--porcelain"], text=True)
        return c, ("dirty" if d.strip() else "clean")
    except Exception:
        return "unknown", "unknown"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cell")
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for k, v in CELLS.items():
            print(f"  {k}: {v}")
        return
    commit, dirty = _commit_dirty()
    cells = list(CELLS) if a.cell == "all" else [a.cell]
    for cell in cells:
        if cell not in CELLS:
            print(f"unknown cell {cell}"); continue
        done, total = run_cell(cell, commit, dirty)
        print(f"[{cell}] complete: {done}/{total} T-files present")


if __name__ == "__main__":
    main()
