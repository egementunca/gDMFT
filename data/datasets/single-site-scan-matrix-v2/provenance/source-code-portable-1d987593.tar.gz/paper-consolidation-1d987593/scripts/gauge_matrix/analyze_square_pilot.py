#!/usr/bin/env python3
"""Analyze the Stage 1 square resolution pilot -> convergence + branch + gate.

Deterministic postprocessing of results/runs/20260717_square_resolution/
square_pilot_raw.csv. The continuum_elliptic_dos route is the reference (its
U=0 anchor matches -4/pi^2 to 8e-9). For every converged (branch, U/D, T/D)
group it reports, per observable, SIGNED absolute + relative + scale-aware
differences of each uniform_kmesh route from the continuum reference, the branch
identity across routes, and the predeclared claim-gate verdict.

Writes into results/deliverables/09_single_site_publication_validation/:
  square_stationary_convergence.csv
  square_branch_matches.csv
  square_claim_gate.csv
"""
from __future__ import annotations

import csv
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(os.path.dirname(_HERE))
RAW = os.path.join(_ROOT, "results/runs/20260717_square_resolution/square_pilot_raw.csv")
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")

OBS = ["Z_pole", "Z_fermi", "D_occ", "n", "Omega_over_D",
       "E_kin_over_D", "E_pot_over_D", "E_tot_over_D"]
GATE_REL = 0.001            # 0.1% predeclared sub-percent tolerance
Z_METAL = 0.02             # branch classifier threshold on Z_pole


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def load():
    rows = [r for r in csv.DictReader(open(RAW))]
    return rows


def main():
    rows = load()
    conv = [r for r in rows if r["converged"] == "1"
            and r["solver_route"].startswith(("R_symmetric", "analytic"))]
    # group by (branch, U/D, T/D)
    groups = {}
    for r in conv:
        groups.setdefault((r["branch"], r["U_over_D"], r["T_over_D"]), {})[
            (r["quadrature"], r["Nk"])] = r

    conv_rows, gate_rows, branch_rows = [], [], []
    for (branch, ud, td), byroute in sorted(groups.items()):
        ref = byroute.get(("continuum_elliptic_dos", ""))
        if ref is None:
            continue
        # branch identity across routes
        kinds = {rt: ("metal" if (_f(rr["Z_pole"]) or 0) > Z_METAL else "insulator")
                 for rt, rr in byroute.items()}
        branch_consistent = len(set(kinds.values())) == 1
        branch_rows.append(dict(
            branch=branch, U_over_D=ud, T_over_D=td,
            n_routes=len(byroute), branch_consistent=int(branch_consistent),
            kinds=";".join(f"{k[0]}{k[1]}={v}" for k, v in kinds.items()),
            dist_to_spinodal_UD=ref["dist_to_spinodal_UD"]))
        for obs in OBS:
            vref = _f(ref.get(obs))
            if vref is None:
                continue
            row = dict(branch=branch, U_over_D=ud, T_over_D=td, observable=obs,
                       value_continuum=vref,
                       dist_to_spinodal_UD=ref["dist_to_spinodal_UD"])
            scale = max(abs(vref), 0.05)      # scale-aware denominator (avoids Z~0 blowup)
            for Nk in ("16", "32", "64"):
                rr = byroute.get(("uniform_kmesh", Nk))
                v = _f(rr.get(obs)) if rr else None
                row[f"value_Nk{Nk}"] = v
                if v is not None:
                    row[f"abs_Nk{Nk}"] = v - vref                 # signed
                    row[f"rel_Nk{Nk}"] = (v - vref) / vref if vref else None
                    row[f"scaleaware_Nk{Nk}"] = (v - vref) / scale
            conv_rows.append(row)
            # gate on Nk=64 (the best mesh) and continuum (reference, exact)
            r64 = row.get("rel_Nk64")
            gate_rows.append(dict(
                branch=branch, U_over_D=ud, T_over_D=td, observable=obs,
                value_continuum=vref, rel_Nk64=r64,
                abs_Nk64=row.get("abs_Nk64"),
                scaleaware_Nk64=row.get("scaleaware_Nk64"),
                gate_rel_tol=GATE_REL,
                Nk64_passes=(int(abs(r64) <= GATE_REL) if r64 is not None else ""),
                continuum_is_reference=1,
                note=("near-spinodal/collapsed: use scale-aware"
                      if abs(vref) < 0.05 else "")))

    _write("square_stationary_convergence.csv", conv_rows)
    _write("square_branch_matches.csv", branch_rows)
    _write("square_claim_gate.csv", gate_rows)

    # summary to stdout
    print("=== Nk64-vs-continuum relative error by observable (converged metal, cold) ===")
    metal_cold = [r for r in conv_rows if r["branch"] == "metal"
                  and r["T_over_D"] == "0.001" and r.get("rel_Nk64") is not None]
    import math
    byobs = {}
    for r in metal_cold:
        v = abs(r["rel_Nk64"])
        if math.isfinite(v):     # skip the U=0 analytic point (no Omega)
            byobs.setdefault(r["observable"], []).append(v)
    for o in OBS:
        if byobs.get(o):
            m = max(byobs[o])
            print(f"  {o:16s} max|rel_Nk64|={m:7.3%}  {'PASS' if m <= GATE_REL else 'FAIL (>0.1%)'}")
    npass = sum(1 for r in gate_rows if r["Nk64_passes"] == 1)
    print(f"\ngate rows: {len(gate_rows)};  Nk64 passes 0.1% on {npass}")


def _write(name, rows):
    if not rows:
        open(os.path.join(OUT, name), "w").close()
        return
    cols = list(rows[0].keys())
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader()
        w.writerows(rows)


if __name__ == "__main__":
    main()
