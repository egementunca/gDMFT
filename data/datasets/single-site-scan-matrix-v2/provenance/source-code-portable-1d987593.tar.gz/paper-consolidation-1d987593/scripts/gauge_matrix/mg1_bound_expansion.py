#!/usr/bin/env python3
"""Small Mg=1 bound-expansion check (Stage-3 requirement 7).

The Mg=1 h-sector escapes to the i-omega renormalizer (eta, W large); if a fitted
parameter rails against its bound the solution is bound_limited, not physically
converged. This re-solves a handful of Mg=1 bare points with the DEFAULT bounds
and with EXPANDED h-sector bounds, and reports whether the observables move
materially. If they do, those parameters are flagged bound_limited and must NOT
be labelled converged.

Writes mg1_bound_expansion.csv into deliverable 09. A few solves only (no scan).
"""
from __future__ import annotations

import csv
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(os.path.dirname(_HERE))
sys.path.insert(0, os.path.join(_ROOT, "scripts"))
sys.path.insert(0, _ROOT)

from scipy.optimize import least_squares  # noqa: E402
from BHFM2.core.solve_min import ModelParamsMin  # noqa: E402
import landscape_map as L  # noqa: E402
from gauge_matrix import scan_matrix as SM  # noqa: E402

OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")
MATERIAL = 1e-3          # relative change above which a parameter is bound_limited
# default and expanded Mg=1 bare bounds [V0, W, eta]
LO = SM.LO1
HI_DEFAULT = SM.HI1
HI_EXPANDED = np.array([5.0, 60.0, 80.0])       # double the h-sector ceilings


def _solve(x0, lo, hi, mp, mu):
    x0 = np.clip(x0, lo + 1e-9, hi - 1e-9)
    sol = least_squares(lambda x: L.residual_ph(SM.sym_spar_mg1(x, mu), mp, 1), x0,
                        method="trf", bounds=(lo, hi), ftol=1e-14, xtol=1e-14, max_nfev=3000)
    d = L.diagnose(SM.sym_spar_mg1(sol.x, mu), mp, 1)
    return sol, d


def main():
    os.makedirs(OUT, exist_ok=True)
    rows = []
    # representative points spanning weak..deep BR (both lattices)
    pts = [("bethe", 1.0, 0.001), ("bethe", 2.0, 0.001), ("bethe", 3.0, 0.001),
           ("bethe", 3.6, 0.001), ("square", 2.0, 0.001), ("square", 3.0, 0.001)]
    for lattice, ud, td in pts:
        U = (2.0 if lattice == "bethe" else 4.0) * ud * 0.5
        mu = U / 2.0
        T_code = td if lattice == "bethe" else 2.0 * td
        mp = SM.mp_for(lattice, U, T_code)
        s0, d0 = _solve(SM.METAL1_X0, LO, HI_DEFAULT, mp, mu)
        s1, d1 = _solve(s0.x, LO, HI_EXPANDED, mp, mu)
        active = [int(v) for v in np.asarray(s0.active_mask, int)]
        def rel(a, b):
            return abs(a - b) / max(abs(a), 1e-12)
        rZ, rD = rel(d0["Z_pole"], d1["Z_pole"]), rel(d0["D"], d1["D"])
        rZR = rel(d0["Z_fermi"], d1["Z_fermi"])      # forward-map Z = R_qp^2 (canonical)
        rOm = rel(d0["Omega"], d1["Omega"]) if np.isfinite(d0["Omega"]) else None
        material = (rZ > MATERIAL) or (rD > MATERIAL) or (rOm is not None and rOm > MATERIAL)
        rows.append(dict(
            lattice=lattice, U_over_D=ud, T_over_D=td,
            x_default=";".join(f"{v:.5g}" for v in s0.x),
            x_expanded=";".join(f"{v:.5g}" for v in s1.x),
            active_mask_default=";".join(map(str, active)),
            Z_pole_bare_default=d0["Z_pole"], Z_pole_bare_expanded=d1["Z_pole"], rel_dZ_bare=rZ,
            Z_R_default=d0["Z_fermi"], Z_R_expanded=d1["Z_fermi"], rel_dZ_R=rZR,
            D_default=d0["D"], D_expanded=d1["D"], rel_dD=rD, rel_dOmega=rOm,
            bound_limited=int(bool(material)),      # material change => cap/bound-limited
            active_at_bound=int(any(active)),
            observables_change_materially=int(bool(material)),
            verdict=("BARE bound_limited (cap-dependent runaway): do NOT label the "
                     "bare h-params converged; the cap-independent physics is the "
                     "canonical Z_R=R_qp^2" if material
                     else "expansion does not move observables materially -> converged")))
    cols = list(rows[0].keys())
    with open(os.path.join(OUT, "mg1_bound_expansion.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    print("mg1_bound_expansion.csv  (BARE pole-Z vs canonical Z_R=R_qp^2 under h-bound expansion):")
    for r in rows:
        print(f"  {r['lattice']:6s} U/D={r['U_over_D']:.1f}: "
              f"rel_dZ_bare={r['rel_dZ_bare']:.1e}  rel_dZ_R={r['rel_dZ_R']:.1e}  "
              f"bound_limited={r['bound_limited']}")
    n_mat = sum(r["observables_change_materially"] for r in rows)
    worst_bare = max(r["rel_dZ_bare"] for r in rows)
    print(f"\n{n_mat}/{len(rows)} points: the BARE Mg=1 h-parametrization is "
          f"bound/cap-LIMITED -- expanding the h-sector ceiling moves Z by up to "
          f"{worst_bare:.1%} along the nearly-flat i-omega renormalizer escape "
          f"(active_mask=0, so it is a flat-direction drift, not a rail). These "
          f"bare h-params are flagged bound_limited and NOT labelled converged.")
    print("NOTE: forward-mapping the same bare fit (rel_dZ_R == rel_dZ_bare) "
          "inherits the cap dependence. The cap-INDEPENDENT determination comes "
          "from an INDEPENDENT fit in R coordinates (R_reoptimized_from_bare / "
          "R_native_continuation, where R in [R_FLOOR, RF_HI] with no h-cap) -- "
          "which is exactly why those are stored as distinct evidence types.")


if __name__ == "__main__":
    main()
