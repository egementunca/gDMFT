#!/usr/bin/env python3
"""ED (finite-pole DMFT-ED) provenance layer for the gauge matrix.

Deterministic postprocessing of the EXISTING dmft_ed prototype outputs -- it
runs NO ED calculation, NO bath-fit optimizer, NO DMFT self-consistency loop.
It only:
  1. records the LLK (PhysRevB.107.L121104) configuration + the current
     prototype's deviations, and the T=0 ground-state semantics, exactly
     (ed_llk_config.json);
  2. splits the stored rows into an ACCEPTED view (converged only) and a
     lossless RAW view (all attempts, stalled retained) with ground-state
     temperature semantics stamped, so ED can never enter a finite-T join
     (ed_accepted.csv, ed_raw_attempts.csv).

The prototype's optimizer, objective, convergence, and Z prescription are
recorded verbatim (from scripts/dmft_ed_bench.py) so downstream code sees the
caveats -- notably that the CSV `fit_chi` is scipy `.cost` = HALF the weighted
chi-squared, and that the bath fit uses Levenberg-Marquardt, not the paper's
conjugate gradient. Reproducing the paper anchors and providing the CG route
are follow-up solver tasks that require explicit approval.
"""
from __future__ import annotations

import csv
import glob
import json
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(os.path.dirname(_HERE))
sys.path.insert(0, os.path.dirname(_HERE))

from gauge_matrix import sources as S  # noqa: E402

OUT = os.path.join(_ROOT, "results/deliverables/08_single_site_gauge_matrix")
RUNS = S.RUNS

ED_DIRS = {"bethe": "dmft_ed", "square": "dmft_ed_square"}


def llk_config():
    return dict(
        reference_paper="PhysRevB.107.L121104-accepted.pdf (LLK)",
        method="ground-state finite-pole DMFT-ED (dense sector diagonalization)",
        temperature_semantics=dict(
            temperature_semantics="ground_state", T_over_D=0, bath_fit_beta=200,
            note="beta=200 is a FICTITIOUS Matsubara bath-fit grid, NOT a "
                 "physical T/D=0.005. ED rows must never enter a finite-T "
                 "exact-key join; compare only with exact T=0 or clearly "
                 "labelled low-T approximations."),
        primary_budgets=[1, 3],
        optional_budget=5,
        out_of_scope_budget=7,
        budget_note="N_b={1,3} matched to M_g={1,3}; N_b=5 optional convergence "
                    "control (validate only if it materially supports the paper); "
                    "N_b=7 explicitly out of scope (4900-dim sectors).",
        lattice_scope=dict(
            bethe="LLK reproduction target (half-filled Bethe, D=1)",
            square="THIS WORK'S EXTENSION, not an LLK-paper reproduction; "
                   "square continuum elliptic DOS, separate research task."),
        bath_fit=dict(
            paper_optimizer="conjugate_gradient",
            prototype_optimizer="scipy.least_squares(method='lm')  "
                                "(Levenberg-Marquardt -- DEVIATES from paper CG)",
            fit_beta=200, Nw=200,
            fit_frequencies="Matsubara wn = (2n+1) pi / beta, n=0..Nw-1",
            weights="1/wn for N_b=1; uniform for N_b>1 (matches paper)",
            objective_convention=(
                "chi2 = sum_n w_n |Delta_fit(iwn) - Delta_target(iwn)|^2. "
                "The stored CSV column `fit_chi` is scipy `.cost` = 0.5*chi2 "
                "(HALF the weighted sum of squares) -- do NOT report it as an "
                "unqualified chi-squared."),
        ),
        dmft_acceptance=dict(
            convergence_gate="sup_n |Sigma'_new(iwn) - Sigma'(iwn)| < 1e-8",
            max_iterations=200, mixing=0.5,
            note="acceptance is on the self-energy fixed point only; the bath-fit "
                 "quality (fit_chi) is recorded but is NOT part of the gate. A "
                 "full acceptance should combine both; stalled rows (converged=0) "
                 "are preserved as raw attempts and excluded from accepted views."),
        Z_prescription=dict(
            prototype="Z = 1/(1 - Im Sigma'(iw0)/w0)  (single lowest-Matsubara "
                      "finite-difference; PH => Sigma'(0)=0)",
            paper="derivative prescription / documented low-frequency "
                  "extrapolation -- reconcile before an accuracy claim."),
        energy_conventions=dict(
            E_kin="2*T*sum_n (zeta*G_latt - 1) with a trigamma high-frequency "
                  "tail from the lattice Green function G_latt (NOT the finite "
                  "impurity-cluster G); U=0 Bethe anchor E_kin=-4/(3 pi)",
            E_tot="E_kin + U*docc",
            spectra_caveat="real-frequency A(w) in the prototype uses the finite "
                           "impurity-cluster Green function, not a lattice-DOS + "
                           "converged-Sigma reconstruction -- fix before an A(w) "
                           "accuracy claim."),
        hilbert_space_dims=dict(Nb1=4, Nb3=36, Nb5=400, Nb7_excluded=4900),
        solver="dense np.linalg.eigh (no Lanczos truncation for N_b<=5)",
        validation_status="PROTOTYPE. Unit tests for the impurity Hamiltonian, "
                          "Lehmann G, Dyson Sigma, causality, sum rules and PH "
                          "symmetry are in tests/test_dmft_ed.py. Paper-anchor "
                          "reproduction for N_b={1,3} and the CG bath-fit route "
                          "are pending solver runs (require approval).",
    )


def build_ed_views():
    acc_rows, raw_rows = [], []
    census = {}
    for lattice, sub in ED_DIRS.items():
        for f in sorted(glob.glob(os.path.join(RUNS, "20260715_paper_scans", sub,
                                               "dmft_ed_Nb*.csv"))):
            for r in csv.DictReader(open(f)):
                nb = int(r["Nb"])
                conv = r["converged"] in ("1", "True")
                row = dict(
                    lattice=lattice, N_b=nb,
                    U_over_D=r["U_over_D"], direction=r["direction"],
                    temperature_semantics="ground_state", T_over_D=0,
                    bath_fit_beta=200,
                    llk_role=("reproduction" if lattice == "bethe"
                              else "this_work_extension"),
                    Z=r["Z"], docc=r["docc"], ekin=r["ekin"], etot=r["etot"],
                    n_imp=r["n_imp"],
                    fit_cost_half_chi2=r["fit_chi"],  # scipy .cost = 0.5*chi2
                    dDelta=r["dDelta"], iters=r["iters"], converged=int(conv),
                    bath_optimizer="levenberg_marquardt",
                )
                raw_rows.append(row)
                census.setdefault((lattice, nb), [0, 0])
                census[(lattice, nb)][0] += 1
                if conv:
                    census[(lattice, nb)][1] += 1
                    acc_rows.append(row)
    cols = list(raw_rows[0].keys())
    for fn, rows in (("ed_accepted.csv", acc_rows),
                     ("ed_raw_attempts.csv", raw_rows)):
        with open(os.path.join(OUT, fn), "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=cols)
            w.writeheader()
            w.writerows(rows)
    return census


def main():
    os.makedirs(OUT, exist_ok=True)
    with open(os.path.join(OUT, "ed_llk_config.json"), "w") as f:
        json.dump(llk_config(), f, indent=2)
    census = build_ed_views()
    print("[ed] accepted/raw census by (lattice, N_b):  accepted / total")
    for k in sorted(census):
        tot, acc = census[k][0], census[k][1]
        print(f"    {k[0]:6s} Nb{k[1]}: {acc:3d} / {tot:3d}  "
              f"(stalled {tot - acc} excluded from accepted view)")


if __name__ == "__main__":
    main()
