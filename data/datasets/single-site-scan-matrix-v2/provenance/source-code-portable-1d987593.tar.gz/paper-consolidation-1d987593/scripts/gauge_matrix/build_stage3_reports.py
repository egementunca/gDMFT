#!/usr/bin/env python3
"""Deterministic Stage-3 reporting: coverage_after, unresolved_conditions,
scan_command_manifest, and a focused per-batch audit.

Reads whatever the scan-matrix runner has produced so far
(results/runs/20260717_scan_matrix/<cell>/T*.csv) plus the run registry, and
writes into deliverable 09:
  coverage_after.csv        keys attempted/converged per (cell) vs the grid
  unresolved_conditions.csv every non-converged / errored condition (explicit gap)
  scan_command_manifest.csv the exact command per cell + completion state
  stage3_audit.csv          row-conservation, R-conversion, no-selected checks

Idempotent; safe to re-run while the campaign is still in progress (it reports
completed vs queued). No solver runs.
"""
from __future__ import annotations

import csv
import glob
import hashlib
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SCAN = os.path.join(_ROOT, "results/runs/20260717_scan_matrix")
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")

CELLS = {
    "bethe_mg1_bare": ("bethe", 1, "bare_native", 884),
    "bethe_mg1_Rnative": ("bethe", 1, "R_native", 884),
    "bethe_mg3_Rnative": ("bethe", 3, "R_native", 884),
    "square_mg1_bare": ("square", 1, "bare_native", 400),
    "square_mg1_Rnative": ("square", 1, "R_native", 400),
    "square_mg3_bare": ("square", 3, "bare_native", 400),
    "square_mg3_Rnative": ("square", 3, "R_native", 400),
}
N_T = {"bethe": 17, "square": 10}


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def cell_rows(cell):
    rows = []
    for f in sorted(glob.glob(os.path.join(SCAN, cell, "T*.csv"))):
        rows.extend(csv.DictReader(open(f)))
    return rows


def main():
    os.makedirs(OUT, exist_ok=True)
    cov, unresolved, manifest, audit = [], [], [], []
    for cell, (lat, Mg, gauge, ngrid) in CELLS.items():
        tfiles = sorted(glob.glob(os.path.join(SCAN, cell, "T*.csv")))
        rows = cell_rows(cell)
        keys = set((round(float(r["U_over_D"]), 4), round(float(r["T_over_D"]), 6))
                   for r in rows)
        conv_keys = set((round(float(r["U_over_D"]), 4), round(float(r["T_over_D"]), 6))
                        for r in rows if r.get("converged") == "1")
        cov.append(dict(
            cell=cell, lattice=lat, M_g=Mg, gauge=gauge, grid_keys=ngrid,
            T_files_done=len(tfiles), T_files_total=N_T[lat],
            rows=len(rows), unique_keys=len(keys), converged_keys=len(conv_keys),
            complete=int(len(tfiles) == N_T[lat]),
            quadrature=("continuum_elliptic_dos" if lat == "square" else "bethe_semicircle")))
        # unresolved conditions (non-converged / errored) -- explicit gaps
        for r in rows:
            if r.get("converged") != "1":
                unresolved.append(dict(
                    cell=cell, lattice=lat, M_g=Mg, gauge=gauge,
                    U_over_D=r.get("U_over_D"), T_over_D=r.get("T_over_D"),
                    branch=r.get("branch"), resnorm=r.get("resnorm"),
                    error=r.get("error", ""), basin=r.get("basin", ""),
                    floor_limited=r.get("floor_limited", "")))
        manifest.append(dict(
            cell=cell, lattice=lat, M_g=Mg, gauge=gauge,
            command=f".venv-numba/bin/python3 scripts/gauge_matrix/scan_matrix.py --cell {cell}",
            output_dir=os.path.relpath(os.path.join(SCAN, cell), _ROOT),
            state=("complete" if len(tfiles) == N_T[lat]
                   else ("in_progress" if tfiles else "queued")),
            T_done=len(tfiles), T_total=N_T[lat]))
        # focused audit
        no_sel = all(r.get("selected", "") in ("", "None") for r in rows)
        has_R = all(("Z_pole_from_R" in r) for r in rows[:50]) if rows else True
        modes_ok = all(r.get("n_modes") in ("3", None, "") for r in rows[:200])
        audit.append(dict(
            cell=cell, rows=len(rows),
            never_selected=int(no_sel),
            R_conversion_present=int(has_R),
            n_modes_all_3=int(modes_ok),
            T_files=len(tfiles)))

    _write("coverage_after.csv", cov)
    _write("unresolved_conditions.csv", unresolved)
    _write("scan_command_manifest.csv", manifest)
    _write("stage3_audit.csv", audit)
    done = sum(c["complete"] for c in cov)
    print(f"cells complete: {done}/{len(CELLS)}")
    for c in cov:
        print(f"  {c['cell']:22s} {c['T_files_done']}/{c['T_files_total']} T "
              f"rows={c['rows']:5d} conv_keys={c['converged_keys']:4d} "
              f"{'COMPLETE' if c['complete'] else 'partial'}")
    print(f"unresolved conditions: {len(unresolved)}")


def _write(name, rows):
    if not rows:
        with open(os.path.join(OUT, name), "w") as f:
            f.write("")
        return
    cols = list(rows[0].keys())
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


if __name__ == "__main__":
    main()
