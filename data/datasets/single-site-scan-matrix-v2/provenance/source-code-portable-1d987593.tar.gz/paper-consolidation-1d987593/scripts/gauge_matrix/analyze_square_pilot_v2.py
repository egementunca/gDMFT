#!/usr/bin/env python3
"""Analyze the Stage-1 pilot v2 -> convergence + claim gate across the FULL grid.

Deterministic postprocessing of square_pilot_v2_raw.csv. Unlike the v1 summary
(cold metal only), this applies the gate across BOTH temperatures, BOTH branches,
BOTH M_g, and BOTH solver routes (bare_native + R_native). continuum_elliptic_dos
is the reference. Reports signed absolute + relative + scale-aware differences of
each uniform_kmesh route from the continuum, per observable.

Writes into deliverable 09:
  square_stationary_convergence_v2.csv   (per Mg/gauge/branch/U/T/observable)
  square_claim_gate_v2.csv               (Nk64 gate verdict per row)
"""
from __future__ import annotations

import csv
import math
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")
RAW = os.path.join(OUT, "square_pilot_v2_raw.csv")
OBS = ["Z_pole", "Z_mats", "D_occ", "n", "Omega_over_D", "E_kin_over_D",
       "E_pot_over_D", "E_tot_over_D"]
GATE = 0.001
NK_NODES = {"16": 256, "32": 1024, "64": 4096}


def _f(x):
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def main():
    rows = [r for r in csv.DictReader(open(RAW)) if r.get("converged") == "1"]
    groups = {}
    for r in rows:
        k = (r["M_g"], r["gauge"], r["branch"], r["U_over_D"], r["T_over_D"])
        groups.setdefault(k, {})[(r["quadrature"], r.get("Nk", ""))] = r
    conv, gate = [], []
    for (Mg, gauge, branch, ud, td), byq in sorted(groups.items()):
        ref = byq.get(("continuum_elliptic_dos", ""))
        if ref is None:
            continue
        for obs in OBS:
            vref = _f(ref.get(obs))
            if vref is None or not math.isfinite(vref):
                continue
            scale = max(abs(vref), 0.05)
            row = dict(M_g=Mg, gauge=gauge, branch=branch, U_over_D=ud, T_over_D=td,
                       observable=obs, value_continuum=vref,
                       continuum_nodes=ref.get("integration_nodes"))
            for nk in ("16", "32", "64"):
                rr = byq.get(("uniform_kmesh", nk))
                v = _f(rr.get(obs)) if rr else None
                if v is not None:
                    row[f"value_Nk{nk}"] = v
                    row[f"abs_Nk{nk}"] = v - vref
                    row[f"rel_Nk{nk}"] = (v - vref) / vref if vref else None
                    row[f"scaleaware_Nk{nk}"] = (v - vref) / scale
            conv.append(row)
            r64 = row.get("rel_Nk64")
            gate.append(dict(M_g=Mg, gauge=gauge, branch=branch, U_over_D=ud,
                             T_over_D=td, observable=obs, value_continuum=vref,
                             rel_Nk64=r64, scaleaware_Nk64=row.get("scaleaware_Nk64"),
                             gate_tol=GATE,
                             Nk64_passes=(int(abs(r64) <= GATE) if r64 is not None else ""),
                             note=("near-Z=0: use scale-aware" if abs(vref) < 0.05 else "")))
    _w("square_stationary_convergence_v2.csv", conv)
    _w("square_claim_gate_v2.csv", gate)
    # summary across the FULL grid, per observable, worst Nk64 rel error (metal)
    print("Nk64-vs-continuum worst |rel| across ALL converged metal rows "
          f"(both Mg, both gauges, both T); gate {GATE:.1%}:")
    by = {}
    for r in conv:
        if r["branch"] != "metal":
            continue
        v = r.get("rel_Nk64")
        if v is not None and math.isfinite(v):
            by.setdefault(r["observable"], []).append(abs(v))
    for o in OBS:
        if by.get(o):
            m = max(by[o])
            print(f"  {o:16s} worst|rel_Nk64|={m:7.3%}  {'PASS' if m <= GATE else 'FAIL(>0.1%)'}")
    npass = sum(1 for g in gate if g["Nk64_passes"] == 1)
    print(f"\ngate rows: {len(gate)}; Nk64 passes on {npass}")


def _w(name, rows):
    if not rows:
        open(os.path.join(OUT, name), "w").close(); return
    cols = list(rows[0].keys())
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


if __name__ == "__main__":
    main()
