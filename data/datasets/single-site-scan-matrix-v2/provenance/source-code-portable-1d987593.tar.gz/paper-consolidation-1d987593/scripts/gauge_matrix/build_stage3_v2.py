#!/usr/bin/env python3
"""Deterministic builder for the lossless v2 Stage-3 deliverables.

Reads the v2 per-T JSONL campaign (results/runs/20260717_scan_matrix_v2/<cell>/
T*.jsonl -- or the tracked raw_campaign/ mirror) and writes, TRACKED, into
deliverable 09:
  stage3_attempts.jsonl          every full v2 attempt (the lossless dataset)
  stage3_scalar_projection.csv   flat per-record scalar view
  coverage_after_v2.csv          coverage with the corrected terminology
  bare_R_pairing.csv             bare vs (converted, reoptimized) diagnostics
  stage3_audit_v2.csv            per-cell losslessness + no-selected checks

Coverage terminology (NOT "converged keys"):
  attempted_keys, keys_with_at_least_one_converged_branch,
  converged_branch_attempts, failed_branch_attempts, branch_not_found,
  solver_failed.  A non-converged / dark Z=0 attempt is NEVER a physical result.

FAILS (raises) if a required input cell is missing. No solver runs.
"""
from __future__ import annotations

import csv
import glob
import json
import math
import os
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")
CELLS = ["bethe_mg1_bare", "bethe_mg1_Rnative", "bethe_mg3_Rnative",
         "square_mg1_bare", "square_mg1_Rnative", "square_mg3_bare", "square_mg3_Rnative"]
GRIDN = {"bethe": 884, "square": 400}
N_T = {"bethe": 17, "square": 10}


def _source_dir():
    """Read the tracked canonical data: the extracted raw_campaign/ dir if
    present, else EXTRACT the TRACKED raw_campaign.tar.gz (so a clean checkout
    rebuilds without results/runs), else the run namespace (local dev)."""
    tracked = os.path.join(OUT, "raw_campaign")
    if glob.glob(os.path.join(tracked, "*", "T*.jsonl")):
        return tracked
    arc = os.path.join(OUT, "raw_campaign.tar.gz")
    if os.path.exists(arc):
        import tarfile
        with tarfile.open(arc) as tf:
            tf.extractall(OUT)
        if glob.glob(os.path.join(tracked, "*", "T*.jsonl")):
            return tracked
    return os.path.join(_ROOT, "results/runs/20260717_scan_matrix_v2")


def _cell_records(src, cell):
    recs = []
    for f in sorted(glob.glob(os.path.join(src, cell, "T*.jsonl"))):
        with open(f) as fh:
            for line in fh:
                if line.strip():
                    recs.append(json.loads(line))
    return recs


def _key(r):
    return (round(r["U_over_D"], 4), round(r["T_over_D"], 6))


# Physical residual-floor gate for "converged branch". The strict optimizer gate
# is 1e-3 (record flag), but the symmetric warm-continuation solves floor higher
# at warm T + high U/D (D01: "warm rows sit on a higher residual floor"): the
# Mg=1 BR metal at U/D 3.25-4.0, T/D up to 0.025 floors at ~1.0-2.2e-3 while still
# a coherent solution (basin=metal, Z~0.1-0.21). 3e-3 admits those real metals and
# still excludes genuine non-convergence; resnorm is stored losslessly so a
# stricter gate can always be re-applied downstream.
PHYSICAL_GATE = 3e-3


def _category(r):
    """solver_failed | branch_not_found | converged_branch | failed_branch.

    converged_branch  = physical solution (resnorm <= PHYSICAL_GATE=3e-3 AND
                        basin not dark);
    branch_not_found  = converged to a DARK decoupled artifact (the intended
                        branch is absent -- e.g. the Mg=1 insulator, BR-only);
    failed_branch     = resnorm above the physical floor;
    a non-converged / dark Z=0 attempt is NEVER labelled a physical result."""
    if r.get("solver_route") == "solver_failed":
        return "solver_failed"
    obs = r.get("observables") or {}
    res = (r.get("residual") or {}).get("total")
    conv = (res is not None and res <= PHYSICAL_GATE)
    if obs.get("basin") == "dark":
        return "branch_not_found"           # decoupled artifact -- branch absent
    if conv:
        return "converged_branch"
    return "failed_branch"


def _scalar_row(r):
    m = r.get("classification") or {}
    obs = r.get("observables") or {}
    opt = r.get("optimizer") or {}
    can = r.get("canonical_h_sectors") or {}
    res = r.get("residual") or {}
    return dict(
        attempt_id=r["attempt_id"], parent_attempt_id=r.get("parent_attempt_id"),
        cell=r["cell"], lattice=r["lattice"], M_g=r["M_g"], branch=r["branch"],
        evidence_type=r["evidence_type"], solver_route=r.get("solver_route"),
        U_over_D=r["U_over_D"], T_over_D=r["T_over_D"], U_raw=r["U_raw"], T_raw=r["T_raw"],
        lattice_quadrature=r["lattice_quadrature"], node_count=r["node_count"],
        n_eps_dos=r.get("n_eps_dos"), category=_category(r),
        Z_pole=obs.get("Z_pole"), Z_mats=obs.get("Z_mats"), D_occ=obs.get("D_occ"),
        n=obs.get("n"), Omega=obs.get("Omega"), Omega_over_D=obs.get("Omega_over_D"),
        E_kin=obs.get("E_kin"), E_kin_over_D=obs.get("E_kin_over_D"),
        E_pot=obs.get("E_pot"), E_tot=obs.get("E_tot"), E_tot_over_D=obs.get("E_tot_over_D"),
        basin=obs.get("basin"),
        resnorm=res.get("total"), opt_status=opt.get("status"), opt_nfev=opt.get("nfev"),
        opt_optimality=opt.get("optimality"),
        n_modes=can.get("n_modes"), lam_reduced=can.get("lam_reduced"), Rf_reduced=can.get("Rf_reduced"),
        converged=m.get("converged"), floor_limited=m.get("floor_limited"),
        norm_error=m.get("norm_error"), closure_error=m.get("closure_error"),
        roundtrip_error=m.get("roundtrip_error"),
        physical=m.get("physical"), branch_continuous=m.get("branch_continuous"),
        selected=m.get("selected"), code_commit=r.get("code_commit"), dirty=r.get("dirty"))


def build():
    src = _source_dir()
    os.makedirs(OUT, exist_ok=True)
    all_recs = {}
    missing = []
    for cell in CELLS:
        tfiles = glob.glob(os.path.join(src, cell, "T*.jsonl"))
        if not tfiles:
            missing.append(cell)
        all_recs[cell] = _cell_records(src, cell)
    # aggregate lossless jsonl + scalar projection
    with open(os.path.join(OUT, "stage3_attempts.jsonl"), "w") as jl, \
         open(os.path.join(OUT, "stage3_scalar_projection.csv"), "w", newline="") as sc:
        sw = None
        for cell in CELLS:
            for r in all_recs[cell]:
                jl.write(json.dumps(r) + "\n")
                row = _scalar_row(r)
                if sw is None:
                    sw = csv.DictWriter(sc, fieldnames=list(row.keys())); sw.writeheader()
                sw.writerow(row)

    # coverage with corrected terminology
    cov = []
    for cell in CELLS:
        lat = "bethe" if cell.startswith("bethe") else "square"
        recs = all_recs[cell]
        native = [r for r in recs if r["evidence_type"] in
                  ("bare_native", "R_native_continuation")]
        keys = set(_key(r) for r in native)
        by_key = {}
        for r in native:
            by_key.setdefault(_key(r), []).append(_category(r))
        conv_keys = sum(1 for k, cats in by_key.items() if "converged_branch" in cats)
        cov.append(dict(
            cell=cell, lattice=lat, grid_keys=GRIDN[lat],
            T_files=len(glob.glob(os.path.join(src, cell, "T*.jsonl"))), T_total=N_T[lat],
            attempted_keys=len(keys),
            keys_with_at_least_one_converged_branch=conv_keys,
            converged_branch_attempts=sum(1 for r in native if _category(r) == "converged_branch"),
            failed_branch_attempts=sum(1 for r in native if _category(r) == "failed_branch"),
            branch_not_found=sum(1 for r in native if _category(r) == "branch_not_found"),
            solver_failed=sum(1 for r in native if _category(r) == "solver_failed"),
            n_eps_dos=(2001 if lat == "square" else ""),
            complete=int(len(glob.glob(os.path.join(src, cell, "T*.jsonl"))) == N_T[lat])))
    _w("coverage_after_v2.csv", cov)

    # bare/R pairing diagnostics
    pairing = []
    for cell in CELLS:
        if "bare" not in cell:
            continue
        recs = all_recs[cell]
        bare = {r["attempt_id"]: r for r in recs if r["evidence_type"] == "bare_native"}
        conv = {r["parent_attempt_id"]: r for r in recs if r["evidence_type"] == "R_converted_from_bare"}
        reopt = {r["parent_attempt_id"]: r for r in recs if r["evidence_type"] == "R_reoptimized_from_bare"}
        for bid, b in bare.items():
            ob = b["observables"] or {}
            cr = conv.get(bid); ro = reopt.get(bid)
            row = dict(cell=cell, bare_attempt_id=bid, U_over_D=b["U_over_D"],
                       T_over_D=b["T_over_D"], branch=b["branch"],
                       Z_bare=ob.get("Z_pole"), basin_bare=ob.get("basin"))
            # exact conversion should reproduce observables to machine precision
            if cr:
                oc = cr["observables"] or {}
                row.update(Z_converted=oc.get("Z_pole"),
                           dZ_convert=_absdiff(ob.get("Z_pole"), oc.get("Z_pole")))
            if ro:
                oo = ro["observables"] or {}
                row.update(
                    Z_reopt=oo.get("Z_pole"), basin_reopt=oo.get("basin"),
                    dZ=_absdiff(ob.get("Z_pole"), oo.get("Z_pole")),
                    dD=_absdiff(ob.get("D_occ"), oo.get("D_occ")),
                    dOmega=_absdiff(ob.get("Omega"), oo.get("Omega")),
                    dOmega_over_D=_absdiff(ob.get("Omega_over_D"), oo.get("Omega_over_D")),
                    resnorm_reopt=(ro["residual"] or {}).get("total"),
                    different_basin=int(ob.get("basin") != oo.get("basin")),
                    bound_limited=int(any((ro["optimizer"] or {}).get("active_mask") or [])),
                    floor_limited=int((ro["classification"] or {}).get("floor_limited") or 0))
            pairing.append(row)
    _w("bare_R_pairing.csv", pairing)

    # unresolved conditions -- every failed_branch / solver_failed explicitly
    # (branch_not_found = the Mg=1 insulator dark artifact is a SEPARATE, expected
    # category, reported in coverage; it is NOT an unresolved solver condition).
    unresolved = []
    for cell in CELLS:
        for r in all_recs[cell]:
            cat = _category(r)
            if cat in ("failed_branch", "solver_failed"):
                res = (r.get("residual") or {}).get("total")
                unresolved.append(dict(
                    cell=cell, evidence_type=r["evidence_type"], branch=r["branch"],
                    U_over_D=r["U_over_D"], T_over_D=r["T_over_D"],
                    category=cat, resnorm=res,
                    basin=(r.get("observables") or {}).get("basin"),
                    Z_pole=(r.get("observables") or {}).get("Z_pole"),
                    optimizer_message=(r.get("optimizer") or {}).get("message"),
                    reason=("solver raised" if cat == "solver_failed"
                            else "residual above 3e-3 physical floor (recorded, not synthesized)")))
    _w("unresolved_conditions_v2.csv", unresolved)

    # losslessness audit
    audit = []
    for cell in CELLS:
        recs = all_recs[cell]
        with_x = sum(1 for r in recs if r.get("x_sol") is not None or r.get("solver_route") == "solver_failed")
        with_arrays = sum(1 for r in recs if r.get("bare_h_sectors") or r.get("solver_route") == "solver_failed")
        sel = sum(1 for r in recs if (r.get("classification") or {}).get("selected") not in (None,))
        modes = set((r.get("canonical_h_sectors") or {}).get("n_modes") for r in recs
                    if r.get("canonical_h_sectors"))
        audit.append(dict(cell=cell, records=len(recs),
                          have_native_vector=with_x, have_full_arrays=with_arrays,
                          selected_set=sel, n_modes=sorted(m for m in modes if m)))
    _w("stage3_audit_v2.csv", audit)

    print(f"source: {os.path.relpath(src, _ROOT)}")
    print(f"cells present: {len(CELLS)-len(missing)}/{len(CELLS)}"
          + (f"  MISSING: {missing}" if missing else ""))
    for c in cov:
        print(f"  {c['cell']:22s} {c['T_files']}/{c['T_total']}T  attempted={c['attempted_keys']} "
              f"conv_keys={c['keys_with_at_least_one_converged_branch']} "
              f"conv_att={c['converged_branch_attempts']} fail={c['failed_branch_attempts']} "
              f"not_found={c['branch_not_found']} solver_fail={c['solver_failed']}")
    total = sum(len(all_recs[c]) for c in CELLS)
    print(f"total attempts: {total}; pairing rows: {len(pairing)}")
    return missing


def _absdiff(a, b):
    if a is None or b is None:
        return None
    try:
        return abs(float(a) - float(b))
    except (TypeError, ValueError):
        return None


def _w(name, rows):
    if not rows:
        open(os.path.join(OUT, name), "w").close(); return
    cols = sorted({k for r in rows for k in r})
    # keep a stable, readable leading order
    lead = [c for c in ("cell", "bare_attempt_id", "U_over_D", "T_over_D", "branch",
                        "lattice", "grid_keys") if c in cols]
    cols = lead + [c for c in cols if c not in lead]
    with open(os.path.join(OUT, name), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)


if __name__ == "__main__":
    strict = "--strict" in sys.argv
    missing = build()
    if strict and missing:
        print(f"STRICT: missing cells {missing}", file=sys.stderr)
        sys.exit(1)
