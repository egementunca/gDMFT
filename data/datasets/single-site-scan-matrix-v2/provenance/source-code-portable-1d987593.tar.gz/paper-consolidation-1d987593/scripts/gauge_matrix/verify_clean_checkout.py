#!/usr/bin/env python3
"""Clean-checkout rebuild verification (Stage-3 requirement 7).

Proves a clean temporary checkout can REBUILD and VERIFY D08/D09 WITHOUT the
gitignored local run files (results/runs/). With ``--commit SHA``, it exports
that exact Git tree into a temporary directory. Without ``--commit``, it copies
the current scoped trees for a pre-commit check. It then:
  1. rebuilds the D09 tables with build_stage3_v2.py, which reads the TRACKED
     raw_campaign/ mirror (not results/runs/);
  2. runs the v2 acceptance tests, the D08 acceptance tests, and the ED tests.
Any failure that depends on results/runs/ is a real defect (the canonical data
must be tracked). D08's raw-byte-identity check self-skips when the gitignored
sources are absent (that check is out of scope for a clean checkout).

Usage:
  .venv-numba/bin/python3 scripts/gauge_matrix/verify_clean_checkout.py
  .venv-numba/bin/python3 scripts/gauge_matrix/verify_clean_checkout.py --commit SHA
"""
from __future__ import annotations

import argparse
import os
import shutil
import subprocess
import sys
import tarfile
import tempfile

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
PY = sys.executable
TRACKED = ["BHFM2", "scripts", "tests",
           "results/deliverables/08_single_site_gauge_matrix",
           "results/deliverables/09_single_site_publication_validation"]


def _copy(src, dst):
    if os.path.isdir(src):
        # Simulate a real checkout: copy only TRACKED files -- exclude the
        # gitignored regenerable artifacts (the extracted raw_campaign/ dir and
        # the large stage3_attempts.jsonl). raw_campaign.tar.gz IS copied; the
        # builder must extract it. D08's expanded roots.jsonl is likewise
        # ignored; its tests stream the tracked roots.jsonl.gz archive.
        shutil.copytree(src, dst, symlinks=False,
                        ignore=shutil.ignore_patterns(
                            "__pycache__", "*.pyc", "raw_campaign",
                            "stage3_attempts.jsonl", "roots.jsonl"))
    else:
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(src, dst)


def _run(tmp, args):
    env = dict(os.environ)
    env["PYTHONPATH"] = os.path.join(tmp, "scripts") + os.pathsep + tmp
    p = subprocess.run([PY] + args, cwd=tmp, env=env, capture_output=True, text=True)
    return p.returncode, (p.stdout + p.stderr)


def _export_commit(tmp, revision):
    commit = subprocess.check_output(
        ["git", "-C", _ROOT, "rev-parse", f"{revision}^{{commit}}"],
        text=True).strip()
    archive = os.path.join(tempfile.gettempdir(), f"gauge_verify_{commit}.tar")
    try:
        subprocess.check_call(
            ["git", "-C", _ROOT, "archive", "--format=tar",
             f"--output={archive}", commit])
        with tarfile.open(archive) as tf:
            tf.extractall(tmp)
    finally:
        if os.path.exists(archive):
            os.remove(archive)
    return commit


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--commit", metavar="SHA",
        help="verify an exact committed tree instead of the current scoped files")
    args = parser.parse_args()

    tmp = tempfile.mkdtemp(prefix="clean_checkout_")
    print(f"clean checkout root: {tmp}")
    try:
        if args.commit:
            commit = _export_commit(tmp, args.commit)
            print(f"exported exact commit: {commit}")
        else:
            commit = None
            for rel in TRACKED:
                src = os.path.join(_ROOT, rel)
                if os.path.exists(src):
                    _copy(src, os.path.join(tmp, rel))
        assert not os.path.exists(os.path.join(tmp, "results", "runs")), \
            "results/runs must NOT be present in the clean checkout"
        print("copied tracked trees; results/runs is ABSENT (as intended)\n")

        checks = []
        # 1. rebuild D09 tables from the tracked raw_campaign (no results/runs)
        rc, out = _run(tmp, ["scripts/gauge_matrix/build_stage3_v2.py", "--strict"])
        checks.append(("rebuild D09 from tracked raw_campaign", rc == 0, out.strip().splitlines()[-1] if out.strip() else ""))
        # 2. v2 acceptance tests
        rc, out = _run(tmp, ["tests/test_stage3_v2.py"])
        checks.append(("v2 acceptance tests", rc == 0, out.strip().splitlines()[-1] if out.strip() else ""))
        # 3. D08 acceptance tests (raw-byte check self-skips)
        rc, out = _run(tmp, ["tests/test_gauge_matrix.py"])
        checks.append(("D08 acceptance tests", rc == 0, out.strip().splitlines()[-1] if out.strip() else ""))
        # 4. ED unit tests
        rc, out = _run(tmp, ["tests/test_dmft_ed.py"])
        checks.append(("ED unit tests", rc == 0, out.strip().splitlines()[-1] if out.strip() else ""))

        ok = all(c[1] for c in checks)
        print("=== clean-checkout verification ===")
        for name, passed, tail in checks:
            print(f"  [{'PASS' if passed else 'FAIL'}] {name}   {tail}")
        if commit:
            print(f"\nverified commit: {commit}")
        print(f"\n{'ALL CLEAN-CHECKOUT CHECKS PASS' if ok else 'CLEAN-CHECKOUT VERIFICATION FAILED'}")
        return 0 if ok else 1
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


if __name__ == "__main__":
    sys.exit(main())
