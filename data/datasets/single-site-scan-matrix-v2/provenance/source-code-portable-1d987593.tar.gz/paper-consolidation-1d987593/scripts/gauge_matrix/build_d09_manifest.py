#!/usr/bin/env python3
"""Comprehensive, reproducibility-grade source manifest for deliverable 09.

Hashes EVERYTHING the D09 results depend on: solver code, builders/scanners,
tests, the LLK PDF, every raw run artifact, and the dirty working-tree patch
state (so an uncommitted result is never presented as reproducible-from-a-commit
without the patch). Idempotent; re-run after each batch.
"""
from __future__ import annotations

import csv
import glob
import hashlib
import os
import subprocess

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")


def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _sha_str(s):
    return hashlib.sha256(s.encode()).hexdigest()


CODE = [
    "BHFM2/core/solve_min.py", "BHFM2/core/canonical_gauge.py",
    "BHFM2/core/reparam_R.py",
    "scripts/dmft_ed_llk.py", "scripts/dmft_ed_bench.py",
    "scripts/symmetric_continuation.py", "scripts/symmetric_continuation_R.py",
    "scripts/landscape_map.py",
]
BUILDERS = sorted(glob.glob(os.path.join(_ROOT, "scripts/gauge_matrix/*.py")))
TESTS = ["tests/test_gauge_matrix.py", "tests/test_dmft_ed.py"]
PDF = "refs/PhysRevB.107.L121104-accepted.pdf"
PATCH_PATHS = ["BHFM2/core/solve_min.py"]


def main():
    os.makedirs(OUT, exist_ok=True)
    commit = subprocess.check_output(["git", "-C", _ROOT, "rev-parse", "HEAD"], text=True).strip()
    # Preserve only the tracked solver change used by this campaign. Other
    # worktree changes are unrelated and must not leak into this scoped bundle.
    diff = subprocess.check_output(
        ["git", "-C", _ROOT, "diff", "HEAD", "--", *PATCH_PATHS], text=True)
    dirty = "dirty" if diff else "clean"
    patch_sha = _sha_str(diff)
    with open(os.path.join(OUT, "dirty_patch.diff"), "w") as f:
        f.write(diff)

    rows = []

    def add(role, path):
        if os.path.exists(path):
            rows.append(dict(role=role, path=os.path.relpath(path, _ROOT) if path.startswith(_ROOT) else path,
                             sha256=_sha(path), bytes=os.path.getsize(path),
                             code_commit=commit, dirty_state=dirty))

    for p in CODE:
        add("solver_code", os.path.join(_ROOT, p))
    for p in BUILDERS:
        add("builder", p)
    for p in TESTS:
        add("test", os.path.join(_ROOT, p))
    add("reference_pdf", PDF)
    add("canonical_archive", os.path.join(OUT, "raw_campaign.tar.gz"))
    # raw run artifacts
    for f in sorted(glob.glob(os.path.join(_ROOT, "results/runs/20260717_scan_matrix/*/T*.csv"))):
        add("scan_run", f)
    for f in sorted(glob.glob(os.path.join(_ROOT, "results/runs/20260717_ed_llk/*.csv"))):
        add("ed_run", f)
    for f in sorted(glob.glob(os.path.join(_ROOT, "results/runs/20260717_square_resolution/*.csv"))):
        add("pilot_run", f)
    # D09 derived tables
    for f in sorted(glob.glob(os.path.join(OUT, "*.csv"))) + sorted(glob.glob(os.path.join(OUT, "*.json"))):
        if os.path.basename(f) != "source_manifest.csv":
            add("d09_output", f)
    # the dirty patch itself
    rows.append(dict(role="dirty_patch", path="results/deliverables/09_single_site_publication_validation/dirty_patch.diff",
                     sha256=patch_sha, bytes=len(diff.encode()),
                     code_commit=commit, dirty_state=dirty))

    cols = ["role", "path", "sha256", "bytes", "code_commit", "dirty_state"]
    with open(os.path.join(OUT, "source_manifest.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    import collections
    by = collections.Counter(r["role"] for r in rows)
    print(f"source_manifest.csv: {len(rows)} entries; commit {commit[:8]} ({dirty}); "
          f"patch sha {patch_sha[:12]}")
    for k, v in sorted(by.items()):
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
