#!/usr/bin/env python3
"""stage3_source_manifest.csv -- fail-on-missing, reproducibility-grade hashing.

Hashes solver code, builders, tests, the LLK PDF, the TRACKED raw_campaign
mirror, the aggregate stage3_attempts.jsonl, every D09 output, and the dirty
patch. FAILS (exit 1) if any REQUIRED input is missing -- the 7 registered
cells' tracked per-T JSONL, stage3_attempts.jsonl, the node certification, and
the LLK PDF. Also de-duplicates the promoted run registry (keeping the last row
per (cell, T)) so a resumed batch never leaves a stale duplicate row.
"""
from __future__ import annotations

import csv
import glob
import hashlib
import os
import subprocess
import sys

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")
RAW = os.path.join(OUT, "raw_campaign")
CELLS = ["bethe_mg1_bare", "bethe_mg1_Rnative", "bethe_mg3_Rnative",
         "square_mg1_bare", "square_mg1_Rnative", "square_mg3_bare", "square_mg3_Rnative"]
N_T = {"bethe": 17, "square": 10}
PDF = "refs/PhysRevB.107.L121104-accepted.pdf"
PATCH_PATHS = ["BHFM2/core/solve_min.py"]


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _dedup_registry():
    reg = os.path.join(RAW, "scan_run_registry.csv")
    if not os.path.exists(reg):
        return 0
    rows = list(csv.DictReader(open(reg)))
    if not rows:
        return 0
    seen, out = {}, []
    for r in rows:
        seen[(r["cell"], r["T_over_D"])] = r      # last wins
    out = list(seen.values())
    removed = len(rows) - len(out)
    if removed:
        with open(reg, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            w.writeheader(); w.writerows(out)
    return removed


def main():
    strict = "--nostrict" not in sys.argv
    removed = _dedup_registry()
    # required inputs
    missing = []
    for cell in CELLS:
        lat = "bethe" if cell.startswith("bethe") else "square"
        n = len(glob.glob(os.path.join(RAW, cell, "T*.jsonl")))
        if n < N_T[lat]:
            missing.append(f"{cell} ({n}/{N_T[lat]} T-files in tracked raw_campaign)")
    for req in ("raw_campaign.tar.gz", "stage3_attempts.jsonl",
                "square_node_certification.json"):
        if not os.path.exists(os.path.join(OUT, req)):
            missing.append(req)
    if not os.path.exists(PDF):
        missing.append("LLK PDF")

    commit = subprocess.check_output(["git", "-C", _ROOT, "rev-parse", "HEAD"], text=True).strip()
    # This is an execution-state patch, not a dump of the unrelated dirty
    # worktree. Untracked builders/tests are hashed individually below.
    diff = subprocess.check_output(
        ["git", "-C", _ROOT, "diff", "HEAD", "--", *PATCH_PATHS], text=True)
    with open(os.path.join(OUT, "dirty_patch.diff"), "w") as f:
        f.write(diff)
    patch_sha = hashlib.sha256(diff.encode()).hexdigest()

    rows = []

    def add(role, path):
        if os.path.exists(path):
            rows.append(dict(role=role,
                             path=os.path.relpath(path, _ROOT) if path.startswith(_ROOT) else path,
                             sha256=_sha(path), bytes=os.path.getsize(path),
                             code_commit=commit))

    for p in ("BHFM2/core/solve_min.py", "BHFM2/core/canonical_gauge.py",
              "BHFM2/core/reparam_R.py", "scripts/dmft_ed_llk.py",
              "scripts/symmetric_continuation.py", "scripts/symmetric_continuation_R.py",
              "scripts/landscape_map.py"):
        add("solver_code", os.path.join(_ROOT, p))
    for p in sorted(glob.glob(os.path.join(_ROOT, "scripts/gauge_matrix/*.py"))):
        add("builder", p)
    for p in ("tests/test_gauge_matrix.py", "tests/test_dmft_ed.py",
              "tests/test_stage3_v2.py"):
        add("test", os.path.join(_ROOT, p))
    add("reference_pdf", PDF)
    add("canonical_archive", os.path.join(OUT, "raw_campaign.tar.gz"))
    for f in sorted(glob.glob(os.path.join(RAW, "**", "T*.jsonl"), recursive=True)):
        add("raw_campaign", f)
    for f in sorted(glob.glob(os.path.join(RAW, "**", "*.csv"), recursive=True)):
        add("raw_registry", f)
    for f in (sorted(glob.glob(os.path.join(OUT, "*.csv")))
              + sorted(glob.glob(os.path.join(OUT, "*.json")))
              + sorted(glob.glob(os.path.join(OUT, "*.jsonl")))):
        if os.path.basename(f) != "stage3_source_manifest.csv":
            add("d09_output", f)
    rows.append(dict(role="dirty_patch",
                     path="results/deliverables/09_single_site_publication_validation/dirty_patch.diff",
                     sha256=patch_sha, bytes=len(diff.encode()), code_commit=commit))

    cols = ["role", "path", "sha256", "bytes", "code_commit"]
    with open(os.path.join(OUT, "stage3_source_manifest.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    import collections
    by = collections.Counter(r["role"] for r in rows)
    print(f"stage3_source_manifest.csv: {len(rows)} entries; commit {commit[:8]}; "
          f"patch {patch_sha[:12]}; deduped {removed} stale registry row(s)")
    for k, v in sorted(by.items()):
        print(f"  {k}: {v}")
    if missing:
        print("\nMISSING REQUIRED INPUTS:", file=sys.stderr)
        for m in missing:
            print("  -", m, file=sys.stderr)
        if strict:
            sys.exit(1)


if __name__ == "__main__":
    main()
