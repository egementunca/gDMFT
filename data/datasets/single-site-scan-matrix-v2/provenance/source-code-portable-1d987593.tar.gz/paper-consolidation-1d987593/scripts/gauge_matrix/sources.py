#!/usr/bin/env python3
"""Lossless source registry + normalizing loaders for the gauge-matrix export.

Every live source of the {bethe,square} x {Mg=1,Mg=3} x {bare, canonical R}
single-site study is described here ONCE, with its checksum, campaign, evidence
type and unit convention. Loaders normalize each on-disk format into a common
``BareRoot`` (a bare_native solution with both h-sectors) or ``REvidence`` (an
independent R-gauge record), WITHOUT deduplicating, selecting, or mutating the
raw artifact. Repeated / multistart attempts are preserved as distinct records.

The old organized trees (results/runs/.../bethe|square/{mg1,mg3}/...) are NOT
listed as sources: they are generated views built by organize_{bethe,square}.py
from the primary campaign artifacts registered below.
"""
from __future__ import annotations

import csv
import glob
import hashlib
import json
import os
import pickle
import re
import sys
from dataclasses import dataclass, field

import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

RUNS = os.path.join(_ROOT, "results/runs")


# --------------------------------------------------------------------------
# checksums / ids
# --------------------------------------------------------------------------
def sha256(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def relpath(path: str) -> str:
    return os.path.relpath(path, _ROOT)


def record_id(checksum: str, rel: str, index) -> str:
    """Stable id from (source checksum, relative source path, record index).

    Tied to the exact source bytes: if a raw artifact changes, its ids change --
    which is what we want (the id certifies provenance, not just position)."""
    key = f"{checksum}|{rel}|{index}".encode()
    return hashlib.sha1(key).hexdigest()[:16]


def point_key(lattice: str, Mg: int, u_over_D: float, t_over_D: float,
              branch: str) -> str:
    """Physical-point join key. NOT unique -- many attempts share one point_key;
    used only to compare physics across evidence types, never to collapse rows."""
    return f"{lattice}|Mg{Mg}|UD{u_over_D:.4f}|TD{t_over_D:.6f}|{branch}"


# --------------------------------------------------------------------------
# normalized records
# --------------------------------------------------------------------------
@dataclass
class BareRoot:
    """One bare_native solution, both h-sectors, unit-tagged, lossless."""
    lattice: str
    M_g: int
    M_h: int
    branch: str
    continuation_direction: str | None
    campaign: str
    source_path: str
    source_checksum: str
    source_record_index: object
    # units
    uot: float
    U_code: float
    T_code: float
    t: float
    mu: float
    # g sector (impurity)
    eps_g: list
    V_g: list
    # bare h sectors
    eta_lattice: list
    W_lattice: list
    eta_gateway: list
    W_gateway: list
    # payloads
    observables: dict
    reliability: dict
    classification: dict


@dataclass
class REvidence:
    """One independent R-gauge record (R_native_continuation or
    R_reoptimized_from_bare): reduced (lambda, Rf) + observables, no forward
    conversion needed (it already lives in R coordinates)."""
    lattice: str
    M_g: int
    M_h: int
    branch: str
    continuation_direction: str | None
    campaign: str
    evidence_type: str
    solver_route: str
    source_path: str
    source_checksum: str
    source_record_index: object
    uot: float
    U_code: float
    T_code: float
    t: float
    mu: float
    lam: float
    Rf: float
    eta_R: list
    W_R: list
    eps_g: list
    V_g: list
    observables: dict
    reliability: dict
    classification: dict
    parent_point_key: str | None = None    # physical key of the bare parent


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _split(s) -> list:
    return [float(x) for x in str(s).split(";") if x not in ("", "nan")]


def _f(x, default=None):
    try:
        return float(x)
    except (TypeError, ValueError):
        return default


def _converged(resnorm, gate=1e-4):
    if resnorm is None or not np.isfinite(resnorm):
        return None
    return bool(resnorm <= gate)


CONVERGENCE_GATE = 1e-4      # documented residual gate for the `converged` flag


# --------------------------------------------------------------------------
# Mg=3 symmetric bare CSVs (bethe: 17 T; square: 10 T)
# --------------------------------------------------------------------------
def _dir_from_branch(branch: str) -> str | None:
    b = (branch or "").lower()
    if b.endswith("-up") or b == "metal-up":
        return "up"
    if b.endswith("-down") or "down" in b:
        return "down"
    return None


def iter_symmetric_mg3(path: str, lattice: str, campaign: str,
                       T_from_name: bool):
    checksum = sha256(path)
    rel = relpath(path)
    tname = None
    if T_from_name:
        m = re.search(r"_T([\d.]+)\.csv$", path)
        tname = float(m.group(1)) if m else None
    with open(path) as f:
        for i, r in enumerate(csv.DictReader(f)):
            uot = _f(r["uot"]); U = _f(r["U"])
            T = _f(r.get("T")) if r.get("T") not in (None, "") else tname
            eta = _f(r["eta"]); W = _f(r["W"])
            eps_g = _f(r["eps_g"]); V0 = _f(r["V0"]); Vg = _f(r["Vg"])
            resnorm = _f(r["resnorm"])
            D_occ = _f(r["D"]); mu = _f(r["mu"])
            obs = dict(
                Z_pole=_f(r["Z_pole"]), Z_mats=_f(r["Z_fermi"]), D_occ=D_occ,
                n=_f(r["n_avg"]), n_lat=_f(r["n_lat"]), Omega=_f(r["Omega"]),
                E_kin=None, E_pot=(U * D_occ if (U is not None and D_occ is not None) else None),
                E_tot=None,
                sumV2=_f(r["sumV2"]), sumW2=_f(r["sumW2"]),
                maxV=_f(r["maxV"]), maxW=_f(r["maxW"]),
            )
            rel_ = dict(total_residual=resnorm, residual_blocks=None,
                        optimizer_success=None, optimizer_status=None,
                        nfev=None, njev=None, basin=r.get("basin"))
            cls = dict(converged=_converged(resnorm),
                       equation_accepted=None, physical=None,
                       gated=None, branch_continuous=None, selected=None)
            yield BareRoot(
                lattice=lattice, M_g=3, M_h=2, branch=r["branch"],
                continuation_direction=_dir_from_branch(r["branch"]),
                campaign=campaign, source_path=rel, source_checksum=checksum,
                source_record_index=i, uot=uot, U_code=U, T_code=T, t=0.5, mu=mu,
                eps_g=[0.0, eps_g, -eps_g], V_g=[V0, Vg, Vg],
                eta_lattice=[eta, -eta], W_lattice=[W, W],
                eta_gateway=_split(r["eta1"]), W_gateway=_split(r["W1"]),
                observables=obs, reliability=rel_, classification=cls)


# --------------------------------------------------------------------------
# Mg=1 multistart attempts (JSON), the lossless bare_native Mg=1 source
# --------------------------------------------------------------------------
def iter_mg1_attempts(attempt_dir: str, lattice: str, campaign: str):
    for path in sorted(glob.glob(os.path.join(attempt_dir, "*.json"))):
        checksum = sha256(path)
        rel = relpath(path)
        d = json.load(open(path))
        op, ob = d["optimized_parameters"], d["observables"]
        if ob.get("lattice") != lattice:
            continue
        uot = _f(ob.get("U_over_t")); U = _f(ob.get("U")); T = _f(ob.get("T"))
        Mg = int(ob.get("Mg", len(op.get("eps1", []))))
        D_occ = _f(ob.get("D_imp1"))
        resnorm = _f(ob.get("resnorm"))
        obs = dict(
            Z_pole=_f(ob.get("Z_pole")), Z_mats=_f(ob.get("Z_mats")),
            D_occ=D_occ, n=_f(ob.get("n_avg")), n_lat=_f(ob.get("n_lat")),
            Omega=_f(ob.get("Omega_total")),
            E_kin=None, E_pot=(U * D_occ if (U is not None and D_occ is not None) else None),
            E_tot=None,
            Omega_imp=_f(ob.get("Omega_imp")), Omega_lat=_f(ob.get("Omega_lat")),
            Omega_gateway=_f(ob.get("Omega_gateway")),
            sumV2=_f(ob.get("sum_V2_imp1")), sumW2=_f(ob.get("sum_W2_imp1")),
        )
        rel_ = dict(
            total_residual=resnorm, resmax=_f(ob.get("resmax")),
            residual_blocks=ob.get("residual_blocks"),
            optimizer_success=ob.get("optimizer_success"),
            optimizer_status=ob.get("optimizer_status"),
            optimizer_cost=_f(ob.get("optimizer_cost")),
            optimizer_message=ob.get("optimizer_message"),
            nfev=ob.get("nfev"), njev=None, dark_bath=ob.get("dark_bath"))
        cls = dict(
            converged=_converged(resnorm),
            equation_accepted=(bool(ob.get("optimizer_success"))
                               if ob.get("optimizer_success") is not None else None),
            physical=None, gated=None, branch_continuous=None, selected=None)
        yield BareRoot(
            lattice=lattice, M_g=Mg, M_h=2,
            branch=str(ob.get("branch_label") or "attempt"),
            continuation_direction=None, campaign=campaign,
            source_path=rel, source_checksum=checksum,
            source_record_index=os.path.basename(path),
            uot=uot, U_code=U, T_code=T, t=_f(ob.get("t"), 0.5), mu=_f(ob.get("mu")),
            eps_g=[_f(x) for x in op.get("eps1", [])],
            V_g=[_f(x) for x in op.get("V1", [])],
            eta_lattice=[_f(x) for x in op.get("eta", [])],
            W_lattice=[_f(x) for x in op.get("W", [])],
            eta_gateway=[_f(x) for x in op.get("eta1", [])],
            W_gateway=[_f(x) for x in op.get("W1", [])],
            observables=obs, reliability=rel_, classification=cls)


# --------------------------------------------------------------------------
# Bethe Mg=3 independent R-native continuation (912 rows, 3 T)
# --------------------------------------------------------------------------
def iter_r_continuation(path: str, lattice: str, campaign: str):
    checksum = sha256(path)
    rel = relpath(path)
    with open(path) as f:
        for i, r in enumerate(csv.DictReader(f)):
            uot = _f(r["uot"]); U = _f(r["U"]); T = _f(r["T"])
            resnorm = _f(r["resnorm"]); D_occ = _f(r["D"])
            obs = dict(Z_pole=_f(r["Z_pole"]), Z_mats=_f(r["Z_fermi"]),
                       Z_R=_f(r["Z_R"]), D_occ=D_occ, n=_f(r["n_avg"]),
                       n_lat=_f(r["n_lat"]), Omega=_f(r["Omega"]),
                       E_kin=None,
                       E_pot=(U * D_occ if (U is not None and D_occ is not None) else None),
                       E_tot=None, sumV2=_f(r["sumV2"]), sumW2=_f(r["sumW2"]))
            rel_ = dict(total_residual=resnorm, basin=r.get("basin"))
            cls = dict(converged=_converged(resnorm), equation_accepted=None,
                       physical=None, gated=None, branch_continuous=None,
                       selected=None)
            yield REvidence(
                lattice=lattice, M_g=3, M_h=2, branch=r["branch"],
                continuation_direction=_dir_from_branch(r["branch"]),
                campaign=campaign, evidence_type="R_native_continuation",
                solver_route="R_symmetric_least_squares",
                source_path=rel, source_checksum=checksum, source_record_index=i,
                uot=uot, U_code=U, T_code=T, t=0.5, mu=_f(r["mu"]),
                lam=_f(r["lam"]), Rf=_f(r["Rf"]),
                eta_R=[_f(r["eta"]), -_f(r["eta"])], W_R=[_f(r["W"]), _f(r["W"])],
                eps_g=[0.0, _f(r["eps_g"]), -_f(r["eps_g"])],
                V_g=[_f(r["V0"]), _f(r["Vg"]), _f(r["Vg"])],
                observables=obs, reliability=rel_, classification=cls)


# --------------------------------------------------------------------------
# Square Mg=3 full-grid R re-optimization (2180 rows, 10 T) -- from
# gauge_certify_square, which persisted the re-optimized (lam,Rf,eta_R,W_R).
# --------------------------------------------------------------------------
def iter_square_reopt(path: str, campaign: str):
    checksum = sha256(path)
    rel = relpath(path)
    with open(path) as f:
        for i, r in enumerate(csv.DictReader(f)):
            uot = _f(r["uot"]); U = uot * 0.5; T = _f(r["T"])
            res_R = _f(r["res_R"])
            floor = bool(int(_f(r["floor_limited"], 0)))
            obs = dict(Z_pole=_f(r["Z_R"]), Z_bare=_f(r["Z_bare"]),
                       D_occ=_f(r["D"]), Omega=_f(r["Omega"]),
                       dZ=_f(r["dZ"]), dD=_f(r["dD"]), dOmega=_f(r["dOmega"]),
                       E_kin=None, E_pot=None, E_tot=None)
            rel_ = dict(total_residual=res_R, res_bare=_f(r["res_bare"]),
                        d_ident=_f(r["d_ident"]), dx_bare=_f(r["dx_bare"]))
            # floor_limited must never be silently promoted to an interior root
            cls = dict(converged=_converged(res_R), equation_accepted=None,
                       physical=None, gated=None, branch_continuous=None,
                       selected=None, floor_limited=floor)
            yield REvidence(
                lattice="square", M_g=3, M_h=2, branch=r["branch"],
                continuation_direction=_dir_from_branch(r["branch"]),
                campaign=campaign, evidence_type="R_reoptimized_from_bare",
                solver_route="R_symmetric_least_squares",
                source_path=rel, source_checksum=checksum, source_record_index=i,
                uot=uot, U_code=U, T_code=T, t=0.5, mu=U / 2.0,
                lam=_f(r["lam"]), Rf=_f(r["Rf"]),
                eta_R=[_f(r["eta_R"]), -_f(r["eta_R"])],
                W_R=[_f(r["W_R"]), _f(r["W_R"])],
                eps_g=[0.0, _f(r["eps_g"]), -_f(r["eps_g"])],
                V_g=[_f(r["V0"]), _f(r["Vg"]), _f(r["Vg"])],
                observables=obs, reliability=rel_, classification=cls,
                parent_point_key=None)


# --------------------------------------------------------------------------
# top-level registry: yields every bare_native root and R-evidence record
# --------------------------------------------------------------------------
def mg1_attempt_dirs():
    """(attempt_dir, lattice, campaign) for all three Mg=1 campaigns."""
    out = []
    # old Bethe + old Square campaigns (2026-07-10 rerun)
    for lat in ("bethe", "square"):
        base = os.path.join(RUNS, "20260710_rerun_mg1", lat)
        for d in sorted(glob.glob(os.path.join(base, "*", "attempts"))):
            out.append((d, lat, f"mg1_{lat}_old_20260710"))
    # July-15 Bethe extension
    base = os.path.join(RUNS, "20260715_paper_scans/mg1_bethe/bethe")
    for d in sorted(glob.glob(os.path.join(base, "*", "attempts"))):
        out.append((d, "bethe", "mg1_bethe_ext_20260715"))
    return out


def iter_bare_roots():
    # Mg=3 bethe (17 T) -- canonical per-temperature symmetric CSVs
    for path in sorted(glob.glob(os.path.join(
            RUNS, "20260715_paper_scans/mg3_bethe/symmetric_bethe_T*.csv"))):
        yield from iter_symmetric_mg3(path, "bethe", "mg3_bethe_20260715",
                                      T_from_name=False)
    # Mg=3 square (10 T)
    for path in sorted(glob.glob(os.path.join(
            RUNS, "20260710_rerun_mg3/symmetric_square_T*.csv"))):
        yield from iter_symmetric_mg3(path, "square", "mg3_square_20260710",
                                      T_from_name=True)
    # Mg=1 attempts (882 across three campaigns)
    for attempt_dir, lat, camp in mg1_attempt_dirs():
        yield from iter_mg1_attempts(attempt_dir, lat, camp)


def iter_r_evidence():
    # Bethe Mg=3 R-native continuation (3 T, 912 rows)
    for path in sorted(glob.glob(os.path.join(
            RUNS, "20260715_paper_scans/mg3_bethe_R/symmetricR_bethe_T*.csv"))):
        yield from iter_r_continuation(path, "bethe", "mg3_bethe_R_20260715")
    # Square Mg=3 R re-optimization (10 T, 2180 rows)
    for path in sorted(glob.glob(os.path.join(
            RUNS, "20260715_paper_scans/gauge_certify_square/"
            "gauge_certify_square_T*.csv"))):
        yield from iter_square_reopt(path, "gauge_certify_square_20260715")
