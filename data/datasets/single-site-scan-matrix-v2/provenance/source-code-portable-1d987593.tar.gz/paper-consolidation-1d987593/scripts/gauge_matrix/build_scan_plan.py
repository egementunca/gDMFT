#!/usr/bin/env python3
"""Stage 3: map every expensive missing run to a paper claim (PLAN ONLY).

Deterministic planning build -- launches NOTHING. Reads the D08 coverage matrix,
enumerates the genuinely missing scans, classifies each by the claim it enables,
and attaches an exact command + a local cost estimate. Writes
scan_expansion_plan.csv and claim_ledger.csv into deliverable 09.

Runs with no defined claim stay deferred. Exact bare->R conversion already
supplies both coordinate representations, so full R-native duplication is needed
only for a solver-route-independence claim; representative R-native crosschecks
are preferred before full ladders.
"""
from __future__ import annotations

import csv
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
D08 = os.path.join(_ROOT, "results/deliverables/08_single_site_gauge_matrix")
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")

SEC_PER_SOLVE = 2.0        # local wall (measured: ~1-2 s/point for small ED)


def missing_mg1():
    cov = list(csv.DictReader(open(os.path.join(D08, "coverage_matrix.csv"))))
    m = {"bethe": 0, "square": 0}
    for r in cov:
        if r["M_g"] == "1" and r["has_bare_native"] == "0":
            m[r["lattice"]] += 1
    return m


BETHE_MISSING_NAT_T = [0.001, 0.002, 0.003, 0.004, 0.0065, 0.008, 0.01, 0.015,
                       0.02, 0.03, 0.05, 0.07, 0.15, 0.2]     # 14
SQUARE_MISSING_NAT_T = [0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.008, 0.01,
                        0.015, 0.02]                          # 10
BETHE_PTS_PER_LADDER = 324      # median rows/T in the dense bethe mg3 scan
SQUARE_PTS_PER_LADDER = 218


def plan_rows():
    m = missing_mg1()
    R = []
    # --- claim: Mg=1 -> Mg=3 accuracy gain vs gem B=1->B=3 ---
    R.append(dict(
        run_id="mg1_bethe_bench_keys", cell="bethe Mg=1 bare", n_units=m["bethe"],
        unit="benchmark (U/D,T/D) keys", arms="metal+insulator+gs",
        claim="mg1_to_mg3_accuracy_vs_gem_ed",
        route="bethe semicircle DOS (Nk=256, reference)",
        command="scripts/<mg1 bare scanner> --lattice bethe --keys <659 missing>  "
                "(branch-aware continuation; retain every attempt; exact R conversion)",
        est_solves=m["bethe"] * 2, est_wall_min=round(m["bethe"] * 2 * SEC_PER_SOLVE / 60, 1),
        priority="deferred_until_claim_defined",
        status="deferred (run only if the paper makes the Mg=1->Mg=3 accuracy claim)"))
    R.append(dict(
        run_id="mg1_square_bench_keys", cell="square Mg=1 bare", n_units=m["square"],
        unit="benchmark (U/D,T/D) keys", arms="metal+insulator+gs",
        claim="mg1_to_mg3_accuracy_vs_gem_ed",
        route="continuum_elliptic_dos (Stage-1 canonical square route)",
        command="scripts/<mg1 bare scanner> --lattice square "
                "--lattice-quadrature continuum_elliptic_dos --keys <330 missing>",
        est_solves=m["square"] * 2, est_wall_min=round(m["square"] * 2 * SEC_PER_SOLVE / 60, 1),
        priority="deferred_until_claim_defined",
        status="deferred; MUST use the continuum route (Nk=16 fails the Stage-1 gate)"))
    # --- claim: independent bare-vs-R solver-route parity ---
    R.append(dict(
        run_id="mg3_bethe_Rnative_repr", cell="bethe Mg=3 R-native (representative)",
        n_units=9, unit="representative points (3 T x metal/coex/insulator)",
        arms="metal+insulator",
        claim="bare_vs_R_solver_route_parity",
        route="R-gauge least_squares (symmetric_continuation_R.py)",
        command=".venv-numba/bin/python3 scripts/symmetric_continuation_R.py "
                "--rows 0.002,0.01,0.05  (then compare vs bare at metal/coexistence/insulator)",
        est_solves=9 * 3, est_wall_min=round(9 * 3 * SEC_PER_SOLVE / 60, 1),
        priority="high_do_before_full_ladders",
        status="ready; preferred crosscheck before committing to full ladders"))
    R.append(dict(
        run_id="mg3_bethe_Rnative_full", cell="bethe Mg=3 R-native (full)",
        n_units=len(BETHE_MISSING_NAT_T), unit="missing T/D ladders",
        arms="metal+insulator",
        claim="bare_vs_R_solver_route_parity",
        route="R-gauge least_squares (symmetric_continuation_R.py)",
        command=".venv-numba/bin/python3 scripts/symmetric_continuation_R.py --rows "
                + ",".join(str(t) for t in BETHE_MISSING_NAT_T),
        est_solves=len(BETHE_MISSING_NAT_T) * BETHE_PTS_PER_LADDER,
        est_wall_min=round(len(BETHE_MISSING_NAT_T) * BETHE_PTS_PER_LADDER * SEC_PER_SOLVE / 60, 1),
        priority="deferred_until_parity_claim",
        status="deferred; only for a full independent-route parity claim (R_converted already gives both reps)"))
    R.append(dict(
        run_id="mg3_square_Rnative_full", cell="square Mg=3 R-native (full)",
        n_units=len(SQUARE_MISSING_NAT_T), unit="missing T/D ladders",
        arms="metal+insulator",
        claim="bare_vs_R_solver_route_parity",
        route="continuum_elliptic_dos R-gauge (NEEDS a square sibling of symmetric_continuation_R.py)",
        command="scripts/<square R-native continuation, continuum route> --rows "
                + ",".join(str(t) for t in SQUARE_MISSING_NAT_T),
        est_solves=len(SQUARE_MISSING_NAT_T) * SQUARE_PTS_PER_LADDER,
        est_wall_min=round(len(SQUARE_MISSING_NAT_T) * SQUARE_PTS_PER_LADDER * SEC_PER_SOLVE / 60, 1),
        priority="deferred_needs_script_and_parity_claim",
        status="deferred; square has NO R-native script yet; also would use the continuum route"))
    return R, m


CLAIMS = [
    dict(claim_id="mg3_reproduces_gem_ed",
         statement="Ghost-DMFT single-site Mg=3 reproduces gem gGA (B=3) and the "
                   "LLK DMFT-ED (Nb=3) references on the dense benchmark grids",
         evidence="D08 dense Mg=3 grids (5506 bethe / 2180 square) + gem + ED refs; "
                  "Stage-2 ED validated (12/12)",
         status="SUPPORTED (existing data); square energy sub-percent needs continuum route",
         runs_needed="none"),
    dict(claim_id="mg1_to_mg3_accuracy_vs_gem_ed",
         statement="Ghost-DMFT Mg=1->Mg=3 improves accuracy toward gem B=1->B=3 "
                   "at every benchmark temperature",
         evidence="requires Mg=1 bare scans on ALL benchmark keys (659 bethe + "
                   "330 square currently missing)",
         status="DEFERRED (Mg=1 grids sparse: bethe 225/884, square 70/400)",
         runs_needed="mg1_bethe_bench_keys, mg1_square_bench_keys (989 keys)"),
    dict(claim_id="bare_vs_R_solver_route_parity",
         statement="The bare (eta,W) and canonical-R gauges are independent solver "
                   "routes to the same stationary physics",
         evidence="deterministic R_converted_from_bare (8568 partners, exact) gives "
                   "BOTH representations; independent R convergence: 912 bethe "
                   "R-native done, 14 bethe + 10 square ladders missing",
         status="SUPPORTED for both-representations; full independent-route parity "
                "needs the missing ladders (start with representative crosschecks)",
         runs_needed="mg3_bethe_Rnative_repr (ready); full ladders deferred"),
    dict(claim_id="square_publication_resolution",
         statement="Square local observables are reported at publication-grade "
                   "quadrature resolution",
         evidence="Stage-1 continuum_elliptic_dos route (U=0 exact to 8e-9) + "
                   "convergence pilot + claim gate",
         status="SUPPORTED: continuum canonical; Nk=64 accepted for energies/D_occ/n; "
                "Z sub-percent needs continuum; Nk=16 historical only",
         runs_needed="none (continuum route established)"),
    dict(claim_id="llk_ed_converges_to_ctqmc",
         statement="Finite-pole DMFT-ED converges to CTQMC with N_b (LLK)",
         evidence="Stage-2: 12/12 convergence-structure checks; Nb={1,3} grid; "
                  "Nb=5 matches CTQMC anchor; CG==LM; U=0 exact",
         status="SUPPORTED for Nb={1,3} finite-bath positions + Nb=5 endpoint",
         runs_needed="none (Nb=7 out of scope)"),
]


def main():
    os.makedirs(OUT, exist_ok=True)
    rows, m = plan_rows()
    with open(os.path.join(OUT, "scan_expansion_plan.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    with open(os.path.join(OUT, "claim_ledger.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(CLAIMS[0].keys())); w.writeheader(); w.writerows(CLAIMS)
    total_deferred = sum(r["est_solves"] for r in rows if "deferred" in r["priority"])
    print(f"missing Mg=1 keys: {m};  scan_expansion_plan.csv rows: {len(rows)}")
    print("run_id / claim / est_solves / est_wall_min / priority:")
    for r in rows:
        print(f"  {r['run_id']:26s} {r['claim']:34s} {r['est_solves']:6d} "
              f"{r['est_wall_min']:7.1f}m  {r['priority']}")
    print(f"\ntotal deferred solves (NOT launched): {total_deferred} "
          f"(~{total_deferred*SEC_PER_SOLVE/3600:.1f} h local)")
    print("claim_ledger.csv: 5 claims mapped")


if __name__ == "__main__":
    main()
