#!/usr/bin/env python3
"""Square k-mesh quadrature-convergence pilot (acceptance criterion 14).

Deterministic analysis of EXISTING square roots -- it runs NO solver. It joins
the production Nk=16 square Mg=3 scan against the stored Nk=64 control
(results/runs/20260710_rerun_mg3/nk64_check/, T_code=0.002 == T/D=0.001) at
matching (branch, U/D) points and reports, per observable, the relative
quadrature uncertainty |x(Nk64) - x(Nk16)| / |x(Nk16)|. It adds the analytic
U=0 kinetic-energy anchor (Nk=16 vs continuum elliptic DOS).

Predeclared claim tolerance: a "sub-percent" square ENERGY/Z accuracy claim
requires the quadrature uncertainty to be <= 0.1% AND small vs the plotted
method difference. The pilot reports GATE PASS/FAIL against the 0.1% tolerance.

Scope: PRELIMINARY. Only Nk in {16, 64} at T/D=0.001 exist as solved roots; a
complete pilot (Nk in {16,32,64} at U/D={0,1,2,2.5,3.0}, T/D={0.001,0.01}, all
branches) or a matched-continuum recompute is a SOLVER run requiring approval.
Dimensionless Z/D_occ/n and phase topology may still be reported with the mesh
stated; only sub-percent square energy accuracy is gated.
"""
from __future__ import annotations

import csv
import math
import os
import sys

_HERE = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(os.path.dirname(_HERE))
sys.path.insert(0, os.path.dirname(_HERE))
from gauge_matrix import sources as S  # noqa: E402

OUT = os.path.join(_ROOT, "results/deliverables/08_single_site_gauge_matrix")
RUNS = S.RUNS
D = 2.0
GATE_TOL = 0.001                      # 0.1% predeclared sub-percent claim tolerance
REP_UD = [0.5, 1.0, 2.0, 2.5, 3.0]    # representative U/D (grid starts at 0.5)
EKIN_NK16_U0 = -0.402721              # reduced E_kin/D, ghost Nk=16 uniform mesh, U=0
EKIN_CONTINUUM_U0 = -4.0 / math.pi ** 2   # = -0.405285, continuum elliptic DOS


def _load(path):
    d = {}
    for r in csv.DictReader(open(path)):
        k = (r["branch"], round(float(r["uot"]) / 4.0, 3))
        d[k] = r
    return d


def build():
    nk16 = _load(os.path.join(RUNS, "20260710_rerun_mg3/symmetric_square_T0.002.csv"))
    nk64 = _load(os.path.join(RUNS, "20260710_rerun_mg3/nk64_check/symmetric_square_T0.002.csv"))
    rows = []
    for br in ("metal-up", "metal-down", "insul-down"):
        for ud in REP_UD:
            k = (br, ud)
            if k not in nk16 or k not in nk64:
                continue
            a, b = nk16[k], nk64[k]
            for obs, col, reduce_by in (("Z_pole", "Z_pole", 1.0),
                                        ("D_occ", "D", 1.0),
                                        ("Omega_over_D", "Omega", D)):
                x16 = float(a[col]) / reduce_by
                x64 = float(b[col]) / reduce_by
                denom = max(abs(x16), 1e-12)
                rel = abs(x64 - x16) / denom
                rows.append(dict(
                    observable=obs, branch=br, U_over_D=ud, T_over_D=0.001,
                    Nk_lo=16, Nk_hi=64, value_Nk16=x16, value_Nk64=x64,
                    abs_diff=abs(x64 - x16), rel_uncertainty=rel,
                    gate_tol=GATE_TOL, gate_pass=int(rel <= GATE_TOL)))
    # U=0 kinetic-energy anchor (analytic; ghost Nk=16 vs continuum elliptic DOS)
    rel_u0 = abs(EKIN_CONTINUUM_U0 - EKIN_NK16_U0) / abs(EKIN_CONTINUUM_U0)
    rows.append(dict(
        observable="E_kin_over_D_U0_anchor", branch="U=0_noninteracting",
        U_over_D=0.0, T_over_D=0.0, Nk_lo=16, Nk_hi="continuum",
        value_Nk16=EKIN_NK16_U0, value_Nk64=EKIN_CONTINUUM_U0,
        abs_diff=abs(EKIN_CONTINUUM_U0 - EKIN_NK16_U0),
        rel_uncertainty=rel_u0, gate_tol=GATE_TOL, gate_pass=int(rel_u0 <= GATE_TOL)))

    cols = ["observable", "branch", "U_over_D", "T_over_D", "Nk_lo", "Nk_hi",
            "value_Nk16", "value_Nk64", "abs_diff", "rel_uncertainty",
            "gate_tol", "gate_pass"]
    with open(os.path.join(OUT, "square_quadrature_pilot.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)

    # verdict
    by_obs = {}
    for r in rows:
        by_obs.setdefault(r["observable"], []).append(r["rel_uncertainty"])
    verdict = {o: max(v) for o, v in by_obs.items()}
    overall_pass = all(m <= GATE_TOL for m in verdict.values())
    return rows, verdict, overall_pass


def main():
    os.makedirs(OUT, exist_ok=True)
    rows, verdict, ok = build()
    print(f"[pilot] {len(rows)} rows -> square_quadrature_pilot.csv")
    print(f"[pilot] max relative quadrature uncertainty by observable "
          f"(gate {GATE_TOL:.1%}):")
    for o, m in sorted(verdict.items()):
        print(f"    {o:28s} {m:7.3%}  {'PASS' if m <= GATE_TOL else 'FAIL (gated)'}")
    print(f"[pilot] OVERALL sub-percent square-energy gate: "
          f"{'PASS' if ok else 'FAIL -> sub-percent square energy claims GATED'}")
    print("[pilot] PRELIMINARY: only Nk in {16,64} at T/D=0.001 exist as solved "
          "roots; completing Nk={16,32,64} or matched-continuum needs approval.")


if __name__ == "__main__":
    main()
