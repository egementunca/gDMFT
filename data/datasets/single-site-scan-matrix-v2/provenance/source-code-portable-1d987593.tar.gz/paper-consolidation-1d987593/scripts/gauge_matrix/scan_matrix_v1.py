#!/usr/bin/env python3
"""Stage 3 registered scan-matrix runner -- RESUMABLE, versioned, append-only.

Completes the registered single-site benchmark matrix on consistent grids:
  {bethe, square} x {M_g=1, M_g=3} x {bare_native, R_native}
on the exact reduced-unit benchmark grids (Bethe 52 U/D x 17 T/D = 884 keys;
Square 40 U/D x 10 T/D = 400 keys), branch-aware, retaining every attempt.

Square uses the Stage-1 canonical `continuum_elliptic_dos` route (NOT N_k=16).
Bethe uses the semicircle DOS quadrature (Nk=256). Every bare root is
forward-converted to its exact canonical-R representation. R-native rows are an
independent R-gauge solve (distinct evidence type), seeded from the bare/exact
conversion but converged independently.

Output (immutable, versioned; never overwrites the N_k=16 or old-campaign
sources): results/runs/20260717_scan_matrix/<cell>/T<T>.csv  + a run registry.
Resumable: an existing, complete T-file is skipped. Failed/metastable attempts
are retained as rows (converged flag records status); `selected` is never set.

Usage:
  .venv-numba/bin/python3 scripts/gauge_matrix/scan_matrix.py --cell bethe_mg1_bare
  .venv-numba/bin/python3 scripts/gauge_matrix/scan_matrix.py --cell all --list
"""
from __future__ import annotations

import argparse
import csv
import glob
import hashlib
import os
import sys
import time

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS = os.path.dirname(_HERE)
_ROOT = os.path.dirname(_SCRIPTS)
for p in (_ROOT, _SCRIPTS):
    if p not in sys.path:
        sys.path.insert(0, p)

from scipy.optimize import least_squares  # noqa: E402
from BHFM2.core.solve_min import (ModelParamsMin, SParMin,  # noqa: E402
                                  MODE_SINGLE_IMPURITY as SI)
from BHFM2.core.reparam_R import hsector_to_bare, R_FLOOR  # noqa: E402
from BHFM2.core import canonical_gauge as cg  # noqa: E402
import landscape_map as L  # noqa: E402
import symmetric_continuation as SC  # noqa: E402
import symmetric_continuation_R as SR  # noqa: E402
from gauge_matrix import convert as C  # noqa: E402

OUTROOT = os.path.join(_ROOT, "results/runs/20260717_scan_matrix")
REGISTRY = os.path.join(OUTROOT, "scan_run_registry.csv")
Z0 = np.zeros(0)

# ---- benchmark grids (reduced units) ----
def _union(*rs):
    v = np.concatenate([np.round(np.arange(a, b + 1e-9, s), 4) for a, b, s in rs])
    return sorted(float(x) for x in np.unique(np.round(v, 4)))

BETHE_T = [0.001, 0.002, 0.003, 0.004, 0.005, 0.0065, 0.008, 0.01, 0.015, 0.02,
           0.025, 0.03, 0.05, 0.07, 0.1, 0.15, 0.2]
BETHE_U = _union((0.5, 4.0, 0.1), (2.0, 3.6, 0.05))            # 52
SQUARE_T = [0.001, 0.002, 0.003, 0.004, 0.005, 0.006, 0.008, 0.01, 0.015, 0.02]
SQUARE_U = _union((0.5, 3.2, 0.1), (2.0, 3.2, 0.05))          # 40

GRID = {"bethe": (BETHE_U, BETHE_T), "square": (SQUARE_U, SQUARE_T)}
LAT_CFG = {          # (Nk, lattice_quadrature, D)
    "bethe": dict(Nk=256, quad="bethe_semicircle", D=1.0),
    "square": dict(Nk=16, quad="continuum_elliptic_dos", D=2.0),
}


def uot_of(u_over_D, lattice):
    return (2.0 if lattice == "bethe" else 4.0) * u_over_D


def t_code_of(t_over_D, lattice):
    return t_over_D if lattice == "bethe" else 2.0 * t_over_D


# continuum-DOS node count for the square route. Default 4001 (node-convergence
# validated to 7e-8 at U=0); overridable via SCAN_N_EPS for the expensive M_g=3
# square cells (n_eps=2001 is validated to 2.8e-7, ~2x faster). The actual value
# is recorded per row (n_eps_dos), so mixed-node cells stay auditable.
N_EPS_DOS = int(os.environ.get("SCAN_N_EPS", "4001"))


def mp_for(lattice, U, T_code):
    c = LAT_CFG[lattice]
    kw = dict(t=0.5, eps_d=0.0, U=U, z=4.0, filling_target=1.0, beta=1.0 / T_code,
              Nk=c["Nk"], lattice=lattice, n_moments=L.N_MOMENTS, Sigma_inf=U / 2.0)
    if lattice == "square":
        kw.update(lattice_quadrature="continuum_elliptic_dos", n_eps_dos=N_EPS_DOS)
    return ModelParamsMin(**kw)


# ==========================================================================
# Mg=1 symmetric solvers (bare + R-native), analog of SC/SR for Mg=3
# ==========================================================================
LO1 = np.array([0.0, 1e-8, 1e-6]);  HI1 = np.array([5.0, 30.0, 40.0])         # V0,W,eta
RF_HI = float(np.sqrt((1.0 - R_FLOOR ** 2) / 2.0))
LO1R = np.array([0.0, 1e-4, R_FLOOR]);  HI1R = np.array([5.0, 30.0, RF_HI])   # V0,lam,Rf
METAL1_X0 = np.array([0.45, 0.6, 0.7])                # coupled metal seed (bare)


def sym_spar_mg1(x, mu):
    V0, W, eta = x
    return SParMin(eta=np.array([eta, -eta]), W=np.array([W, W]), eta_b=Z0, B_h=Z0,
                   eps1=np.array([0.0]), V1=np.array([V0]),
                   eta1=np.array([eta, -eta]), W1=np.array([W, W]),
                   eps2=Z0, V2=Z0, eta2=Z0, W2=Z0, eta_b2=Z0, B_h2=Z0,
                   eps_b=Z0, B_g=Z0, mu=float(mu))


def solve_mg1(mp, x0, mu, max_nfev=3000):
    x0 = np.clip(x0, LO1 + 1e-9, HI1 - 1e-9)
    sol = least_squares(lambda x: L.residual_ph(sym_spar_mg1(x, mu), mp, 1), x0,
                        method="trf", bounds=(LO1, HI1), ftol=1e-14, xtol=1e-14,
                        max_nfev=max_nfev)
    return sol.x, float(np.linalg.norm(sol.fun))


def sym_spar_mg1_R(xR, mu):
    V0, lam, Rf = xR
    eta, W = hsector_to_bare(np.array([lam, -lam]), np.array([Rf, Rf]), 0.0)
    return SParMin(eta=eta, W=W, eta_b=Z0, B_h=Z0,
                   eps1=np.array([0.0]), V1=np.array([V0]),
                   eta1=eta.copy(), W1=W.copy(),
                   eps2=Z0, V2=Z0, eta2=Z0, W2=Z0, eta_b2=Z0, B_h2=Z0,
                   eps_b=Z0, B_g=Z0, mu=float(mu))


def seed_mg1_R_from_bare(x_bare):
    V0, W, eta = x_bare
    lam3, R3 = cg.forward(0.0, np.array([eta, -eta]), np.array([W, W]))
    qp = int(np.argmin(np.abs(lam3)))
    mask = np.ones(3, bool); mask[qp] = False
    lam = float(np.mean(np.abs(lam3[mask]))); Rf = float(np.clip(np.mean(np.abs(R3[mask])), R_FLOOR, RF_HI))
    return np.array([V0, max(lam, 1e-4), Rf])


def solve_mg1_R(mp, xR0, mu, max_nfev=3000):
    xR0 = np.clip(xR0, LO1R + 1e-9, HI1R - 1e-9)
    sol = least_squares(lambda x: L.residual_ph(sym_spar_mg1_R(x, mu), mp, 1), xR0,
                        method="trf", bounds=(LO1R, HI1R), ftol=1e-14, xtol=1e-14,
                        max_nfev=max_nfev)
    return sol.x, float(np.linalg.norm(sol.fun))


# ==========================================================================
# per-root row assembly (adds exact canonical R representation + diagnostics)
# ==========================================================================
def _canon(p, lattice):
    """Forward-convert a solved SParMin's h-sectors to canonical R + diagnostics."""
    eta = np.asarray(p.eta, float); W = np.asarray(p.W, float)
    eta1 = np.asarray(p.eta1, float); W1 = np.asarray(p.W1, float)
    cr = C.convert_root(eta, W, eta1, W1, lattice)
    d = cr.diagnostics()
    lamL, RfL = C.reduced_lambda_Rf(cr.lat_sector)
    return dict(
        lam_lattice_full=";".join(f"{x:.8g}" for x in C._arr(cr.lat_sector.lam)),
        R_lattice_full=";".join(f"{x:.8g}" for x in C._arr(cr.lat_sector.R)),
        lam_gateway_full=";".join(f"{x:.8g}" for x in C._arr(cr.gw_sector.lam)),
        R_gateway_full=";".join(f"{x:.8g}" for x in C._arr(cr.gw_sector.R)),
        lam_reduced=lamL, Rf_reduced=RfL, Z_pole_from_R=cr.Z_pole,
        n_modes=d["n_modes"], norm_error=d["norm_error"],
        closure_error=d["closure_error"], roundtrip_error=d["roundtrip_error"],
        interlacing_error=d["interlacing_error"], floor_limited=int(d["floor_limited"]))


def _row(lattice, Mg, gauge, u_over_D, t_over_D, branch, d, p, resnorm, U, T_code,
         commit, dirty, extra=None):
    D = LAT_CFG[lattice]["D"]
    D_occ = d.get("D") if d else None
    row = dict(
        lattice=lattice, M_g=Mg, M_h=2, gauge=gauge, branch=branch,
        solver_route=("bare_least_squares" if gauge == "bare_native"
                      else "R_native_least_squares"),
        evidence_type=gauge, lattice_quadrature=LAT_CFG[lattice]["quad"],
        Nk=(LAT_CFG[lattice]["Nk"] if lattice == "square" else 256),
        n_eps_dos=(N_EPS_DOS if lattice == "square" else ""),
        U_over_D=u_over_D, T_over_D=t_over_D, U_raw=U, T_raw=T_code, t=0.5, D=D,
        Z_pole=(d.get("Z_pole") if d else None), Z_mats=(d.get("Z_fermi") if d else None),
        D_occ=D_occ, n=(d.get("n_avg") if d else None),
        n_lat=(d.get("n_lat") if d else None),
        Omega=(d.get("Omega") if d else None),
        Omega_over_D=(d["Omega"] / D if (d and d.get("Omega") is not None
                                         and np.isfinite(d["Omega"])) else None),
        E_pot=(U * D_occ if (D_occ is not None) else None),
        E_pot_over_D=((U * D_occ) / D if (D_occ is not None) else None),
        sumV2=(d.get("sumV2") if d else None), sumW2=(d.get("sumW2") if d else None),
        basin=(d.get("basin") if d else None), resnorm=resnorm,
        converged=int(resnorm < 1e-3) if resnorm is not None else None,
        equation_accepted=None, physical=None, gated=None,
        branch_continuous=None, selected=None,
        code_commit=commit, dirty=dirty)
    if p is not None:
        row.update(_canon(p, lattice))
    if extra:
        row.update(extra)
    return row


# ==========================================================================
# cell runner (resumable, per-T)
# ==========================================================================
def _seed_grow_uot(lattice):
    return uot_of(2.0, lattice)          # grow metal at U/D=2 (SC convention)


def run_cell(cell, commit, dirty):
    lattice, Mg, gauge = CELLS[cell]
    Us, Ts = GRID[lattice]
    uot_grid = sorted(uot_of(u, lattice) for u in Us)
    ms = _seed_grow_uot(lattice)
    hi = [u for u in uot_grid if u >= ms - 1e-9]
    lo = [u for u in uot_grid if u < ms - 1e-9][::-1]
    down = list(uot_grid[::-1])
    outdir = os.path.join(OUTROOT, cell)
    os.makedirs(outdir, exist_ok=True)
    done = 0
    for T in Ts:
        fn = os.path.join(outdir, f"T{T:g}.csv")
        if os.path.exists(fn) and os.path.getsize(fn) > 0:
            done += 1
            continue
        t0 = time.time()
        T_code = t_code_of(T, lattice)
        SC.WARM_GATE = 1e-3 if T >= 0.02 else 1e-4
        rows = _run_cell_T(lattice, Mg, gauge, T, T_code, hi, lo, down,
                           commit, dirty)
        with open(fn, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(rows[0].keys()), extrasaction="ignore")
            w.writeheader(); w.writerows(rows)
        conv = sum(1 for r in rows if r.get("converged") == 1)
        _register(cell, T, len(rows), conv, fn, time.time() - t0, commit, dirty)
        print(f"[{cell}] T/D={T:g}: {len(rows)} rows ({conv} conv) "
              f"-> {os.path.basename(fn)} ({time.time()-t0:.0f}s)", flush=True)
        done += 1
    return done, len(Ts)


def _run_cell_T(lattice, Mg, gauge, T, T_code, hi, lo, down, commit, dirty):
    rows = []
    first_metal_x = {}          # captures the raw x of the first converged metal-up

    def solve_at(uot, seed, branch):
        """Returns (row, solved_x_or_None). solved_x is the raw parameter vector
        for warm-chaining; None if the solve errored."""
        U = uot * 0.5; mu = U / 2.0
        u_over_D = uot / (2.0 if lattice == "bethe" else 4.0)
        mp = mp_for(lattice, U, T_code)
        try:
            if gauge == "bare_native" and Mg == 1:
                xs, r = solve_mg1(mp, seed, mu); p = sym_spar_mg1(xs, mu); mgn = 1
            elif gauge == "bare_native":
                xs, r = SC.solve_sym(mp, seed, mu); p = SC.sym_spar(xs, mu); mgn = 3
            elif Mg == 1:
                xs, r = solve_mg1_R(mp, seed, mu); p = sym_spar_mg1_R(xs, mu); mgn = 1
            else:
                xs, r = SR.solve_sym_R(mp, seed, mu); p = SR.sym_spar_R(xs, mu); mgn = 3
            d = L.diagnose(p, mp, mgn); d["basin"] = L.basin_label(d)
            row = _row(lattice, Mg, gauge, round(u_over_D, 4), T, branch, d, p, r,
                       U, T_code, commit, dirty)
            return row, (xs if r < SC.WARM_GATE else None)
        except Exception as exc:
            row = _row(lattice, Mg, gauge, round(u_over_D, 4), T, branch, None, None,
                       None, U, T_code, commit, dirty,
                       extra=dict(error=f"{type(exc).__name__}:{exc}"))
            return row, None

    def metal_seed():
        if gauge == "bare_native":
            return (METAL1_X0 if Mg == 1 else SC.METAL_X0).copy()
        return (seed_mg1_R_from_bare(METAL1_X0) if Mg == 1
                else SR.seed_R_from_bare5(SC.METAL_X0))

    def ins_seed(U):
        if Mg == 3:
            return (SC.ins_seed(U) if gauge == "bare_native"
                    else SR.seed_R_from_bare5(SC.ins_seed(U)))
        bare = np.array([1e-3, U / (2 * np.sqrt(2)), 3e-3])   # Mg=1 dead-Kondo insulator
        return bare if gauge == "bare_native" else seed_mg1_R_from_bare(bare)

    # metal-up: grow from U/D=2 upward, warm-chaining
    seed = metal_seed()
    for uot in hi:
        row, xnew = solve_at(uot, seed, "metal-up"); rows.append(row)
        if xnew is not None:
            seed = xnew
            first_metal_x.setdefault("x", xnew)
    # metal-down: from the first converged metal-up solution downward
    seed = first_metal_x.get("x", metal_seed())
    for uot in lo:
        row, xnew = solve_at(uot, seed, "metal-down"); rows.append(row)
        if xnew is not None:
            seed = xnew
    # insulator-down
    seed = ins_seed(down[0] * 0.5)
    for uot in down:
        row, xnew = solve_at(uot, seed, "insul-down"); rows.append(row)
        if xnew is not None:
            seed = xnew
    return rows


# ==========================================================================
# registry + provenance
# ==========================================================================
def _sha(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _register(cell, T, n_rows, n_conv, fn, wall, commit, dirty):
    os.makedirs(OUTROOT, exist_ok=True)
    new = not os.path.exists(REGISTRY)
    with open(REGISTRY, "a", newline="") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["cell", "T_over_D", "n_rows", "n_converged", "artifact",
                        "sha256", "wall_s", "code_commit", "dirty"])
        w.writerow([cell, T, n_rows, n_conv, os.path.relpath(fn, _ROOT),
                    _sha(fn), round(wall, 1), commit, dirty])


CELLS = {
    "bethe_mg1_bare": ("bethe", 1, "bare_native"),
    "bethe_mg1_Rnative": ("bethe", 1, "R_native"),
    "bethe_mg3_Rnative": ("bethe", 3, "R_native"),
    "square_mg1_bare": ("square", 1, "bare_native"),
    "square_mg1_Rnative": ("square", 1, "R_native"),
    "square_mg3_bare": ("square", 3, "bare_native"),
    "square_mg3_Rnative": ("square", 3, "R_native"),
}


def _commit_dirty():
    import subprocess
    try:
        c = subprocess.check_output(["git", "-C", _ROOT, "rev-parse", "HEAD"], text=True).strip()
        d = subprocess.check_output(["git", "-C", _ROOT, "status", "--porcelain"], text=True)
        return c, ("dirty" if d.strip() else "clean")
    except Exception:
        return "unknown", "unknown"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cell", required=True)
    ap.add_argument("--list", action="store_true")
    a = ap.parse_args()
    if a.list:
        for k, v in CELLS.items():
            print(f"  {k}: {v}")
        return
    commit, dirty = _commit_dirty()
    cells = list(CELLS) if a.cell == "all" else [a.cell]
    for cell in cells:
        if cell not in CELLS:
            print(f"unknown cell {cell}"); continue
        done, total = run_cell(cell, commit, dirty)
        print(f"[{cell}] complete: {done}/{total} T-files present")


if __name__ == "__main__":
    main()
