#!/usr/bin/env python3
"""Stage 1 square-lattice resolution pilot: TRUE stationary-solution convergence.

Re-solves the symmetric single-site stationary equations at four provenance-
recorded square quadratures -- uniform_kmesh Nk in {16,32,64} and
continuum_elliptic_dos -- from MATCHED physical parents (the stored Nk=16
roots), at U/D in {0,1,2,2.5,3.0}, T/D in {0.001,0.01}, both metal and insulator
branches, M_g in {1,3}. It NEVER overwrites the Nk=16 sources: output goes to a
new immutable namespace. Every attempt (including non-convergent) is retained.

Each interacting point is a genuine re-solve of the stationary equations at that
quadrature (the quadrature changes the stationary solution), not a fixed-root
observable reevaluation. U=0 uses the analytic non-interacting values. Every
row records the exact canonical-R representation of the converged bare root.

Output: results/runs/20260717_square_resolution/square_pilot_raw.csv
Usage:  .venv-numba/bin/python3 scripts/gauge_matrix/run_square_pilot.py
"""
from __future__ import annotations

import csv
import os
import sys
import time

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS = os.path.dirname(_HERE)
_ROOT = os.path.dirname(_SCRIPTS)
for p in (_ROOT, _SCRIPTS):
    if p not in sys.path:
        sys.path.insert(0, p)

from BHFM2.core.solve_min import (ModelParamsMin, lat_obs,  # noqa: E402
                                  MODE_SINGLE_IMPURITY as SI)
from dataclasses import replace  # noqa: E402
import landscape_map as L  # noqa: E402
import symmetric_continuation as SC  # noqa: E402
import symmetric_continuation_R as SR  # noqa: E402
from gauge_matrix import convert as C  # noqa: E402
from gauge_matrix import square_integration as SIQ  # noqa: E402

OUTDIR = os.path.join(_ROOT, "results/runs/20260717_square_resolution")
STORE = os.path.join(_ROOT, "results/runs/20260710_rerun_mg3")
D = 2.0
t = 0.5
UD_GRID = [0.0, 1.0, 2.0, 2.5, 3.0]
TD_GRID = [0.001, 0.01]
ROUTES = [("uniform_kmesh", 16), ("uniform_kmesh", 32),
          ("uniform_kmesh", 64), ("continuum_elliptic_dos", 0)]
# square metal spinodal neighborhood (reduced units) for the distance field
SPINODAL_UD = 3.2


def stored_seed(td, branch):
    """Load stored Nk=16 symmetric_square roots for one T/D, keyed by uot."""
    T_code = 2.0 * td
    fn = os.path.join(STORE, f"symmetric_square_T{T_code:g}.csv")
    rows = {}
    for r in csv.DictReader(open(fn)):
        if r["branch"] != branch:
            continue
        rows[round(float(r["uot"]), 3)] = r
    return rows, os.path.relpath(fn, _ROOT)


def nearest(rows, uot):
    if not rows:
        return None
    k = min(rows, key=lambda u: abs(u - uot))
    return rows[k] if abs(k - uot) < 0.15 else None


def solve_point(mp, xseed, mu):
    xsol, r = SR.solve_sym_R(mp, xseed, mu)
    p = SR.sym_spar_R(xsol, mu)
    d = L.diagnose(p, mp, 3)
    mp_f = replace(mp, Sigma_inf=mp.U / 2.0)
    lat = lat_obs(p, mp_f, 2, 0, mode=SI)
    e_kin = float(lat["e_kin"])
    # exact canonical-R of the converged bare root (both h-sectors)
    eta = float(p.eta[0]); W = float(p.W[0])
    cr = C.convert_root([eta, -eta], [W, W],
                        list(np.asarray(p.eta1, float)), list(np.asarray(p.W1, float)),
                        "square")
    diag = cr.diagnostics()
    return xsol, r, d, e_kin, cr, diag


def main():
    os.makedirs(OUTDIR, exist_ok=True)
    commit = _commit()
    rows = []
    t0 = time.time()
    for branch in ("metal-up", "insul-down"):
        for td in TD_GRID:
            seeds, seed_path = stored_seed(td, branch)
            for ud in UD_GRID:
                uot = 4.0 * ud
                U = uot * t
                mu = U / 2.0
                T_code = 2.0 * td
                if ud == 0.0:
                    # analytic non-interacting per route (no solve)
                    for route, Nk in ROUTES:
                        e, w = (SIQ.kmesh_nodes(Nk, t) if route == "uniform_kmesh"
                                else SIQ.elliptic_dos_nodes(t))
                        a = SIQ.anchors(e, w, t)
                        rows.append(_row(
                            commit, route, Nk, ud, td, 3, "metal", "analytic_noninteracting",
                            seed_path, None, Z_pole=1.0, Z_fermi=1.0, D_occ=0.25,
                            n=1.0, Omega=float("nan"), e_kin=a["E_kin_over_D"] * D,
                            resnorm=0.0, cr=None, diag=None, converged=True,
                            eta=None, W=None, eps_g=None, V0=None, Vg=None))
                    continue
                seed_row = nearest(seeds, uot)
                if seed_row is None:
                    # No stored matched parent at this (uot, branch). For the
                    # robust metal branch fall back to the generic metal seed
                    # (recorded); the insulator below coexistence genuinely has
                    # no branch, so leave it unseeded (reported non-converged).
                    if branch.startswith("metal"):
                        xseed = SR.seed_R_from_bare5(SC.METAL_X0)
                        parent_tag = "generic_metal_seed_SC.METAL_X0"
                    else:
                        for route, Nk in ROUTES:
                            rows.append(_row(commit, route, Nk, ud, td, 3,
                                             _branch_kind(branch), "no_matched_parent",
                                             seed_path, None, converged=False))
                        continue
                else:
                    xb = np.array([float(seed_row["V0"]), float(seed_row["Vg"]),
                                   float(seed_row["eps_g"]), float(seed_row["W"]),
                                   float(seed_row["eta"])])
                    xseed = SR.seed_R_from_bare5(xb)
                    parent_tag = os.path.basename(seed_path) + f"#uot{uot:g}"
                for route, Nk in ROUTES:
                    mp = ModelParamsMin(
                        t=t, eps_d=0.0, U=U, z=4.0, filling_target=1.0,
                        beta=1.0 / T_code, Nk=(Nk or 16), lattice="square",
                        n_moments=L.N_MOMENTS, Sigma_inf=U / 2.0,
                        lattice_quadrature=route, n_eps_dos=4001)
                    try:
                        xsol, r, d, e_kin, cr, diag = solve_point(mp, xseed, mu)
                        rows.append(_row(
                            commit, route, Nk, ud, td, 3, _branch_kind(branch),
                            "R_symmetric_least_squares", seed_path, parent_tag,
                            Z_pole=float(d["Z_pole"]), Z_fermi=float(d["Z_fermi"]),
                            D_occ=float(d["D"]), n=float(d["n_avg"]),
                            Omega=float(d["Omega"]), e_kin=e_kin, resnorm=r,
                            cr=cr, diag=diag, converged=(r < 1e-3),
                            eta=float(xsol_eta(d)), W=None,
                            eps_g=float(xsol[2]), V0=float(xsol[0]), Vg=float(xsol[1])))
                    except Exception as exc:
                        rows.append(_row(commit, route, Nk, ud, td, 3,
                                         _branch_kind(branch), "solver_error:" + type(exc).__name__,
                                         seed_path, None, converged=False))
    _write(rows)
    print(f"[square-pilot] {len(rows)} rows -> "
          f"{os.path.relpath(OUTDIR, _ROOT)}/square_pilot_raw.csv "
          f"({time.time() - t0:.0f}s)")


def _branch_kind(b):
    return "metal" if b.startswith("metal") else "insulator"


def xsol_eta(d):
    return float(str(d["eta"]).split(";")[0])


def _row(commit, route, Nk, ud, td, Mg, branch, solver_route, seed_path, parent,
         Z_pole=None, Z_fermi=None, D_occ=None, n=None, Omega=None, e_kin=None,
         resnorm=None, cr=None, diag=None, converged=None,
         eta=None, W=None, eps_g=None, V0=None, Vg=None):
    e_pot = None if (D_occ is None) else (4.0 * ud) * t * D_occ  # U * D_occ; U=uot*t=4ud*t
    e_tot = None if (e_kin is None or e_pot is None) else e_kin + e_pot
    row = dict(
        code_commit=commit, dirty=_dirty(), solver_route=solver_route,
        lattice="square", quadrature=route,
        Nk=(Nk if route == "uniform_kmesh" else ""),
        n_eps_dos=(4001 if route == "continuum_elliptic_dos" else ""),
        M_g=Mg, M_h=2, branch=branch, seed_path=seed_path, seed_parent=parent,
        U_over_D=ud, T_over_D=td, U_raw=4.0 * ud * t, T_raw=2.0 * td,
        Z_pole=Z_pole, Z_fermi=Z_fermi, D_occ=D_occ, n=n,
        Omega=Omega, Omega_over_D=(None if Omega is None else Omega / D),
        E_kin=e_kin, E_kin_over_D=(None if e_kin is None else e_kin / D),
        E_pot=e_pot, E_pot_over_D=(None if e_pot is None else e_pot / D),
        E_tot=e_tot, E_tot_over_D=(None if e_tot is None else e_tot / D),
        eps_g_R=eps_g, V0_R=V0, Vg_R=Vg,
        resnorm=resnorm, converged=(None if converged is None else int(converged)),
        equation_accepted=None, physical=None, gated=None,
        branch_continuous=None, selected=None,
        dist_to_spinodal_UD=round(SPINODAL_UD - ud, 4),
        norm_error=(None if diag is None else diag["norm_error"]),
        closure_error=(None if diag is None else diag["closure_error"]),
        roundtrip_error=(None if diag is None else diag["roundtrip_error"]),
        floor_limited=(None if diag is None else int(diag["floor_limited"])),
        lam_lattice_full=(None if cr is None else ";".join(f"{x:.8g}" for x in C._arr(cr.lat_sector.lam))),
        R_lattice_full=(None if cr is None else ";".join(f"{x:.8g}" for x in C._arr(cr.lat_sector.R))),
        quadrature_resolution_status=("reference_continuum"
                                      if route == "continuum_elliptic_dos"
                                      else f"uniform_kmesh_Nk{Nk}"),
    )
    return row


def _write(rows):
    cols = list(rows[0].keys())
    with open(os.path.join(OUTDIR, "square_pilot_raw.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)


def _commit():
    import subprocess
    try:
        return subprocess.check_output(["git", "-C", _ROOT, "rev-parse", "HEAD"],
                                       text=True).strip()
    except Exception:
        return "unknown"


def _dirty():
    import subprocess
    try:
        out = subprocess.check_output(["git", "-C", _ROOT, "status", "--porcelain"],
                                      text=True)
        return "dirty" if out.strip() else "clean"
    except Exception:
        return "unknown"


if __name__ == "__main__":
    main()
