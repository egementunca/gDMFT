#!/usr/bin/env python3
"""Stage 1 square resolution pilot v2 -- corrections over v1 (which is PRESERVED).

v1 (run_square_pilot.py -> square_pilot_raw.csv) is kept as prototype evidence.
v2 adds/fixes, writing a SEPARATE artifact (square_pilot_v2_raw.csv):
  * M_g=1 stationary pilot (v1 was M_g=3 only);
  * bare_native AND R_native solver routes distinguished (v1 solved in R coords
    only and labelled everything bare);
  * the ACTUAL integration node count recorded per row (Nk^2 for the mesh,
    n_eps for the continuum route);
  * duplicated U=0 rows removed (one analytic non-interacting row per
    route/M_g, not one per branch);
  * both metal and insulator branches at every interacting point.

Quadratures: uniform_kmesh Nk={16,32,64} and continuum_elliptic_dos (n_eps=4001,
node-convergence-validated to 7e-8 at U=0). Reduced units throughout.

Output: results/deliverables/09_single_site_publication_validation/square_pilot_v2_raw.csv
Usage:  .venv-numba/bin/python3 scripts/gauge_matrix/run_square_pilot_v2.py
"""
from __future__ import annotations

import csv
import os
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS = os.path.dirname(_HERE)
_ROOT = os.path.dirname(_SCRIPTS)
for p in (_ROOT, _SCRIPTS):
    if p not in sys.path:
        sys.path.insert(0, p)

from BHFM2.core.solve_min import ModelParamsMin, lat_obs, MODE_SINGLE_IMPURITY as SI  # noqa: E402
from dataclasses import replace  # noqa: E402
import landscape_map as L  # noqa: E402
import symmetric_continuation as SC  # noqa: E402
import symmetric_continuation_R as SR  # noqa: E402
from gauge_matrix import scan_matrix as SM  # noqa: E402
from gauge_matrix import square_integration as SIQ  # noqa: E402
from gauge_matrix import convert as C  # noqa: E402

OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")
STORE = os.path.join(_ROOT, "results/runs/20260710_rerun_mg3")
D = 2.0; t = 0.5
UD = [0.0, 1.0, 2.0, 2.5, 3.0]
TD = [0.001, 0.01]
ROUTES = [("uniform_kmesh", 16), ("uniform_kmesh", 32), ("uniform_kmesh", 64),
          ("continuum_elliptic_dos", 4001)]
SPINODAL_UD = 3.2


def mp_q(U, T_code, route, param):
    kw = dict(t=t, eps_d=0.0, U=U, z=4.0, filling_target=1.0, beta=1.0 / T_code,
              lattice="square", n_moments=L.N_MOMENTS, Sigma_inf=U / 2.0)
    if route == "uniform_kmesh":
        kw.update(Nk=param, lattice_quadrature="uniform_kmesh")
        nodes = param * param
    else:
        kw.update(Nk=16, lattice_quadrature="continuum_elliptic_dos", n_eps_dos=param)
        nodes = param
    return ModelParamsMin(**kw), nodes


def solve_one(Mg, gauge, U, T_code, route, param, seed):
    mp, nodes = mp_q(U, T_code, route, param)
    mu = U / 2.0
    if gauge == "bare_native" and Mg == 1:
        xs, r = SM.solve_mg1(mp, seed, mu); p = SM.sym_spar_mg1(xs, mu); mgn = 1
    elif gauge == "bare_native":
        xs, r = SC.solve_sym(mp, seed, mu); p = SC.sym_spar(xs, mu); mgn = 3
    elif Mg == 1:
        xs, r = SM.solve_mg1_R(mp, seed, mu); p = SM.sym_spar_mg1_R(xs, mu); mgn = 1
    else:
        xs, r = SR.solve_sym_R(mp, seed, mu); p = SR.sym_spar_R(xs, mu); mgn = 3
    d = L.diagnose(p, mp, mgn)
    lat = lat_obs(p, replace(mp, Sigma_inf=U / 2.0), 2, 0, mode=SI)
    e_kin = float(lat["e_kin"])
    cr = C.convert_root(np.asarray(p.eta, float), np.asarray(p.W, float),
                        np.asarray(p.eta1, float), np.asarray(p.W1, float), "square")
    return xs, r, d, e_kin, cr.diagnostics(), nodes


def bare_seed(Mg, gauge):
    if gauge == "bare_native":
        return (SM.METAL1_X0 if Mg == 1 else SC.METAL_X0).copy()
    return (SM.seed_mg1_R_from_bare(SM.METAL1_X0) if Mg == 1
            else SR.seed_R_from_bare5(SC.METAL_X0))


def ins_seed(Mg, gauge, U):
    if Mg == 3:
        return SC.ins_seed(U) if gauge == "bare_native" else SR.seed_R_from_bare5(SC.ins_seed(U))
    bare = np.array([1e-3, U / (2 * np.sqrt(2)), 3e-3])
    return bare if gauge == "bare_native" else SM.seed_mg1_R_from_bare(bare)


def _row(Mg, gauge, route, nodes, ud, td, branch, d, e_kin, diag, r, U):
    D_occ = d.get("D") if d else None
    return dict(
        lattice="square", M_g=Mg, M_h=2, gauge=gauge, solver_route=gauge,
        quadrature=route, integration_nodes=nodes,
        Nk=(int(nodes ** 0.5) if route == "uniform_kmesh" else ""),
        n_eps=(nodes if route == "continuum_elliptic_dos" else ""),
        branch=branch, U_over_D=ud, T_over_D=td, U_raw=U, T_raw=2.0 * td,
        Z_pole=(d.get("Z_pole") if d else None), Z_mats=(d.get("Z_fermi") if d else None),
        D_occ=D_occ, n=(d.get("n_avg") if d else None),
        Omega=(d.get("Omega") if d else None),
        Omega_over_D=(d["Omega"] / D if (d and d.get("Omega") is not None) else None),
        E_kin=e_kin, E_kin_over_D=(e_kin / D if e_kin is not None else None),
        E_pot=(U * D_occ if D_occ is not None else None),
        E_pot_over_D=((U * D_occ) / D if D_occ is not None else None),
        E_tot_over_D=(((e_kin + U * D_occ) / D) if (e_kin is not None and D_occ is not None) else None),
        resnorm=r, converged=(int(r < 1e-3) if r is not None else None),
        dist_to_spinodal_UD=round(SPINODAL_UD - ud, 4),
        norm_error=(diag["norm_error"] if diag else None),
        roundtrip_error=(diag["roundtrip_error"] if diag else None),
        floor_limited=(int(diag["floor_limited"]) if diag else None),
        equation_accepted=None, physical=None, gated=None,
        branch_continuous=None, selected=None)


def main():
    os.makedirs(OUT, exist_ok=True)
    rows = []
    for Mg in (3, 1):
        # bare_native full grid; R_native as SPOT CHECKS at metal/coexist/insulator
        for gauge in ("bare_native", "R_native"):
            spot = {2.0, 2.5, 3.0} if gauge == "R_native" else set(UD)
            for td in TD:
                T_code = 2.0 * td
                for branch in ("metal", "insulator"):
                    for ud in UD:
                        if ud not in spot:
                            continue
                        if ud == 0.0:
                            if branch != "metal":       # dedup: one U=0 row per route/Mg
                                continue
                            for route, param in ROUTES:
                                e, w = (SIQ.kmesh_nodes(param, t) if route == "uniform_kmesh"
                                        else SIQ.elliptic_dos_nodes(t, n_eps=param))
                                a = SIQ.anchors(e, w, t)
                                rows.append(_row(Mg, gauge, route,
                                                 (param * param if route == "uniform_kmesh" else param),
                                                 0.0, td, "noninteracting",
                                                 dict(Z_pole=1.0, Z_fermi=1.0, D=0.25, n_avg=1.0,
                                                      Omega=float("nan")),
                                                 a["E_kin_over_D"] * D, None, 0.0, 0.0))
                            continue
                        U = 4.0 * ud * t
                        seed0 = bare_seed(Mg, gauge) if branch == "metal" else ins_seed(Mg, gauge, U)
                        for route, param in ROUTES:
                            try:
                                xs, r, d, e_kin, diag, nodes = solve_one(
                                    Mg, gauge, U, T_code, route, param, seed0)
                                d["basin"] = L.basin_label(d)
                                rows.append(_row(Mg, gauge, route, nodes, ud, td,
                                                 branch, d, e_kin, diag, r, U))
                            except Exception as exc:
                                rows.append(_row(Mg, gauge, route,
                                                 (param * param if route == "uniform_kmesh" else param),
                                                 ud, td, branch, None, None, None, None, U)
                                             | dict(error=f"{type(exc).__name__}:{exc}"))
    cols = list(rows[0].keys())
    with open(os.path.join(OUT, "square_pilot_v2_raw.csv"), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols, extrasaction="ignore")
        w.writeheader(); w.writerows(rows)
    conv = sum(1 for r in rows if r.get("converged") == 1)
    print(f"square_pilot_v2_raw.csv: {len(rows)} rows, {conv} converged")
    import collections
    by = collections.Counter((r["M_g"], r["gauge"]) for r in rows)
    for k, v in sorted(by.items()):
        print(f"  Mg={k[0]} {k[1]}: {v} rows")


if __name__ == "__main__":
    main()
