#!/usr/bin/env python3
"""Selectable, provenance-recorded square-lattice integration routes.

Two ways to integrate the tight-binding square lattice (dispersion
eps_k = -2 t (cos kx + cos ky), band [-4t, 4t], half-bandwidth D = 4t):

  uniform_kmesh          : the production route -- a uniform Nk x Nk (kx, ky)
                           mesh, weight 1/Nk^2. Converges only ~1/Nk near the
                           van Hove singularity at eps = 0 (the half-filling
                           Fermi level), so small Nk biases half-filled energies.
  continuum_elliptic_dos : a 1-D quadrature over the exact square density of
                           states rho(eps) = K(m)/(2 pi^2 t), m = 1-(eps/4t)^2
                           (complete elliptic integral of the first kind), with
                           nodes graded toward the eps=0 log singularity so the
                           van Hove point is resolved. The D=1 continuum limit.

Both return `(eps, weight)` node lists in code units (t as given). Higher-orbit
form-factor fields are 0 (single-impurity mode does not use them).

U=0 anchors used to validate a route:
  normalization  sum w            = 1
  first moment   sum w eps         = 0            (PH symmetry)
  E_kin/D (T=0, half filling)      = -4/pi^2      (= -0.4052847...)
  second moment  sum w eps^2 / D^2 = 1/4          (square lattice)
"""
from __future__ import annotations

import numpy as np
from scipy.special import ellipk

MINUS_4_OVER_PI2 = -4.0 / np.pi ** 2      # continuum square E_kin/D at U=0, T=0


def kmesh_nodes(Nk: int, t: float = 0.5):
    """Uniform Nk x Nk (kx, ky) mesh nodes (eps, weight)."""
    k = np.linspace(-np.pi, np.pi, Nk, endpoint=False)
    wk = 1.0 / (Nk * Nk)
    kx, ky = np.meshgrid(k, k, indexing="ij")
    eps = (-2.0 * t * (np.cos(kx) + np.cos(ky))).ravel()
    w = np.full(eps.size, wk)
    return eps, w


def square_dos(eps, t: float = 0.5):
    """Exact tight-binding square-lattice DOS rho(eps), band [-4t, 4t]."""
    eps = np.asarray(eps, float)
    band = 4.0 * t
    m = 1.0 - (eps / band) ** 2                    # scipy ellipk takes parameter m=k^2
    # clamp off the exact van Hove point (m=1 -> ellipk diverges logarithmically,
    # integrable); a finite cap keeps rho(eps->0) large-but-finite so the graded
    # midpoint weight rho*deps stays finite.
    m = np.clip(m, 0.0, 1.0 - 1e-15)
    out = np.zeros_like(eps)
    inside = m > 0.0
    out[inside] = ellipk(m[inside]) / (2.0 * np.pi ** 2 * t)
    return out


def elliptic_dos_nodes(t: float = 0.5, n_eps: int = 20001, grade: float = 3.0):
    """1-D square-DOS quadrature nodes graded toward the van Hove point eps=0.

    Midpoint rule on a symmetric grid whose spacing tightens near eps=0 via a
    sinh-like grading (exponent `grade`), so the integrable log singularity is
    resolved. Weight_i = rho(eps_i) * d(eps)_i, renormalized to sum to 1 exactly
    (the residual is the discretization error of the DOS normalization).
    """
    band = 4.0 * t
    # graded node centers in (-band, band): u uniform in (-1,1) -> eps = band*sign*|u|^grade
    u = np.linspace(-1.0, 1.0, n_eps + 1)          # cell edges
    edges = band * np.sign(u) * np.abs(u) ** grade
    centers = 0.5 * (edges[1:] + edges[:-1])
    deps = np.diff(edges)
    w = square_dos(centers, t) * deps
    w = w / w.sum()                                 # enforce exact normalization
    return centers, w


def anchors(eps, w, t: float = 0.5):
    """U=0 validation anchors for a node set (eps, w)."""
    D = 4.0 * t
    norm = float(np.sum(w))
    m1 = float(np.sum(w * eps))
    m2 = float(np.sum(w * eps ** 2)) / D ** 2
    # T=0 half-filled kinetic energy per site: 2 * sum_{eps<0} eps w  (spin factor 2)
    occ = eps < 0.0
    e_kin = 2.0 * float(np.sum((w * eps)[occ]))
    return dict(normalization=norm, first_moment=m1, E_kin_over_D=e_kin / D,
                second_moment_over_D2=m2)


def node_convergence(t: float = 0.5, node_counts=(1001, 2001, 4001, 8001)):
    """Continuum-DOS node-count convergence of the U=0 anchors. Returns a list of
    dicts (one per node count) with the anchors + errors vs the continuum limit."""
    ref = MINUS_4_OVER_PI2
    rows = []
    prev = None
    for n in node_counts:
        e, w = elliptic_dos_nodes(t, n_eps=n)
        a = anchors(e, w, t)
        rows.append(dict(
            n_eps=n, normalization=a["normalization"], first_moment=a["first_moment"],
            E_kin_over_D=a["E_kin_over_D"],
            abs_err_Ekin_vs_analytic=abs(a["E_kin_over_D"] - ref),
            second_moment_over_D2=a["second_moment_over_D2"],
            delta_Ekin_vs_prev=(None if prev is None else abs(a["E_kin_over_D"] - prev)),
        ))
        prev = a["E_kin_over_D"]
    return rows


if __name__ == "__main__":
    t = 0.5
    print(f"{'route':26s} {'norm':>10s} {'m1':>10s} {'Ekin/D':>12s} "
          f"{'|dEkin/D|':>11s} {'m2/D2':>8s}")
    ref = MINUS_4_OVER_PI2
    for name, (e, w) in [
        ("kmesh Nk=16", kmesh_nodes(16, t)),
        ("kmesh Nk=32", kmesh_nodes(32, t)),
        ("kmesh Nk=64", kmesh_nodes(64, t)),
        ("kmesh Nk=256", kmesh_nodes(256, t)),
        ("continuum_elliptic", elliptic_dos_nodes(t)),
    ]:
        a = anchors(e, w, t)
        print(f"{name:26s} {a['normalization']:10.6f} {a['first_moment']:10.2e} "
              f"{a['E_kin_over_D']:12.7f} {abs(a['E_kin_over_D']-ref):11.2e} "
              f"{a['second_moment_over_D2']:8.4f}")
    print(f"\nreference E_kin/D = -4/pi^2 = {ref:.7f};  m2/D2 (exact) = 0.25")
    print("\ncontinuum DOS node-count convergence:")
    print(f"{'n_eps':>8s} {'Ekin/D':>12s} {'|err vs -4/pi^2|':>16s} {'|delta vs prev|':>16s}")
    for r in node_convergence(t):
        dp = r["delta_Ekin_vs_prev"]
        print(f"{r['n_eps']:8d} {r['E_kin_over_D']:12.8f} "
              f"{r['abs_err_Ekin_vs_analytic']:16.2e} "
              f"{('%.2e' % dp) if dp is not None else '-':>16s}")
