#!/usr/bin/env python3
"""Promote the v2 raw campaign into the TRACKED deliverable so the canonical
solution data does not live only under gitignored results/runs/.

Copies every per-T JSONL + the run registry from
results/runs/20260717_scan_matrix_v2/<cell>/ into
results/deliverables/09_single_site_publication_validation/raw_campaign/<cell>/,
and mirrors the superseded runs under raw_campaign/_superseded/ (so nothing is
hidden). Idempotent; verifies byte-identity on re-copy (never silently replaces
a differing file). After this, build_stage3_v2.py reads from the tracked mirror.
"""
from __future__ import annotations

import glob
import gzip
import hashlib
import os
import shutil
import sys
import tarfile

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SRC = os.path.join(_ROOT, "results/runs/20260717_scan_matrix_v2")
DST = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation/raw_campaign")


def _sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()


def _copy(src, dst):
    os.makedirs(os.path.dirname(dst), exist_ok=True)
    if os.path.exists(dst):
        if _sha(src) == _sha(dst):
            return "same"
        raise SystemExit(f"REFUSING to overwrite differing tracked file: {dst}")
    shutil.copy2(src, dst)
    return "copied"


def _normalized_tarinfo(info):
    info.uid = info.gid = 0
    info.uname = info.gname = ""
    info.mtime = 0
    info.mode = 0o755 if info.isdir() else 0o644
    info.pax_headers = {}
    return info


def _write_deterministic_archive(src, dst):
    tmp = dst + ".tmp"
    with open(tmp, "wb") as raw:
        with gzip.GzipFile(
                filename="", mode="wb", fileobj=raw, compresslevel=9,
                mtime=0) as compressed:
            with tarfile.open(
                    fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as tf:
                tf.add(src, arcname="raw_campaign",
                       filter=_normalized_tarinfo)
    os.replace(tmp, dst)


def main():
    n_copy = n_same = 0
    # per-cell per-T JSONL
    for f in sorted(glob.glob(os.path.join(SRC, "*", "T*.jsonl"))):
        rel = os.path.relpath(f, SRC)
        r = _copy(f, os.path.join(DST, rel))
        n_copy += (r == "copied"); n_same += (r == "same")
    # registry
    reg = os.path.join(SRC, "scan_run_registry.csv")
    if os.path.exists(reg):
        _copy(reg, os.path.join(DST, "scan_run_registry.csv"))
    # superseded runs (preserved, mirrored so nothing is hidden)
    for sup in sorted(glob.glob(os.path.join(_ROOT, "results/runs/20260717_scan_matrix_v2_superseded_*"))):
        tag = os.path.basename(sup)
        for f in sorted(glob.glob(os.path.join(sup, "*", "T*.jsonl"))):
            rel = os.path.relpath(f, sup)
            _copy(f, os.path.join(DST, "_superseded", tag, rel))
    # also mirror the v1 registry + a pointer note (v1 CSV campaign preserved)
    v1reg = os.path.join(_ROOT, "results/runs/20260717_scan_matrix/scan_run_registry.csv")
    if os.path.exists(v1reg):
        _copy(v1reg, os.path.join(DST, "_v1_campaign", "scan_run_registry_v1.csv"))
    n_files = len(glob.glob(os.path.join(DST, "*", "T*.jsonl")))

    # The extracted raw_campaign/ dir (64M) is large; the TRACKED artifact is a
    # deterministic tar.gz (~6M). Build it, and gitignore the regenerable large
    # files so only the compressed canonical data + the small tables are tracked.
    arc = os.path.join(os.path.dirname(DST), "raw_campaign.tar.gz")
    _write_deterministic_archive(DST, arc)
    gi = os.path.join(os.path.dirname(DST), ".gitignore")
    with open(gi, "w") as f:
        f.write("# regenerable from the TRACKED raw_campaign.tar.gz via "
                "scripts/gauge_matrix/build_stage3_v2.py\n"
                "raw_campaign/\n"
                "stage3_attempts.jsonl\n")
    print(f"raw_campaign/: {n_copy} copied, {n_same} unchanged; {n_files} per-T "
          f"JSONL. Tracked artifact: raw_campaign.tar.gz "
          f"({os.path.getsize(arc)/1048576:.1f} MB); extracted dir + "
          f"stage3_attempts.jsonl gitignored (regenerable).")


if __name__ == "__main__":
    main()
