#!/usr/bin/env python3
"""Build the canonical single-site gauge-matrix export (deterministic, no solver).

Produces, under results/deliverables/08_single_site_gauge_matrix/:
  source_manifest.csv    per-file checksums + record counts (conservation)
  roots.jsonl.gz         deterministic lossless archive, one JSON record per
                         representation (bare + converted-R +
                         native/reoptimized-R), full canonical arrays + diags
  roots_archive_manifest.json
                         compressed/decompressed checksums, sizes, record count
  scalar_projection.csv  flat per-record scalar view for quick analysis
  grid_registry.json     canonical Bethe/Square benchmark grids  (build_grids)
  coverage_matrix.csv    point-key coverage by evidence type      (build_grids)
  coverage_report.md     the human-readable coverage/missing report(build_grids)

This module writes the first three. `build_grids.py` writes the grid/coverage
set. Everything here is deterministic gauge conversion + postprocessing: NO
optimizer, ED, gem, or DMFT-ED calculation is invoked.

Usage:
  .venv-numba/bin/python3 -m gauge_matrix.build            # from scripts/
  python3 scripts/gauge_matrix/build.py
  python3 scripts/gauge_matrix/build.py --archive-only
"""
from __future__ import annotations

import csv
import gzip
import glob
import hashlib
import json
import os
import shutil
import subprocess
import sys

import numpy as np

_HERE = os.path.dirname(os.path.abspath(__file__))
_SCRIPTS = os.path.dirname(_HERE)
_ROOT = os.path.dirname(_SCRIPTS)
for p in (_SCRIPTS, _ROOT):
    if p not in sys.path:
        sys.path.insert(0, p)

from gauge_matrix import sources as S          # noqa: E402
from gauge_matrix import convert as C          # noqa: E402
from BHFM2.core.reparam_R import hsector_to_bare  # noqa: E402

OUT = os.path.join(_ROOT, "results/deliverables/08_single_site_gauge_matrix")
RUNS = S.RUNS
ROOTS_JSONL = os.path.join(OUT, "roots.jsonl")
ROOTS_ARCHIVE = os.path.join(OUT, "roots.jsonl.gz")
ROOTS_ARCHIVE_MANIFEST = os.path.join(OUT, "roots_archive_manifest.json")


def code_commit() -> str:
    try:
        return subprocess.check_output(
            ["git", "-C", _ROOT, "rev-parse", "HEAD"], text=True).strip()
    except Exception:
        return "unknown"


COMMIT = None    # set in main()


# ==========================================================================
# source manifest (Phase 1): checksum + record-count every live source file
# ==========================================================================
def _n_csv(path):
    with open(path) as f:
        return max(0, sum(1 for _ in f) - 1)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _manifest_groups():
    """(glob or file, kind, role, lattice, Mg, evidence_type, counter) tuples.

    role: canonical_source | generated_view | reference | checkpoint
    """
    g = []
    P = lambda *a: os.path.join(RUNS, *a)
    # --- canonical bare sources ---
    g.append((P("20260715_paper_scans/mg3_bethe/symmetric_bethe_T*.csv"),
              "csv", "canonical_source", "bethe", 3, "bare_native", _n_csv))
    g.append((P("20260710_rerun_mg3/symmetric_square_T*.csv"),
              "csv", "canonical_source", "square", 3, "bare_native", _n_csv))
    for d, lat, camp in S.mg1_attempt_dirs():
        g.append((os.path.join(d, "*.json"), "json_attempt", "canonical_source",
                  lat, 1, "bare_native", None))
    # --- canonical R-gauge sources ---
    g.append((P("20260715_paper_scans/mg3_bethe_R/symmetricR_bethe_T*.csv"),
              "csv", "canonical_source", "bethe", 3, "R_native_continuation", _n_csv))
    g.append((P("20260715_paper_scans/gauge_certify_square/gauge_certify_square_T*.csv"),
              "csv", "canonical_source", "square", 3, "R_reoptimized_from_bare", _n_csv))
    # --- Mg=1 bare checkpoints (full x vectors; observables joined via rebuild) ---
    for lat in ("bethe", "square"):
        for arm in ("metal", "gs", "ins", "census"):
            g.append((P("20260710_rerun_mg1/ckpt", f"{lat}_{arm}", "*.pkl"),
                      "pkl", "checkpoint", lat, 1, "bare_native", None))
    # --- scalar / partial certification artifacts (LOSSY, superseded by this export) ---
    g.append((P("20260715_paper_scans/gauge_certify/gauge_certify_bethe_T*.csv"),
              "csv", "generated_view", "bethe", 3, "R_reoptimized_scalar_only", _n_csv))
    g.append((P("20260715_paper_scans/gauge_certify/mg1_R_certify_bethe.csv"),
              "csv", "generated_view", "bethe", 1, "R_converted_scalar_only", _n_csv))
    g.append((P("20260715_paper_scans/gauge_certify/mg1_R_certify_square.csv"),
              "csv", "generated_view", "square", 1, "R_converted_scalar_only", _n_csv))
    # --- collector rebuilds (generated views, lossy) ---
    g.append((P("20260710_rerun_mg1/r1_mg1_rebuild.csv"),
              "csv", "generated_view", "both", 1, "collector", _n_csv))
    g.append((P("20260715_paper_scans/mg1_bethe/r1_mg1_rebuild.csv"),
              "csv", "generated_view", "bethe", 1, "collector", _n_csv))
    g.append((P("20260710_rerun_mg3/r2_mg3_rebuild_bethe.csv"),
              "csv", "generated_view", "bethe", 3, "collector", _n_csv))
    g.append((P("20260710_rerun_mg3/r2_mg3_rebuild_square.csv"),
              "csv", "generated_view", "square", 3, "collector", _n_csv))
    # --- reference methods (gem + DMFT-ED) ---
    g.append((P("20260715_paper_scans/gem_gga/gem_B*_T*.csv"),
              "csv", "reference", "bethe", 0, "gem", _n_csv))
    g.append((P("20260715_paper_scans/gem_gga_square/gem_B*_T*.csv"),
              "csv", "reference", "square", 0, "gem", _n_csv))
    g.append((P("20260715_paper_scans/dmft_ed/dmft_ed_Nb*.csv"),
              "csv", "reference", "bethe", 0, "dmft_ed_groundstate", _n_csv))
    g.append((P("20260715_paper_scans/dmft_ed_square/dmft_ed_Nb*.csv"),
              "csv", "reference", "square", 0, "dmft_ed_groundstate", _n_csv))
    return g


def build_manifest():
    rows = []
    for pat, kind, role, lat, Mg, ev, counter in _manifest_groups():
        for path in sorted(glob.glob(pat)):
            n = counter(path) if counter else 1
            rows.append(dict(
                source_path=S.relpath(path), sha256=S.sha256(path),
                kind=kind, role=role, lattice=lat, M_g=Mg, evidence_type=ev,
                n_records=n, bytes=os.path.getsize(path)))
    fn = os.path.join(OUT, "source_manifest.csv")
    cols = ["source_path", "sha256", "kind", "role", "lattice", "M_g",
            "evidence_type", "n_records", "bytes"]
    with open(fn, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        w.writerows(rows)
    return rows


# ==========================================================================
# roots archive (Phase 3): bare + R_converted partner + R-evidence records
# ==========================================================================
def _model_block(lattice, M_g, branch, cont_dir, solver_route, evidence_type,
                 uot, U_code, T_code, t):
    D = C.D_OF_LATTICE[lattice]
    return dict(
        lattice=lattice, M_h=2, M_g=M_g, branch=branch,
        continuation_direction=cont_dir, solver_route=solver_route,
        evidence_type=evidence_type, D=D, t=t,
        U_raw=U_code, T_raw=T_code,
        U_over_D=(C.u_over_d(uot, lattice) if uot is not None else None),
        T_over_D=(C.t_over_d(T_code, lattice) if T_code is not None else None))


def _reduce_obs(obs, lattice):
    """Add reduced (/D) siblings for energy-like observables; keep raw."""
    D = C.D_OF_LATTICE[lattice]
    out = dict(obs)
    for k in ("Omega", "E_kin", "E_pot", "E_tot", "Omega_imp", "Omega_lat",
              "Omega_gateway"):
        if obs.get(k) is not None:
            out[f"{k}_over_D"] = float(obs[k]) / D
    for k in ("sumV2", "sumW2"):
        if obs.get(k) is not None:
            out[f"{k}_over_D2"] = float(obs[k]) / D ** 2
    for k in ("maxV", "maxW"):
        if obs.get(k) is not None:
            out[f"{k}_over_D"] = float(obs[k]) / D
    return out


def _quadrature_block(lattice):
    if lattice == "square":
        return dict(lattice_quadrature="uniform_kmesh", Nk=16, n_kpoints=256,
                    quadrature_resolution_status="preliminary_for_subpercent_energy_claims")
    return dict(lattice_quadrature="bethe_semicircle_closed_form", Nk=256,
                n_kpoints=None, quadrature_resolution_status="reference_analytic")


def _bare_and_converted(b: S.BareRoot):
    """Yield (bare_native record, R_converted_from_bare record) for one root."""
    lat = b.lattice
    uod = C.u_over_d(b.uot, lat) if b.uot is not None else None
    tod = C.t_over_d(b.T_code, lat) if b.T_code is not None else None
    pk = S.point_key(lat, b.M_g, uod or 0.0, tod or 0.0, b.branch)
    rid = S.record_id(b.source_checksum, b.source_path, b.source_record_index)

    bare = dict(
        identity=dict(source_record_id=rid, point_key=pk, parent_id=None,
                      campaign=b.campaign, source_path=b.source_path,
                      source_checksum=b.source_checksum,
                      source_record_index=b.source_record_index,
                      code_commit=COMMIT),
        model=_model_block(lat, b.M_g, b.branch, b.continuation_direction,
                           "bare_least_squares", "bare_native",
                           b.uot, b.U_code, b.T_code, b.t),
        g_sector=dict(eps_g=b.eps_g, V_g=b.V_g),
        bare_h_sectors=dict(eta_lattice=b.eta_lattice, W_lattice=b.W_lattice,
                            eta_gateway=b.eta_gateway, W_gateway=b.W_gateway),
        canonical_h_sectors=None,
        observables=_reduce_obs(b.observables, lat),
        reliability=dict(b.reliability),
        classification=dict(b.classification),
        quadrature=_quadrature_block(lat),
    )

    # deterministic forward conversion of BOTH h-sectors
    cr = C.convert_root(b.eta_lattice, b.W_lattice, b.eta_gateway, b.W_gateway,
                        lat, ebar=0.0)
    Ld, Gd = cr.lat_sector, cr.gw_sector
    lamL, RfL = C.reduced_lambda_Rf(Ld)
    lamG, RfG = C.reduced_lambda_Rf(Gd)
    diag = cr.diagnostics()
    conv = dict(
        identity=dict(source_record_id=rid + ":Rconv", point_key=pk,
                      parent_id=rid, campaign=b.campaign,
                      source_path=b.source_path,
                      source_checksum=b.source_checksum,
                      source_record_index=b.source_record_index,
                      code_commit=COMMIT),
        model=_model_block(lat, b.M_g, b.branch, b.continuation_direction,
                           "deterministic_forward_map", "R_converted_from_bare",
                           b.uot, b.U_code, b.T_code, b.t),
        g_sector=dict(eps_g=b.eps_g, V_g=b.V_g),
        bare_h_sectors=dict(eta_lattice=b.eta_lattice, W_lattice=b.W_lattice,
                            eta_gateway=b.eta_gateway, W_gateway=b.W_gateway),
        canonical_h_sectors=dict(
            lambda_lattice_full=C._arr(Ld.lam), R_lattice_full=C._arr(Ld.R),
            lambda_gateway_full=C._arr(Gd.lam), R_gateway_full=C._arr(Gd.R),
            lambda_lattice_over_D=C._arr(C.scale_energy(Ld.lam, lat)),
            lambda_gateway_over_D=C._arr(C.scale_energy(Gd.lam, lat)),
            lam_reduced_lattice=lamL, Rf_reduced_lattice=RfL,
            lam_reduced_gateway=lamG, Rf_reduced_gateway=RfG,
            Z_pole_from_R=cr.Z_pole, Z_pole_gateway_poleSum=cr.z_pole_gateway,
            n_modes=diag["n_modes"]),
        observables=_reduce_obs(b.observables, lat),
        reliability=dict(
            b.reliability,
            norm_error=diag["norm_error"], closure_error=diag["closure_error"],
            roundtrip_error=diag["roundtrip_error"],
            interlacing_error=diag["interlacing_error"]),
        classification=dict(b.classification, floor_limited=diag["floor_limited"]),
        quadrature=_quadrature_block(lat),
    )
    return bare, conv


def _r_evidence_record(e: S.REvidence):
    lat = e.lattice
    uod = C.u_over_d(e.uot, lat) if e.uot is not None else None
    tod = C.t_over_d(e.T_code, lat) if e.T_code is not None else None
    pk = S.point_key(lat, e.M_g, uod or 0.0, tod or 0.0, e.branch)
    rid = S.record_id(e.source_checksum, e.source_path, e.source_record_index)

    # Assemble the full canonical arrays from the reduced (lam, Rf): PH ghosts at
    # +/-lam with overlap Rf, QP mode closing normalization + ebar=0. Reuse the
    # trusted arrowhead codec, then forward-map for identical diagnostics.
    lam, Rf = e.lam, e.Rf
    cls = dict(e.classification)
    floor = bool(cls.get("floor_limited", False))
    try:
        eta_bk, W_bk = hsector_to_bare(np.array([lam, -lam]),
                                       np.array([Rf, Rf]), 0.0)
        hs = C.forward_hsector(eta_bk, W_bk, 0.0)
        canon = dict(
            lambda_full=C._arr(hs.lam), R_full=C._arr(hs.R),
            lambda_over_D=C._arr(C.scale_energy(hs.lam, lat)),
            lam_reduced=lam, Rf_reduced=Rf, Z_pole_from_R=float(hs.Z_fermi),
            n_modes=int(hs.lam.size),
            eta_R=C._arr(e.eta_R), W_R=C._arr(e.W_R))
        rel_extra = dict(norm_error=hs.norm_error, closure_error=hs.closure_error,
                         roundtrip_error=C._nan(hs.roundtrip_error),
                         interlacing_error=hs.interlacing_error)
        if hs.floor_limited:
            floor = True
    except Exception as exc:
        canon = dict(lam_reduced=lam, Rf_reduced=Rf, n_modes=3,
                     reconstruction_error=str(exc))
        rel_extra = {}

    return dict(
        identity=dict(source_record_id=rid, point_key=pk,
                      parent_id=None, parent_point_key=e.parent_point_key,
                      campaign=e.campaign, source_path=e.source_path,
                      source_checksum=e.source_checksum,
                      source_record_index=e.source_record_index,
                      code_commit=COMMIT),
        model=_model_block(lat, e.M_g, e.branch, e.continuation_direction,
                           e.solver_route, e.evidence_type,
                           e.uot, e.U_code, e.T_code, e.t),
        g_sector=dict(eps_g=e.eps_g, V_g=e.V_g),
        bare_h_sectors=None,
        canonical_h_sectors=canon,
        observables=_reduce_obs(e.observables, lat),
        reliability=dict(e.reliability, **rel_extra),
        classification=dict(cls, floor_limited=floor),
        quadrature=_quadrature_block(lat),
    )


SCALAR_COLS = [
    "source_record_id", "parent_id", "point_key", "evidence_type", "campaign",
    "lattice", "M_g", "M_h", "branch", "continuation_direction", "solver_route",
    "U_over_D", "T_over_D", "U_raw", "T_raw",
    "Z_pole", "Z_pole_from_R", "Z_mats", "D_occ", "n", "Omega", "Omega_over_D",
    "E_pot", "E_pot_over_D", "lam_reduced", "Rf_reduced",
    "total_residual", "norm_error", "closure_error", "roundtrip_error",
    "interlacing_error", "floor_limited", "n_modes",
    "converged", "equation_accepted", "physical", "gated",
    "branch_continuous", "selected",
    "lattice_quadrature", "quadrature_resolution_status",
]


def _scalar_row(rec):
    ident, model = rec["identity"], rec["model"]
    obs = rec.get("observables") or {}
    canon = rec.get("canonical_h_sectors") or {}
    rel = rec.get("reliability") or {}
    cls = rec.get("classification") or {}
    quad = rec.get("quadrature") or {}
    lam_red = canon.get("lam_reduced", canon.get("lam_reduced_gateway"))
    Rf_red = canon.get("Rf_reduced", canon.get("Rf_reduced_gateway"))
    return {
        "source_record_id": ident["source_record_id"],
        "parent_id": ident.get("parent_id"),
        "point_key": ident["point_key"],
        "evidence_type": model["evidence_type"], "campaign": ident["campaign"],
        "lattice": model["lattice"], "M_g": model["M_g"], "M_h": model["M_h"],
        "branch": model["branch"],
        "continuation_direction": model["continuation_direction"],
        "solver_route": model["solver_route"],
        "U_over_D": model["U_over_D"], "T_over_D": model["T_over_D"],
        "U_raw": model["U_raw"], "T_raw": model["T_raw"],
        "Z_pole": obs.get("Z_pole"), "Z_pole_from_R": canon.get("Z_pole_from_R"),
        "Z_mats": obs.get("Z_mats"), "D_occ": obs.get("D_occ"),
        "n": obs.get("n"), "Omega": obs.get("Omega"),
        "Omega_over_D": obs.get("Omega_over_D"),
        "E_pot": obs.get("E_pot"), "E_pot_over_D": obs.get("E_pot_over_D"),
        "lam_reduced": lam_red, "Rf_reduced": Rf_red,
        "total_residual": rel.get("total_residual"),
        "norm_error": rel.get("norm_error"),
        "closure_error": rel.get("closure_error"),
        "roundtrip_error": rel.get("roundtrip_error"),
        "interlacing_error": rel.get("interlacing_error"),
        "floor_limited": cls.get("floor_limited"),
        "n_modes": canon.get("n_modes"),
        "converged": cls.get("converged"),
        "equation_accepted": cls.get("equation_accepted"),
        "physical": cls.get("physical"), "gated": cls.get("gated"),
        "branch_continuous": cls.get("branch_continuous"),
        "selected": cls.get("selected"),
        "lattice_quadrature": quad.get("lattice_quadrature"),
        "quadrature_resolution_status": quad.get("quadrature_resolution_status"),
    }


def build_roots():
    os.makedirs(OUT, exist_ok=True)
    jl = open(ROOTS_JSONL, "w")
    sc = open(os.path.join(OUT, "scalar_projection.csv"), "w", newline="")
    sw = csv.DictWriter(sc, fieldnames=SCALAR_COLS)
    sw.writeheader()
    counts = dict(bare_native=0, R_converted_from_bare=0,
                  R_native_continuation=0, R_reoptimized_from_bare=0)
    floor = dict(R_converted_from_bare=0, R_reoptimized_from_bare=0,
                 R_native_continuation=0)
    rt_fail = 0
    for b in S.iter_bare_roots():
        bare, conv = _bare_and_converted(b)
        for rec in (bare, conv):
            jl.write(json.dumps(rec) + "\n")
            sw.writerow(_scalar_row(rec))
            counts[rec["model"]["evidence_type"]] += 1
        if conv["classification"].get("floor_limited"):
            floor["R_converted_from_bare"] += 1
        rte = conv["reliability"].get("roundtrip_error")
        if rte is None or (isinstance(rte, float) and not np.isfinite(rte)):
            rt_fail += 1
    for e in S.iter_r_evidence():
        rec = _r_evidence_record(e)
        jl.write(json.dumps(rec) + "\n")
        sw.writerow(_scalar_row(rec))
        ev = rec["model"]["evidence_type"]
        counts[ev] += 1
        if rec["classification"].get("floor_limited"):
            floor[ev] += 1
    jl.close(); sc.close()
    return dict(counts=counts, floor_limited=floor, roundtrip_fail=rt_fail)


def archive_roots():
    """Create a deterministic, lossless gzip of the expanded root table."""
    if not os.path.exists(ROOTS_JSONL):
        raise FileNotFoundError(ROOTS_JSONL)

    tmp = ROOTS_ARCHIVE + ".tmp"
    with open(ROOTS_JSONL, "rb") as src, open(tmp, "wb") as raw:
        with gzip.GzipFile(
                filename="", mode="wb", fileobj=raw, compresslevel=9,
                mtime=0) as dst:
            shutil.copyfileobj(src, dst, length=1 << 20)
    os.replace(tmp, ROOTS_ARCHIVE)

    with open(ROOTS_JSONL, "rb") as f:
        record_count = sum(1 for line in f if line.strip())
    meta = {
        "archive": os.path.basename(ROOTS_ARCHIVE),
        "format": "gzip",
        "compression_level": 9,
        "deterministic_gzip_mtime": 0,
        "record_count": record_count,
        "uncompressed_bytes": os.path.getsize(ROOTS_JSONL),
        "uncompressed_sha256": _sha256(ROOTS_JSONL),
        "archive_bytes": os.path.getsize(ROOTS_ARCHIVE),
        "archive_sha256": _sha256(ROOTS_ARCHIVE),
    }
    manifest_tmp = ROOTS_ARCHIVE_MANIFEST + ".tmp"
    with open(manifest_tmp, "w") as f:
        json.dump(meta, f, indent=2, sort_keys=True)
        f.write("\n")
    os.replace(manifest_tmp, ROOTS_ARCHIVE_MANIFEST)
    return meta


def main():
    global COMMIT
    if "--archive-only" in sys.argv:
        meta = archive_roots()
        print(f"[roots archive] {meta['record_count']} records; "
              f"{meta['uncompressed_bytes']} -> {meta['archive_bytes']} bytes; "
              f"payload sha256={meta['uncompressed_sha256']}")
        return

    COMMIT = code_commit()
    os.makedirs(OUT, exist_ok=True)
    print(f"[gauge-matrix] OUT = {S.relpath(OUT)}  commit={COMMIT[:8]}")
    man = build_manifest()
    print(f"[manifest] {len(man)} source files checksummed")
    stats = build_roots()
    archive = archive_roots()
    print(f"[roots] evidence-type counts: {stats['counts']}")
    print(f"[roots] floor-limited: {stats['floor_limited']}")
    print(f"[roots] converted roundtrip failures: {stats['roundtrip_fail']}")
    print(f"[roots archive] {archive['uncompressed_bytes']} -> "
          f"{archive['archive_bytes']} bytes")
    with open(os.path.join(OUT, "_build_stats.json"), "w") as f:
        json.dump(dict(commit=COMMIT, manifest_files=len(man), **stats), f, indent=2)


if __name__ == "__main__":
    main()
