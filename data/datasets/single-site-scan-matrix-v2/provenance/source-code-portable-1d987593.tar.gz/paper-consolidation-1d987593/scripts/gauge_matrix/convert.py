#!/usr/bin/env python3
"""Deterministic bare -> canonical-R gauge conversion + diagnostics + units.

This is the pure, login-node-safe core of the single-site gauge-matrix export.
It performs NO optimization, NO ED, NO lattice self-consistency: it only

  * forward-maps a bare h-sector (ebar, eta[Mh], W[Mh]) to its canonical
    spectrum (lambda[Mh+1], R[Mh+1]) via the arrowhead eigendecomposition of
    BHFM2.core.canonical_gauge (the April-28 draft Eqs 20-32);
  * measures the exactness of that representation (normalization, ebar-closure,
    inverse round-trip back to (eta, W), and pole/zero interlacing);
  * converts code-unit energies/weights to reduced U/D units by dimension.

Every quantity it emits is therefore `R_converted_from_bare` evidence -- a
mathematically complete gauge representation of the SAME bare root, not an
independent R-solver convergence. The distinction is carried explicitly by the
caller via `evidence_type`.

Unit conventions (tested in tests/test_gauge_matrix.py):

    lattice   D     U/D          T/D          energy   quadratic   Omega/E
    bethe     1.0   uot/2        T_code       x/D=x    q/D^2=q     E/D=E
    square    2.0   uot/4        T_code/2     x/D      q/D^2       E/D

`R` overlaps and Z, D_occ, n are dimensionless (unchanged by D).
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass, field

import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from BHFM2.core import canonical_gauge as cg  # noqa: E402

# R_FLOOR mirrors BHFM2.core.reparam_R.R_FLOOR (the quasiparticle-overlap floor
# that keeps Z away from exactly 0 so the arrowhead inverse stays well posed).
# Redeclared here as a plain constant so this pure-numpy/scipy module has no
# dependency on the numba-heavy solver stack (login-node / bare-pytest safe).
R_FLOOR = 1e-5
MH = 2                       # single-site h-sector budget everywhere in this study
N_MODES = MH + 1             # = 3 canonical modes (do NOT relabel as Mh=3)
Z_SINGULAR = 1e-8            # bare Z below this: R-map floor territory (Z=0 singular)

# Half-bandwidth D in code units, per lattice.
D_OF_LATTICE = {"bethe": 1.0, "square": 2.0}


# --------------------------------------------------------------------------
# unit conversions (by dimension)
# --------------------------------------------------------------------------
def u_over_d(uot: float, lattice: str) -> float:
    """Reduced interaction U/D. Bethe: uot/2 ; Square: uot/4."""
    if lattice == "bethe":
        return uot / 2.0
    if lattice == "square":
        return uot / 4.0
    raise ValueError(f"unknown lattice {lattice!r}")


def t_over_d(t_code: float, lattice: str) -> float:
    """Reduced temperature T/D. Bethe: T_code ; Square: T_code/2."""
    if lattice == "bethe":
        return float(t_code)
    if lattice == "square":
        return float(t_code) / 2.0
    raise ValueError(f"unknown lattice {lattice!r}")


def scale_energy(x, lattice: str):
    """Energy / pole position: x/D."""
    return np.asarray(x, float) / D_OF_LATTICE[lattice]


def scale_quadratic(q, lattice: str):
    """Quadratic weight / moment (sum V^2, sum W^2): q/D^2."""
    return np.asarray(q, float) / D_OF_LATTICE[lattice] ** 2


# --------------------------------------------------------------------------
# forward map of one h-sector, with full exactness diagnostics
# --------------------------------------------------------------------------
@dataclass
class HSectorCanonical:
    """Canonical (lambda, R) representation of one bare h-sector + diagnostics."""
    eta: np.ndarray            # (Mh,) input bare ghost levels (code units)
    W: np.ndarray              # (Mh,) input bare couplings (code units)
    ebar: float                # on-site level used for the arrowhead (0 at PH)
    lam: np.ndarray            # (Mh+1,) canonical eigenvalues, ascending
    R: np.ndarray              # (Mh+1,) d-overlaps, R>=0, sum R^2 = 1
    qp_index: int              # index of the lambda~=0 (Fermi) quasiparticle mode
    Z_fermi: float             # R[qp]^2 (Fermi-level residue = pole-sum Z)
    # exactness diagnostics
    norm_error: float          # |sum R^2 - 1|
    closure_error: float       # |sum lam R^2 - ebar|
    roundtrip_error: float     # max|inverse(lam,R) - (eta,W)| (nan if singular)
    interlacing_error: float   # max interlacing violation of eta among lam
    floor_limited: bool        # any R at/under R_FLOOR or Z < Z_SINGULAR

    def as_dict(self, lattice: str | None = None) -> dict:
        """Flat dict of arrays (code units) plus reduced (/D) energy arrays."""
        d = dict(
            eta=_arr(self.eta), W=_arr(self.W), ebar=float(self.ebar),
            lam=_arr(self.lam), R=_arr(self.R), qp_index=int(self.qp_index),
            Z_fermi=float(self.Z_fermi),
            norm_error=float(self.norm_error),
            closure_error=float(self.closure_error),
            roundtrip_error=_nan(self.roundtrip_error),
            interlacing_error=float(self.interlacing_error),
            floor_limited=bool(self.floor_limited),
        )
        if lattice is not None:
            d["eta_over_D"] = _arr(scale_energy(self.eta, lattice))
            d["W_over_D"] = _arr(scale_energy(self.W, lattice))
            d["lam_over_D"] = _arr(scale_energy(self.lam, lattice))
        return d


def forward_hsector(eta, W, ebar: float = 0.0) -> HSectorCanonical:
    """(eta[Mh], W[Mh], ebar) -> canonical (lambda, R) with exactness diagnostics.

    Deterministic: an eigendecomposition of the arrowhead h_dh (forward) plus an
    arrowhead inverse (round-trip check). No optimization.
    """
    eta = np.asarray(eta, float).ravel()
    W = np.asarray(W, float).ravel()
    lam, R = cg.forward(ebar, eta, W)              # ascending lam, R>=0, sum R^2=1
    R2 = R ** 2
    qp = int(np.argmin(np.abs(lam)))               # Fermi (lambda~0) quasiparticle
    Z_fermi = float(R[qp] ** 2)

    norm_error = float(abs(np.sum(R2) - 1.0))
    closure_error = float(abs(np.sum(lam * R2) - ebar))

    # Round-trip: reconstruct (eta, W) from (lam, R) and compare. The arrowhead
    # inverse is singular when a mode is dark (R->0) or the spectrum degenerates
    # (Z->0, the Mott boundary) -- exactly the boundaries where the inverse
    # solver chart is floor-limited. The FORWARD (lam, R) is always exact; it is
    # the inverse chart that fails there.
    try:
        _, eta_bk, W_bk = cg.inverse(lam, R)
        # inverse returns ascending-interval order; compare against sorted |eta|.
        roundtrip_error = float(max(
            np.max(np.abs(np.sort(eta_bk) - np.sort(eta))),
            np.max(np.abs(np.sort(W_bk) - np.sort(np.abs(W)))),
        ))
    except Exception:
        roundtrip_error = float("nan")

    # Interlacing: each eta must lie strictly inside a distinct (lam_g, lam_{g+1})
    # open interval (the zeros of phi interlace its poles). Measure the worst
    # excursion of a sorted eta outside its bracketing lambda interval.
    interlacing_error = _interlacing_error(lam, eta)

    # The inverse chart is floor-limited at the Z=0 / dark-ghost / degenerate
    # boundaries: bare Z below the singular floor, any overlap at/under R_FLOOR,
    # OR a failed inverse round-trip (rule 5). A failed round-trip therefore can
    # never masquerade as an ordinary interior R-native solution.
    floor_limited = bool(
        Z_fermi < Z_SINGULAR
        or np.any(R <= R_FLOOR * (1.0 + 1e-9))
        or not np.isfinite(roundtrip_error))

    return HSectorCanonical(
        eta=eta, W=W, ebar=float(ebar), lam=lam, R=R, qp_index=qp,
        Z_fermi=Z_fermi, norm_error=norm_error, closure_error=closure_error,
        roundtrip_error=roundtrip_error, interlacing_error=interlacing_error,
        floor_limited=floor_limited,
    )


def _interlacing_error(lam, eta) -> float:
    """Worst violation of the eta-in-(lam_g,lam_{g+1}) interlacing, 0 if clean."""
    lam_s = np.sort(np.asarray(lam, float).ravel())
    eta_s = np.sort(np.asarray(eta, float).ravel())
    if eta_s.size != lam_s.size - 1:
        return float("nan")
    worst = 0.0
    for a, e in enumerate(eta_s):
        lo, hi = lam_s[a], lam_s[a + 1]
        below = lo - e            # >0 if eta left of the interval
        above = e - hi            # >0 if eta right of the interval
        worst = max(worst, below, above, 0.0)
    return float(worst)


# --------------------------------------------------------------------------
# symmetric reduced (lambda, Rf) coordinate of a PH h-sector
# --------------------------------------------------------------------------
def reduced_lambda_Rf(hs: HSectorCanonical) -> tuple[float, float]:
    """Collapse a PH-symmetric canonical h-sector to its scalar (lambda, Rf).

    Mirror of symmetric_continuation_R.seed_R_from_bare5's QP convention: the
    ghosts sit at +/-lambda with equal overlaps Rf; Z = R_qp^2 = 1 - 2 Rf^2.
    Returns (lambda, Rf) with lambda = mean|lam_ghost|, Rf = mean R_ghost.
    """
    lam, R = np.asarray(hs.lam, float), np.abs(np.asarray(hs.R, float))
    mask = np.ones(lam.size, dtype=bool)
    mask[hs.qp_index] = False
    lam_g, R_g = lam[mask], R[mask]
    return float(np.mean(np.abs(lam_g))), float(np.mean(R_g))


# --------------------------------------------------------------------------
# full root conversion: both h-sectors
# --------------------------------------------------------------------------
@dataclass
class CanonicalRoot:
    """Full canonical (R_converted_from_bare) representation of one bare root."""
    lattice: str
    lat_sector: HSectorCanonical      # lattice h-sector (eta, W)
    gw_sector: HSectorCanonical       # gateway h-sector (eta1, W1)
    Z_pole: float                     # reported pole-Z = gateway Z_fermi
    z_pole_gateway: float             # 1/(1+sum W1^2/eta1^2), the production Z

    def diagnostics(self) -> dict:
        """Worst-case exactness diagnostics across both sectors."""
        L, G = self.lat_sector, self.gw_sector
        rt = [x for x in (L.roundtrip_error, G.roundtrip_error) if np.isfinite(x)]
        return dict(
            n_modes=int(L.lam.size),
            norm_error=max(L.norm_error, G.norm_error),
            closure_error=max(L.closure_error, G.closure_error),
            roundtrip_error=(max(rt) if rt else float("nan")),
            interlacing_error=max(L.interlacing_error, G.interlacing_error),
            floor_limited=bool(L.floor_limited or G.floor_limited),
        )


def convert_root(eta_lat, W_lat, eta_gw, W_gw, lattice: str,
                 ebar: float = 0.0) -> CanonicalRoot:
    """Forward-convert one bare root (both h-sectors) to canonical coordinates.

    eta_lat/W_lat are the lattice h-sector; eta_gw/W_gw the gateway h-sector.
    The symmetric solver sets them equal, but both are converted and stored
    independently (the generic R implementation keeps them distinct).
    """
    L = forward_hsector(eta_lat, W_lat, ebar)
    G = forward_hsector(eta_gw, W_gw, ebar)
    # Production pole-Z uses the gateway self-energy poles (eta1, W1).
    eta1 = np.asarray(eta_gw, float).ravel()
    W1 = np.asarray(W_gw, float).ravel()
    if np.any(np.abs(eta1) <= 1e-12):
        z_pole_gw = 0.0
    else:
        z_pole_gw = 1.0 / (1.0 + float(np.sum(W1 ** 2 / eta1 ** 2)))
    return CanonicalRoot(lattice=lattice, lat_sector=L, gw_sector=G,
                         Z_pole=G.Z_fermi, z_pole_gateway=z_pole_gw)


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def _arr(a) -> list:
    return [float(x) for x in np.asarray(a, float).ravel()]


def _nan(x) -> float | None:
    x = float(x)
    return None if not np.isfinite(x) else x
