#!/usr/bin/env python3
"""Deterministic builder for the D09 ED tables (no ED run).

Reads the LLK-style DMFT-ED grid (results/runs/20260717_ed_llk/ed_llk_Nb*_cg.csv,
produced by scripts/dmft_ed_llk.py --grid) and writes, into deliverable 09:
  ed_raw_attempts.csv   every attempt (lossless; stalled retained)
  ed_accepted.csv       fixed_point_converged==1 only (excludes stalled)
Both carry the five separated flags + ground-state semantics. Idempotent.
"""
from __future__ import annotations

import csv
import glob
import os

_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SRC = os.path.join(_ROOT, "results/runs/20260717_ed_llk")
OUT = os.path.join(_ROOT, "results/deliverables/09_single_site_publication_validation")


def main():
    os.makedirs(OUT, exist_ok=True)
    raw = []
    for f in sorted(glob.glob(os.path.join(SRC, "ed_llk_Nb*_cg.csv"))):
        raw.extend(csv.DictReader(open(f)))
    if not raw:
        print("no ED grid found; run scripts/dmft_ed_llk.py --grid --Nb 1,3 first")
        return
    cols = list(raw[0].keys())
    acc = [r for r in raw if r.get("fixed_point_converged") == "1"]
    for name, rows in (("ed_raw_attempts.csv", raw), ("ed_accepted.csv", acc)):
        with open(os.path.join(OUT, name), "w", newline="") as fh:
            w = csv.DictWriter(fh, fieldnames=cols, extrasaction="ignore")
            w.writeheader(); w.writerows(rows)
    print(f"ed_raw_attempts.csv: {len(raw)} rows; ed_accepted.csv: {len(acc)} "
          f"(fixed_point_converged); excluded {len(raw) - len(acc)} stalled")
    import collections
    for nb in ("1", "3"):
        r = [x for x in raw if x["Nb"] == nb]
        a = [x for x in r if x.get("fixed_point_converged") == "1"]
        q = [x for x in r if x.get("accuracy_qualified") == "1"]
        print(f"  Nb={nb}: {len(r)} raw, {len(a)} accepted, {len(q)} accuracy_qualified")


if __name__ == "__main__":
    main()
