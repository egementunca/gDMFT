#!/usr/bin/env python3
"""LANDSCAPE MAP -- bare gauge vs physical R-gauge, single-impurity ghost solver.

De-blackboxing step 1. At ONE fixed point (U/t, T, Mg on the Bethe lattice) we
seed the SAME pure gateway objective from a spread of seeds and enumerate the
DISTINCT converged solutions in each gauge, with full diagnostics + a basin
label. The question: how many minima survive in the R-gauge, and are the dark /
runaway (W-railed insulator) basins gone, bounded, or merely relabeled?

Objective (PH half filling, exactly determined, matches the professor's convention):
  * gateway_plus_impfill_moments : local_h_occ + local_h_coh + g1_occ + g1_coh
    + fill_imp + moments. The diagnostic-only fill_lat (n_lat) row is DROPPED
    (CLAUDE.md: not minimized).
  * PH pinned : mu = U/2 and Sigma_inf = U/2 are HELD, not fitted / not
    feed-forward, so ebar = eps_d + Sigma_inf - mu = 0 (the prof's PH hard-coding).
  * n_moments = 3 -> 14 eqs = 14 params (delta = 0), Mg=3.

Gauges compared (identical objective, matched bound ceiling):
  * bare : fit {eta, W, eps1, V1, eta1, W1} directly (scipy TRF + 2-pt FD).
           W may rail high -> the "runaway" insulator (prof's V->0, eta->0, W->inf).
  * R    : fit the physical {lam, R} of the h-sectors (canonical_gauge), QP
           overlap closed by sum R^2 = 1 so Z = R_qp^2 in [0,1] is bounded BY
           CONSTRUCTION. Reconstructs (eta,W) at the pinned ebar=0 and evaluates
           the SAME objective.

Diagnostics per converged solution:
  resnorm, sumV2 = sum V1^2 (impurity g-bath weight), sumW2 = sum(W^2)+sum(W1^2)
  (h-sector self-energy weight), maxW, maxV, Z_pole = 1/(1+sum W1^2/eta1^2),
  Z_fermi (arrowhead residue), D (double occ), n_avg, n_lat,
  Omega = Omega_imp + Omega_lat - Omega_gw (the prof's free energy F).

Local ED only (Mg=3 impurity = 256-dim). Run under the py3.12 numba venv:
    .venv-numba/bin/python3 scripts/landscape_map.py
"""
from __future__ import annotations

import argparse
import csv
import json
import os
import sys
from dataclasses import replace

import numpy as np

_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _ROOT not in sys.path:
    sys.path.insert(0, _ROOT)

from scipy.optimize import least_squares  # noqa: E402

from BHFM2.core.solve_min import (  # noqa: E402
    ModelParamsMin, SParMin, CodecMin, imp1_obs, lat_obs,
    compute_omega_scheme, MODE_SINGLE_IMPURITY as SI,
)
from BHFM2.core import canonical_gauge as cg  # noqa: E402
from BHFM2.core import reparam_R as rr  # noqa: E402
from BHFM2.runners.run_bonding_systematic import (  # noqa: E402
    _grouped_residuals, _objective_vector,
)

MH = 2
N_MOMENTS = 3          # Mg=3, PH gateway_plus_impfill_moments -> 14 eq = 14 par
OBJECTIVE = "gateway_plus_impfill_moments"


# --------------------------------------------------------------------------
# PH objective (pinned Sigma_inf, ebar=0), both gauges
# --------------------------------------------------------------------------
def residual_ph(p, mp, Mg):
    """gateway_plus_impfill_moments residual with Sigma_inf pinned at U/2."""
    _, blocks, _ = _grouped_residuals(p, mp, MH, Mg, 0, SI, pin_sigma_inf=mp.U / 2.0)
    return _objective_vector(blocks, OBJECTIVE)


def to_bare_ph(pR, mp, Mg):
    """Reconstruct bare SParMin from physical R-params at the pinned PH point
    (ebar = eps_d + Sigma_inf - mu = 0 + U/2 - U/2 = 0)."""
    ebar = 0.0
    etaL, WL = rr.hsector_to_bare(pR.lamL_g, pR.RL_f, ebar)
    etaG, WG = rr.hsector_to_bare(pR.lamG_g, pR.RG_f, ebar)
    z0 = np.zeros(0)
    return SParMin(eta=etaL, W=WL, eta_b=z0, B_h=z0,
                   eps1=np.asarray(pR.eps1, float), V1=np.asarray(pR.V1, float),
                   eta1=etaG, W1=WG, eps2=z0, V2=z0, eta2=z0, W2=z0,
                   eta_b2=z0, B_h2=z0, eps_b=z0, B_g=z0, mu=float(pR.mu))


def seed_R_ph(p_bare, Mg, mu):
    """Map a bare seed into R-coords at ebar=0 (forward transform)."""
    lamL_g, RL_f = rr.hsector_from_bare(p_bare.eta, p_bare.W, 0.0)
    lamG_g, RG_f = rr.hsector_from_bare(p_bare.eta1, p_bare.W1, 0.0)
    return rr.SParR(lamL_g=lamL_g, RL_f=RL_f,
                    eps1=np.asarray(p_bare.eps1, float),
                    V1=np.asarray(p_bare.V1, float),
                    lamG_g=lamG_g, RG_f=RG_f, mu=float(mu))


# --------------------------------------------------------------------------
# bounds -- matched ceiling so bare and R get a fair shot at the runaway
# --------------------------------------------------------------------------
def bare_bounds(Mh, Mg, E=8.0, W_cap=10.0, V_cap=5.0):
    """Custom bare bounds allowing W to rail high (reproduce the runaway).
    mu is fixed (PH), so it is NOT a fit variable."""
    fields = [("eta", Mh, -E, E), ("W", Mh, 1e-8, W_cap),
              ("eps1", Mg, -E, E), ("V1", Mg, 1e-8, V_cap),
              ("eta1", Mh, -E, E), ("W1", Mh, 1e-8, W_cap)]
    lo, hi = [], []
    for _, n, l, h in fields:
        lo += [l] * n
        hi += [h] * n
    return np.array(lo), np.array(hi)


# --------------------------------------------------------------------------
# diagnostics
# --------------------------------------------------------------------------
def z_pole_gateway(p):
    """Production pole-sum Z from the gateway self-energy poles (eta1, W1):
    Z = 1/(1 + sum W1^2/eta1^2)."""
    eta1 = np.asarray(p.eta1, float).ravel()
    W1 = np.asarray(p.W1, float).ravel()
    safe = np.abs(eta1) > 1e-12
    if np.any(~safe):
        return 0.0  # a pole sitting on the Fermi level -> Z collapses
    s = float(np.sum((W1 ** 2) / (eta1 ** 2)))
    return 1.0 / (1.0 + s)


def diagnose(p, mp, Mg):
    """Full diagnostic dict for a bare-gauge SParMin at the pinned PH point."""
    Sigma_inf = mp.U / 2.0
    mp_f = replace(mp, Sigma_inf=Sigma_inf)
    imp1 = imp1_obs(p, mp_f, Mg)
    n_d = float(imp1["dens"])
    D = float(imp1["double_occ"])
    lat = lat_obs(p, mp_f, MH, 0, mode=SI)
    resnorm = float(np.linalg.norm(residual_ph(p, mp, Mg)))

    V1 = np.asarray(p.V1, float).ravel()
    W = np.asarray(p.W, float).ravel()
    W1 = np.asarray(p.W1, float).ravel()
    sumV2 = float(np.sum(V1 ** 2))
    sumW2 = float(np.sum(W ** 2) + np.sum(W1 ** 2))
    maxV = float(np.max(np.abs(V1))) if V1.size else 0.0
    maxW = float(max(np.max(np.abs(W)) if W.size else 0.0,
                     np.max(np.abs(W1)) if W1.size else 0.0))

    z_pole = z_pole_gateway(p)
    ebar = 0.0
    try:
        lamG, RG = cg.forward(ebar, p.eta1, p.W1)
        z_fermi = float(cg.fermi_Z(lamG, RG)[0])
    except Exception:
        z_fermi = float("nan")
    try:
        om = compute_omega_scheme(p, mp_f, MH, Mg, 0, mode=SI)
        Omega = float(om["Omega_total"])
    except Exception:
        Omega = float("nan")

    return dict(
        resnorm=resnorm, sumV2=sumV2, sumW2=sumW2, maxV=maxV, maxW=maxW,
        Z_pole=z_pole, Z_fermi=z_fermi, D=D, n_avg=n_d, n_lat=float(lat["dens"]),
        Omega=Omega, mu=float(p.mu),
        eta=_join(p.eta), W=_join(p.W), eps1=_join(p.eps1), V1=_join(p.V1),
        eta1=_join(p.eta1), W1=_join(p.W1),
    )


def basin_label(d):
    """Classify a converged solution into a physical basin family.

    dark        : impurity g-bath decoupled (maxV tiny) -> impurity is an atom.
    runaway_ins : h-sector coupling railed high AND Z collapsed = the prof's
                  V->0/eta->0/W->inf Mott insulator, unbounded in the bare gauge.
    insulator   : Z collapsed but W not railed (bounded insulator).
    metal       : coherent quasiparticle survives (Z_pole appreciable).

    Z_pole is the robust classifier; Z_fermi agrees at PH (ebar=0) except when a
    ghost pole collapses onto the Fermi level, so we key off Z_pole.
    """
    if d["maxV"] < 0.05:
        return "dark"
    if d["maxW"] > 4.0 and d["Z_pole"] < 1e-2:
        return "runaway_ins"
    if d["Z_pole"] > 0.02:
        return "metal"
    if d["Z_pole"] < 1e-2:
        return "insulator"
    return "other"


def _join(a):
    return ";".join(f"{x:.6g}" for x in np.asarray(a, float).ravel())


# --------------------------------------------------------------------------
# seeds
# --------------------------------------------------------------------------
def make_seeds(U, Mg, rng, n_random=10):
    """A spread of bare-gauge SParMin seeds designed to land in different basins,
    plus random seeds to catch anything else."""
    mu0 = U / 2.0
    z3 = np.zeros(0)

    def spar(eta, W, eps1, V1, eta1, W1):
        return SParMin(eta=np.array(eta, float), W=np.array(W, float),
                       eta_b=z3, B_h=z3,
                       eps1=np.array(eps1, float), V1=np.array(V1, float),
                       eta1=np.array(eta1, float), W1=np.array(W1, float),
                       eps2=z3, V2=z3, eta2=z3, W2=z3, eta_b2=z3, B_h2=z3,
                       eps_b=z3, B_g=z3, mu=float(mu0))

    seeds = {}
    seeds["metal"] = spar([-0.7, 0.7], [0.6, 0.6],
                          [-1.5, 0.0, 1.5], [0.5, 0.5, 0.5],
                          [-0.7, 0.7], [0.6, 0.6])
    seeds["dark_full"] = spar([-0.7, 0.7], [0.6, 0.6],
                              [-1.5, 0.0, 1.5], [1e-4, 1e-4, 1e-4],
                              [-0.7, 0.7], [0.6, 0.6])
    seeds["dark_mg1"] = spar([-0.7, 0.7], [0.6, 0.6],
                             [0.0, 8.0, -8.0], [0.4, 1e-6, 1e-6],
                             [-0.7, 0.7], [0.6, 0.6])
    seeds["runaway"] = spar([0.02, -0.02], [8.0, 8.0],
                            [-1.5, 0.0, 1.5], [1e-3, 1e-3, 1e-3],
                            [0.02, -0.02], [8.0, 8.0])
    for i in range(n_random):
        eta = np.sort(rng.uniform(-2, 2, MH)) + np.array([-0.05, 0.05])[:MH]
        eta1 = np.sort(rng.uniform(-2, 2, MH)) + np.array([-0.05, 0.05])[:MH]
        seeds[f"rand{i}"] = spar(
            eta, rng.uniform(0.1, 3.0, MH),
            rng.uniform(-3, 3, Mg), rng.uniform(0.05, 2.0, Mg),
            eta1, rng.uniform(0.1, 3.0, MH))
    return seeds


# --------------------------------------------------------------------------
# solves
# --------------------------------------------------------------------------
def solve_bare(mp, Mg, p_init, lo, hi, fixed_mu, max_nfev=500):
    codec = CodecMin(MH, Mg, 0, mode=SI, fixed_mu=fixed_mu)
    x0 = np.clip(codec.pack(p_init), lo + 1e-9, hi - 1e-9)

    def fn(x):
        return residual_ph(codec.unpack(x), mp, Mg)

    sol = least_squares(fn, x0, method="trf", bounds=(lo, hi),
                        ftol=1e-13, xtol=1e-13, max_nfev=max_nfev)
    return codec.unpack(sol.x), int(sol.nfev)


def solve_R(mp, Mg, p_init, fixed_mu, max_nfev=1000):
    """R-gauge solve. Fits the physical {lam,R} with sum R^2 = 1, so Z = R_qp^2
    in [0,1] is bounded BY CONSTRUCTION -- the property under test.

    Convergence uses the analytic-Jacobian ``solve_min_R`` (the R-gauge FD path
    is corrupted by the nonlinear inverse-map reconstruction and stalls). Its
    analytic Jacobian is tied to core ``residual_min`` (feed-forward Sigma_inf),
    whose PH fixed points are IDENTICAL to the pinned objective's (verified:
    pinned||r|| == core||r|| at every fixed point). We converge with it, then
    gate/diagnose with the pinned ``residual_ph`` -- fair and consistent."""
    mp_core = replace(mp, n_moments=4)  # core residual_min square-ish at fixed_mu
    pR = rr.seed_R_from_bare(p_init, mp_core, MH, Mg)
    res = rr.solve_min_R(mp_core, MH, Mg, 1.0, pR_init=pR, fixed_mu=fixed_mu,
                         max_nfev=max_nfev, jac="analytic", mode=SI)
    return res["p_bare"], int(res.get("nfev", 0))


# --------------------------------------------------------------------------
# dedup
# --------------------------------------------------------------------------
def signature(d):
    def slog(x):
        return round(np.log10(abs(x) + 1e-30), 1)
    return (round(d["Z_pole"], 3), slog(d["sumV2"]), slog(d["sumW2"]),
            round(d["Omega"], 3) if np.isfinite(d["Omega"]) else None)


def dedup(records, res_gate=1e-4):
    conv = [r for r in records if r["resnorm"] <= res_gate]
    fams = {}
    for r in conv:
        s = signature(r)
        if s not in fams or r["resnorm"] < fams[s]["resnorm"]:
            fams[s] = r
    return sorted(fams.values(), key=lambda r: (r["basin"], -r["Z_pole"]))


# --------------------------------------------------------------------------
# main
# --------------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--uot", type=float, default=8.0, help="U/t")
    ap.add_argument("--T", type=float, default=0.025)
    ap.add_argument("--Mg", type=int, default=3)
    ap.add_argument("--lattice", default="bethe")
    ap.add_argument("--t", type=float, default=0.5)
    ap.add_argument("--Nk", type=int, default=96)
    ap.add_argument("--n-random", type=int, default=10)
    ap.add_argument("--seed", type=int, default=1234)
    ap.add_argument("--res-gate", type=float, default=1e-4)
    ap.add_argument("--max-nfev", type=int, default=600)
    ap.add_argument("--out", default=os.path.join(
        _ROOT, "results/runs/20260707_r_gauge_deblackbox/landscape_U{uot}_T{T}_Mg{Mg}.csv"))
    args = ap.parse_args()

    U = args.uot * args.t
    fixed_mu = U / 2.0
    beta = 1.0 / args.T
    mp = ModelParamsMin(t=args.t, eps_d=0.0, U=U, z=4.0, filling_target=1.0,
                        beta=beta, Nk=args.Nk, lattice=args.lattice,
                        n_moments=N_MOMENTS, Sigma_inf=U / 2.0)
    lo, hi = bare_bounds(MH, args.Mg)
    rng = np.random.default_rng(args.seed)
    seeds = make_seeds(U, args.Mg, rng, n_random=args.n_random)

    print(f"=== LANDSCAPE  {args.lattice} U/t={args.uot} (U={U}, U/D={U/(2*args.t):.3g}) "
          f"T={args.T} Mg={args.Mg} Mh={MH} obj={OBJECTIVE} n_moments={N_MOMENTS} "
          f"PH-pinned(mu=Sigma_inf=U/2) ===")
    print(f"    {len(seeds)} seeds x {{bare, R}}\n")

    records = []
    for name, p0 in seeds.items():
        for gauge in ("bare", "R"):
            try:
                if gauge == "bare":
                    p_sol, nfev = solve_bare(mp, args.Mg, p0, lo, hi, fixed_mu, args.max_nfev)
                else:
                    p_sol, nfev = solve_R(mp, args.Mg, p0, fixed_mu, args.max_nfev)
                d = diagnose(p_sol, mp, args.Mg)
                d.update(seed=name, gauge=gauge, nfev=int(nfev))
                d["basin"] = basin_label(d)
                records.append(d)
                print(f"  [{gauge:4s} {name:9s}] ||r||={d['resnorm']:.1e} "
                      f"Z_p={d['Z_pole']:.4f} Z_f={d['Z_fermi']:.4f} D={d['D']:.4f} "
                      f"sumV2={d['sumV2']:.3g} sumW2={d['sumW2']:.3g} maxW={d['maxW']:.2g} "
                      f"n_lat={d['n_lat']:.3f} Om={d['Omega']:.4f} -> {d['basin']}", flush=True)
            except Exception as exc:
                print(f"  [{gauge:4s} {name:9s}] ERR {type(exc).__name__}: {exc}", flush=True)

    out = args.out.format(uot=args.uot, T=args.T, Mg=args.Mg)
    os.makedirs(os.path.dirname(out), exist_ok=True)
    cols = ["seed", "gauge", "basin", "resnorm", "Z_pole", "Z_fermi", "D",
            "sumV2", "sumW2", "maxV", "maxW", "n_avg", "n_lat", "Omega", "mu",
            "nfev", "eta", "W", "eps1", "V1", "eta1", "W1"]
    with open(out, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in records:
            w.writerow({k: r.get(k, "") for k in cols})
    print(f"\nWrote {len(records)} raw records -> {out}")

    print(f"\n=== DISTINCT converged families (resnorm <= {args.res_gate:g}) ===")
    summary = {}
    for gauge in ("bare", "R"):
        recs = [r for r in records if r["gauge"] == gauge]
        fams = dedup(recs, res_gate=args.res_gate)
        summary[gauge] = fams
        print(f"\n  --- {gauge} : {len(fams)} distinct minima "
              f"({sum(1 for r in recs if r['resnorm']<=args.res_gate)}/{len(recs)} seeds converged) ---")
        print(f"    {'basin':12s} {'||r||':>9s} {'Z_pole':>8s} {'D':>7s} "
              f"{'sumV2':>9s} {'sumW2':>9s} {'Omega':>9s}  from")
        for r in fams:
            print(f"    {r['basin']:12s} {r['resnorm']:9.1e} {r['Z_pole']:8.4f} "
                  f"{r['D']:7.4f} {r['sumV2']:9.3g} {r['sumW2']:9.3g} "
                  f"{r['Omega']:9.4f}  {r['seed']}")

    print("\n=== free-energy selection (lowest Omega among non-artifact families) ===")
    for gauge in ("bare", "R"):
        phys = [r for r in summary[gauge] if r["basin"] in ("metal", "insulator")]
        if phys:
            best = min(phys, key=lambda r: r["Omega"])
            print(f"  {gauge:4s}: physical = {best['basin']} "
                  f"Z_pole={best['Z_pole']:.4f} Omega={best['Omega']:.4f}")
        else:
            print(f"  {gauge:4s}: no non-artifact family converged")

    meta = dict(uot=args.uot, U=U, U_over_D=U / (2 * args.t), T=args.T,
                Mg=args.Mg, Mh=MH, lattice=args.lattice, objective=OBJECTIVE,
                n_moments=N_MOMENTS, ph_pinned=True, res_gate=args.res_gate,
                n_distinct={g: len(summary[g]) for g in summary})
    with open(out.replace(".csv", "_meta.json"), "w") as f:
        json.dump(meta, f, indent=2)


if __name__ == "__main__":
    main()
